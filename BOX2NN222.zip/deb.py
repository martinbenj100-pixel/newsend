#!/usr/bin/env python3
"""CHECKV2 validation-only runner.

Ce script valide les adresses de liste.txt avec les comptes de imap.txt et
enregistre les résultats dans good.txt et bad.txt.

Il n'appelle aucun transport d'envoi final. Le moteur CHECKV2 envoie toutefois
une sonde minimale par SMTP pour permettre la détection des NDR/bounces.
Le fichier checkv2.py doit être placé dans le même dossier que ce script.

Format de imap.txt :
    ovh|adresse@example.com|mot_de_passe
    homepl|adresse@example.com|mot_de_passe

Utilisation :
    python deb.py
    python deb.py --initial-wait 30 --batch-size 1
"""

from __future__ import annotations

import argparse
import os
import signal
import sys
import threading
from pathlib import Path

try:
    from checkv2 import run_checkv2
except ImportError as error:
    raise SystemExit(
        "Impossible de charger checkv2.py. "
        "Placez checkv2.py dans le même dossier que deb.py."
    ) from error


BASE_DIR = Path(__file__).resolve().parent
STOP_REQUESTED = threading.Event()


def _stop_handler(_signum: int, _frame: object) -> None:
    if not STOP_REQUESTED.is_set():
        print("\n[CHECKV2] Arrêt demandé. Le contrôle en cours se termine...", flush=True)
        STOP_REQUESTED.set()


def _read_recipient_list(path: Path) -> list[str]:
    if not path.exists():
        raise RuntimeError(f"Fichier introuvable : {path}")

    recipients: list[str] = []
    seen: set[str] = set()
    for line_number, raw_line in enumerate(
        path.read_text(encoding="utf-8").splitlines(),
        start=1,
    ):
        address = raw_line.strip()
        if not address or address.startswith("#"):
            continue
        if "@" not in address:
            print(
                f"[CHECKV2] Ligne {line_number} ignorée : adresse invalide.",
                flush=True,
            )
            continue
        normalized = address.casefold()
        if normalized not in seen:
            recipients.append(address)
            seen.add(normalized)
    if not recipients:
        raise RuntimeError(f"Aucune adresse exploitable dans {path}")
    return recipients


def _count_account_lines(path: Path) -> int:
    if not path.exists():
        raise RuntimeError(f"Fichier introuvable : {path}")
    return sum(
        1
        for raw_line in path.read_text(encoding="utf-8").splitlines()
        if raw_line.strip() and not raw_line.lstrip().startswith("#")
    )


def _log(line: str) -> None:
    print(line, flush=True)


def main() -> int:
    parser = argparse.ArgumentParser(
        description="CHECKV2 : valide les adresses et met à jour good.txt en direct."
    )
    parser.add_argument(
        "--initial-wait",
        type=int,
        default=60,
        help="attente après la sonde avant de conclure (secondes)",
    )
    parser.add_argument(
        "--min-adaptive-wait",
        type=int,
        default=10,
        help="attente minimale après un bounce (secondes)",
    )
    parser.add_argument(
        "--poll-interval",
        type=int,
        default=3,
        help="intervalle de lecture IMAP (secondes)",
    )
    parser.add_argument(
        "--batch-size",
        type=int,
        default=1,
        help="nombre de candidats avant la seconde vérification",
    )
    parser.add_argument(
        "--batch-wait",
        type=int,
        default=1,
        help="attente avant la seconde vérification du lot (secondes)",
    )
    parser.add_argument(
        "--max-concurrent-accounts",
        type=int,
        default=None,
        help="nombre maximal de comptes en parallèle (par défaut : tous les comptes)",
    )
    parser.add_argument(
        "--recent-ndr-limit",
        type=int,
        default=10,
        help="nombre de NDR récents à analyser par boîte",
    )
    parser.add_argument(
        "--mailbox-scope",
        choices=("INBOX", "ALL"),
        default="INBOX",
        help="dossiers IMAP inspectés pendant le contrôle",
    )
    args = parser.parse_args()

    os.chdir(BASE_DIR)
    signal.signal(signal.SIGINT, _stop_handler)
    if hasattr(signal, "SIGTERM"):
        signal.signal(signal.SIGTERM, _stop_handler)

    try:
        recipients = _read_recipient_list(BASE_DIR / "liste.txt")
        configured_accounts = _count_account_lines(BASE_DIR / "imap.txt")
        max_concurrent_accounts = (
            args.max_concurrent_accounts
            if args.max_concurrent_accounts is not None
            else max(1, configured_accounts)
        )
        config = {
            "CHECKV2_DRY_RUN": True,
            "CHECKV2_INITIAL_WAIT": max(1, args.initial_wait),
            "CHECKV2_MIN_ADAPTIVE_WAIT": max(1, args.min_adaptive_wait),
            "CHECKV2_POLL_INTERVAL": max(1, args.poll_interval),
            "CHECKV2_BATCH_SIZE": max(1, args.batch_size),
            "CHECKV2_BATCH_WAIT": max(1, args.batch_wait),
            "CHECKV2_MAX_CONCURRENT_ACCOUNTS": max(1, max_concurrent_accounts),
            "CHECKV2_RECENT_NDR_LIMIT": max(1, args.recent_ndr_limit),
            "CHECKV2_MAILBOX_SCOPE": args.mailbox_scope,
            "GOOD_FILE": str(BASE_DIR / "good.txt"),
            "BAD_FILE": str(BASE_DIR / "bad.txt"),
        }

        print(
            f"[CHECKV2] {len(recipients)} adresse(s) à contrôler.",
            flush=True,
        )
        print(
            "[CHECKV2] Mode validation seule : aucun envoi final.",
            flush=True,
        )
        print(
            f"[CHECKV2] Comptes en parallèle : {max(1, max_concurrent_accounts)}.",
            flush=True,
        )
        stats = run_checkv2(
            recipients,
            config,
            lambda _recipient: (
                True,
                "enregistrement uniquement — aucun envoi final",
            ),
            _log,
            STOP_REQUESTED.is_set,
        )
        print(
            "[CHECKV2] Résultat : "
            f"{stats['valid']} bon(s), {stats['bounce']} bounce(s), "
            f"{stats['error']} erreur(s).",
            flush=True,
        )
        return 0
    except KeyboardInterrupt:
        _stop_handler(signal.SIGINT, None)
        return 130
    except RuntimeError as error:
        print(f"[CHECKV2] Erreur : {error}", file=sys.stderr, flush=True)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())