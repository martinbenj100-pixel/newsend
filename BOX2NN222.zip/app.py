#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# app.py — Interface web pour YODA SEND MIX SMTP V4.5

from flask import Flask, render_template, request, jsonify, Response, session, redirect, url_for, send_from_directory, send_file
from functools import wraps
from werkzeug.utils import secure_filename
import subprocess
import threading
import queue
import json
import os
import sys
import time
import collections
import tempfile
import urllib.request
import smtplib
from smtp_connection import establish_tls, open_smtp
from resend_client import ResendError, send_email as send_resend_email
from sendbyte_client import SendByteError, send_email as send_sendbyte_email
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.utils import formataddr, formatdate, make_msgid, parseaddr
from html import escape as html_escape
from inline_logo import replace_logo_image_source

app = Flask(__name__)
IS_PRODUCTION = (
    os.environ.get('APP_ENV', '').strip().lower() == 'production'
    or os.environ.get('NODE_ENV', '').strip().lower() == 'production'
)
SESSION_SECRET = os.environ.get('SESSION_SECRET', '').strip()
if IS_PRODUCTION and not SESSION_SECRET:
    raise RuntimeError('SESSION_SECRET doit être configuré dans les Secrets Replit en production.')
app.secret_key = SESSION_SECRET or 'yoda-default-secret-change-me'

# ─── Auth ─────────────────────────────────────────────────────────────────

PANEL_PASSWORD = os.environ.get('PANEL_PASSWORD', '')

def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not PANEL_PASSWORD:
            if IS_PRODUCTION:
                if request.path.startswith('/api/'):
                    return jsonify({
                        'success': False,
                        'error': 'PANEL_PASSWORD doit être configuré dans les Secrets Replit.'
                    }), 503
                return render_template(
                    'login.html',
                    error='PANEL_PASSWORD doit être configuré dans les Secrets Replit.'
                ), 503
            return f(*args, **kwargs)          # pas de mot de passe défini → accès libre
        if not session.get('authenticated'):
            if request.path.startswith('/api/'):
                return jsonify({'success': False, 'error': 'Non authentifié'}), 401
            return redirect(url_for('login_page'))
        return f(*args, **kwargs)
    return decorated

@app.route('/login', methods=['GET', 'POST'])
def login_page():
    if not PANEL_PASSWORD:
        if IS_PRODUCTION:
            return render_template(
                'login.html',
                error='PANEL_PASSWORD doit être configuré dans les Secrets Replit.'
            ), 503
        return redirect('/')
    error = None
    if request.method == 'POST':
        pwd = request.form.get('password', '')
        if pwd == PANEL_PASSWORD:
            session['authenticated'] = True
            return redirect('/')
        error = 'Mot de passe incorrect'
    return render_template('login.html', error=error)

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login_page'))

@app.route('/healthz')
def healthz():
    """Endpoint public et stable pour la sonde de démarrage Replit."""
    return jsonify({'status': 'ok'})

# ─── Trois slots indépendants : SEND, CHECKV2 et REINFORCE ────────────────

class ProcessSlot:
    def __init__(self, name):
        self.name       = name
        self.process    = None
        self.lock       = threading.Lock()
        self.buffer     = collections.deque(maxlen=3000)
        self.subscribers     = []
        self.subscribers_lock = threading.Lock()

    def broadcast(self, line):
        self.buffer.append(line)
        with self.subscribers_lock:
            dead = []
            for q in self.subscribers:
                try:
                    q.put_nowait(line)
                except Exception:
                    dead.append(q)
            for q in dead:
                self.subscribers.remove(q)

    def is_running(self):
        with self.lock:
            return self.process is not None and self.process.poll() is None

    def stream_generator(self):
        q = queue.Queue(maxsize=5000)
        history = list(self.buffer)
        with self.subscribers_lock:
            self.subscribers.append(q)
        for line in history:
            yield f"data: {json.dumps(line)}\n\n"
        try:
            while True:
                try:
                    line = q.get(timeout=25)
                    yield f"data: {json.dumps(line)}\n\n"
                except queue.Empty:
                    yield 'data: ""\n\n'   # keepalive
        finally:
            with self.subscribers_lock:
                if q in self.subscribers:
                    self.subscribers.remove(q)

SLOTS = {
    'send':      ProcessSlot('send'),
    'checkv2':   ProcessSlot('checkv2'),
    'reinforce': ProcessSlot('reinforce'),
}

APP_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(APP_DIR)
CONFIG_FILE = os.path.join(APP_DIR, 'config.txt')
CONTROL_FILE = os.path.join(APP_DIR, 'control.json')
CONFIG_LOCK = threading.RLock()
temp_configs = []   # fichiers temporaires à nettoyer après coup
LOGO_UPLOAD_DIR = os.path.join(APP_DIR, 'uploads')
ALLOWED_LOGO_EXTENSIONS = {'.png', '.jpg', '.jpeg', '.gif', '.webp'}
MAX_LOGO_BYTES = 5 * 1024 * 1024

# ─── Config helper ────────────────────────────────────────────────────────

def _read_config_content() -> str:
    """Lit une copie complète et cohérente de config.txt."""
    with CONFIG_LOCK:
        try:
            with open(CONFIG_FILE, 'r', encoding='utf-8') as config_file:
                return config_file.read()
        except FileNotFoundError:
            return ''


def _read_config_values() -> dict[str, str]:
    """Retourne les paramètres de configuration depuis une seule lecture."""
    values = {}
    for line in _read_config_content().splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith('#') or '=' not in stripped:
            continue
        key, value = stripped.split('=', 1)
        values[key.strip()] = value.strip()
    return values


def _write_config_content(content: str) -> None:
    """Écrit config.txt de manière atomique pour ne jamais exposer un fichier tronqué."""
    with CONFIG_LOCK:
        fd, temporary_path = tempfile.mkstemp(
            prefix='.config-', suffix='.tmp', dir=os.path.dirname(CONFIG_FILE), text=True,
        )
        try:
            with os.fdopen(fd, 'w', encoding='utf-8') as config_file:
                config_file.write(content)
                config_file.flush()
                os.fsync(config_file.fileno())
            os.replace(temporary_path, CONFIG_FILE)
        except Exception:
            try:
                os.unlink(temporary_path)
            except OSError:
                pass
            raise


def _validate_config_updates(updates: dict) -> dict[str, str]:
    """Valide les mises à jour avant de les insérer dans le format KEY=value."""
    validated = {}
    for raw_key, raw_value in updates.items():
        key = str(raw_key).strip()
        if not key or not key.replace('_', '').isalnum():
            raise ValueError('Clé de configuration invalide.')
        value = str(raw_value).strip()
        if '\n' in value or '\r' in value:
            raise ValueError(f'La valeur de « {key} » ne doit pas contenir de saut de ligne.')
        validated[key] = value
    return validated


def _visible_from_header(config_values: dict[str, str], envelope_sender: str) -> str:
    """Construit le From affiché sans changer l'expéditeur d'enveloppe SMTP."""
    configured_from = config_values.get('VISIBLE_FROM', '').strip()
    if configured_from:
        configured_name, visible_email = parseaddr(configured_from)
        if not visible_email:
            visible_email = configured_from
        if '@' not in visible_email:
            raise ValueError('VISIBLE_FROM doit contenir une adresse email valide.')
        sender_name = configured_name or config_values.get('SENDER_NAME', '').strip()
        return formataddr((sender_name, visible_email)) if sender_name else visible_email

    sender_name = config_values.get('SENDER_NAME', '').strip() or 'YODA Mailer'
    return formataddr((sender_name, envelope_sender))


def _update_config_values(updates: dict) -> dict[str, str]:
    """Met à jour plusieurs clés en une seule écriture atomique."""
    validated = _validate_config_updates(updates)
    if not validated:
        raise ValueError('Aucune valeur de configuration fournie.')

    with CONFIG_LOCK:
        existing_content = _read_config_content()
        lines = []
        replaced = set()

        for line in existing_content.splitlines():
            stripped = line.strip()
            if stripped and not stripped.startswith('#') and '=' in stripped:
                key = stripped.split('=', 1)[0].strip()
                if key in validated:
                    if key not in replaced:
                        lines.append(f'{key}={validated[key]}')
                        replaced.add(key)
                    continue
            lines.append(line)

        for key, value in validated.items():
            if key not in replaced:
                lines.append(f'{key}={value}')

        _write_config_content('\n'.join(lines) + '\n')
    return validated


def make_temp_config(overrides: dict) -> str:
    """Lit config.txt et crée une copie temporaire portable."""
    base = _read_config_content()

    lines = []
    keys_done = set()
    for line in base.splitlines():
        stripped = line.strip()
        if stripped and not stripped.startswith('#') and '=' in stripped:
            key = stripped.split('=', 1)[0].strip()
            if key in overrides:
                lines.append(f"{key}={overrides[key]}")
                keys_done.add(key)
                continue
        lines.append(line)
    for key, val in overrides.items():
        if key not in keys_done:
            lines.append(f"{key}={val}")

    tmp = tempfile.NamedTemporaryFile(
        mode='w', suffix='.txt', prefix='yoda_cfg_',
        delete=False, encoding='utf-8', dir=tempfile.gettempdir()
    )
    tmp.write('\n'.join(lines) + '\n')
    tmp.close()
    return tmp.name


def _checkv2_account_lines() -> tuple[list[str], str]:
    """Charge les comptes CHECKV2 uniquement depuis imap.txt."""
    def source_lines(content: str) -> list[str]:
        return [
            line.strip()
            for line in content.splitlines()
            if line.strip() and not line.lstrip().startswith('#')
        ]

    try:
        with open(os.path.join(APP_DIR, 'imap.txt'), 'r', encoding='utf-8') as accounts_file:
            return source_lines(accounts_file.read()), 'file'
    except OSError:
        return [], 'missing'


# ─── Thread lecteur stdout ────────────────────────────────────────────────

def _reader_thread(slot: ProcessSlot, proc, tmp_cfg=None):
    try:
        for raw in iter(proc.stdout.readline, b''):
            line = raw.decode('utf-8', errors='replace')
            slot.broadcast(line)
            # CHECKV2 publie les validations et les envois Resend dans le
            # terminal ENVOI pour conserver le flux d'expédition au même endroit.
            if line.startswith('[CHECKV2→ENVOI]'):
                SLOTS['send'].broadcast(
                    '\033[36m' + line.replace('[CHECKV2→ENVOI] ', '', 1) + '\033[0m'
                )
    except Exception:
        pass
    finally:
        slot.broadcast(f'\r\n\033[33m[Interface] ⏹ Processus [{slot.name}] terminé\033[0m\r\n')
        if tmp_cfg:
            try:
                os.unlink(tmp_cfg)
            except Exception:
                pass

# ─── Routes ───────────────────────────────────────────────────────────────

@app.route('/')
@login_required
def index():
    return render_template('index.html')

@app.route('/favicon.svg')
def favicon():
    return send_from_directory(
        os.path.join(os.path.dirname(__file__), 'artifacts', 'yoda-mailer', 'public'),
        'favicon.svg',
    )

# ─── Config ───────────────────────────────────────────────────────────────

@app.route('/api/config', methods=['GET'])
@login_required
def get_config():
    try:
        return jsonify({'success': True, 'content': _read_config_content()})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/config/save', methods=['POST'])
@login_required
def save_config():
    data = request.get_json(silent=True) or {}
    content = data.get('content', '')
    if not isinstance(content, str):
        return jsonify({'success': False, 'error': 'Le contenu de configuration est invalide.'})
    try:
        _write_config_content(content)
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/config/update', methods=['POST'])
@login_required
def update_config():
    """Met à jour un groupe de paramètres sans écraser les clés non affichées."""
    data = request.get_json(silent=True) or {}
    values = data.get('values')
    if not isinstance(values, dict):
        return jsonify({'success': False, 'error': 'Les valeurs de configuration sont invalides.'})
    try:
        updated = _update_config_values(values)
        return jsonify({'success': True, 'values': updated})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/config/set', methods=['POST'])
@login_required
def set_config_key():
    """Met à jour une seule clé dans config.txt sans toucher au reste."""
    data = request.get_json(silent=True) or {}
    key   = (data.get('key') or '').strip()
    value = (data.get('value') or '').strip()
    if not key:
        return jsonify({'success': False, 'error': 'key manquant'})
    try:
        _update_config_values({key: value})
        return jsonify({'success': True, 'key': key, 'value': value})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})


@app.route('/api/resend/status', methods=['GET'])
@login_required
def resend_status():
    """Retourne uniquement l'état non sensible de la connexion Resend."""
    values = _read_config_values()
    has_direct_secret = bool(os.environ.get('RESEND_API_KEY', '').strip())
    return jsonify({
        'success': True,
        'enabled': values.get('USE_RESEND_API', 'false').lower() == 'true',
        'from': values.get('RESEND_FROM', ''),
        'reply_to': values.get('RESEND_REPLY_TO', ''),
        'access_mode': 'secret' if has_direct_secret else 'managed_connection',
    })


@app.route('/api/resend/test', methods=['POST'])
@login_required
def resend_test():
    """Envoie un message de test exclusivement via Resend."""
    data = request.get_json(silent=True) or {}
    current_values = _read_config_values()
    recipient = str(data.get('to') or '').strip()
    sender_value = str(data.get('from') or current_values.get('RESEND_FROM', '')).strip()
    reply_to = str(data.get('reply_to') or current_values.get('RESEND_REPLY_TO', '')).strip()

    if not recipient or '@' not in recipient:
        return jsonify({'success': False, 'error': 'Adresse destinataire invalide.'})

    sender_name, sender_address = parseaddr(sender_value)
    if not sender_address:
        sender_address = sender_value
    if not sender_address or '@' not in sender_address:
        return jsonify({
            'success': False,
            'error': 'Renseignez RESEND_FROM avec une adresse vérifiée dans Resend.',
        })
    if reply_to and '@' not in parseaddr(reply_to)[1]:
        return jsonify({'success': False, 'error': 'RESEND_REPLY_TO doit être une adresse email valide.'})

    display_sender = formataddr((sender_name or 'YODA Mailer', sender_address))
    safe_sender = html_escape(display_sender)
    safe_recipient = html_escape(recipient)
    html_body = f"""<html><body style="font-family:Arial,sans-serif;background:#f5f5f5;padding:20px;">
<div style="max-width:520px;margin:auto;background:#fff;border-radius:8px;padding:28px;border:1px solid #ddd;">
  <h2 style="color:#00b4d8;">Connexion Resend validée</h2>
  <p>Ce message confirme que YODA Mailer peut envoyer via l’API Resend.</p>
  <p style="font-size:12px;color:#666;">Expéditeur : {safe_sender}<br>Destinataire : {safe_recipient}</p>
</div></body></html>"""
    text_body = (
        "Connexion Resend validée\n\n"
        "YODA Mailer peut envoyer via l’API Resend.\n"
        f"Expéditeur : {display_sender}\n"
        f"Destinataire : {recipient}\n"
    )

    try:
        result = send_resend_email(
            sender=display_sender,
            recipients=[recipient],
            subject='[TEST] YODA Mailer — Connexion Resend',
            html_content=html_body,
            text_content=text_body,
            reply_to=reply_to or None,
        )
        return jsonify({
            'success': True,
            'provider': 'Resend API',
            'from': display_sender,
            'id': result.get('id'),
        })
    except ResendError as error:
        return jsonify({'success': False, 'error': str(error)})
    except Exception as error:
        return jsonify({'success': False, 'error': str(error)})


@app.route('/api/logo/upload', methods=['POST'])
@login_required
def upload_email_logo():
    """Enregistre un logo local destiné à être embarqué dans les e-mails."""
    uploaded = request.files.get('logo')
    if uploaded is None or not uploaded.filename:
        return jsonify({'success': False, 'error': 'Aucun logo sélectionné.'}), 400

    original_name = secure_filename(uploaded.filename)
    extension = os.path.splitext(original_name)[1].lower()
    if extension not in ALLOWED_LOGO_EXTENSIONS:
        return jsonify({
            'success': False,
            'error': 'Format non pris en charge. Utilisez PNG, JPG, GIF ou WebP.',
        }), 400

    uploaded.stream.seek(0, os.SEEK_END)
    size = uploaded.stream.tell()
    uploaded.stream.seek(0)
    if size <= 0 or size > MAX_LOGO_BYTES:
        return jsonify({
            'success': False,
            'error': 'Le logo doit peser entre 1 octet et 5 Mo.',
        }), 400

    os.makedirs(LOGO_UPLOAD_DIR, exist_ok=True)
    final_name = f'email-logo{extension}'
    final_path = os.path.join(LOGO_UPLOAD_DIR, final_name)
    temporary_path = final_path + '.tmp'

    try:
        uploaded.save(temporary_path)
        os.replace(temporary_path, final_path)

        for filename in os.listdir(LOGO_UPLOAD_DIR):
            candidate = os.path.join(LOGO_UPLOAD_DIR, filename)
            if filename.startswith('email-logo') and candidate != final_path:
                try:
                    os.unlink(candidate)
                except OSError:
                    pass

        relative_path = os.path.relpath(final_path, APP_DIR)
        _update_config_values({
            'LOGO': 'cid:yoda-email-logo',
            'LOGO_FILE': relative_path,
        })
        return jsonify({
            'success': True,
            'filename': original_name,
            'logo': 'cid:yoda-email-logo',
        })
    except Exception as e:
        try:
            if os.path.exists(temporary_path):
                os.unlink(temporary_path)
        except OSError:
            pass
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/logo/image', methods=['GET'])
@login_required
def get_email_logo():
    logo_path = _read_config_values().get('LOGO_FILE', '').strip()
    absolute_path = os.path.abspath(os.path.join(APP_DIR, logo_path))
    if (
        not logo_path
        or os.path.commonpath([APP_DIR, absolute_path]) != APP_DIR
        or not os.path.isfile(absolute_path)
    ):
        return jsonify({'success': False, 'error': 'Aucun logo configuré.'}), 404
    return send_file(absolute_path, conditional=True)


@app.route('/api/message/preview', methods=['GET'])
@login_required
def preview_email_message():
    values = _read_config_values()
    message_path = values.get('MESSAGE_FILE', 'message.html').strip() or 'message.html'
    absolute_path = os.path.abspath(os.path.join(APP_DIR, message_path))
    if (
        os.path.commonpath([APP_DIR, absolute_path]) != APP_DIR
        or not os.path.isfile(absolute_path)
    ):
        return jsonify({'success': False, 'error': 'Fichier HTML introuvable.'}), 404

    try:
        with open(absolute_path, 'r', encoding='utf-8') as message_file:
            html = message_file.read()
        logo_path = values.get('LOGO_FILE', '').strip()
        logo_exists = bool(
            logo_path
            and os.path.isfile(os.path.abspath(os.path.join(APP_DIR, logo_path)))
        )
        replaced = False
        if logo_exists:
            html, replaced = replace_logo_image_source(html, '/api/logo/image')
        return jsonify({
            'success': True,
            'html': html,
            'logoDetected': replaced,
            'filename': message_path,
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

# ─── Statuts ──────────────────────────────────────────────────────────────

@app.route('/api/status', methods=['GET'])
@login_required
def get_status():
    try:
        with open(CONTROL_FILE, 'r', encoding='utf-8') as f:
            data = json.load(f)
        return jsonify({'success': True, 'data': data})
    except FileNotFoundError:
        return jsonify({'success': True, 'data': {
            'status': 'stopped',
            'mode': 'send',
            'total_sent': 0,
            'total_errors': 0,
            'processed_count': 0,
            'total_recipients': 0,
        }})
    except (OSError, json.JSONDecodeError) as exc:
        app.logger.warning("Impossible de lire le statut de campagne: %s", exc)
        return jsonify({
            'success': False,
            'error': 'Statut temporairement indisponible',
        }), 503

@app.route('/api/process/status', methods=['GET'])
@login_required
def process_status():
    return jsonify({
        'send':      SLOTS['send'].is_running(),
        'checkv2':   SLOTS['checkv2'].is_running(),
        'reinforce': SLOTS['reinforce'].is_running(),
    })

# ─── IP sortante ──────────────────────────────────────────────────────────

_ip_cache = {'ip': None, 'ts': 0}
_IP_TTL = 30  # secondes

@app.route('/api/ip', methods=['GET'])
@login_required
def get_outgoing_ip():
    now = time.time()
    force_refresh = request.args.get('fresh', '').strip().lower() in {'1', 'true', 'yes'}
    if not force_refresh and _ip_cache['ip'] and now - _ip_cache['ts'] < _IP_TTL:
        response = jsonify({'success': True, 'ip': _ip_cache['ip'], 'cached': True})
        response.headers['Cache-Control'] = 'no-store'
        return response
    try:
        with urllib.request.urlopen('https://api.ipify.org', timeout=5) as r:
            ip = r.read().decode().strip()
        _ip_cache['ip'] = ip
        _ip_cache['ts'] = now
        response = jsonify({'success': True, 'ip': ip, 'cached': False})
        response.headers['Cache-Control'] = 'no-store'
        return response
    except Exception as e:
        response = jsonify({'success': False, 'ip': _ip_cache['ip'] or '—', 'error': str(e)})
        response.headers['Cache-Control'] = 'no-store'
        return response

# ─── Lancement ────────────────────────────────────────────────────────────

MODE_INFO = {
    'send': {
        'slot':  'send',
        'label': 'Envoi normal',
        'overrides': {},
        'extra_arg': None,
    },
    'check': {
        'slot':  'send',
        'label': 'Check emails (RCPT TO → good.txt / bad.txt)',
        'overrides': {'Check': 'true'},
        'extra_arg': None,
    },
    'checkv2': {
        'slot':  'checkv2',
        'label': 'CHECKV2 (SMTP / IMAP → Resend immédiat)',
        'overrides': {},
        'extra_arg': 'checkv2',
    },
    'reinforce': {
        'slot':  'reinforce',
        'label': 'Reinforce (écoute control.json)',
        'overrides': {'WARM_BOUCLE': 'false'},
        'extra_arg': 'reinforce',
    },
    'warm_boucle': {
        'slot':  'reinforce',
        'label': 'Warm Boucle (warmup infini sur clean.txt)',
        'overrides': {'WARM_BOUCLE': 'true'},
        'extra_arg': 'reinforce',
    },
}

def _launch_slot_process(slot, label, cfg_path, extra_arg=None, tmp_cfg=None):
    """Lance un processus dans un slot déjà verrouillé."""
    cmd = [sys.executable, '-u', os.path.join(APP_DIR, 'send.py'), cfg_path]
    if extra_arg:
        cmd.append(extra_arg)

    env = os.environ.copy()
    env['PYTHONUNBUFFERED'] = '1'
    env['PYTHONIOENCODING'] = 'utf-8'
    env['PYTHONUTF8'] = '1'

    proc = subprocess.Popen(
        cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        bufsize=0,
        env=env,
        cwd=APP_DIR
    )
    slot.process = proc
    slot.broadcast(
        f'\033[32m[Interface] ▶ [{slot.name.upper()}] {label}\033[0m\r\n'
        f'\033[90m$ {" ".join(cmd)}\033[0m\r\n\r\n'
    )
    reader = threading.Thread(
        target=_reader_thread,
        args=(slot, proc, tmp_cfg),
        daemon=True,
    )
    reader.start()
    return proc

@app.route('/api/start', methods=['POST'])
@login_required
def start_process():
    data_req = request.get_json() or {}
    mode = data_req.get('mode', 'send')
    checkv2_account_count = None
    checkv2_account_source = None

    if mode not in MODE_INFO:
        return jsonify({'success': False, 'error': f'Mode inconnu : {mode}'})

    config_values = _read_config_values()

    def config_flag_enabled(key: str) -> bool:
        return config_values.get(key, '').lower() == 'true'

    # Le lancement principal est routé vers CHECKV2 quand l'option est active.
    # Les deux modes ne tournent jamais simultanément pour une même liste, afin
    # d'éviter un envoi direct puis un doublon après vérification.
    if mode == 'send' and config_flag_enabled('CHECKV2_ENABLED'):
        mode = 'checkv2'

    if mode == 'send':
        managed_transport = any(
            config_flag_enabled(key)
            for key in ('USE_AUTH_MODE', 'USE_RESEND_API', 'USE_SENDBYTE_API')
        )
        if not managed_transport and not config_flag_enabled('USE_FIXED_SMTP'):
            mx_target_mode = config_values.get('MX_TARGET_MODE', 'PRIMARY').strip().upper()
            if mx_target_mode not in {'PRIMARY', 'ALL', 'MATCH'}:
                return jsonify({
                    'success': False,
                    'error': 'MX_TARGET_MODE doit être PRIMARY, ALL ou MATCH.'
                })
            if mx_target_mode == 'MATCH' and not config_values.get('MX_TARGET_PATTERN', '').strip():
                return jsonify({
                    'success': False,
                    'error': 'Renseignez MX_TARGET_PATTERN, par exemple ovh.net, pour le mode MATCH.'
                })

    # CHECKV2 reste un mode explicitement activé dans la configuration.
    if mode == 'checkv2':
        if not config_flag_enabled('CHECKV2_ENABLED'):
            return jsonify({
                'success': False,
                'error': 'Activez CHECKV2 dans l’onglet Vérifieur avant de le démarrer.'
            })
        resend_on = config_flag_enabled('USE_RESEND_API')
        auth_on = config_flag_enabled('USE_AUTH_MODE')
        if resend_on and auth_on:
            return jsonify({
                'success': False,
                'error': 'Activez un seul transport pour CHECKV2 : Resend ou SMTP AUTH.'
            })
        if not resend_on and not auth_on:
            return jsonify({
                'success': False,
                'error': 'Activez Resend ou SMTP AUTH dans Paramètres avant de démarrer CHECKV2.'
            })
        if resend_on and '@' not in config_values.get('RESEND_FROM', ''):
            return jsonify({
                'success': False,
                'error': 'Renseignez une adresse RESEND_FROM vérifiée avant de démarrer CHECKV2.'
            })

    # Vérifier les prérequis avant de démarrer un sous-processus qui échouerait
    # immédiatement. Les détails sensibles des comptes ne sont jamais renvoyés.
    if mode in ('send', 'check', 'checkv2'):
        list_filename = 'liste.txt'
        if mode != 'checkv2':
            list_filename = config_values.get('EMAIL_LIST_FILE', '').strip() or 'liste.txt'

        list_path = list_filename if os.path.isabs(list_filename) else os.path.join(APP_DIR, list_filename)
        try:
            with open(list_path, 'r', encoding='utf-8') as recipients_file:
                has_recipient = any('@' in line for line in recipients_file)
        except OSError:
            return jsonify({
                'success': False,
                'error': f'La liste de destinataires « {list_filename} » est introuvable.'
            })
        if not has_recipient:
            return jsonify({
                'success': False,
                'error': f'Ajoutez au moins une adresse e-mail dans « {list_filename} » avant de lancer le processus.'
            })

    if mode == 'checkv2':
        account_lines, account_source = _checkv2_account_lines()
        if not account_lines:
            return jsonify({
                'success': False,
                'error': (
                    'CHECKV2 ne trouve aucun compte IMAP dans « imap.txt ». '
                    'Ajoutez une ligne provider|email|password par compte.'
                )
            })
        checkv2_account_count = len(account_lines)
        checkv2_account_source = 'imap.txt'
        if any(len(line.split('|')) < 3 for line in account_lines):
            return jsonify({
                'success': False,
                'error': (
                    'Les comptes CHECKV2 sont invalides. Format attendu : '
                    'provider|email|password, une ligne par compte.'
                )
            })

    # ⛔ Reinforce et Warm Boucle interdits avec un fournisseur géré.
    if mode in ('reinforce', 'warm_boucle'):
        try:
            auth_on = config_flag_enabled('USE_AUTH_MODE')
            resend_on = config_flag_enabled('USE_RESEND_API')
            sendbyte_on = config_flag_enabled('USE_SENDBYTE_API')
            if auth_on or resend_on or sendbyte_on:
                provider = 'SendByte API' if sendbyte_on else ('Resend API' if resend_on else 'AUTH SMTP')
                return jsonify({
                    'success': False,
                    'error': f'⛔ Mode {provider} actif — Reinforce et Warm Boucle sont désactivés avec un fournisseur géré.'
                })
        except Exception:
            pass

    info = MODE_INFO[mode]
    slot = SLOTS[info['slot']]

    # Un envoi SMTP direct avec Reinforce activé doit toujours disposer d'un
    # vrai listener. L'historique affiché dans le terminal ne prouve pas que
    # l'ancien processus est encore vivant.
    if (
        mode == 'send'
        and config_flag_enabled('USE_IP_REINFORCE')
        and not any(config_flag_enabled(key) for key in (
            'USE_AUTH_MODE', 'USE_RESEND_API', 'USE_SENDBYTE_API'
        ))
    ):
        reinforce_slot = SLOTS['reinforce']
        with reinforce_slot.lock:
            reinforce_running = (
                reinforce_slot.process is not None
                and reinforce_slot.process.poll() is None
            )
            if not reinforce_running:
                reinforce_cfg = make_temp_config({'WARM_BOUCLE': 'false'})
                try:
                    _launch_slot_process(
                        reinforce_slot,
                        MODE_INFO['reinforce']['label'],
                        reinforce_cfg,
                        MODE_INFO['reinforce']['extra_arg'],
                        reinforce_cfg,
                    )
                    reinforce_slot.broadcast(
                        '\033[36m[Interface] Listener démarré automatiquement '
                        'avant l’envoi.\033[0m\r\n'
                    )
                except Exception:
                    try:
                        os.unlink(reinforce_cfg)
                    except OSError:
                        pass
                    raise

    with slot.lock:
        if slot.process is not None and slot.process.poll() is None:
            return jsonify({'success': False,
                            'error': f'Un processus [{info["slot"]}] est déjà en cours'})

        if not os.path.exists(CONFIG_FILE):
            return jsonify({'success': False,
                            'error': f'{CONFIG_FILE} introuvable'})

        # Construire le config (temp si overrides, normal sinon)
        if info['overrides']:
            cfg_path = make_temp_config(info['overrides'])
            tmp_cfg = cfg_path
        else:
            cfg_path = CONFIG_FILE
            tmp_cfg = None

        try:
            proc = _launch_slot_process(
                slot,
                info['label'],
                cfg_path,
                info['extra_arg'],
                tmp_cfg,
            )
            return jsonify({
                'success': True,
                'pid': proc.pid,
                'slot': info['slot'],
                'mode': mode,
                'label': info['label'],
                'account_count': checkv2_account_count,
                'account_source': checkv2_account_source,
            })
        except Exception as e:
            if tmp_cfg:
                try: os.unlink(tmp_cfg)
                except: pass
            return jsonify({'success': False, 'error': str(e)})

# ─── Arrêt ────────────────────────────────────────────────────────────────

@app.route('/api/stop', methods=['POST'])
@login_required
def stop_process():
    data_req = request.get_json() or {}
    slot_name = data_req.get('slot', 'send')
    slot = SLOTS.get(slot_name)
    if not slot:
        return jsonify({'success': False, 'error': 'Slot inconnu'})

    errors = []

    # 1 — Signal control.json (watchdog warm_boucle / reinforce)
    try:
        ctrl = {}
        if os.path.exists(CONTROL_FILE):
            with open(CONTROL_FILE, 'r', encoding='utf-8') as f:
                ctrl = json.load(f)
        ctrl['status'] = 'stopped'
        ctrl['stop_target'] = slot_name
        ctrl['last_update'] = datetime.now().isoformat()
        fd, temporary_path = tempfile.mkstemp(
            prefix='.control-', suffix='.tmp', dir=os.path.dirname(CONTROL_FILE), text=True,
        )
        try:
            with os.fdopen(fd, 'w', encoding='utf-8') as f:
                json.dump(ctrl, f, indent=2)
                f.flush()
                os.fsync(f.fileno())
            os.replace(temporary_path, CONTROL_FILE)
        except Exception:
            try:
                os.unlink(temporary_path)
            except OSError:
                pass
            raise
    except Exception as e:
        errors.append(f'control.json: {e}')

    # 2 — SIGTERM sur le process
    with slot.lock:
        if slot.process and slot.process.poll() is None:
            try:
                slot.process.terminate()
                slot.broadcast(f'\r\n\033[31m[Interface] ⏹ SIGTERM envoyé [{slot_name}]\033[0m\r\n')
            except Exception as e:
                errors.append(f'terminate: {e}')

    if errors:
        return jsonify({'success': False, 'error': ', '.join(errors)})
    return jsonify({'success': True})

@app.route('/api/kill', methods=['POST'])
@login_required
def kill_process():
    data_req = request.get_json() or {}
    slot_name = data_req.get('slot', 'send')
    slot = SLOTS.get(slot_name)
    if slot:
        with slot.lock:
            if slot.process and slot.process.poll() is None:
                slot.process.kill()
                slot.broadcast(f'\r\n\033[31m[Interface] ⚡ SIGKILL [{slot_name}]\033[0m\r\n')
    return jsonify({'success': True})

# ─── SSE : un endpoint par slot ───────────────────────────────────────────

@app.route('/api/logs/stream/<slot_name>')
@login_required
def logs_stream(slot_name):
    slot = SLOTS.get(slot_name)
    if not slot:
        return Response('', status=404)
    return Response(
        slot.stream_generator(),
        mimetype='text/event-stream',
        headers={
            'Cache-Control':    'no-cache',
            'X-Accel-Buffering':'no',
            'Connection':       'keep-alive',
        }
    )

# ─── Fichiers ─────────────────────────────────────────────────────────────

ALLOWED_FILES  = [
    'liste.txt','message.html','liens.txt','clean.txt',
    'smtp.txt','fail.txt','good.txt','bad.txt',
    'base.txt','pkey.pem','dom.txt','c.txt',
]
READONLY_FILES = ['fail.txt','good.txt','bad.txt']

def _project_file_path(name):
    """Retourne le chemin absolu d'un fichier autorisé du projet."""
    if name not in ALLOWED_FILES:
        raise ValueError('Fichier non autorisé')
    return os.path.join(APP_DIR, name)

@app.route('/api/file/<name>', methods=['GET'])
@login_required
def get_file(name):
    if name not in ALLOWED_FILES:
        return jsonify({'success': False, 'error': 'Fichier non autorisé'})
    if name == 'smtp.txt':
        return jsonify({
            'success': False,
            'error': "L'API YODA NE PERMET PAS L'ACCÈS AUX SMTP",
        }), 403
    try:
        with open(_project_file_path(name), 'r', encoding='utf-8') as f:
            content = f.read()
        lines = len([l for l in content.splitlines() if l.strip()])
        return jsonify({'success': True, 'content': content, 'lines': lines})
    except FileNotFoundError:
        return jsonify({'success': True, 'content': '', 'lines': 0})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/file/<name>', methods=['POST'])
@login_required
def save_file(name):
    if name not in ALLOWED_FILES or name in READONLY_FILES:
        return jsonify({'success': False, 'error': 'Fichier non autorisé ou lecture seule'})
    if name == 'smtp.txt':
        return jsonify({
            'success': False,
            'error': "L'API YODA NE PERMET PAS L'ACCÈS AUX SMTP",
        }), 403
    data_req = request.get_json()
    content  = data_req.get('content', '')
    try:
        with open(_project_file_path(name), 'w', encoding='utf-8') as f:
            f.write(content)
        lines = len([l for l in content.splitlines() if l.strip()])
        return jsonify({'success': True, 'lines': lines})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/file/<name>/clear', methods=['POST'])
@login_required
def clear_file(name):
    if name not in READONLY_FILES:
        return jsonify({'success': False, 'error': 'Seulement fail/good/bad'})
    try:
        open(_project_file_path(name), 'w', encoding='utf-8').close()
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

# ─── SMTP Manager ─────────────────────────────────────────────────────────

SMTP_FILE = os.path.join(APP_DIR, 'smtp.txt')
SMTP_CONTENT_HIDDEN_MESSAGE = "Le contenu de smtp.txt n'est pas accessible depuis l'interface."


def _smtp_content_hidden():
    return jsonify({
        'success': False,
        'error': SMTP_CONTENT_HIDDEN_MESSAGE,
    }), 403

def _read_smtp_entries():
    """Lit smtp.txt et retourne une liste de dicts {email,password,server,port}."""
    try:
        with open(SMTP_FILE, 'r', encoding='utf-8') as f:
            lines = [l.strip() for l in f if l.strip() and not l.startswith('#')]
    except FileNotFoundError:
        return []
    entries = []
    for line in lines:
        parts = line.split(':')
        entries.append({
            'email':    parts[0] if len(parts) > 0 else '',
            'password': parts[1] if len(parts) > 1 else '',
            'server':   parts[2] if len(parts) > 2 else '',
            'port':     parts[3] if len(parts) > 3 else '',
            'raw':      line,
        })
    return entries

def _write_smtp_entries(entries):
    """Écrit la liste de dicts dans smtp.txt."""
    lines = []
    for e in entries:
        parts = [e.get('email',''), e.get('password',''), e.get('server','')]
        if e.get('port',''):
            parts.append(e['port'])
        lines.append(':'.join(parts))
    with open(SMTP_FILE, 'w', encoding='utf-8') as f:
        f.write('\n'.join(lines) + ('\n' if lines else ''))

@app.route('/api/smtp/list', methods=['GET'])
@login_required
def smtp_list():
    return jsonify({
        'success': True,
        'entries': [],
        'count': len(_read_smtp_entries()),
    })

@app.route('/api/smtp/add', methods=['POST'])
@login_required
def smtp_add():
    return _smtp_content_hidden()

@app.route('/api/smtp/delete/<int:index>', methods=['POST'])
@login_required
def smtp_delete(index):
    return _smtp_content_hidden()

@app.route('/api/smtp/update/<int:index>', methods=['POST'])
@login_required
def smtp_update(index):
    return _smtp_content_hidden()

@app.route('/api/smtp/get/<int:index>', methods=['GET'])
@login_required
def smtp_get(index):
    return _smtp_content_hidden()

# ─── Résultats ────────────────────────────────────────────────────────────

@app.route('/api/results', methods=['GET'])
@login_required
def get_results():
    results = {}
    for fname in ['fail.txt','good.txt','bad.txt']:
        try:
            with open(_project_file_path(fname), 'r', encoding='utf-8') as f:
                lines = [l.strip() for l in f if l.strip()]
            results[fname] = {'count': len(lines), 'emails': lines[:500]}
        except Exception:
            results[fname] = {'count': 0, 'emails': []}
    return jsonify({'success': True, 'results': results})

@app.route('/api/liste/count', methods=['GET'])
@login_required
def liste_count():
    try:
        with open(_project_file_path('liste.txt'), 'r', encoding='utf-8') as f:
            n = sum(1 for l in f if '@' in l)
        return jsonify({'success': True, 'count': n})
    except Exception:
        return jsonify({'success': True, 'count': 0})

@app.route('/api/liste/preview', methods=['GET'])
@login_required
def liste_preview():
    """Retourne les emails de liste.txt pour affichage scrollable."""
    try:
        with open(_project_file_path('liste.txt'), 'r', encoding='utf-8') as f:
            emails = [l.strip() for l in f if l.strip() and '@' in l]
        return jsonify({'success': True, 'emails': emails, 'count': len(emails)})
    except FileNotFoundError:
        return jsonify({'success': True, 'emails': [], 'count': 0})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/test-mail/send', methods=['POST'])
@login_required
def send_test_mail():
    """Envoie un email de test via le transport configuré."""
    data = request.get_json() or {}
    to_addr = (data.get('to') or '').strip()
    if not to_addr or '@' not in to_addr:
        return jsonify({'success': False, 'error': 'Adresse email invalide'})

    try:
        # Lire la config courante
        cfg = {}
        if os.path.exists(CONFIG_FILE):
            with open(CONFIG_FILE, 'r', encoding='utf-8') as f:
                for line in f:
                    line = line.strip()
                    if not line or line.startswith('#'):
                        continue
                    if '=' in line:
                        k, v = line.split('=', 1)
                        cfg[k.strip()] = v.strip()

        use_resend = cfg.get('USE_RESEND_API', 'false').lower() == 'true'
        use_sendbyte = cfg.get('USE_SENDBYTE_API', 'false').lower() == 'true'
        use_auth = cfg.get('USE_AUTH_MODE', 'false').lower() == 'true'
        smtp_host = None
        smtp_port = 587
        smtp_user = None
        smtp_pass = None
        transport_label = None
        display_from = None

        active_providers = [
            label
            for enabled, label in (
                (use_sendbyte, 'SendByte'),
                (use_resend, 'Resend'),
                (use_auth, 'AUTH SMTP'),
            )
            if enabled
        ]
        if len(active_providers) > 1:
            return jsonify({
                'success': False,
                'error': 'Choisissez un seul fournisseur d’envoi avant le test : '
                + ', '.join(active_providers) + ' sont actifs.'
            })
        if use_sendbyte:
            from_addr = cfg.get('SENDBYTE_FROM', '').strip()
            reply_to = cfg.get('SENDBYTE_REPLY_TO', '').strip()
            if not from_addr or '@' not in from_addr:
                return jsonify({
                    'success': False,
                    'error': 'Configurez SENDBYTE_FROM avec une adresse vérifiée dans SendByte.'
                })
            transport_label = 'SendByte API'
        elif use_resend:
            configured_from = cfg.get('RESEND_FROM', '').strip()
            configured_name, from_addr = parseaddr(configured_from)
            if not from_addr:
                from_addr = configured_from
            reply_to = cfg.get('RESEND_REPLY_TO', '').strip()
            if not from_addr or '@' not in from_addr:
                return jsonify({
                    'success': False,
                    'error': 'Configurez RESEND_FROM avec une adresse vérifiée dans Resend.'
                })
            sender_name = cfg.get('SENDER_NAME', '').strip() or configured_name or 'YODA Mailer'
            display_from = formataddr((sender_name, from_addr))
            transport_label = 'Resend API'
        elif use_auth:
            smtp_file = cfg.get('SMTP_ACCOUNTS_FILE', 'smtp.txt')
            if os.path.exists(smtp_file):
                with open(smtp_file, 'r', encoding='utf-8') as f:
                    lines = [l.strip() for l in f if l.strip() and not l.startswith('#')]
                if lines:
                    parts = lines[0].split(':')
                    smtp_user = parts[0] if len(parts) > 0 else None
                    smtp_pass = parts[1] if len(parts) > 1 else None
                    smtp_host = parts[2] if len(parts) > 2 else None
                    if len(parts) > 3 and parts[3].isdigit():
                        smtp_port = int(parts[3])
                    else:
                        smtp_port = int(cfg.get('AUTH_SMTP_PORT', 587))
            if not smtp_host:
                return jsonify({'success': False, 'error': 'Aucun compte SMTP dans smtp.txt'})
            from_addr = smtp_user
            display_from = _visible_from_header(cfg, from_addr)
        else:
            smtp_host = cfg.get('SMTP_SERVER', '')
            smtp_port = int(cfg.get('SMTP_PORT', 25))
            envelope_domain = (
                cfg.get('ENVELOPE_SENDER_DOMAIN', '').strip()
                or cfg.get('SENDER_DOMAIN', 'test.com').strip()
            )
            from_addr = f"{cfg.get('EMAIL_USERNAME','test')}@{envelope_domain}"
            if not smtp_host:
                return jsonify({'success': False, 'error': 'SMTP_SERVER non configuré'})
            display_from = _visible_from_header(cfg, from_addr)

        if not transport_label:
            transport_label = f'{smtp_host}:{smtp_port}'

        # Construire un email de test avec les mêmes en-têtes standards qu'une
        # campagne. Il ne faut pas imiter les en-têtes ajoutés par les MTA ou
        # les filtres destinataires : ils sont vérifiés côté réception.
        msg = MIMEMultipart('alternative')
        msg['Subject'] = '[TEST] YODA MAILER — Vérification SMTP'
        msg['From'] = display_from or formataddr(('YODA Mailer', from_addr))
        msg['To'] = to_addr
        msg['Date'] = formatdate(localtime=True)
        msg['Message-ID'] = make_msgid(domain=from_addr.rsplit('@', 1)[-1])
        html_body = f"""<html><body style="font-family:Arial,sans-serif;background:#f5f5f5;padding:20px;">
<div style="max-width:500px;margin:auto;background:#fff;border-radius:8px;padding:28px;border:1px solid #ddd;">
  <h2 style="color:#00b4d8;">Vérification SMTP</h2>
  <p>Ce message confirme que le serveur SMTP accepte l'envoi. La délivrabilité dépend aussi de l'alignement SPF, DKIM et DMARC du domaine.</p>
  <table style="width:100%;border-collapse:collapse;margin-top:16px;">
    <tr><td style="padding:6px;color:#666;">Transport utilisé</td><td style="padding:6px;font-weight:bold;">{transport_label}</td></tr>
    <tr><td style="padding:6px;color:#666;">Expéditeur</td><td style="padding:6px;font-weight:bold;">{from_addr}</td></tr>
    <tr><td style="padding:6px;color:#666;">Destinataire</td><td style="padding:6px;font-weight:bold;">{to_addr}</td></tr>
    <tr><td style="padding:6px;color:#666;">Heure</td><td style="padding:6px;">{time.strftime('%Y-%m-%d %H:%M:%S')}</td></tr>
  </table>
  <p style="margin-top:20px;font-size:12px;color:#999;">Vérifiez les résultats d'authentification dans les en-têtes complets du message reçu.</p>
</div></body></html>"""
        text_body = (
            "Vérification SMTP\n\n"
            "Le serveur SMTP a accepté cet envoi. Vérifiez SPF, DKIM et DMARC "
            "dans les en-têtes complets du message reçu."
        )
        msg.attach(MIMEText(text_body, 'plain', 'utf-8'))
        msg.attach(MIMEText(html_body, 'html', 'utf-8'))

        if use_sendbyte:
            result = send_sendbyte_email(
                sender=from_addr,
                recipients=[to_addr],
                subject=msg['Subject'],
                html_content=html_body,
                text_content=text_body,
                reply_to=reply_to,
            )
            return jsonify({
                'success': True,
                'provider': 'SendByte API',
                'from': from_addr,
                'id': result.get('id'),
                'sandbox': result.get('sandbox', False),
            })

        if use_resend:
            result = send_resend_email(
                sender=display_from or from_addr,
                recipients=[to_addr],
                subject=msg['Subject'],
                html_content=html_body,
                text_content=text_body,
                reply_to=reply_to,
            )
            return jsonify({
                'success': True,
                'provider': 'Resend API',
                'from': display_from or from_addr,
                'id': result.get('id'),
            })

        # Connexion SMTP
        if smtp_port == 465:
            import ssl
            ctx = ssl.create_default_context()
            server = open_smtp(smtp_host, smtp_port, timeout=30, ssl_context=ctx)
        else:
            server = open_smtp(smtp_host, smtp_port, timeout=30)
        require_tls = cfg.get('SMTP_REQUIRE_TLS', 'true').lower() == 'true'
        establish_tls(server, smtp_host, smtp_port, required=require_tls)

        if smtp_user and smtp_pass:
            server.login(smtp_user, smtp_pass)

        server.sendmail(from_addr, [to_addr], msg.as_string())
        server.quit()

        return jsonify({'success': True, 'smtp': f'{smtp_host}:{smtp_port}', 'from': from_addr})

    except (ResendError, SendByteError) as e:
        return jsonify({'success': False, 'error': str(e)})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

# ─── Réinitialisation du runtime ────────────────────────────────────────────

def _pid_listening_on_port(port):
    """Trouve le PID à l'écoute sur un port sous Unix ou Windows."""
    if os.name == 'nt':
        try:
            result = subprocess.run(
                ['netstat', '-ano', '-p', 'tcp'],
                capture_output=True,
                text=True,
                encoding='utf-8',
                errors='replace',
                check=False,
            )
            for line in result.stdout.splitlines():
                parts = line.split()
                if len(parts) >= 5 and parts[0].upper() == 'TCP':
                    local_address = parts[1]
                    state = parts[3].upper()
                    if state == 'LISTENING' and local_address.rsplit(':', 1)[-1] == str(port):
                        try:
                            return int(parts[4])
                        except ValueError:
                            continue
        except (OSError, subprocess.SubprocessError):
            pass
        return None

    try:
        result = subprocess.run(
            ['fuser', f'{port}/tcp'],
            capture_output=True,
            text=True,
            encoding='utf-8',
            errors='replace',
            check=False,
        )
        pids = result.stdout.strip().split()
        return int(pids[0]) if pids else None
    except (OSError, ValueError, subprocess.SubprocessError):
        return None


def _terminate_pid(pid):
    """Termine un processus avec la commande native du système."""
    if os.name == 'nt':
        subprocess.run(
            ['taskkill', '/PID', str(pid), '/T', '/F'],
            capture_output=True,
            text=True,
            encoding='utf-8',
            errors='replace',
            check=False,
        )
    else:
        import signal as _signal
        os.kill(pid, _signal.SIGTERM)


@app.route('/api/reboot', methods=['POST'])
@login_required
def reboot_server():
    """
    Réinitialise le cache IP et arrête les sous-processus actifs sans terminer
    le serveur Flask. Un endpoint ne doit pas s'auto-terminer : le gestionnaire
    de workflow le considérerait comme un crash et l'artifact passerait en
    état FAILED.
    """
    _ip_cache['ip'] = None
    _ip_cache['ts'] = 0
    # Arrêt propre des sous-processus actifs, sans couper le serveur web.
    for slot in SLOTS.values():
        with slot.lock:
            if slot.process and slot.process.poll() is None:
                try:
                    slot.process.terminate()
                except Exception:
                    pass

    return jsonify({
        'success': True,
        'message': 'Runtime réinitialisé ; le serveur web reste disponible.',
        'ip_rotation_guaranteed': False,
    })

# ─── Démarrage ────────────────────────────────────────────────────────────

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=False, threaded=True)
