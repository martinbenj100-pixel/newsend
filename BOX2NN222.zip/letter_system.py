# ============================================================
# LETTER SYSTEM — Portage depuis server_1786645606819.js
# Gestion des templates HTML, synonymes et reformulation
# ============================================================

import random
import re
from datetime import datetime

# ─────────────────────────────────────────────────────
# DICTIONNAIRE DE SYNONYMES (500+ entrées)
# Portage complet depuis le JS — contexte administratif/technique
# ─────────────────────────────────────────────────────
SYNONYMS = {


  'détecté': ['repéré', 'constaté', 'identifié', 'relevé', 'observé', 'décelé', 'remarqué', 'noté'],
  'détectons': ['constatons', 'identifions', 'relevons', 'observons', 'décelons', 'remarquons', 'notons'],
  'détecter': ['constater', 'identifier', 'relever', 'observer', 'déceler', 'remarquer', 'noter'],
  'observer': ['constater', 'remarquer', 'relever', 'examiner', 'analyser', 'noter', 'déceler'],
  'observons': ['constatons', 'remarquons', 'relevons', 'examinons', 'analysons', 'notons', 'décelons'],
  'observé': ['constaté', 'remarqué', 'relevé', 'examiné', 'analysé', 'noté', 'décelé'],
  'constater': ['observer', 'remarquer', 'relever', 'reconnaître', 'établir', 'noter', 'identifier'],
  'constatons': ['observons', 'remarquons', 'relevons', 'reconnaissons', 'établissons', 'notons', 'identifions'],
  'constaté': ['observé', 'remarqué', 'relevé', 'reconnu', 'établi', 'noté', 'identifié'],
  'remarquer': ['constater', 'observer', 'relever', 'noter', 'déceler', 'identifier', 'repérer'],
  'remarqué': ['constaté', 'observé', 'relevé', 'noté', 'décelé', 'identifié', 'repéré'],
  'identifier': ['reconnaître', 'repérer', 'détecter', 'établir', 'déceler', 'localiser', 'déterminer'],
  'identifié': ['reconnu', 'repéré', 'détecté', 'établi', 'décelé', 'localisé', 'déterminé'],
  'trouver': ['découvrir', 'repérer', 'localiser', 'identifier', 'déceler', 'détecter'],
  'trouvé': ['découvert', 'repéré', 'localisé', 'identifié', 'décelé', 'détecté'],
  'découvrir': ['trouver', 'repérer', 'identifier', 'déceler', 'détecter', 'localiser'],
  'découvert': ['trouvé', 'repéré', 'identifié', 'décelé', 'détecté', 'localisé'],
  'noter': ['constater', 'remarquer', 'relever', 'observer', 'consigner', 'signaler'],
  'notez': ['constatez', 'remarquez', 'relevez', 'observez', 'consignez', 'signalez'],

  'procéder': ['effectuer', 'réaliser', 'accomplir', 'opérer', 'exécuter', 'entreprendre', 'engager'],
  'procédez': ['effectuez', 'réalisez', 'accomplissez', 'opérez', 'exécutez', 'entreprenez', 'engagez'],
  'effectuer': ['réaliser', 'accomplir', 'procéder à', 'opérer', 'exécuter', 'entreprendre', 'mener'],
  'effectuez': ['réalisez', 'accomplissez', 'procédez à', 'opérez', 'exécutez', 'entreprenez', 'menez'],
  'effectué': ['réalisé', 'accompli', 'opéré', 'exécuté', 'entrepris', 'mené'],
  'réaliser': ['effectuer', 'accomplir', 'exécuter', 'mener à bien', 'opérer', 'entreprendre', 'concrétiser'],
  'réalisez': ['effectuez', 'accomplissez', 'exécutez', 'menez à bien', 'opérez', 'entreprenez', 'concrétisez'],
  'réalisé': ['effectué', 'accompli', 'exécuté', 'opéré', 'entrepris', 'concrétisé', 'mené à bien'],
  'exécuter': ['réaliser', 'accomplir', 'effectuer', 'opérer', 'procéder à', 'mener', 'entreprendre'],
  'exécutez': ['réalisez', 'accomplissez', 'effectuez', 'opérez', 'procédez à', 'menez', 'entreprenez'],
  'compléter': ['finaliser', 'achever', 'terminer', 'parachever', 'clôturer', 'boucler', 'conclure'],
  'complétez': ['finalisez', 'achevez', 'terminez', 'parachevez', 'clôturez', 'bouclez', 'concluez'],
  'complété': ['finalisé', 'achevé', 'terminé', 'parachevé', 'clôturé', 'bouclé', 'conclu'],
  'finaliser': ['compléter', 'achever', 'terminer', 'clôturer', 'boucler', 'parachever', 'conclure'],
  'finalisez': ['complétez', 'achevez', 'terminez', 'clôturez', 'bouclez', 'parachevez', 'concluez'],
  'finalisé': ['complété', 'achevé', 'terminé', 'clôturé', 'bouclé', 'parachevé', 'conclu'],
  'terminer': ['achever', 'finaliser', 'clôturer', 'compléter', 'boucler', 'parachever', 'conclure'],
  'terminez': ['achevez', 'finalisez', 'clôturez', 'complétez', 'bouclez', 'parachevez', 'concluez'],
  'terminé': ['achevé', 'finalisé', 'clôturé', 'complété', 'bouclé', 'parachevé', 'conclu'],
  'commencer': ['débuter', 'entamer', 'amorcer', 'initier', 'engager', 'lancer', 'démarrer'],
  'commencez': ['débutez', 'entamez', 'amorcez', 'initiez', 'engagez', 'lancez', 'démarrez'],
  'lancer': ['démarrer', 'initier', 'entamer', 'engager', 'amorcer', 'débuter', 'déclencher'],
  'lancez': ['démarrez', 'initiez', 'entamez', 'engagez', 'amorcez', 'débutez', 'déclenchez'],
  'démarrer': ['lancer', 'commencer', 'entamer', 'initier', 'amorcer', 'débuter', 'engager'],

  'protéger': ['préserver', 'sécuriser', 'sauvegarder', 'défendre', 'garantir'],
  'protégez': ['préservez', 'sécurisez', 'sauvegardez', 'défendez', 'garantissez'],
  'protégé': ['préservé', 'sécurisé', 'sauvegardé', 'défendu', 'garanti'],
  'sauvegarder': ['préserver', 'protéger', 'conserver', 'enregistrer', 'sécuriser', 'archiver'],
  'sauvegardez': ['préservez', 'protégez', 'conservez', 'enregistrez', 'sécurisez', 'archivez'],
  'sauvegardé': ['préservé', 'protégé', 'conservé', 'enregistré', 'sécurisé', 'archivé'],
  'préserver': ['protéger', 'sauvegarder', 'maintenir', 'conserver', 'sécuriser', 'défendre'],
  'préservez': ['protégez', 'sauvegardez', 'maintenez', 'conservez', 'sécurisez', 'défendez'],
  'préservé': ['protégé', 'sauvegardé', 'maintenu', 'conservé', 'sécurisé', 'défendu'],
  'sécuriser': ['protéger', 'préserver', 'sauvegarder', 'défendre', 'garantir'],
  'sécurisez': ['protégez', 'préservez', 'sauvegardez', 'défendez', 'garantissez'],

  'garantir': ['assurer', 'offrir', 'procurer', 'maintenir', 'préserver', 'sécuriser', 'permettre'],
  'garantissons': ['assurons', 'offrons', 'procurons', 'maintenons', 'préservons', 'sécurisons', 'permettons'],
  'garantit': ['assure', 'offre', 'procure', 'maintient', 'préserve', 'sécurise', 'permet'],
  'garanti': ['assuré', 'offert', 'procuré', 'maintenu', 'préservé', 'sécurisé', 'permis'],
  'assurer': ['garantir', 'offrir', 'procurer', 'maintenir', 'préserver', 'permettre'],
  'assurez': ['garantissez', 'offrez', 'procurez', 'maintenez', 'préservez', 'permettez'],
  'assurons': ['garantissons', 'offrons', 'procurons', 'maintenons', 'préservons', 'permettons'],
  'assure': ['garantit', 'offre', 'procure', 'maintient', 'préserve', 'permet'],
  'assuré': ['garanti', 'offert', 'procuré', 'maintenu', 'préservé', 'permis'],
  'offrir': ['procurer', 'garantir', 'assurer', 'permettre', 'proposer', 'fournir'],
  'offre': ['procure', 'garantit', 'assure', 'permet', 'propose', 'fournit'],
  'permettre': ['autoriser', 'garantir', 'assurer', 'offrir', 'procurer', 'rendre possible'],
  'permet': ['autorise', 'garantit', 'assure', 'offre', 'procure', 'rend possible'],

  'optimiser': ['améliorer', 'perfectionner', 'affiner', 'bonifier', 'rehausser'],
  'optimisé': ['amélioré', 'perfectionné', 'affiné', 'bonifié', 'rehaussé'],
  'améliorer': ['perfectionner', 'optimiser', 'affiner', 'bonifier', 'rehausser', 'enrichir'],
  'améliorez': ['perfectionnez', 'optimisez', 'affinez', 'bonifiez', 'rehaussez', 'enrichissez'],
  'amélioré': ['perfectionné', 'optimisé', 'affiné', 'bonifié', 'rehaussé', 'enrichi'],

  'nécessiter': ['requérir', 'exiger', 'impliquer', 'demander', 'réclamer'],
  'nécessite': ['requiert', 'exige', 'implique', 'demande', 'réclame'],
  'exiger': ['requérir', 'nécessiter', 'imposer', 'réclamer', 'demander'],
  'exige': ['requiert', 'nécessite', 'impose', 'réclame', 'demande'],
  'requérir': ['nécessiter', 'exiger', 'demander', 'réclamer', 'impliquer'],
  'requiert': ['nécessite', 'exige', 'demande', 'réclame', 'implique'],

  'actualiser': ['renouveler', 'rafraîchir', 'réviser', 'mettre à jour', 'moderniser', 'réactualiser'],
  'mettre à jour': ['actualiser', 'renouveler', 'rafraîchir', 'réviser', 'moderniser', 'réactualiser'],
  'actualisez': ['renouvelez', 'rafraîchissez', 'révisez', 'mettez à jour', 'modernisez', 'réactualisez'],
  'actualisé': ['renouvelé', 'rafraîchi', 'révisé', 'mis à jour', 'modernisé', 'réactualisé'],
  'modifier': ['changer', 'ajuster', 'réviser', 'adapter', 'transformer', 'actualiser', 'corriger'],
  'modifiez': ['changez', 'ajustez', 'révisez', 'adaptez', 'transformez', 'actualisez', 'corrigez'],
  'modifié': ['changé', 'ajusté', 'révisé', 'adapté', 'transformé', 'actualisé', 'corrigé'],
  'changer': ['modifier', 'ajuster', 'renouveler', 'transformer', 'remplacer', 'actualiser'],
  'changez': ['modifiez', 'ajustez', 'renouvelez', 'transformez', 'remplacez', 'actualisez'],
  'ajuster': ['adapter', 'régler', 'modifier', 'affiner', 'aligner', 'accorder'],
  'ajustez': ['adaptez', 'réglez', 'modifiez', 'affinez', 'alignez', 'accordez'],
  'adapter': ['ajuster', 'accommoder', 'aligner', 'conformer', 'accorder', 'régler'],
  'adaptez': ['ajustez', 'accommodez', 'alignez', 'conformez', 'accordez', 'réglez'],
  'renouveler': ['actualiser', 'reconduire', 'proroger', 'rétablir', 'régénérer', 'moderniser'],
  'renouvelez': ['actualisez', 'reconduisez', 'prorogez', 'rétablissez', 'régénérez', 'modernisez'],
  'renouvelé': ['actualisé', 'reconduit', 'prorogé', 'rétabli', 'régénéré', 'modernisé'],
  'corriger': ['rectifier', 'modifier', 'réviser', 'amender', 'redresser', 'ajuster'],
  'corrigez': ['rectifiez', 'modifiez', 'révisez', 'amendez', 'redressez', 'ajustez'],
  'corrigé': ['rectifié', 'modifié', 'révisé', 'amendé', 'redressé', 'ajusté'],
  'rectifier': ['corriger', 'modifier', 'ajuster', 'amender', 'redresser', 'réviser'],

  'cliquer': ['appuyer', 'presser', 'sélectionner', 'actionner', 'toucher'],
  'cliquez': ['appuyez', 'pressez', 'sélectionnez', 'actionnez', 'touchez'],
  'sélectionner': ['choisir', 'retenir', 'désigner', 'cocher', 'opter pour', 'préférer'],
  'sélectionnez': ['choisissez', 'retenez', 'désignez', 'cochez', 'optez pour', 'préférez'],
  'choisir': ['sélectionner', 'retenir', 'désigner', 'opter pour', 'préférer', 'cocher'],
  'choisissez': ['sélectionnez', 'retenez', 'désignez', 'optez pour', 'préférez', 'cochez'],
  'valider': ['confirmer', 'approuver', 'entériner', 'homologuer', 'certifier', 'ratifier', 'attester'],
  'validez': ['confirmez', 'approuvez', 'entérinez', 'homologuez', 'certifiez', 'ratifiez', 'attestez'],
  'validé': ['confirmé', 'approuvé', 'entériné', 'homologué', 'certifié', 'ratifié', 'attesté'],
  'confirmer': ['valider', 'attester', 'certifier', 'entériner', 'approuver', 'ratifier'],
  'confirmez': ['validez', 'attestez', 'certifiez', 'entérinez', 'approuvez', 'ratifiez'],
  'confirmé': ['validé', 'attesté', 'certifié', 'entériné', 'approuvé', 'ratifié'],
  'saisir': ['entrer', 'renseigner', 'inscrire', 'introduire', 'noter', 'consigner'],
  'saisissez': ['entrez', 'renseignez', 'inscrivez', 'introduisez', 'notez', 'consignez'],
  'entrer': ['saisir', 'renseigner', 'inscrire', 'introduire', 'noter', 'consigner'],
  'entrez': ['saisissez', 'renseignez', 'inscrivez', 'introduisez', 'notez', 'consignez'],
  'remplir': ['compléter', 'renseigner', 'saisir', 'garnir'],
  'remplissez': ['complétez', 'renseignez', 'saisissez', 'garnissez'],
  'renseigner': ['saisir', 'entrer', 'compléter', 'indiquer', 'inscrire', 'préciser'],
  'renseignez': ['saisissez', 'entrez', 'complétez', 'indiquez', 'inscrivez', 'précisez'],
  'indiquer': ['préciser', 'mentionner', 'signaler', 'renseigner', 'noter', 'montrer', 'spécifier'],
  'indiquez': ['précisez', 'mentionnez', 'signalez', 'renseignez', 'notez', 'montrez', 'spécifiez'],
  'mentionner': ['indiquer', 'signaler', 'préciser', 'citer', 'noter', 'évoquer'],
  'préciser': ['spécifier', 'détailler', 'indiquer', 'clarifier', 'mentionner', 'expliciter'],
  'précisez': ['spécifiez', 'détaillez', 'indiquez', 'clarifiez', 'mentionnez', 'explicitez'],

  'contacter': ['joindre', 'solliciter', 'appeler'],
  'contactez': ['joignez', 'sollicitez', 'appelez'],
  'joindre': ['contacter', 'solliciter', 'appeler'],
  'joignez': ['contactez', 'sollicitez', 'appelez'],
  'répondre': ['répliquer', 'donner suite', 'réagir', 'rétorquer', 'accuser réception'],
  'répondez': ['répliquez', 'donnez suite', 'réagissez', 'rétorquez', 'accusez réception'],
  'signaler': ['indiquer', 'notifier', 'informer', 'communiquer', 'annoncer', 'mentionner', 'préciser'],
  'signalez': ['indiquez', 'notifiez', 'informez', 'communiquez', 'annoncez', 'mentionnez', 'précisez'],
  'notifier': ['signaler', 'informer', 'communiquer', 'annoncer', 'aviser', 'prévenir', 'indiquer'],
  'notifiez': ['signalez', 'informez', 'communiquez', 'annoncez', 'avisez', 'prévenez', 'indiquez'],
  'informer': ['prévenir', 'notifier', 'aviser', 'signaler', 'communiquer', 'renseigner', 'annoncer'],
  'informez': ['prévenez', 'notifiez', 'avisez', 'signalez', 'communiquez', 'renseignez', 'annoncez'],
  'prévenir': ['informer', 'avertir', 'notifier', 'aviser', 'signaler', 'alerter'],
  'prévenez': ['informez', 'avertissez', 'notifiez', 'avisez', 'signalez', 'alertez'],
  'avertir': ['prévenir', 'informer', 'notifier', 'signaler', 'aviser', 'alerter'],
  'avertissez': ['prévenez', 'informez', 'notifiez', 'signalez', 'avisez', 'alertez'],
  'communiquer': ['transmettre', 'partager', 'faire parvenir', 'diffuser', 'relayer', 'notifier', 'adresser'],
  'communiquez': ['transmettez', 'partagez', 'faites parvenir', 'diffusez', 'relayez', 'notifiez', 'adressez'],
  'communiqué': ['transmis', 'partagé', 'diffusé', 'relayé', 'notifié', 'adressé'],
  'transmettre': ['communiquer', 'faire parvenir', 'relayer', 'acheminer', 'adresser', 'diffuser', 'envoyer'],
  'transmettez': ['communiquez', 'faites parvenir', 'relayez', 'acheminez', 'adressez', 'diffusez', 'envoyez'],
  'transmis': ['communiqué', 'relayé', 'acheminé', 'adressé', 'diffusé', 'envoyé'],
  'envoyer': ['transmettre', 'expédier', 'adresser', 'faire parvenir', 'acheminer', 'communiquer', 'relayer'],
  'envoyez': ['transmettez', 'expédiez', 'adressez', 'faites parvenir', 'acheminez', 'communiquez', 'relayez'],
  'envoyé': ['transmis', 'expédié', 'adressé', 'acheminé', 'communiqué', 'relayé'],
  'adresser': ['envoyer', 'transmettre', 'faire parvenir', 'communiquer', 'expédier'],
  'adressez': ['envoyez', 'transmettez', 'faites parvenir', 'communiquez', 'expédiez'],

  'connaître': ['savoir', 'maîtriser', 'être informé de', 'avoir connaissance de'],
  'comprendre': ['saisir', 'appréhender', 'concevoir', 'assimiler', 'percevoir'],
  'comprenez': ['saisissez', 'appréhendez', 'concevez', 'assimilez', 'percevez'],
  'expliquer': ['exposer', 'préciser', 'détailler', 'clarifier', 'éclaircir', 'développer'],
  'expliquez': ['exposez', 'précisez', 'détaillez', 'clarifiez', 'éclaircissez', 'développez'],
  'clarifier': ['éclaircir', 'expliquer', 'préciser', 'élucider', 'détailler', 'exposer'],
  'clarifiez': ['éclaircissez', 'expliquez', 'précisez', 'élucidez', 'détaillez', 'exposez'],

  'surveiller': ['contrôler', 'observer', 'superviser', 'monitorer', 'suivre'],
  'surveillez': ['contrôlez', 'observez', 'supervisez', 'monitorez', 'suivez'],
  'contrôler': ['vérifier', 'inspecter', 'examiner', 'auditer', 'superviser', 'analyser'],
  'contrôlez': ['vérifiez', 'inspectez', 'examinez', 'auditez', 'supervisez', 'analysez'],
  'vérifier': ['contrôler', 'examiner', 'confirmer', 'valider', 'inspecter', 'attester', 'authentifier'],
  'vérifiez': ['contrôlez', 'examinez', 'confirmez', 'validez', 'inspectez', 'attestez', 'authentifiez'],
  'vérifié': ['contrôlé', 'examiné', 'confirmé', 'validé', 'inspecté', 'attesté', 'authentifié'],
  'examiner': ['analyser', 'étudier', 'inspecter', 'contrôler', 'auditer', 'ausculter'],
  'examinez': ['analysez', 'étudiez', 'inspectez', 'contrôlez', 'auditez', 'ausculter'],
  'analyser': ['examiner', 'étudier', 'évaluer', 'inspecter', 'ausculter', 'décortiquer'],
  'analysez': ['examinez', 'étudiez', 'évaluez', 'inspectez', 'auscultez', 'décortiquez'],
  'évaluer': ['estimer', 'apprécier', 'analyser', 'mesurer', 'juger', 'examiner'],
  'évaluez': ['estimez', 'appréciez', 'analysez', 'mesurez', 'jugez', 'examinez'],

  'utiliser': ['employer', 'exploiter', 'se servir de', 'recourir à', 'user de', 'mobiliser'],
  'utilisez': ['employez', 'exploitez', 'servez-vous de', 'recourez à', 'usez de', 'mobilisez'],
  'utilisé': ['employé', 'exploité', 'mobilisé'],
  'employer': ['utiliser', 'exploiter', 'recourir à', 'se servir de', 'user de', 'mobiliser'],
  'accéder': ['entrer', 'parvenir', 'atteindre', 'joindre', 'gagner'],
  'accédez': ['entrez', 'parvenez à', 'atteignez', 'joignez', 'gagnez'],
  'obtenir': ['recevoir', 'récupérer', 'acquérir', 'gagner', 'décrocher'],
  'obtenez': ['recevez', 'récupérez', 'acquérez', 'gagnez', 'décrochez'],
  'récupérer': ['retrouver', 'reprendre', 'obtenir', 'recouvrer', 'regagner'],
  'récupérez': ['retrouvez', 'reprenez', 'obtenez', 'recouvrez', 'regagnez'],
  'restaurer': ['rétablir', 'récupérer', 'reconstituer', 'restituer', 'remettre en état'],
  'restaurez': ['rétablissez', 'récupérez', 'reconstituez', 'restituez', 'remettez en état'],
  'restauré': ['rétabli', 'récupéré', 'reconstitué', 'restitué', 'remis en état'],
  'rétablir': ['restaurer', 'reconstituer', 'restituer', 'remettre en état', 'récupérer'],
  'rétablissez': ['restaurez', 'reconstituez', 'restituez', 'remettez en état', 'récupérez'],
  'rétabli': ['restauré', 'reconstitué', 'restitué', 'remis en état', 'récupéré'],
  'suspendre': ['interrompre', 'ajourner', 'reporter', 'geler', 'stopper'],
  'suspendu': ['interrompu', 'ajourné', 'reporté', 'gelé', 'stoppé'],
  'bloquer': ['empêcher', 'suspendre', 'geler', 'stopper', 'entraver'],
  'bloqué': ['suspendu', 'gelé', 'interrompu', 'stoppé', 'entravé'],
  'débloquer': ['libérer', 'lever', 'restaurer', 'dégager', 'réactiver'],
  'activer': ['enclencher', 'lancer', 'mettre en marche', 'déclencher', 'réactiver'],
  'activez': ['enclenchez', 'lancez', 'mettez en marche', 'déclenchez', 'réactivez'],
  'activé': ['enclenché', 'lancé', 'déclenché', 'réactivé'],
  'désactiver': ['arrêter', 'interrompre', 'suspendre', 'stopper', 'inhiber'],
  'désactivé': ['arrêté', 'interrompu', 'suspendu', 'stoppé', 'inhibé'],
  'recevoir': ['obtenir', 'récupérer', 'accueillir', 'percevoir'],
  'recevez': ['obtenez', 'récupérez', 'accueillez', 'percevez'],



  'problème': ['souci', 'incident', 'dysfonctionnement', 'défaut', 'ennui', 'désagrément'],
  'problèmes': ['soucis', 'incidents', 'dysfonctionnements', 'défauts', 'ennuis', 'désagréments'],
  'incident': ['événement', 'problème', 'dysfonctionnement', 'souci', 'contretemps'],
  'incidents': ['événements', 'problèmes', 'dysfonctionnements', 'soucis', 'contretemps'],
  'dysfonctionnement': ['problème', 'incident', 'défaut', 'défaillance', 'souci'],
  'dysfonctionnements': ['problèmes', 'incidents', 'défauts', 'défaillances', 'soucis'],
  'défaut': ['problème', 'dysfonctionnement', 'vice', 'incident'],
  'défauts': ['problèmes', 'dysfonctionnements', 'vices', 'incidents'],
  'risque': ['danger', 'péril', 'aléa', 'menace'],
  'risques': ['dangers', 'périls', 'aléas', 'menaces'],
  'danger': ['risque', 'péril', 'menace', 'aléa'],
  'dangers': ['risques', 'périls', 'menaces', 'aléas'],

  'anomalie': ['irrégularité', 'défaillance', 'incohérence', 'aberration'],
  'anomalies': ['irrégularités', 'défaillances', 'incohérences', 'aberrations'],
  'irrégularité': ['anomalie', 'défaillance', 'incohérence', 'inexactitude'],
  'irrégularités': ['anomalies', 'défaillances', 'incohérences', 'inexactitudes'],
  'faille': ['vulnérabilité', 'brèche', 'faiblesse', 'lacune', 'défaut'],
  'failles': ['vulnérabilités', 'brèches', 'faiblesses', 'lacunes', 'défauts'],
  'erreur': ['inexactitude', 'méprise', 'faute', 'anomalie', 'irrégularité'],
  'erreurs': ['inexactitudes', 'méprises', 'fautes', 'anomalies', 'irrégularités'],
  'vulnérabilité': ['faille', 'faiblesse', 'brèche', 'défaut'],
  'vulnérabilités': ['failles', 'faiblesses', 'brèches', 'défauts'],
  'menace': ['danger', 'risque', 'péril', 'intimidation'],
  'menaces': ['dangers', 'risques', 'périls', 'intimidations'],

  'informations': ['données', 'renseignements', 'coordonnées', 'précisions', 'éléments'],
  'données': ['informations', 'renseignements', 'éléments', 'précisions', 'coordonnées'],
  'renseignements': ['informations', 'précisions', 'détails', 'coordonnées', 'éléments'],
  'précisions': ['détails', 'clarifications', 'informations', 'renseignements', 'éléments'],
  'coordonnées': ['informations', 'renseignements', 'données', 'éléments'],

  'détails': ['précisions', 'éléments', 'renseignements', 'informations', 'points'],
  'éléments': ['informations', 'renseignements', 'détails', 'précisions', 'points'],
  'document': ['fichier', 'formulaire', 'écrit', 'support'],
  'documents': ['fichiers', 'formulaires', 'écrits', 'supports'],
  'fichier': ['document', 'formulaire', 'support'],
  'fichiers': ['documents', 'formulaires', 'supports'],
  'formulaire': ['document', 'fichier', 'imprimé'],
  'formulaires': ['documents', 'fichiers', 'imprimés'],

  'compte': ['espace', 'profil', 'dossier', 'abonnement'],
  'comptes': ['espaces', 'profils', 'dossiers', 'abonnements'],
  'espace': ['compte', 'profil', 'dossier'],
  'espaces': ['comptes', 'profils', 'dossiers'],
  'profil': ['compte', 'espace', 'dossier', 'fiche'],
  'profils': ['comptes', 'espaces', 'dossiers', 'fiches'],
  'identifiant': ['code', 'référence', 'login'],
  'identifiants': ['codes', 'références', 'logins'],
  'dossier': ['compte', 'profil', 'fichier', 'document'],
  'dossiers': ['comptes', 'profils', 'fichiers', 'documents'],

  'connexion': ['liaison', 'ouverture', 'session'],
  'connexions': ['liaisons', 'ouvertures', 'sessions'],
  'session': ['connexion', 'séance'],
  'sessions': ['connexions', 'séances'],

  'services': ['prestations', 'offres', 'solutions', 'fonctions'],
  'prestations': ['services', 'offres', 'solutions', 'fournitures'],
  'solution': ['réponse', 'alternative', 'option', 'recours', 'issue'],
  'solutions': ['réponses', 'alternatives', 'options', 'recours', 'issues'],
  'option': ['choix', 'alternative', 'possibilité', 'faculté', 'variante'],
  'options': ['choix', 'alternatives', 'possibilités', 'facultés', 'variantes'],
  'offre': ['proposition', 'prestation', 'service', 'solution'],
  'offres': ['propositions', 'prestations', 'services', 'solutions'],

  'identification': ['authentification', 'reconnaissance', 'vérification', 'confirmation'],
  'authentification': ['identification', 'vérification', 'confirmation', 'certification'],
  'vérification': ['contrôle', 'authentification', 'inspection', 'confirmation', 'validation'],
  'vérifications': ['contrôles', 'inspections', 'confirmations', 'validations'],
  'validation': ['confirmation', 'approbation', 'homologation', 'ratification', 'certification'],
  'validations': ['confirmations', 'approbations', 'homologations', 'ratifications'],
  'confirmation': ['validation', 'attestation', 'approbation', 'ratification', 'certification'],
  'confirmations': ['validations', 'attestations', 'approbations', 'ratifications'],
  'certification': ['validation', 'homologation', 'attestation', 'authentification'],
  'certifications': ['validations', 'homologations', 'attestations'],
  'inspection': ['contrôle', 'examen', 'vérification', 'audit'],
  'inspections': ['contrôles', 'examens', 'vérifications', 'audits'],
  'reconnaissance': ['identification', 'authentification', 'validation'],

  'contrôle': ['vérification', 'examen', 'inspection', 'audit', 'supervision'],
  'contrôles': ['vérifications', 'examens', 'inspections', 'audits', 'supervisions'],
  'audit': ['contrôle', 'inspection', 'examen', 'vérification', 'analyse'],
  'audits': ['contrôles', 'inspections', 'examens', 'vérifications', 'analyses'],
  'examen': ['contrôle', 'inspection', 'analyse', 'étude', 'vérification'],
  'examens': ['contrôles', 'inspections', 'analyses', 'études', 'vérifications'],

  'moment': ['instant', 'temps'],
  'moments': ['instants', 'temps'],

  'échéance': ['date limite', 'expiration', 'date butoir'],
  'échéances': ['dates limites', 'dates butoirs'],
  'période': ['durée', 'phase', 'intervalle'],
  'périodes': ['durées', 'phases', 'intervalles'],
  'durée': ['période', 'phase'],
  'durées': ['périodes', 'phases'],
  'date': ['échéance', 'jour'],
  'dates': ['échéances', 'jours'],

  'équipe': ['cellule', 'unité'],
  'équipes': ['cellules', 'unités'],
  'département': ['service', 'bureau', 'pôle', 'division', 'section'],
  'départements': ['services', 'bureaux', 'pôles', 'divisions', 'sections'],
  'bureau': ['service', 'département', 'agence', 'cabinet'],
  'bureaux': ['services', 'départements', 'agences', 'cabinets'],
  'division': ['département', 'section', 'branche', 'unité'],
  'divisions': ['départements', 'sections', 'branches', 'unités'],
  'section': ['département', 'division', 'branche', 'partie'],
  'sections': ['départements', 'divisions', 'branches', 'parties'],

  'assistance': ['aide', 'appui', 'accompagnement', 'entraide'],
  'aide': ['assistance', 'appui', 'accompagnement', 'entraide'],

  'support': ['appui', 'accompagnement', 'soutien', 'renfort'],
  'soutien': ['appui', 'accompagnement', 'support', 'renfort'],
  'accompagnement': ['suivi', 'soutien', 'appui', 'assistance', 'encadrement'],
  'appui': ['support', 'soutien', 'accompagnement', 'assistance', 'aide'],

  'plateforme': ['interface', 'infrastructure'],
  'plateformes': ['interfaces', 'infrastructures'],
  'interface': ['plateforme', 'panneau'],
  'application': ['logiciel', 'programme', 'outil', 'appli'],
  'applications': ['logiciels', 'programmes', 'outils', 'applis'],
  'page': ['écran', 'interface', 'onglet'],
  'pages': ['écrans', 'interfaces', 'onglets'],

  'site': ['portail', 'espace'],
  'sites': ['portails', 'espaces'],
  'portail': ['site', 'espace'],
  'portails': ['sites', 'espaces'],
  'logiciel': ['programme', 'outil', 'application', 'utilitaire'],
  'logiciels': ['programmes', 'outils', 'applications', 'utilitaires'],
  'programme': ['logiciel', 'application', 'outil'],
  'programmes': ['logiciels', 'applications', 'outils'],
  'système': ['dispositif', 'mécanisme', 'infrastructure'],
  'systèmes': ['dispositifs', 'mécanismes', 'infrastructures'],
  'outil': ['logiciel', 'programme', 'application', 'utilitaire'],
  'outils': ['logiciels', 'programmes', 'applications', 'utilitaires'],

  'email': ['courriel', 'mail', 'message'],
  'emails': ['courriels', 'mails', 'messages'],
  'courriel': ['email', 'mail', 'message'],
  'courriels': ['emails', 'mails', 'messages'],
  'message': ['courriel', 'communication', 'notification', 'email'],
  'messages': ['courriels', 'communications', 'notifications', 'emails'],
  'notification': ['message', 'alerte', 'communication', 'avis', 'signalement'],
  'notifications': ['messages', 'alertes', 'communications', 'avis', 'signalements'],
  'communication': ['message', 'notification', 'échange', 'information', 'avis'],
  'communications': ['messages', 'notifications', 'échanges', 'informations', 'avis'],
  'alerte': ['notification', 'avertissement', 'signal', 'avis'],
  'alertes': ['notifications', 'avertissements', 'signaux', 'avis'],
  'avis': ['notification', 'message', 'communication', 'annonce'],

  'client': ['utilisateur', 'abonné', 'usager', 'membre'],
  'clients': ['utilisateurs', 'abonnés', 'usagers', 'membres'],
  'utilisateur': ['client', 'usager', 'abonné', 'membre', 'internaute'],
  'utilisateurs': ['clients', 'usagers', 'abonnés', 'membres', 'internautes'],
  'abonné': ['client', 'membre', 'adhérent', 'usager', 'souscripteur'],
  'abonnés': ['clients', 'membres', 'adhérents', 'usagers', 'souscripteurs'],
  'membre': ['adhérent', 'abonné', 'inscrit', 'affilié'],
  'membres': ['adhérents', 'abonnés', 'inscrits', 'affiliés'],
  'usager': ['utilisateur', 'client', 'abonné'],
  'usagers': ['utilisateurs', 'clients', 'abonnés'],

  'sécurité': ['protection', 'sûreté', 'sauvegarde'],
  'protection': ['sécurité', 'sauvegarde', 'préservation'],
  'sûreté': ['sécurité', 'protection', 'fiabilité'],
  'confidentialité': ['discrétion', 'secret'],
  'intégrité': ['authenticité', 'exactitude'],
  'fiabilité': ['crédibilité', 'sûreté', 'solidité'],

  'entreprise': ['société', 'compagnie', 'structure', 'firme', 'maison'],
  'entreprises': ['sociétés', 'compagnies', 'structures', 'firmes', 'maisons'],
  'société': ['entreprise', 'compagnie', 'structure', 'firme'],
  'sociétés': ['entreprises', 'compagnies', 'structures', 'firmes'],
  'compagnie': ['entreprise', 'société', 'firme'],
  'compagnies': ['entreprises', 'sociétés', 'firmes'],
  'organisation': ['structure', 'entité', 'organisme'],
  'organisations': ['structures', 'entités', 'organismes'],
  'institution': ['organisme', 'établissement', 'entité', 'organisation'],
  'institutions': ['organismes', 'établissements', 'entités', 'organisations'],
  'agence': ['bureau', 'antenne', 'succursale'],
  'agences': ['bureaux', 'antennes', 'succursales'],
  'structure': ['organisation', 'entité', 'organisme'],
  'structures': ['organisations', 'entités', 'organismes'],

  'organisme': ['établissement', 'organisation', 'institution', 'entité'],
  'organismes': ['établissements', 'organisations', 'institutions', 'entités'],
  'établissement': ['organisme', 'institution', 'structure'],
  'établissements': ['organismes', 'institutions', 'structures'],

  'demande': ['requête', 'sollicitation', 'question'],
  'demandes': ['requêtes', 'sollicitations', 'questions'],
  'requête': ['demande', 'sollicitation', 'question'],
  'requêtes': ['demandes', 'sollicitations', 'questions'],
  'procédure': ['démarche', 'marche à suivre', 'méthode', 'protocole'],
  'procédures': ['démarches', 'méthodes', 'protocoles'],
  'démarche': ['procédure', 'approche', 'méthode', 'action'],
  'démarches': ['procédures', 'approches', 'méthodes', 'actions'],
  'méthode': ['approche', 'manière', 'procédé', 'procédure', 'technique'],
  'méthodes': ['approches', 'manières', 'procédés', 'procédures', 'techniques'],
  'condition': ['clause', 'modalité', 'critère', 'exigence', 'stipulation'],
  'conditions': ['clauses', 'modalités', 'critères', 'exigences', 'stipulations'],
  'exigence': ['obligation', 'condition', 'requête', 'nécessité'],
  'exigences': ['obligations', 'conditions', 'requêtes', 'nécessités'],
  'obligation': ['exigence', 'contrainte', 'devoir', 'engagement', 'nécessité'],
  'obligations': ['exigences', 'contraintes', 'devoirs', 'engagements', 'nécessités'],
  'convention': ['accord', 'entente', 'contrat', 'pacte'],
  'conventions': ['accords', 'ententes', 'contrats', 'pactes'],
  'modalité': ['condition', 'clause', 'critère', 'manière'],
  'modalités': ['conditions', 'clauses', 'critères', 'manières'],
  'clause': ['condition', 'modalité', 'stipulation', 'critère'],
  'clauses': ['conditions', 'modalités', 'stipulations', 'critères'],

  'processus': ['mécanisme', 'déroulement', 'procédé', 'cheminement'],
  'engagement': ['obligation', 'promesse', 'devoir'],
  'engagements': ['obligations', 'promesses', 'devoirs'],
  'contrat': ['accord', 'convention', 'entente', 'pacte'],
  'contrats': ['accords', 'conventions', 'ententes', 'pactes'],
  'accord': ['entente', 'convention', 'pacte', 'contrat'],
  'accords': ['ententes', 'conventions', 'pactes', 'contrats'],
  'critère': ['condition', 'clause', 'exigence', 'modalité'],
  'critères': ['conditions', 'clauses', 'exigences', 'modalités'],



  'associées': ['liées', 'rattachées', 'relatives', 'attachées', 'reliées', 'connectées'],
  'liées': ['associées', 'rattachées', 'attachées', 'reliées', 'connectées', 'relatives'],
  'rattachées': ['liées', 'associées', 'attachées', 'reliées', 'connectées'],
  'relatives': ['associées', 'liées', 'rattachées', 'attachées', 'concernant'],

  'associés': ['liés', 'rattachés', 'relatifs', 'attachés', 'reliés', 'connectés'],
  'liés': ['associés', 'rattachés', 'attachés', 'reliés', 'connectés', 'relatifs'],
  'rattachés': ['liés', 'associés', 'attachés', 'reliés', 'connectés'],
  'relatifs': ['associés', 'liés', 'rattachés', 'attachés'],

  'associé': ['lié', 'rattaché', 'relatif', 'attaché', 'relié', 'connecté'],
  'associée': ['liée', 'rattachée', 'relative', 'attachée', 'reliée', 'connectée'],
  'lié': ['associé', 'rattaché', 'attaché', 'relié', 'connecté', 'relatif'],
  'liée': ['associée', 'rattachée', 'attachée', 'reliée', 'connectée', 'relative'],

  'numérique': ['digital', 'informatique', 'électronique', 'en ligne', 'dématérialisé'],
  'numériques': ['digitaux', 'informatiques', 'électroniques', 'dématérialisés'],
  'digital': ['numérique', 'électronique', 'informatique', 'dématérialisé'],
  'digitale': ['numérique', 'électronique', 'informatique', 'dématérialisée'],
  'digitaux': ['numériques', 'électroniques', 'informatiques', 'dématérialisés'],
  'informatique': ['numérique', 'digital', 'électronique'],
  'informatiques': ['numériques', 'digitaux', 'électroniques'],
  'électronique': ['numérique', 'digital', 'informatique', 'dématérialisé'],
  'électroniques': ['numériques', 'digitaux', 'informatiques', 'dématérialisés'],

  'moderne': ['récent', 'actuel', 'contemporain', 'nouveau', 'innovant'],
  'modernes': ['récents', 'actuels', 'contemporains', 'nouveaux', 'innovants'],
  'récent': ['nouveau', 'moderne', 'actuel', 'contemporain', 'neuf'],
  #'récente': ['nouvelle', 'moderne', 'actuelle', 'contemporaine', 'neuve'],
  'récents': ['nouveaux', 'modernes', 'actuels', 'contemporains', 'neufs'],
  #'récentes': ['nouvelles', 'modernes', 'actuelles', 'contemporaines', 'neuves'],
  'nouveau': ['récent', 'neuf', 'moderne', 'inédit'],
  #'nouvelle': ['récente', 'neuve', 'moderne', 'inédite'],
  'nouveaux': ['récents', 'neufs', 'modernes', 'inédits'],
  #'nouvelles': ['récentes', 'neuves', 'modernes', 'inédites'],
  'actuel': ['récent', 'moderne', 'contemporain', 'présent'],
  'actuelle': ['récente', 'moderne', 'contemporaine', 'présente'],

  'actif': ['ouvert', 'fonctionnel', 'valide', 'opérationnel', 'en cours', 'utilisable'],
  'active': ['ouverte', 'fonctionnelle', 'valide', 'opérationnelle', 'en cours', 'utilisable'],
  'actifs': ['ouverts', 'fonctionnels', 'valides', 'opérationnels', 'utilisables'],
  'actives': ['ouvertes', 'fonctionnelles', 'valides', 'opérationnelles', 'utilisables'],
  'inactif': ['fermé', 'suspendu', 'invalide', 'bloqué', 'désactivé', 'inutilisable'],
  'inactive': ['fermée', 'suspendue', 'invalide', 'bloquée', 'désactivée', 'inutilisable'],
  'inactifs': ['fermés', 'suspendus', 'invalides', 'bloqués', 'désactivés', 'inutilisables'],
  'inactives': ['fermées', 'suspendues', 'invalides', 'bloquées', 'désactivées', 'inutilisables'],

  'disponible': ['accessible'],
  'disponibles': ['accessibles', 'libres', 'ouverts', 'joignables'],
  'accessible': ['disponible', 'utilisable', 'ouvert', 'atteignable', 'joignable'],
  'accessibles': ['disponibles',  'ouverts', 'atteignables', 'joignables'],

  'fonctionnel': ['opérationnel', 'actif', 'utilisable', 'performant'],
  'fonctionnelle': ['opérationnelle', 'active', 'utilisable', 'performante'],
  'fonctionnels': ['opérationnels', 'actifs', 'utilisables', 'performants'],
  'fonctionnelles': ['opérationnelles', 'actives', 'utilisables', 'performantes'],
  'opérationnel': ['fonctionnel', 'actif', 'utilisable', 'prêt'],
  'opérationnelle': ['fonctionnelle', 'active', 'utilisable', 'prête'],
  'opérationnels': ['fonctionnels', 'actifs', 'utilisables', 'prêts'],
  'opérationnelles': ['fonctionnelles', 'actives', 'utilisables', 'prêtes'],

  'valide': ['valable', 'légitime', 'conforme', 'recevable', 'reconnu'],
  'valides': ['valables', 'légitimes', 'conformes', 'recevables', 'reconnus'],
  'valable': ['valide', 'légitime', 'conforme', 'recevable', 'acceptable'],
  'valables': ['valides', 'légitimes', 'conformes', 'recevables', 'acceptables'],
  'expiré': ['périmé', 'échu', 'dépassé', 'obsolète', 'caduc'],
  'expirée': ['périmée', 'échue', 'dépassée', 'obsolète', 'caduque'],
  'expirés': ['périmés', 'échus', 'dépassés', 'obsolètes', 'caducs'],
  'expirées': ['périmées', 'échues', 'dépassées', 'obsolètes', 'caduques'],
  'obsolète': ['dépassé', 'périmé', 'ancien', 'désuet', 'caduc'],
  'obsolètes': ['dépassés', 'périmés', 'anciens', 'désuets', 'caducs'],
  'conforme': ['valide', 'valable', 'régulier', 'correct'],
  'conformes': ['valides', 'valables', 'réguliers', 'corrects'],

  'officiel': ['certifié', 'authentique', 'homologué', 'attesté', 'reconnu', 'validé'],
  'officiels': ['certifiés', 'authentiques', 'homologués', 'attestés', 'reconnus', 'validés'],
  'officielle': ['certifiée', 'authentique', 'homologuée', 'attestée', 'reconnue', 'validée'],
  'officielles': ['certifiées', 'authentiques', 'homologuées', 'attestées', 'reconnues', 'validées'],
  'authentique': ['véritable', 'officiel', 'certifié', 'attesté', 'original', 'légitime'],
  'authentiques': ['véritables', 'officiels', 'certifiés', 'attestés', 'originaux', 'légitimes'],
  'certifié': ['authentique', 'officiel', 'homologué', 'attesté', 'reconnu', 'validé'],
  'certifiée': ['authentique', 'officielle', 'homologuée', 'attestée', 'reconnue', 'validée'],
  'certifiés': ['authentiques', 'officiels', 'homologués', 'attestés', 'reconnus', 'validés'],
  'certifiées': ['authentiques', 'officielles', 'homologuées', 'attestées', 'reconnues', 'validées'],
  'homologué': ['certifié', 'validé', 'approuvé', 'officiel', 'attesté', 'reconnu'],
  'homologuée': ['certifiée', 'validée', 'approuvée', 'officielle', 'attestée', 'reconnue'],
  'homologués': ['certifiés', 'validés', 'approuvés', 'officiels', 'attestés', 'reconnus'],
  'homologuées': ['certifiées', 'validées', 'approuvées', 'officielles', 'attestées', 'reconnues'],
  'approuvé': ['validé', 'entériné', 'homologué', 'accepté', 'agréé', 'ratifié'],
  'approuvée': ['validée', 'entérinée', 'homologuée', 'acceptée', 'agréée', 'ratifiée'],
  'approuvés': ['validés', 'entérinés', 'homologués', 'acceptés', 'agréés', 'ratifiés'],
  'approuvées': ['validées', 'entérinées', 'homologuées', 'acceptées', 'agréées', 'ratifiées'],
  'légitime': ['valable', 'fondé', 'reconnu', 'valide', 'justifié'],
  'légitimes': ['valables', 'fondés', 'reconnus', 'valides', 'justifiés'],

  'sécurisé': ['protégé', 'fiable', 'sûr', 'préservé'],
  'sécurisée': ['protégée', 'fiable', 'sûre', 'préservée'],
  'sécurisés': ['protégés', 'fiables', 'sûrs', 'préservés'],
  'sécurisées': ['protégées', 'fiables', 'sûres', 'préservées'],
  'protégé': ['sécurisé', 'préservé', 'défendu', 'sauvegardé'],
  'protégée': ['sécurisée', 'préservée', 'défendue', 'sauvegardée'],
  'protégés': ['sécurisés', 'préservés', 'défendus', 'sauvegardés'],
  'protégées': ['sécurisées', 'préservées', 'défendues', 'sauvegardées'],
  'confidentiel': ['privé', 'discret', 'protégé', 'secret', 'personnel'],
  'confidentielle': ['privée', 'discrète', 'protégée', 'secrète', 'personnelle'],
  'confidentiels': ['privés', 'discrets', 'protégés', 'secrets', 'personnels'],
  'confidentielles': ['privées', 'discrètes', 'protégées', 'secrètes', 'personnelles'],
  'sensible': ['critique'],
  'sensibles': ['critiques'],
  'fiable': ['sûr', 'sécurisé', 'solide', 'crédible', 'sérieux'],
  'fiables': ['sûrs', 'sécurisés', 'solides', 'crédibles', 'sérieux'],

  'fluide': ['efficace', 'souple'],
  'fluides': ['efficaces', 'souples'],
  'efficace': ['performant', 'concluant', 'fluide', 'productif', 'opérationnel'],
  'efficaces': ['performants', 'concluants', 'fluides', 'productifs', 'opérationnels'],
  'performant': ['efficace', 'productif', 'opérationnel', 'concluant'],
  'performants': ['efficaces', 'productifs', 'opérationnels', 'concluants'],
  'performante': ['efficace', 'productive', 'opérationnelle', 'concluante'],
  'performantes': ['efficaces', 'productives', 'opérationnelles', 'concluantes'],

  'personnel': ['privé', 'individuel', 'particulier', 'propre'],
  'personnels': ['privés', 'individuels', 'particuliers', 'propres'],
  'personnelle': ['privée', 'individuelle', 'particulière', 'propre'],
  'personnelles': ['privées', 'individuelles', 'confidentielles', 'particulières', 'propres'],
  'privé': ['personnel', 'confidentiel', 'individuel', 'particulier'],
  'privée': ['personnelle', 'confidentielle', 'individuelle', 'particulière'],
  'privés': ['personnels', 'confidentiels', 'individuels', 'particuliers'],
  'privées': ['personnelles', 'confidentielles', 'individuelles', 'particulières'],
  'individuel': ['personnel', 'particulier', 'propre', 'privé', 'singulier'],
  'individuelle': ['personnelle', 'particulière', 'propre', 'privée', 'singulière'],
  'individuels': ['personnels', 'particuliers', 'propres', 'privés', 'singuliers'],
  'individuelles': ['personnelles', 'particulières', 'propres', 'privées', 'singulières'],
  'particulier': ['personnel', 'privé', 'individuel', 'propre', 'spécifique'],
  'particulière': ['personnelle', 'privée', 'individuelle', 'propre', 'spécifique'],
  'particuliers': ['personnels', 'privés', 'individuels', 'propres', 'spécifiques'],
  'particulières': ['personnelles', 'privées', 'individuelles', 'propres', 'spécifiques'],
  'spécifique': ['particulier', 'précis', 'défini', 'propre', 'concret'],
  'spécifiques': ['particuliers', 'précis', 'définis', 'propres', 'concrets'],
  'précis': ['exact', 'spécifique', 'défini', 'concret', 'clair'],
  'précise': ['exacte', 'spécifique', 'définie', 'concrète', 'claire'],

  'important': ['essentiel', 'majeur', 'significatif', 'considérable', 'notable', 'crucial'],
  'importante': ['essentielle', 'majeure', 'significative', 'considérable', 'notable', 'cruciale'],
  'importants': ['essentiels', 'majeurs', 'significatifs', 'considérables', 'notables', 'cruciaux'],
  'importantes': ['essentielles', 'majeures', 'significatives', 'considérables', 'notables', 'cruciales'],
  'essentiel': ['fondamental', 'capital', 'primordial', 'crucial', 'indispensable', 'majeur'],
  'essentielle': ['fondamentale', 'capitale', 'primordiale', 'cruciale', 'indispensable', 'majeure'],
  'essentiels': ['fondamentaux', 'capitaux', 'primordiaux', 'cruciaux', 'indispensables', 'majeurs'],
  'essentielles': ['fondamentales', 'capitales', 'primordiales', 'cruciales', 'indispensables', 'majeures'],
  'majeur': ['important', 'considérable', 'essentiel', 'principal', 'notable'],
  'majeure': ['importante', 'considérable', 'essentielle', 'principale', 'notable'],
  'majeurs': ['importants', 'considérables', 'essentiels', 'principaux', 'notables'],
  'majeures': ['importantes', 'considérables', 'essentielles', 'principales', 'notables'],
  'primordial': ['essentiel', 'fondamental', 'capital', 'crucial', 'majeur'],
  'primordiale': ['essentielle', 'fondamentale', 'capitale', 'cruciale', 'majeure'],
  'primordiaux': ['essentiels', 'fondamentaux', 'capitaux', 'cruciaux', 'majeurs'],
  'primordiales': ['essentielles', 'fondamentales', 'capitales', 'cruciales', 'majeures'],
  'fondamental': ['essentiel', 'capital', 'primordial', 'crucial', 'majeur'],
  'fondamentale': ['essentielle', 'capitale', 'primordiale', 'cruciale', 'majeure'],
  'fondamentaux': ['essentiels', 'capitaux', 'primordiaux', 'cruciaux', 'majeurs'],
  'fondamentales': ['essentielles', 'capitales', 'primordiales', 'cruciales', 'majeures'],
  'crucial': ['essentiel', 'capital', 'décisif', 'primordial', 'critique'],
  'cruciale': ['essentielle', 'capitale', 'décisive', 'primordiale', 'critique'],
  'cruciaux': ['essentiels', 'capitaux', 'décisifs', 'primordiaux', 'critiques'],
  'cruciales': ['essentielles', 'capitales', 'décisives', 'primordiales', 'critiques'],
  'capital': ['essentiel', 'fondamental', 'primordial', 'crucial', 'majeur'],
  'capitale': ['essentielle', 'fondamentale', 'primordiale', 'cruciale', 'majeure'],
  'significatif': ['notable', 'considérable', 'important', 'remarquable'],
  'significative': ['notable', 'considérable', 'importante', 'remarquable'],
  'significatifs': ['notables', 'considérables', 'importants', 'remarquables'],
  'significatives': ['notables', 'considérables', 'importantes', 'remarquables'],
  'notable': ['significatif', 'remarquable', 'considérable', 'important'],
  'notables': ['significatifs', 'remarquables', 'considérables', 'importants'],
  'considérable': ['important', 'majeur', 'notable', 'significatif', 'substantiel'],
  'considérables': ['importants', 'majeurs', 'notables', 'significatifs', 'substantiels'],
  'principal': ['majeur', 'essentiel', 'central', 'premier', 'primordial'],
  'principale': ['majeure', 'essentielle', 'centrale', 'première', 'primordiale'],
  'principaux': ['majeurs', 'essentiels', 'centraux', 'premiers', 'primordiaux'],
  'principales': ['majeures', 'essentielles', 'centrales', 'premières', 'primordiales'],

  'impératif': ['essentiel', 'nécessaire', 'indispensable', 'obligatoire', 'primordial', 'requis', 'crucial'],
  'impérative': ['essentielle', 'nécessaire', 'indispensable', 'obligatoire', 'primordiale', 'requise', 'cruciale'],
  'impératifs': ['essentiels', 'nécessaires', 'indispensables', 'obligatoires', 'primordiaux', 'requis', 'cruciaux'],
  'impératives': ['essentielles', 'nécessaires', 'indispensables', 'obligatoires', 'primordiales', 'requises', 'cruciales'],
  'nécessaire': ['indispensable', 'obligatoire', 'essentiel', 'requis', 'impératif', 'utile', 'primordial'],
  'nécessaires': ['indispensables', 'obligatoires', 'essentiels', 'requis', 'impératifs', 'utiles', 'primordiaux'],
  'obligatoire': ['impératif', 'nécessaire', 'indispensable', 'requis', 'imposé', 'essentiel'],
  'obligatoires': ['impératifs', 'nécessaires', 'indispensables', 'requis', 'imposés', 'essentiels'],
  'requis': ['nécessaire', 'obligatoire', 'demandé', 'attendu', 'impératif', 'exigé'],
  'requise': ['nécessaire', 'obligatoire', 'demandée', 'attendue', 'impérative', 'exigée'],
  'indispensable': ['essentiel', 'nécessaire', 'obligatoire', 'impératif', 'primordial', 'crucial'],
  'indispensables': ['essentiels', 'nécessaires', 'obligatoires', 'impératifs', 'primordiaux', 'cruciaux'],

  'urgent': ['pressant', 'prioritaire', 'immédiat', 'critique', 'impératif'],
  'urgente': ['pressante', 'prioritaire', 'immédiate', 'critique', 'impérative'],
  'urgents': ['pressants', 'prioritaires', 'immédiats', 'critiques', 'impératifs'],
  'urgentes': ['pressantes', 'prioritaires', 'immédiates', 'critiques', 'impératives'],
  'immédiat': ['instantané', 'direct', 'urgent', 'prompt'],
  'immédiate': ['instantanée', 'directe', 'urgente', 'prompte'],
  'immédiats': ['instantanés', 'directs', 'urgents', 'prompts'],
  'immédiates': ['instantanées', 'directes', 'urgentes', 'promptes'],
  'pressant': ['urgent', 'impératif', 'prioritaire'],
  'pressante': ['urgente', 'impérative', 'prioritaire'],
  'critique': ['grave'],
  'critiques': ['graves'],
  'grave': ['sérieux', 'sévère', 'critique', 'important'],
  'graves': ['sérieux', 'sévères', 'critiques', 'importants'],
  'prioritaire': ['urgent', 'principal', 'essentiel', 'impératif'],
  'prioritaires': ['urgents', 'principaux', 'essentiels', 'impératifs'],

  'complet': ['entier', 'intégral', 'exhaustif', 'total', 'plein'],
  'complète': ['entière', 'intégrale', 'exhaustive', 'totale', 'pleine'],
  'complets': ['entiers', 'intégraux', 'exhaustifs', 'totaux', 'pleins'],
  'complètes': ['entières', 'intégrales', 'exhaustives', 'totales', 'pleines'],
  'total': ['complet', 'entier', 'intégral', 'global', 'plein'],
  'totale': ['complète', 'entière', 'intégrale', 'globale', 'pleine'],
  'totaux': ['complets', 'entiers', 'intégraux', 'globaux', 'pleins'],
  'totales': ['complètes', 'entières', 'intégrales', 'globales', 'pleines'],
  'entier': ['complet', 'total', 'intégral', 'plein'],
  'entière': ['complète', 'totale', 'intégrale', 'pleine'],
  'entiers': ['complets', 'totaux', 'intégraux', 'pleins'],
  'entières': ['complètes', 'totales', 'intégrales', 'pleines'],
  'clair': ['évident', 'précis', 'compréhensible', 'limpide', 'net'],
  'claire': ['évidente', 'précise', 'compréhensible', 'limpide', 'nette'],
  'clairs': ['évidents', 'précis', 'compréhensibles', 'limpides', 'nets'],
  'claires': ['évidentes', 'précises', 'compréhensibles', 'limpides', 'nettes'],
  'évident': ['clair', 'manifeste', 'apparent', 'flagrant', 'incontestable'],
  'évidente': ['claire', 'manifeste', 'apparente', 'flagrante', 'incontestable'],
  'évidents': ['clairs', 'manifestes', 'apparents', 'flagrants', 'incontestables'],
  'évidentes': ['claires', 'manifestes', 'apparentes', 'flagrantes', 'incontestables'],
  'simple': ['basique', 'élémentaire', 'facile', 'aisé'],
  'simples': ['basiques', 'élémentaires', 'faciles', 'aisés'],
  'facile': ['simple', 'aisé', 'accessible', 'commode', 'praticable'],
  'faciles': ['simples', 'aisés', 'accessibles', 'commodes', 'praticables'],
  'rapide': ['prompt', 'immédiat', 'expéditif', 'accéléré', 'véloce'],
  'rapides': ['prompts', 'immédiats', 'expéditifs', 'accélérés', 'véloces'],



  'afin de': ['pour', 'en vue de', 'dans le but de', 'de façon à', 'de manière à', 'dans l\'objectif de'],
  'afin que': ['pour que', 'de sorte que', 'de manière que', 'de façon que'],
  'pour que': ['afin que', 'de sorte que', 'de manière que', 'de façon que'],
  'en vue de': ['afin de', 'pour', 'dans le but de', 'dans l\'objectif de', 'de manière à'],
  'dans le but de': ['afin de', 'en vue de', 'pour', 'dans l\'objectif de', 'de manière à'],
  'de façon à': ['afin de', 'de manière à', 'pour', 'en vue de'],
  'de manière à': ['afin de', 'de façon à', 'pour', 'en vue de'],

  'en raison de': ['du fait de', 'suite à', 'compte tenu de', 'à cause de', 'en conséquence de'],
  'du fait de': ['en raison de', 'suite à', 'compte tenu de', 'à cause de'],
  'suite à': ['à la suite de', 'consécutivement à', 'après', 'en raison de', 'du fait de'],
  'à la suite de': ['suite à', 'consécutivement à', 'après', 'en raison de'],
  'compte tenu de': ['en raison de', 'du fait de', 'étant donné', 'eu égard à', 'vu'],
  'grâce à': ['au moyen de', 'par le biais de', 'par l\'intermédiaire de', 'via', 'moyennant'],
  'au moyen de': ['grâce à', 'par le biais de', 'via', 'par l\'intermédiaire de', 'moyennant'],
  'par le biais de': ['au moyen de', 'via', 'par l\'intermédiaire de', 'grâce à', 'moyennant'],
  'par conséquent': ['ainsi', 'dès lors', 'de ce fait', 'en conséquence', 'donc'],
  'de ce fait': ['ainsi', 'par conséquent', 'dès lors', 'en conséquence'],
  'dès lors': ['par conséquent', 'ainsi', 'de ce fait', 'en conséquence'],

  'en cas de': ['dans l\'éventualité de', 'lors de', 'advenant', 'si'],
  'pour toute': ['concernant toute', 'en cas de', 'relativement à toute', 'quant à toute'],
  'pour tout': ['concernant tout', 'relativement à tout', 'quant à tout', 'en cas de'],

  'concernant': ['relatif à', 'au sujet de', 'à propos de', 'quant à', 'relativement à', 'touchant'],
  'au sujet de': ['concernant', 'à propos de', 'quant à', 'relativement à'],
  'à propos de': ['concernant', 'au sujet de', 'quant à', 'relativement à'],
  'relativement à': ['concernant', 'quant à', 'à propos de', 'au sujet de'],

  'notamment': ['en particulier', 'spécialement', 'précisément', 'entre autres', 'surtout'],
  'en particulier': ['notamment', 'spécifiquement', 'précisément', 'surtout', 'entre autres'],

  'toutefois': ['cependant', 'néanmoins', 'pourtant', 'malgré tout'],
  'cependant': ['toutefois', 'néanmoins', 'pourtant', 'malgré tout'],
  'néanmoins': ['cependant', 'toutefois', 'pourtant', 'malgré tout'],
  'pourtant': ['cependant', 'toutefois', 'néanmoins', 'malgré tout'],

  'de plus': ['en outre', 'également', 'par ailleurs', 'aussi', 'de surcroît'],
  'en outre': ['de plus', 'également', 'par ailleurs', 'aussi', 'de surcroît'],
  'par ailleurs': ['de plus', 'en outre', 'également', 'aussi', 'd\'autre part'],



  'rapidement': ['vite', 'promptement', 'sans tarder', 'au plus vite', 'sans délai', 'immédiatement'],
  'vite': ['rapidement', 'promptement', 'sans délai', 'sans tarder', 'au plus vite'],
  'immédiatement': ['aussitôt', 'sur-le-champ', 'sans délai', 'instantanément', 'tout de suite'],
  'aussitôt': ['immédiatement', 'sur-le-champ', 'sans tarder', 'instantanément', 'tout de suite'],
  'promptement': ['rapidement', 'vite', 'sans tarder', 'sans délai', 'diligemment'],
  'progressivement': ['graduellement', 'peu à peu', 'par étapes', 'petit à petit'],
  'graduellement': ['progressivement', 'peu à peu', 'par degrés', 'petit à petit'],

  'actuellement': ['à présent', 'à ce jour', 'à l\'heure actuelle', 'aujourd\'hui', 'maintenant'],
  'maintenant': ['à présent', 'désormais', 'à l\'heure actuelle', 'actuellement', 'aujourd\'hui'],
  'désormais': ['dorénavant', 'dès à présent', 'à partir de maintenant', 'à l\'avenir'],
  'dorénavant': ['désormais', 'dès à présent', 'à partir de maintenant', 'à l\'avenir'],
  'auparavant': ['précédemment', 'antérieurement', 'avant', 'préalablement'],
  'précédemment': ['auparavant', 'antérieurement', 'avant', 'préalablement'],
  'ensuite': ['puis', 'par la suite', 'consécutivement', 'après', 'ultérieurement'],
  'puis': ['ensuite', 'par la suite', 'après'],
  'bientôt': ['prochainement', 'sous peu', 'd\'ici peu', 'incessamment'],
  'prochainement': ['bientôt', 'sous peu', 'd\'ici peu', 'incessamment'],
  'toujours': ['constamment', 'continuellement', 'en permanence', 'sans cesse', 'perpétuellement'],
  'souvent': ['fréquemment', 'régulièrement', 'habituellement', 'communément', 'ordinairement'],
  'parfois': ['quelquefois', 'occasionnellement', 'à l\'occasion', 'par moments', 'de temps à autre'],
  'rarement': ['peu souvent', 'exceptionnellement', 'occasionnellement', 'de temps à autre'],

  'très': ['particulièrement', 'extrêmement', 'fort', 'grandement', 'hautement'],
  'extrêmement': ['très', 'particulièrement', 'infiniment', 'excessivement', 'grandement'],
  'particulièrement': ['spécialement', 'notamment', 'précisément', 'singulièrement', 'surtout'],
  'énormément': ['considérablement', 'grandement', 'excessivement', 'largement', 'beaucoup'],
  'beaucoup': ['grandement', 'considérablement', 'largement', 'énormément', 'amplement'],
  'complètement': ['totalement', 'entièrement', 'intégralement', 'absolument', 'pleinement'],
  'totalement': ['complètement', 'entièrement', 'intégralement', 'absolument', 'pleinement'],
  'entièrement': ['complètement', 'totalement', 'intégralement', 'absolument', 'pleinement'],
  'absolument': ['totalement', 'complètement', 'catégoriquement', 'formellement', 'entièrement'],
  'intégralement': ['complètement', 'totalement', 'entièrement', 'pleinement'],
  'pleinement': ['complètement', 'totalement', 'entièrement', 'intégralement'],

  'clairement': ['nettement', 'distinctement', 'précisément', 'manifestement'],
  'précisément': ['exactement', 'spécifiquement', 'clairement', 'nettement'],
  'exactement': ['précisément', 'rigoureusement', 'strictement', 'parfaitement'],
  'facilement': ['aisément', 'sans peine', 'simplement', 'commodément'],
  'aisément': ['facilement', 'sans peine', 'simplement', 'commodément'],
  'directement': ['sans intermédiaire', 'personnellement', 'immédiatement'],
  'automatiquement': ['systématiquement', 'spontanément', 'mécaniquement'],
  'systématiquement': ['automatiquement', 'invariablement', 'régulièrement', 'méthodiquement'],
  'gratuitement': ['sans frais', 'à titre gracieux', 'librement'],

  'environ': ['approximativement', 'à peu près', 'aux alentours de', 'quelque', 'de l\'ordre de'],
  'approximativement': ['environ', 'à peu près', 'presque', 'aux alentours de'],
  'presque': ['quasiment', 'à peu près', 'pratiquement', 'quasi'],
  'quasiment': ['presque', 'pratiquement', 'quasi', 'à peu près']
};


# ─────────────────────────────────────────────────────
# FONCTION DE REFORMULATION (portage fidèle du JS)
# ─────────────────────────────────────────────────────
def reformulate_text(text):
    """Reformule un texte en remplaçant aléatoirement des mots/locutions par des synonymes.
    Portage fidèle de reformulateText() du JS (même logique : 50% de chance par remplacement)."""
    if not text:
        return text

    # 1. Précalcul : sépare les clés multi-mots des mono-mots
    #    Triés par longueur décroissante pour éviter qu'une clé courte n'avale une longue
    multi_word_keys = sorted(
        [k for k in SYNONYMS.keys() if ' ' in k],
        key=lambda k: len(k),
        reverse=True
    )

    reformulated = text

    # 2. Remplacement des locutions multi-mots (insensible à la casse, 50% de chance)
    for key in multi_word_keys:
        escaped = re.escape(key)
        pattern = re.compile(r'\b' + escaped + r'\b', re.IGNORECASE)

        def replace_multi(match):
            if random.random() >= 0.5:
                return match.group(0)  # pas de remplacement cette fois
            synonyms = SYNONYMS[key]
            chosen = random.choice(synonyms)
            # Respecte la casse initiale
            if match.group(0)[0].isupper():
                return chosen[0].upper() + chosen[1:]
            return chosen

        reformulated = pattern.sub(replace_multi, reformulated)

    # 3. Traitement mot-par-mot
    sentences = re.split(r'([.!?]+\s*)', reformulated)
    new_sentences = []
    for sentence in sentences:
        words = sentence.split(' ')
        new_words = []
        for word in words:
            # Nettoie la ponctuation pour chercher dans le dict
            clean = re.sub(r'[.,!?;:()"«»]', '', word)
            punct = re.findall(r'[.,!?;:()"«»]', word)

            if clean in SYNONYMS and random.random() < 0.5:
                synonyms = SYNONYMS[clean]
                chosen = random.choice(synonyms)
                new_words.append(chosen + ''.join(punct))
            else:
                new_words.append(word)
        new_sentences.append(' '.join(new_words))

    return ''.join(new_sentences)


# ─────────────────────────────────────────────────────
# TEMPLATES HTML (10 modèles — portage complet du JS)
# Placeholders : [PRIMARY_COLOR] [BUTTON_COLOR] [LOGO_URL]
#                [NOM_ENTREPRISE] [TEXTE_INTRO] [TEXTE_CONTENU]
#                [TEXTE_CONCLUSION] [LIEN_CTA] [LIEN_DESABONNEMENT]
#                [DATE_ACTION] [REFERENCE_DOSSIER] [MENTIONS_LEGALES]
#                [NOTE_SECURITE] [MESSAGE_ACTION] [LIEN_ALTERNATIF]
# ─────────────────────────────────────────────────────
TEMPLATES = [
    {
        'id': 'template1',
        'name': 'Style Classique Banque/Assurance',
        'html': '''<table class="body" style="WIDTH: 100%; BORDER-COLLAPSE: collapse; BORDER-SPACING: 0; BACKGROUND-COLOR: #f0f2f5;">
    <tbody>
        <tr>
            <td style="PADDING: 20px 0;" valign="top" align="left">
                <table class="container" style="MAX-WIDTH: 580px; WIDTH: 100%; BORDER-COLLAPSE: collapse; BORDER-SPACING: 0; BACKGROUND-COLOR: #ffffff; border-radius: 6px; box-shadow: 0 2px 6px rgba(0,0,0,0.05);" align="center">
                    <tbody>
                        <tr>
                            <td style="PADDING: 30px 30px 15px; BACKGROUND-COLOR: [PRIMARY_COLOR]; border-radius: 6px 6px 0 0;">
                                <p style="MARGIN: 0; text-align: center;">
                                    <img style="COLOR: #e6e6e6; BACKGROUND-COLOR: #e6e6e6; MAX-WIDTH: 120px;" src="[LOGO_URL]" alt="[NOM_ENTREPRISE]">
                                </p>
                            </td>
                        </tr>
                        <tr>
                            <td style="PADDING: 25px 30px 20px;">
                                <p style="FONT-SIZE: 13px; FONT-FAMILY: Arial,Helvetica,sans-serif; COLOR: #666666; MARGIN: 0 0 12px; TEXT-TRANSFORM: uppercase; LETTER-SPACING: 1px;"></p>
                                <h2 style="FONT-SIZE: 20px; FONT-FAMILY: Arial,Helvetica,sans-serif; COLOR: #1a1a2e; MARGIN: 0 0 12px; LINE-HEIGHT: 1.3;"></h2>
                                <p style="FONT-SIZE: 15px; FONT-FAMILY: Arial,Helvetica,sans-serif; COLOR: #333333; MARGIN: 0 0 12px; LINE-HEIGHT: 1.6;">[TEXTE_INTRO]</p>
                                <p style="FONT-SIZE: 15px; FONT-FAMILY: Arial,Helvetica,sans-serif; COLOR: #333333; MARGIN: 0 0 16px; LINE-HEIGHT: 1.6;">[TEXTE_CONTENU]</p>
                                <div style="BACKGROUND-COLOR: #f8f9fa; PADDING: 14px 18px; border-radius: 4px; MARGIN: 0 0 16px; border-left: 3px solid [PRIMARY_COLOR];">
                                    <p style="FONT-SIZE: 14px; FONT-FAMILY: Arial,Helvetica,sans-serif; COLOR: #555555; MARGIN: 0; LINE-HEIGHT: 1.5;"><strong>&#128204; R&#233;f&#233;rence :</strong> [REFERENCE_DOSSIER]</p>
                                </div>
                                <p style="TEXT-ALIGN: center; MARGIN: 0 0 16px;">
                                    <a style="FONT-SIZE: 15px; TEXT-DECORATION: none; FONT-FAMILY: Arial,Helvetica,sans-serif; FONT-WEIGHT: 600; COLOR: #ffffff; PADDING: 12px 34px; DISPLAY: inline-block; BACKGROUND-COLOR: [BUTTON_COLOR]; border-radius: 6px;" href="[LIEN_CTA]">&#128272; Acc&#233;der &#224; mon compte</a>
                                </p>
                                <p style="FONT-SIZE: 13px; FONT-FAMILY: Arial,Helvetica,sans-serif; COLOR: #888888; MARGIN: 0 0 8px; LINE-HEIGHT: 1.4; FONT-STYLE: italic;">[DATE_ACTION]</p>
                                <p style="FONT-SIZE: 15px; FONT-FAMILY: Arial,Helvetica,sans-serif; COLOR: #333333; MARGIN: 16px 0 4px; LINE-HEIGHT: 1.5;">[TEXTE_CONCLUSION]</p>
                                <p style="FONT-SIZE: 15px; FONT-FAMILY: Arial,Helvetica,sans-serif; COLOR: #333333; MARGIN: 0 0 4px; LINE-HEIGHT: 1.5;">Cordialement,<br><strong>[NOM_ENTREPRISE]</strong></p>
                            </td>
                        </tr>
                        <tr>
                            <td style="PADDING: 0 30px 15px;">
                                <hr style="BORDER-TOP: #e0e0e0 1px solid; BORDER-RIGHT: 0; BORDER-BOTTOM: 0; BORDER-LEFT: 0; MARGIN: 0 0 10px;">
                                <p style="FONT-SIZE: 11px; FONT-FAMILY: Arial,Helvetica,sans-serif; COLOR: #999999; MARGIN: 0; LINE-HEIGHT: 1.4; TEXT-ALIGN: center;">
                                    <a style="COLOR: #999999; TEXT-DECORATION: underline;" href="[LIEN_DESABONNEMENT]">Se d&#233;sabonner</a> &nbsp;&middot;&nbsp; [MENTIONS_LEGALES]
                                </p>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </td>
        </tr>
    </tbody>
</table>'''
    },
    {
        'id': 'template2',
        'name': 'Style Minimaliste / Moderne',
        'html': '''<table class="body" style="WIDTH: 100%; BORDER-COLLAPSE: collapse; BORDER-SPACING: 0; BACKGROUND-COLOR: #fafafa;">
    <tbody>
        <tr>
            <td style="PADDING: 20px 0;" valign="top" align="left">
                <table class="container" style="MAX-WIDTH: 560px; WIDTH: 100%; BORDER-COLLAPSE: collapse; BORDER-SPACING: 0; BACKGROUND-COLOR: #ffffff; border-radius: 0; box-shadow: none; BORDER: 1px solid #e8e8e8;" align="center">
                    <tbody>
                        <tr>
                            <td style="PADDING: 30px 30px 20px; BORDER-BOTTOM: 2px solid [PRIMARY_COLOR]; TEXT-ALIGN: center;">
                                <img style="COLOR: #e6e6e6; BACKGROUND-COLOR: #e6e6e6; MAX-WIDTH: 120px;" src="[LOGO_URL]" alt="[NOM_ENTREPRISE]">
                            </td>
                        </tr>
                        <tr>
                            <td style="PADDING: 25px 30px 20px;">
                                <div style="TEXT-ALIGN: center; MARGIN: 0 0 16px;">
                                    <span style="FONT-SIZE: 36px;"></span>
                                </div>
                                <h2 style="FONT-SIZE: 18px; FONT-FAMILY: Arial,Helvetica,sans-serif; COLOR: #2c3e50; MARGIN: 0 0 12px; TEXT-ALIGN: center; LINE-HEIGHT: 1.3;"></h2>
                                <p style="FONT-SIZE: 14px; FONT-FAMILY: Arial,Helvetica,sans-serif; COLOR: #555555; MARGIN: 0 0 10px; TEXT-ALIGN: center; LINE-HEIGHT: 1.6;">[TEXTE_INTRO]</p>
                                <p style="FONT-SIZE: 14px; FONT-FAMILY: Arial,Helvetica,sans-serif; COLOR: #555555; MARGIN: 0 0 12px; LINE-HEIGHT: 1.7;">[TEXTE_CONTENU]</p>
                                <div style="TEXT-ALIGN: center; MARGIN: 0 0 16px; PADDING: 12px; BACKGROUND-COLOR: #f8f9fa; border-radius: 4px;">
                                    <p style="FONT-SIZE: 13px; FONT-FAMILY: Arial,Helvetica,sans-serif; COLOR: #888888; MARGIN: 0; LETTER-SPACING: 0.5px;">&#9200; [DATE_ACTION]</p>
                                </div>
                                <p style="TEXT-ALIGN: center; MARGIN: 0 0 16px;">
                                    <a style="FONT-SIZE: 15px; TEXT-DECORATION: none; FONT-FAMILY: Arial,Helvetica,sans-serif; FONT-WEIGHT: 600; COLOR: #ffffff; PADDING: 12px 40px; DISPLAY: inline-block; BACKGROUND-COLOR: [BUTTON_COLOR]; border-radius: 4px; LETTER-SPACING: 0.5px;" href="[LIEN_CTA]">Se connecter &#8594;</a>
                                </p>
                                <p style="FONT-SIZE: 13px; FONT-FAMILY: Arial,Helvetica,sans-serif; COLOR: #999999; TEXT-ALIGN: center; MARGIN: 0; LINE-HEIGHT: 1.4;">[NOTE_SECURITE]</p>
                                <p style="FONT-SIZE: 14px; FONT-FAMILY: Arial,Helvetica,sans-serif; COLOR: #555555; MARGIN: 16px 0 4px; LINE-HEIGHT: 1.5;">[TEXTE_CONCLUSION]<br><strong>[NOM_ENTREPRISE]</strong></p>
                            </td>
                        </tr>
                        <tr>
                            <td style="PADDING: 15px 30px; BACKGROUND-COLOR: #f8f9fa;">
                                <p style="FONT-SIZE: 11px; FONT-FAMILY: Arial,Helvetica,sans-serif; COLOR: #aaaaaa; MARGIN: 0; TEXT-ALIGN: center; LINE-HEIGHT: 1.4;">
                                    [MENTIONS_LEGALES] &nbsp;&middot;&nbsp; <a style="COLOR: #aaaaaa; TEXT-DECORATION: underline;" href="[LIEN_DESABONNEMENT]">Se d&#233;sabonner</a>
                                </p>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </td>
        </tr>
    </tbody>
</table>'''
    },
    {
        'id': 'template3',
        'name': 'Style avec Bandeau Couleur',
        'html': '''<table class="body" style="WIDTH: 100%; BORDER-COLLAPSE: collapse; BORDER-SPACING: 0; BACKGROUND-COLOR: #eef2f7;">
    <tbody>
        <tr>
            <td style="PADDING: 20px 0;" valign="top" align="left">
                <table class="container" style="MAX-WIDTH: 600px; WIDTH: 100%; BORDER-COLLAPSE: collapse; BORDER-SPACING: 0; BACKGROUND-COLOR: #ffffff; border-radius: 10px; box-shadow: 0 4px 12px rgba(0,0,0,0.05);" align="center">
                    <tbody>
                        <tr>
                            <td style="PADDING: 0; BACKGROUND-COLOR: [PRIMARY_COLOR]; border-radius: 10px 10px 0 0;">
                                <p style="MARGIN: 0; PADDING: 18px 30px; text-align: center;">
                                    <img style="COLOR: #e6e6e6; BACKGROUND-COLOR: #e6e6e6; MAX-WIDTH: 100px;" src="[LOGO_URL]" alt="[NOM_ENTREPRISE]">
                                </p>
                            </td>
                        </tr>
                        <tr>
                            <td style="PADDING: 25px 30px 20px;">
                                <h2 style="FONT-SIZE: 19px; FONT-FAMILY: Arial,Helvetica,sans-serif; COLOR: #2c3e50; MARGIN: 0 0 10px; LINE-HEIGHT: 1.3;"></h2>
                                <p style="FONT-SIZE: 14px; FONT-FAMILY: Arial,Helvetica,sans-serif; COLOR: #444444; MARGIN: 0 0 10px; LINE-HEIGHT: 1.6;">[TEXTE_INTRO]</p>
                                <p style="FONT-SIZE: 14px; FONT-FAMILY: Arial,Helvetica,sans-serif; COLOR: #444444; MARGIN: 0 0 16px; LINE-HEIGHT: 1.6;">[TEXTE_CONTENU]</p>
                                <div style="BACKGROUND-COLOR: #fef9f7; PADDING: 12px 16px; border-radius: 4px; MARGIN: 0 0 16px; BORDER: 1px solid [PRIMARY_COLOR];">
                                    <p style="FONT-SIZE: 13px; FONT-FAMILY: Arial,Helvetica,sans-serif; COLOR: [PRIMARY_COLOR]; MARGIN: 0; LINE-HEIGHT: 1.4;"> [MESSAGE_ACTION]</p>
                                </div>
                                <p style="TEXT-ALIGN: center; MARGIN: 0 0 16px;">
                                    <a style="FONT-SIZE: 15px; TEXT-DECORATION: none; FONT-FAMILY: Arial,Helvetica,sans-serif; FONT-WEIGHT: 600; COLOR: #ffffff; PADDING: 12px 36px; DISPLAY: inline-block; BACKGROUND-COLOR: [BUTTON_COLOR]; border-radius: 6px;" href="[LIEN_CTA]"> Acc&#233;der &#224; mon espace</a>
                                </p>
                                <p style="FONT-SIZE: 13px; FONT-FAMILY: Arial,Helvetica,sans-serif; COLOR: #888888; MARGIN: 0 0 8px; LINE-HEIGHT: 1.4;">[DATE_ACTION]</p>
                                <p style="FONT-SIZE: 14px; FONT-FAMILY: Arial,Helvetica,sans-serif; COLOR: #444444; MARGIN: 16px 0 4px; LINE-HEIGHT: 1.5;">[TEXTE_CONCLUSION]<br><strong>[NOM_ENTREPRISE]</strong></p>
                            </td>
                        </tr>
                        <tr>
                            <td style="PADDING: 0 30px 15px;">
                                <hr style="BORDER-TOP: #e8e8e8 1px solid; BORDER-RIGHT: 0; BORDER-BOTTOM: 0; BORDER-LEFT: 0; MARGIN: 0 0 10px;">
                                <p style="FONT-SIZE: 11px; FONT-FAMILY: Arial,Helvetica,sans-serif; COLOR: #aaaaaa; MARGIN: 0; TEXT-ALIGN: center; LINE-HEIGHT: 1.4;">
                                    <a style="COLOR: #aaaaaa; TEXT-DECORATION: underline;" href="[LIEN_DESABONNEMENT]">Se d&#233;sabonner</a> &nbsp;&middot;&nbsp; [MENTIONS_LEGALES]
                                </p>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </td>
        </tr>
    </tbody>
</table>'''
    },
    {
        'id': 'template4',
        'name': 'Style avec Icônes / Cards',
        'html': '''<table class="body" style="WIDTH: 100%; BORDER-COLLAPSE: collapse; BORDER-SPACING: 0; BACKGROUND-COLOR: #f5f6fa;">
    <tbody>
        <tr>
            <td style="PADDING: 20px 0;" valign="top" align="left">
                <table class="container" style="MAX-WIDTH: 600px; WIDTH: 100%; BORDER-COLLAPSE: collapse; BORDER-SPACING: 0; BACKGROUND-COLOR: #ffffff; border-radius: 12px; box-shadow: 0 2px 10px rgba(0,0,0,0.04);" align="center">
                    <tbody>
                        <tr>
                            <td style="PADDING: 25px 30px 15px; TEXT-ALIGN: center;">
                                <img style="COLOR: #e6e6e6; BACKGROUND-COLOR: #e6e6e6; MAX-WIDTH: 120px;" src="[LOGO_URL]" alt="[NOM_ENTREPRISE]">
                            </td>
                        </tr>
                        <tr>
                            <td style="PADDING: 0 30px 20px;">
                                <table style="WIDTH: 100%; BORDER-COLLAPSE: collapse; BORDER-SPACING: 0; MARGIN: 0 0 16px;">
                                    <tbody>
                                        <tr>
                                            <td style="WIDTH: 48%; PADDING: 12px; BACKGROUND-COLOR: #e8f4fd; TEXT-ALIGN: center; border-radius: 6px; BORDER: 1px solid [PRIMARY_COLOR];">
                                                <p style="FONT-SIZE: 20px; MARGIN: 0;">&#128272;</p>
                                                <p style="FONT-SIZE: 11px; FONT-FAMILY: Arial,Helvetica,sans-serif; COLOR: #555555; MARGIN: 4px 0 0;">S&#233;curis&#233;</p>
                                            </td>
                                            <td style="WIDTH: 4%;"></td>
                                            <td style="WIDTH: 48%; PADDING: 12px; BACKGROUND-COLOR: #fef9e7; TEXT-ALIGN: center; border-radius: 6px; BORDER: 1px solid [PRIMARY_COLOR];">
                                                <p style="FONT-SIZE: 20px; MARGIN: 0;">&#128204;</p>
                                                <p style="FONT-SIZE: 11px; FONT-FAMILY: Arial,Helvetica,sans-serif; COLOR: #555555; MARGIN: 4px 0 0;">Important</p>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                                <h2 style="FONT-SIZE: 18px; FONT-FAMILY: Arial,Helvetica,sans-serif; COLOR: #1a1a2e; MARGIN: 0 0 10px; LINE-HEIGHT: 1.3;"></h2>
                                <p style="FONT-SIZE: 14px; FONT-FAMILY: Arial,Helvetica,sans-serif; COLOR: #444444; MARGIN: 0 0 10px; LINE-HEIGHT: 1.6;">[TEXTE_INTRO]</p>
                                <p style="FONT-SIZE: 14px; FONT-FAMILY: Arial,Helvetica,sans-serif; COLOR: #444444; MARGIN: 0 0 16px; LINE-HEIGHT: 1.6;">[TEXTE_CONTENU]</p>
                                <p style="TEXT-ALIGN: center; MARGIN: 0 0 16px;">
                                    <a style="FONT-SIZE: 15px; TEXT-DECORATION: none; FONT-FAMILY: Arial,Helvetica,sans-serif; FONT-WEIGHT: 600; COLOR: #ffffff; PADDING: 12px 34px; DISPLAY: inline-block; BACKGROUND-COLOR: [BUTTON_COLOR]; border-radius: 25px;" href="[LIEN_CTA]"> Je me connecte</a>
                                </p>
                                <p style="FONT-SIZE: 12px; FONT-FAMILY: Arial,Helvetica,sans-serif; COLOR: #999999; TEXT-ALIGN: center; MARGIN: 0; LINE-HEIGHT: 1.4;">[DATE_ACTION]</p>
                                <p style="FONT-SIZE: 14px; FONT-FAMILY: Arial,Helvetica,sans-serif; COLOR: #444444; MARGIN: 16px 0 4px; LINE-HEIGHT: 1.5;">[TEXTE_CONCLUSION]<br><strong>[NOM_ENTREPRISE]</strong></p>
                            </td>
                        </tr>
                        <tr>
                            <td style="PADDING: 15px 30px; BACKGROUND-COLOR: #f8f9fa; border-radius: 0 0 12px 12px;">
                                <p style="FONT-SIZE: 10px; FONT-FAMILY: Arial,Helvetica,sans-serif; COLOR: #bbbbbb; MARGIN: 0; TEXT-ALIGN: center; LINE-HEIGHT: 1.4;">
                                    [MENTIONS_LEGALES] &nbsp;&middot;&nbsp; <a style="COLOR: #bbbbbb; TEXT-DECORATION: underline;" href="[LIEN_DESABONNEMENT]">Se d&#233;sabonner</a>
                                </p>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </td>
        </tr>
    </tbody>
</table>'''
    },
    {
        'id': 'template5',
        'name': 'Style avec Encadré Couleur',
        'html': '''<table class="body" style="WIDTH: 100%; BORDER-COLLAPSE: collapse; BORDER-SPACING: 0; BACKGROUND-COLOR: #e8ecf1;">
    <tbody>
        <tr>
            <td style="PADDING: 20px 0;" valign="top" align="left">
                <table class="container" style="MAX-WIDTH: 600px; WIDTH: 100%; BORDER-COLLAPSE: collapse; BORDER-SPACING: 0; BACKGROUND-COLOR: #ffffff; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.06); border: 3px solid [PRIMARY_COLOR];" align="center">
                    <tbody>
                        <tr>
                            <td style="PADDING: 25px 30px 15px; BACKGROUND-COLOR: [PRIMARY_COLOR];">
                                <p style="MARGIN: 0; text-align: center;">
                                    <img style="COLOR: #e6e6e6; BACKGROUND-COLOR: #e6e6e6; MAX-WIDTH: 100px;" src="[LOGO_URL]" alt="[NOM_ENTREPRISE]">
                                </p>
                            </td>
                        </tr>
                        <tr>
                            <td style="PADDING: 25px 30px 20px;">
                                <div style="BACKGROUND-COLOR: #ebf5fb; PADDING: 14px 18px; border-radius: 4px; MARGIN: 0 0 16px; border-left: 4px solid [PRIMARY_COLOR];">
                                    <p style="FONT-SIZE: 14px; FONT-FAMILY: Arial,Helvetica,sans-serif; COLOR: [PRIMARY_COLOR]; MARGIN: 0; FONT-WEIGHT: 600;"></p>
                                </div>
                                <h2 style="FONT-SIZE: 19px; FONT-FAMILY: Arial,Helvetica,sans-serif; COLOR: #1a1a2e; MARGIN: 0 0 10px; LINE-HEIGHT: 1.3;"></h2>
                                <p style="FONT-SIZE: 14px; FONT-FAMILY: Arial,Helvetica,sans-serif; COLOR: #444444; MARGIN: 0 0 10px; LINE-HEIGHT: 1.6;">[TEXTE_INTRO]</p>
                                <p style="FONT-SIZE: 14px; FONT-FAMILY: Arial,Helvetica,sans-serif; COLOR: #444444; MARGIN: 0 0 16px; LINE-HEIGHT: 1.6;">[TEXTE_CONTENU]</p>
                                <div style="BACKGROUND-COLOR: #f8f9fa; PADDING: 12px 16px; border-radius: 4px; MARGIN: 0 0 16px; TEXT-ALIGN: center;">
                                    <p style="FONT-SIZE: 14px; FONT-FAMILY: Arial,Helvetica,sans-serif; COLOR: [PRIMARY_COLOR]; MARGIN: 0; FONT-WEIGHT: 700;">R&#233;f&#233;rence : [REFERENCE_DOSSIER]</p>
                                </div>
                                <p style="TEXT-ALIGN: center; MARGIN: 0 0 16px;">
                                    <a style="FONT-SIZE: 15px; TEXT-DECORATION: none; FONT-FAMILY: Arial,Helvetica,sans-serif; FONT-WEIGHT: 600; COLOR: #ffffff; PADDING: 12px 36px; DISPLAY: inline-block; BACKGROUND-COLOR: [BUTTON_COLOR]; border-radius: 6px;" href="[LIEN_CTA]">Consulter maintenant</a>
                                </p>
                                <p style="FONT-SIZE: 13px; FONT-FAMILY: Arial,Helvetica,sans-serif; COLOR: #888888; MARGIN: 0; LINE-HEIGHT: 1.4;">[DATE_ACTION]</p>
                                <p style="FONT-SIZE: 14px; FONT-FAMILY: Arial,Helvetica,sans-serif; COLOR: #444444; MARGIN: 16px 0 4px; LINE-HEIGHT: 1.5;">[TEXTE_CONCLUSION]<br><strong>[NOM_ENTREPRISE]</strong></p>
                            </td>
                        </tr>
                        <tr>
                            <td style="PADDING: 0 30px 15px;">
                                <hr style="BORDER-TOP: #e0e0e0 1px solid; BORDER-RIGHT: 0; BORDER-BOTTOM: 0; BORDER-LEFT: 0; MARGIN: 0 0 10px;">
                                <p style="FONT-SIZE: 11px; FONT-FAMILY: Arial,Helvetica,sans-serif; COLOR: #aaaaaa; MARGIN: 0; TEXT-ALIGN: center; LINE-HEIGHT: 1.4;">
                                    <a style="COLOR: #aaaaaa; TEXT-DECORATION: underline;" href="[LIEN_DESABONNEMENT]">Se d&#233;sabonner</a> &nbsp;&middot;&nbsp; [MENTIONS_LEGALES]
                                </p>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </td>
        </tr>
    </tbody>
</table>'''
    },
    {
        'id': 'template6',
        'name': 'Style Confiance',
        'html': '''<table class="body" style="WIDTH: 100%; BORDER-COLLAPSE: collapse; BORDER-SPACING: 0; BACKGROUND-COLOR: #f0f7f0;">
    <tbody>
        <tr>
            <td style="PADDING: 20px 0;" valign="top" align="left">
                <table class="container" style="MAX-WIDTH: 580px; WIDTH: 100%; BORDER-COLLAPSE: collapse; BORDER-SPACING: 0; BACKGROUND-COLOR: #ffffff; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.06);" align="center">
                    <tbody>
                        <tr>
                            <td style="PADDING: 0 30px; BACKGROUND-COLOR: [PRIMARY_COLOR]; border-radius: 8px 8px 0 0;">
                                <p style="MARGIN: 0; PADDING: 16px 0; text-align: center;">
                                    <img style="COLOR: #e6e6e6; BACKGROUND-COLOR: #e6e6e6; MAX-WIDTH: 100px;" src="[LOGO_URL]" alt="[NOM_ENTREPRISE]">
                                </p>
                            </td>
                        </tr>
                        <tr>
                            <td style="PADDING: 25px 30px 20px;">
                                <div style="TEXT-ALIGN: center; MARGIN: 0 0 16px;">
                                    <span style="FONT-SIZE: 40px;"></span>
                                </div>
                                <h2 style="FONT-SIZE: 19px; FONT-FAMILY: Arial,Helvetica,sans-serif; COLOR: #1a1a2e; MARGIN: 0 0 10px; TEXT-ALIGN: center; LINE-HEIGHT: 1.3;"></h2>
                                <p style="FONT-SIZE: 14px; FONT-FAMILY: Arial,Helvetica,sans-serif; COLOR: #444444; MARGIN: 0 0 10px; LINE-HEIGHT: 1.6;">[TEXTE_INTRO]</p>
                                <p style="FONT-SIZE: 14px; FONT-FAMILY: Arial,Helvetica,sans-serif; COLOR: #444444; MARGIN: 0 0 16px; LINE-HEIGHT: 1.6;">[TEXTE_CONTENU]</p>
                                <p style="TEXT-ALIGN: center; MARGIN: 0 0 16px;">
                                    <a style="FONT-SIZE: 15px; TEXT-DECORATION: none; FONT-FAMILY: Arial,Helvetica,sans-serif; FONT-WEIGHT: 600; COLOR: #ffffff; PADDING: 12px 34px; DISPLAY: inline-block; BACKGROUND-COLOR: [BUTTON_COLOR]; border-radius: 6px;" href="[LIEN_CTA]">Confirmer et acc&#233;der</a>
                                </p>
                                <div style="TEXT-ALIGN: center; MARGIN: 0 0 16px;">
                                    <p style="FONT-SIZE: 12px; FONT-FAMILY: Arial,Helvetica,sans-serif; COLOR: #888888; MARGIN: 0; LINE-HEIGHT: 1.4;">&#9200; [DATE_ACTION]</p>
                                </div>
                                <p style="FONT-SIZE: 14px; FONT-FAMILY: Arial,Helvetica,sans-serif; COLOR: #444444; MARGIN: 16px 0 4px; LINE-HEIGHT: 1.5;">[TEXTE_CONCLUSION]<br><strong>[NOM_ENTREPRISE]</strong></p>
                            </td>
                        </tr>
                        <tr>
                            <td style="PADDING: 0 30px 15px;">
                                <hr style="BORDER-TOP: #e0e0e0 1px solid; BORDER-RIGHT: 0; BORDER-BOTTOM: 0; BORDER-LEFT: 0; MARGIN: 0 0 10px;">
                                <p style="FONT-SIZE: 11px; FONT-FAMILY: Arial,Helvetica,sans-serif; COLOR: #aaaaaa; MARGIN: 0; TEXT-ALIGN: center; LINE-HEIGHT: 1.4;">
                                    <a style="COLOR: #aaaaaa; TEXT-DECORATION: underline;" href="[LIEN_DESABONNEMENT]">Se d&#233;sabonner</a> &nbsp;&middot;&nbsp; [MENTIONS_LEGALES]
                                </p>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </td>
        </tr>
    </tbody>
</table>'''
    },
    {
        'id': 'template7',
        'name': 'Style avec Barre Latérale',
        'html': '''<table class="body" style="WIDTH: 100%; BORDER-COLLAPSE: collapse; BORDER-SPACING: 0; BACKGROUND-COLOR: #f4f6f9;">
    <tbody>
        <tr>
            <td style="PADDING: 20px 0;" valign="top" align="left">
                <table class="container" style="MAX-WIDTH: 600px; WIDTH: 100%; BORDER-COLLAPSE: collapse; BORDER-SPACING: 0; BACKGROUND-COLOR: #ffffff; border-radius: 6px; box-shadow: 0 2px 6px rgba(0,0,0,0.04);" align="center">
                    <tbody>
                        <tr>
                            <td style="PADDING: 25px 30px 20px;">
                                <table style="WIDTH: 100%; BORDER-COLLAPSE: collapse; BORDER-SPACING: 0;">
                                    <tbody>
                                        <tr>
                                            <td style="WIDTH: 6px; BACKGROUND-COLOR: [PRIMARY_COLOR]; border-radius: 4px 0 0 4px; PADDING: 0;"></td>
                                            <td style="PADDING: 0 0 0 20px;">
                                                <img style="COLOR: #e6e6e6; BACKGROUND-COLOR: #e6e6e6; MAX-WIDTH: 100px;" src="[LOGO_URL]" alt="[NOM_ENTREPRISE]">
                                                <h2 style="FONT-SIZE: 18px; FONT-FAMILY: Arial,Helvetica,sans-serif; COLOR: #2c3e50; MARGIN: 10px 0 10px; LINE-HEIGHT: 1.3;"></h2>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                                <p style="FONT-SIZE: 14px; FONT-FAMILY: Arial,Helvetica,sans-serif; COLOR: #444444; MARGIN: 0 0 10px; LINE-HEIGHT: 1.6;">[TEXTE_INTRO]</p>
                                <p style="FONT-SIZE: 14px; FONT-FAMILY: Arial,Helvetica,sans-serif; COLOR: #444444; MARGIN: 0 0 16px; LINE-HEIGHT: 1.6;">[TEXTE_CONTENU]</p>
                                <div style="BACKGROUND-COLOR: #f4ecf7; PADDING: 12px 16px; border-radius: 4px; MARGIN: 0 0 16px; BORDER: 1px solid [PRIMARY_COLOR];">
                                    <p style="FONT-SIZE: 13px; FONT-FAMILY: Arial,Helvetica,sans-serif; COLOR: [PRIMARY_COLOR]; MARGIN: 0; LINE-HEIGHT: 1.4;"> [NOTE_SECURITE]</p>
                                </div>
                                <p style="TEXT-ALIGN: center; MARGIN: 0 0 16px;">
                                    <a style="FONT-SIZE: 15px; TEXT-DECORATION: none; FONT-FAMILY: Arial,Helvetica,sans-serif; FONT-WEIGHT: 600; COLOR: #ffffff; PADDING: 12px 34px; DISPLAY: inline-block; BACKGROUND-COLOR: [BUTTON_COLOR]; border-radius: 6px;" href="[LIEN_CTA]"> Me connecter</a>
                                </p>
                                <p style="FONT-SIZE: 13px; FONT-FAMILY: Arial,Helvetica,sans-serif; COLOR: #888888; MARGIN: 0; LINE-HEIGHT: 1.4;">[DATE_ACTION]</p>
                                <p style="FONT-SIZE: 14px; FONT-FAMILY: Arial,Helvetica,sans-serif; COLOR: #444444; MARGIN: 16px 0 4px; LINE-HEIGHT: 1.5;">[TEXTE_CONCLUSION]<br><strong>[NOM_ENTREPRISE]</strong></p>
                            </td>
                        </tr>
                        <tr>
                            <td style="PADDING: 0 30px 15px;">
                                <hr style="BORDER-TOP: #e8e8e8 1px solid; BORDER-RIGHT: 0; BORDER-BOTTOM: 0; BORDER-LEFT: 0; MARGIN: 0 0 10px;">
                                <p style="FONT-SIZE: 11px; FONT-FAMILY: Arial,Helvetica,sans-serif; COLOR: #aaaaaa; MARGIN: 0; TEXT-ALIGN: center; LINE-HEIGHT: 1.4;">
                                    <a style="COLOR: #aaaaaa; TEXT-DECORATION: underline;" href="[LIEN_DESABONNEMENT]">Se d&#233;sabonner</a> &nbsp;&middot;&nbsp; [MENTIONS_LEGALES]
                                </p>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </td>
        </tr>
    </tbody>
</table>'''
    },
    {
        'id': 'template8',
        'name': 'Style Urgence',
        'html': '''<table class="body" style="WIDTH: 100%; BORDER-COLLAPSE: collapse; BORDER-SPACING: 0; BACKGROUND-COLOR: #fdf6ec;">
    <tbody>
        <tr>
            <td style="PADDING: 20px 0;" valign="top" align="left">
                <table class="container" style="MAX-WIDTH: 580px; WIDTH: 100%; BORDER-COLLAPSE: collapse; BORDER-SPACING: 0; BACKGROUND-COLOR: #ffffff; border-radius: 10px; box-shadow: 0 4px 12px rgba(0,0,0,0.08);" align="center">
                    <tbody>
                        <tr>
                            <td style="PADDING: 0; BACKGROUND-COLOR: [PRIMARY_COLOR]; border-radius: 10px 10px 0 0;">
                                <table style="WIDTH: 100%; BORDER-COLLAPSE: collapse; BORDER-SPACING: 0;">
                                    <tbody>
                                        <tr>
                                            <td style="PADDING: 12px 20px;">
                                                <img style="COLOR: #e6e6e6; BACKGROUND-COLOR: #e6e6e6; MAX-WIDTH: 80px;" src="[LOGO_URL]" alt="[NOM_ENTREPRISE]">
                                            </td>
                                            <td style="PADDING: 12px 20px; TEXT-ALIGN: right;">
                                                <span style="FONT-SIZE: 11px; FONT-FAMILY: Arial,Helvetica,sans-serif; COLOR: #ffffff; BACKGROUND-COLOR: rgba(255,255,255,0.2); PADDING: 2px 10px; border-radius: 12px;">URGENT</span>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </td>
                        </tr>
                        <tr>
                            <td style="PADDING: 25px 30px 20px;">
                                <h2 style="FONT-SIZE: 19px; FONT-FAMILY: Arial,Helvetica,sans-serif; COLOR: [PRIMARY_COLOR]; MARGIN: 0 0 10px; LINE-HEIGHT: 1.3;"></h2>
                                <p style="FONT-SIZE: 14px; FONT-FAMILY: Arial,Helvetica,sans-serif; COLOR: #444444; MARGIN: 0 0 10px; LINE-HEIGHT: 1.6;">[TEXTE_INTRO]</p>
                                <p style="FONT-SIZE: 14px; FONT-FAMILY: Arial,Helvetica,sans-serif; COLOR: #444444; MARGIN: 0 0 16px; LINE-HEIGHT: 1.6;">[TEXTE_CONTENU]</p>
                                <div style="BACKGROUND-COLOR: #fdebd0; PADDING: 12px 16px; border-radius: 4px; MARGIN: 0 0 16px; BORDER: 1px solid [PRIMARY_COLOR];">
                                    <p style="FONT-SIZE: 13px; FONT-FAMILY: Arial,Helvetica,sans-serif; COLOR: [PRIMARY_COLOR]; MARGIN: 0; LINE-HEIGHT: 1.4;">[MESSAGE_ACTION]</p>
                                </div>
                                <p style="TEXT-ALIGN: center; MARGIN: 0 0 16px;">
                                    <a style="FONT-SIZE: 15px; TEXT-DECORATION: none; FONT-FAMILY: Arial,Helvetica,sans-serif; FONT-WEIGHT: 600; COLOR: #ffffff; PADDING: 12px 34px; DISPLAY: inline-block; BACKGROUND-COLOR: [BUTTON_COLOR]; border-radius: 6px;" href="[LIEN_CTA]"> Agir maintenant</a>
                                </p>
                                <p style="FONT-SIZE: 13px; FONT-FAMILY: Arial,Helvetica,sans-serif; COLOR: #888888; MARGIN: 0; LINE-HEIGHT: 1.4;">[DATE_ACTION]</p>
                                <p style="FONT-SIZE: 14px; FONT-FAMILY: Arial,Helvetica,sans-serif; COLOR: #444444; MARGIN: 16px 0 4px; LINE-HEIGHT: 1.5;">[TEXTE_CONCLUSION]<br><strong>[NOM_ENTREPRISE]</strong></p>
                            </td>
                        </tr>
                        <tr>
                            <td style="PADDING: 0 30px 15px;">
                                <hr style="BORDER-TOP: #e8e8e8 1px solid; BORDER-RIGHT: 0; BORDER-BOTTOM: 0; BORDER-LEFT: 0; MARGIN: 0 0 10px;">
                                <p style="FONT-SIZE: 11px; FONT-FAMILY: Arial,Helvetica,sans-serif; COLOR: #aaaaaa; MARGIN: 0; TEXT-ALIGN: center; LINE-HEIGHT: 1.4;">
                                    <a style="COLOR: #aaaaaa; TEXT-DECORATION: underline;" href="[LIEN_DESABONNEMENT]">Se d&#233;sabonner</a> &nbsp;&middot;&nbsp; [MENTIONS_LEGALES]
                                </p>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </td>
        </tr>
    </tbody>
</table>'''
    },
    {
        'id': 'template9',
        'name': 'Style Gris / Élégant',
        'html': '''<table class="body" style="WIDTH: 100%; BORDER-COLLAPSE: collapse; BORDER-SPACING: 0; BACKGROUND-COLOR: #eaeef3;">
    <tbody>
        <tr>
            <td style="PADDING: 20px 0;" valign="top" align="left">
                <table class="container" style="MAX-WIDTH: 560px; WIDTH: 100%; BORDER-COLLAPSE: collapse; BORDER-SPACING: 0; BACKGROUND-COLOR: #ffffff; border-radius: 8px; box-shadow: 0 3px 10px rgba(0,0,0,0.04);" align="center">
                    <tbody>
                        <tr>
                            <td style="PADDING: 30px 30px 15px; TEXT-ALIGN: center; BORDER-BOTTOM: 1px solid #e8e8e8;">
                                <img style="COLOR: #e6e6e6; BACKGROUND-COLOR: #e6e6e6; MAX-WIDTH: 100px;" src="[LOGO_URL]" alt="[NOM_ENTREPRISE]">
                            </td>
                        </tr>
                        <tr>
                            <td style="PADDING: 25px 30px 20px;">
                                <div style="TEXT-ALIGN: center; MARGIN: 0 0 16px;">
                                    <span style="FONT-SIZE: 32px;">&#128196;</span>
                                </div>
                                <h2 style="FONT-SIZE: 18px; FONT-FAMILY: Arial,Helvetica,sans-serif; COLOR: #2c3e50; MARGIN: 0 0 10px; TEXT-ALIGN: center; LINE-HEIGHT: 1.3;"></h2>
                                <p style="FONT-SIZE: 14px; FONT-FAMILY: Arial,Helvetica,sans-serif; COLOR: #555555; MARGIN: 0 0 10px; LINE-HEIGHT: 1.6;">[TEXTE_INTRO]</p>
                                <p style="FONT-SIZE: 14px; FONT-FAMILY: Arial,Helvetica,sans-serif; COLOR: #555555; MARGIN: 0 0 16px; LINE-HEIGHT: 1.6;">[TEXTE_CONTENU]</p>
                                <div style="BACKGROUND-COLOR: #f8f9fa; PADDING: 10px 16px; border-radius: 4px; MARGIN: 0 0 16px; TEXT-ALIGN: center; BORDER: 1px dashed [PRIMARY_COLOR];">
                                    <p style="FONT-SIZE: 13px; FONT-FAMILY: Arial,Helvetica,sans-serif; COLOR: #7f8c8d; MARGIN: 0;">&#128206; [REFERENCE_DOSSIER]</p>
                                </div>
                                <p style="TEXT-ALIGN: center; MARGIN: 0 0 16px;">
                                    <a style="FONT-SIZE: 15px; TEXT-DECORATION: none; FONT-FAMILY: Arial,Helvetica,sans-serif; FONT-WEIGHT: 600; COLOR: #ffffff; PADDING: 12px 34px; DISPLAY: inline-block; BACKGROUND-COLOR: [BUTTON_COLOR]; border-radius: 4px;" href="[LIEN_CTA]"> Acc&#233;der &#224; l&#39;espace client</a>
                                </p>
                                <p style="FONT-SIZE: 13px; FONT-FAMILY: Arial,Helvetica,sans-serif; COLOR: #888888; MARGIN: 0; TEXT-ALIGN: center; LINE-HEIGHT: 1.4;">[DATE_ACTION]</p>
                                <p style="FONT-SIZE: 14px; FONT-FAMILY: Arial,Helvetica,sans-serif; COLOR: #555555; MARGIN: 16px 0 4px; LINE-HEIGHT: 1.5;">[TEXTE_CONCLUSION]<br><strong>[NOM_ENTREPRISE]</strong></p>
                            </td>
                        </tr>
                        <tr>
                            <td style="PADDING: 15px 30px; BACKGROUND-COLOR: #f8f9fa; border-radius: 0 0 8px 8px;">
                                <p style="FONT-SIZE: 10px; FONT-FAMILY: Arial,Helvetica,sans-serif; COLOR: #bbbbbb; MARGIN: 0; TEXT-ALIGN: center; LINE-HEIGHT: 1.4;">
                                    [MENTIONS_LEGALES] &nbsp;&middot;&nbsp; <a style="COLOR: #bbbbbb; TEXT-DECORATION: underline;" href="[LIEN_DESABONNEMENT]">Se d&#233;sabonner</a>
                                </p>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </td>
        </tr>
    </tbody>
</table>'''
    },
    {
        'id': 'template10',
        'name': 'Style avec Double Bouton',
        'html': '''<table class="body" style="WIDTH: 100%; BORDER-COLLAPSE: collapse; BORDER-SPACING: 0; BACKGROUND-COLOR: #f0f2f5;">
    <tbody>
        <tr>
            <td style="PADDING: 20px 0;" valign="top" align="left">
                <table class="container" style="MAX-WIDTH: 600px; WIDTH: 100%; BORDER-COLLAPSE: collapse; BORDER-SPACING: 0; BACKGROUND-COLOR: #ffffff; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.05);" align="center">
                    <tbody>
                        <tr>
                            <td style="PADDING: 25px 30px 15px;">
                                <table style="WIDTH: 100%; BORDER-COLLAPSE: collapse; BORDER-SPACING: 0;">
                                    <tbody>
                                        <tr>
                                            <td>
                                                <img style="COLOR: #e6e6e6; BACKGROUND-COLOR: #e6e6e6; MAX-WIDTH: 100px;" src="[LOGO_URL]" alt="[NOM_ENTREPRISE]">
                                            </td>
                                            <td style="TEXT-ALIGN: right;">
                                                <span style="FONT-SIZE: 11px; FONT-FAMILY: Arial,Helvetica,sans-serif; COLOR: #ffffff; BACKGROUND-COLOR: [PRIMARY_COLOR]; PADDING: 2px 12px; border-radius: 4px;"></span>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </td>
                        </tr>
                        <tr>
                            <td style="PADDING: 0 30px 20px;">
                                <div style="TEXT-ALIGN: center; MARGIN: 0 0 16px;">
                                    <span style="FONT-SIZE: 38px;">&#128236;</span>
                                </div>
                                <h2 style="FONT-SIZE: 18px; FONT-FAMILY: Arial,Helvetica,sans-serif; COLOR: #1a1a2e; MARGIN: 0 0 10px; TEXT-ALIGN: center; LINE-HEIGHT: 1.3;"></h2>
                                <p style="FONT-SIZE: 14px; FONT-FAMILY: Arial,Helvetica,sans-serif; COLOR: #444444; MARGIN: 0 0 10px; TEXT-ALIGN: center; LINE-HEIGHT: 1.6;">[TEXTE_INTRO]</p>
                                <p style="FONT-SIZE: 14px; FONT-FAMILY: Arial,Helvetica,sans-serif; COLOR: #444444; MARGIN: 0 0 16px; LINE-HEIGHT: 1.6;">[TEXTE_CONTENU]</p>
                                <div style="TEXT-ALIGN: center; MARGIN: 0 0 16px;">
                                    <a style="FONT-SIZE: 15px; TEXT-DECORATION: none; FONT-FAMILY: Arial,Helvetica,sans-serif; FONT-WEIGHT: 600; COLOR: #ffffff; PADDING: 12px 36px; DISPLAY: inline-block; BACKGROUND-COLOR: [BUTTON_COLOR]; border-radius: 6px; MARGIN: 0 0 8px;" href="[LIEN_CTA]">Je me connecte</a>
                                </div>
                                <div style="TEXT-ALIGN: center; MARGIN: 0 0 16px;">
                                    <p style="FONT-SIZE: 12px; FONT-FAMILY: Arial,Helvetica,sans-serif; COLOR: #999999; MARGIN: 0; LINE-HEIGHT: 1.4;"></p>
                                </div>
                                <p style="FONT-SIZE: 13px; FONT-FAMILY: Arial,Helvetica,sans-serif; COLOR: #888888; MARGIN: 0; LINE-HEIGHT: 1.4;">[DATE_ACTION]</p>
                                <p style="FONT-SIZE: 14px; FONT-FAMILY: Arial,Helvetica,sans-serif; COLOR: #444444; MARGIN: 16px 0 4px; LINE-HEIGHT: 1.5;">[TEXTE_CONCLUSION]<br><strong>[NOM_ENTREPRISE]</strong></p>
                            </td>
                        </tr>
                        <tr>
                            <td style="PADDING: 0 30px 15px;">
                                <hr style="BORDER-TOP: #e0e0e0 1px solid; BORDER-RIGHT: 0; BORDER-BOTTOM: 0; BORDER-LEFT: 0; MARGIN: 0 0 10px;">
                                <p style="FONT-SIZE: 11px; FONT-FAMILY: Arial,Helvetica,sans-serif; COLOR: #aaaaaa; MARGIN: 0; TEXT-ALIGN: center; LINE-HEIGHT: 1.4;">
                                    <a style="COLOR: #aaaaaa; TEXT-DECORATION: underline;" href="[LIEN_DESABONNEMENT]">Se d&#233;sabonner</a> &nbsp;&middot;&nbsp; [MENTIONS_LEGALES]
                                </p>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </td>
        </tr>
    </tbody>
</table>'''
    },
]

# ─────────────────────────────────────────────────────
# TEXTE DE BASE PAR DÉFAUT (reformulé à chaque envoi)
# ─────────────────────────────────────────────────────
DEFAULT_BASE_TEXT = (
    "Nous avons détecté que votre compte nécessite une vérification de vos informations personnelles. "
    "Afin de garantir la sécurité et la protection de votre espace client, nous vous invitons à procéder "
    "à la mise à jour de vos coordonnées dans les plus brefs délais. "
    "Cette démarche est nécessaire pour maintenir votre accès aux services et assurer la conformité "
    "de votre profil avec nos obligations réglementaires en vigueur. "
    "Pour toute question concernant cette procédure, notre équipe d'assistance reste disponible."
)


# ─────────────────────────────────────────────────────
# FONCTION PRINCIPALE DE GÉNÉRATION D'EMAIL
# ─────────────────────────────────────────────────────
def generate_email_from_template(template, config, base_text, cta_link,
                                  unsub_link='#', mentions=''):
    """Génère un email HTML complet à partir d'un template et de la config.

    Args:
        template   : dict avec 'id', 'name', 'html' (un élément de TEMPLATES)
        config     : dict avec les clés COLOR, LOGO, COMPANY_NAME, etc.
        base_text  : texte brut à reformuler (contenu principal de l'email)
        cta_link   : lien du bouton CTA
        unsub_link : lien de désabonnement (par défaut '#')
        mentions   : mentions légales (par défaut vide)

    Returns:
        dict avec 'html', 'subject', 'text'
    """
    # 1. Reformulation du texte de base avec synonymes
    reformulated_text = reformulate_text(base_text)

    # 2. Valeurs de remplacement
    primary_color = config.get('COLOR', '#003da5')
    button_color  = primary_color
    logo_url      = config.get('LOGO', '')
    company_name  = config.get('COMPANY_NAME', 'Service Client')
    date_action   = datetime.now().strftime('%d/%m/%Y')
    ref_dossier   = 'REF-' + datetime.now().strftime('%Y%m%d%H%M%S')
    note_securite = 'Ce message est sécurisé et ne nécessite aucune réponse par e-mail.'
    message_action = 'Veuillez procéder à cette mise à jour dans les plus brefs délais.'
    conclusion     = "Pour toute question, notre équipe d'assistance est à votre disposition via notre site officiel."

    if not mentions:
        mentions = config.get('MENTIONS_LEGALES', 'Mentions légales')

    # 3. Remplacement de tous les placeholders dans le HTML
    html = template['html']
    replacements = {
        '[NOM_ENTREPRISE]':    company_name,
        '[LIEN_CTA]':         cta_link,
        '[LIEN_DESABONNEMENT]': unsub_link,
        '[LIEN_ALTERNATIF]':  cta_link,
        '[DATE_ACTION]':       date_action,
        '[MENTIONS_LEGALES]':  mentions,
        '[TEXTE_INTRO]':       'Madame, Monsieur,',
        '[TEXTE_CONTENU]':     reformulated_text,
        '[TEXTE_CONCLUSION]':  conclusion,
        '[LOGO_URL]':          logo_url,
        '[PRIMARY_COLOR]':     primary_color,
        '[BUTTON_COLOR]':      button_color,
        '[REFERENCE_DOSSIER]': ref_dossier,
        '[NOTE_SECURITE]':     note_securite,
        '[MESSAGE_ACTION]':    message_action,
    }

    for placeholder, value in replacements.items():
        html = html.replace(placeholder, value)

    # 4. Sujet de l'email
    subject = f'Mise à jour requise - {company_name}'

    return {
        'html':    html,
        'subject': subject,
        'text':    reformulated_text,
    }


def pick_random_template():
    """Retourne un template aléatoire parmi les 10 disponibles."""
    return random.choice(TEMPLATES)


def load_base_text(config):
    """Charge le texte de base depuis un fichier ou retourne le texte par défaut.

    Le fichier est configuré via BASE_TEXT_FILE dans le fichier de config.
    Si le fichier n'existe pas, utilise DEFAULT_BASE_TEXT.
    """
    import os
    base_text_file = config.get('BASE_TEXT_FILE', 'base_text.txt')
    if os.path.exists(base_text_file):
        try:
            with open(base_text_file, 'r', encoding='utf-8') as f:
                content = f.read().strip()
            if content:
                return content
        except Exception:
            pass
    return DEFAULT_BASE_TEXT


def build_letter_message(config, cta_link):
    """Point d'entrée principal : génère le HTML complet quand LETTER_RANDOM=true.

    Args:
        config   : dict CONFIG de send.py (contient COLOR, LOGO, COMPANY_NAME, etc.)
        cta_link : URL du bouton CTA (vient de liens.txt)

    Returns:
        str : contenu HTML complet prêt à être envoyé
    """
    template  = pick_random_template()
    base_text = load_base_text(config)
    result    = generate_email_from_template(template, config, base_text, cta_link)
    return result['html']
