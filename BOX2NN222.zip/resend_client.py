"""Client Resend pour Replit et les copies locales Windows."""

import base64
import html
import json
import os
import re
import shutil
import subprocess
import urllib.error
import urllib.request
from pathlib import Path


class ResendError(RuntimeError):
    """Erreur renvoyée par Resend, son pont local ou l'API directe."""

    def __init__(self, message, *, retryable=True):
        super().__init__(message)
        self.retryable = retryable


_BRIDGE_PATH = Path(__file__).with_name("resend_bridge.js")
_API_FILE_PATH = Path(__file__).with_name("API.txt")
_RESEND_API_URL = "https://api.resend.com"


def _one_line(value):
    """Conserve toute l'erreur du pont sans casser les logs par email."""
    return " ".join(str(value or "").split())


def _read_api_file_key():
    """Lit la clé locale sans jamais l’écrire dans les logs."""
    try:
        if not _API_FILE_PATH.exists():
            _API_FILE_PATH.write_text(
                "# Clé API Resend locale uniquement — ne pas partager ce fichier.\n"
                "RESEND_API_KEY=\n",
                encoding="utf-8",
            )
            return ""
        lines = _API_FILE_PATH.read_text(encoding="utf-8").splitlines()
    except OSError:
        return ""

    for line in lines:
        value = line.strip()
        if not value or value.startswith("#"):
            continue
        if "=" in value:
            name, secret = value.split("=", 1)
            if name.strip().upper() == "RESEND_API_KEY":
                return secret.strip().strip('"').strip("'")
        elif value.startswith("re_"):
            # Accepte aussi une clé seule pour les anciennes copies locales.
            return value
    return ""


def _direct_api_key():
    """Privilégie le secret Replit, puis la clé du fichier local."""
    return os.environ.get("RESEND_API_KEY", "").strip() or _read_api_file_key()


def _missing_replit_identity(error):
    text = str(error).lower()
    return (
        "replit identity token not found" in text
        or "neither repl_identity nor web_repl_renewal" in text
        or "are you running this inside a repl" in text
    )


def _response_body(raw_body):
    text = raw_body.decode("utf-8", errors="replace") if isinstance(raw_body, bytes) else raw_body
    if not text:
        return {}
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        return {"message": _one_line(text)}


def _response_is_non_retryable(status, body):
    """Les erreurs client ne doivent pas être répétées automatiquement."""
    try:
        status = int(status)
    except (TypeError, ValueError):
        status = 0
    if 400 <= status < 500 and status not in (408, 429):
        return True
    if not isinstance(body, dict):
        return False
    return (
        body.get("error_code") == 1010
        or body.get("error_name") == "browser_signature_banned"
        or body.get("cloudflare_error") is True
    )


def _request_direct(path, payload=None, *, method="POST", api_key):
    """Appelle l'API Resend directement pour une exécution hors Repl."""
    data = None
    if payload is not None:
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    request = urllib.request.Request(
        f"{_RESEND_API_URL}{path}",
        data=data,
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            "Accept": "application/json",
            "User-Agent": "YODA-Mailer/1.0 (Resend API client)",
        },
        method=method,
    )
    try:
        with urllib.request.urlopen(request, timeout=45) as response:
            body = _response_body(response.read())
            if not 200 <= response.status < 300:
                details = body.get("message") or body.get("name") or body
                raise ResendError(
                    f"Resend ({response.status}): {_one_line(details)}",
                    retryable=not _response_is_non_retryable(response.status, body),
                )
            return body
    except urllib.error.HTTPError as exc:
        body = _response_body(exc.read())
        details = body.get("message") or body.get("name") or body
        raise ResendError(
            f"Resend ({exc.code}): {_one_line(details)}",
            retryable=not _response_is_non_retryable(exc.code, body),
        ) from exc
    except urllib.error.URLError as exc:
        raise ResendError(f"Connexion directe à Resend impossible : {_one_line(exc.reason)}") from exc
    except TimeoutError as exc:
        raise ResendError("La requête directe Resend a expiré.") from exc


def _request(path, payload=None, *, method="POST"):
    api_key = _direct_api_key()
    if api_key:
        return _request_direct(path, payload, method=method, api_key=api_key)

    request_data = json.dumps(
        {"path": path, "method": method, "body": payload},
        ensure_ascii=False,
    )
    try:
        node = shutil.which("node") or "node"
        result = subprocess.run(
            [node, str(_BRIDGE_PATH)],
            input=request_data,
            text=True,
            encoding="utf-8",
            errors="replace",
            capture_output=True,
            timeout=45,
            cwd=str(_BRIDGE_PATH.parent),
            env=os.environ.copy(),
            check=False,
        )
    except FileNotFoundError as exc:
        raise ResendError("Node.js est requis pour utiliser la connexion Resend.") from exc
    except subprocess.TimeoutExpired as exc:
        raise ResendError("La requête Resend a expiré.") from exc

    try:
        response = json.loads(result.stdout)
    except json.JSONDecodeError as exc:
        details = _one_line(result.stderr) or "Réponse invalide du pont Resend."
        if "Cannot find module" in details:
            details += " — installez les dépendances Node avec « pnpm install » depuis le dossier du projet."
        raise ResendError(details) from exc

    if not response.get("ok"):
        details = response.get("body") or response.get("error") or "Requête Resend refusée."
        if isinstance(details, dict):
            details = details.get("message") or details.get("name") or json.dumps(details, ensure_ascii=False)
        response_status = response.get("status", "erreur")
        error = ResendError(
            f"Resend ({response_status}): {_one_line(details)}",
            retryable=not _response_is_non_retryable(response_status, response.get("body")),
        )
        if _missing_replit_identity(error):
            if api_key:
                return _request_direct(path, payload, method=method, api_key=api_key)
            raise ResendError(
                "La connexion Resend gérée par Replit est disponible uniquement dans un Repl. "
                "Hors Replit, renseignez RESEND_API_KEY dans le fichier API.txt."
            ) from error
        raise error
    return response.get("body") or {}


def html_to_text(content):
    """Produit une version texte simple pour les clients non HTML."""
    without_tags = re.sub(r"<[^>]+>", " ", content or "")
    normalized = re.sub(r"\s+", " ", html.unescape(without_tags)).strip()
    return normalized or "Message envoyé via Resend."


def build_attachments(paths):
    attachments = []
    for path in paths or []:
        if not os.path.isfile(path):
            continue
        with open(path, "rb") as file:
            attachments.append({
                "filename": os.path.basename(path),
                "content": base64.b64encode(file.read()).decode("ascii"),
            })
    return attachments


def build_inline_attachments(items):
    """Encode les images CID au format inline attendu par Resend."""
    attachments = []
    for item in items or []:
        if not isinstance(item, dict):
            continue
        path = item.get("path")
        content_id = str(item.get("cid") or "").strip().strip("<>")
        if not path or not content_id or not os.path.isfile(path):
            continue
        with open(path, "rb") as file:
            attachments.append({
                "filename": str(item.get("filename") or os.path.basename(path)),
                "content": base64.b64encode(file.read()).decode("ascii"),
                "content_id": content_id,
            })
    return attachments


def send_email(*, sender, recipients, subject, html_content, text_content=None,
               reply_to=None, headers=None, attachments=None, inline_attachments=None):
    if not sender or "@" not in sender:
        raise ResendError(
            "RESEND_FROM doit contenir une adresse d’expédition vérifiée dans Resend."
        )

    to_addresses = [address for address in recipients if address and "@" in address]
    if not to_addresses:
        raise ResendError("Aucun destinataire valide pour Resend.")

    payload = {
        "from": sender,
        "to": to_addresses,
        "subject": subject,
        "html": html_content,
        "text": text_content or html_to_text(html_content),
    }
    if reply_to and "@" in reply_to:
        payload["reply_to"] = reply_to
    if headers:
        payload["headers"] = headers
    all_attachments = build_attachments(attachments)
    all_attachments.extend(build_inline_attachments(inline_attachments))
    if all_attachments:
        payload["attachments"] = all_attachments

    return _request("/emails", payload)