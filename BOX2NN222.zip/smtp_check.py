"""Test contrôlé de tous les comptes SMTP avec confirmation par boîtes IMAP."""

from __future__ import annotations

import email
import imaplib
import json
import os
import re
import smtplib
import ssl
import tempfile
import threading
import time
import uuid
import unicodedata
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from email.header import decode_header, make_header
from email.mime.application import MIMEApplication
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.utils import formataddr, formatdate, make_msgid, parseaddr
from html import escape as html_escape
from pathlib import Path

from letter_system import build_letter_message
from letter_to_image import LetterImageError, render_html_to_png
from smtp_connection import establish_tls, open_smtp
from secure_coordinator import SecureCoordinator


def _email_addresses(values: object, *, maximum: int = 10) -> list[str]:
    if not isinstance(values, list):
        raise ValueError("La liste des adresses de test est invalide.")
    result: list[str] = []
    seen: set[str] = set()
    for raw in values:
        value = str(raw or "").strip()
        normalized = value.lower()
        if not value or "@" not in value or normalized in seen:
            continue
        seen.add(normalized)
        result.append(value)
    if not result:
        raise ValueError("Ajoutez au moins une adresse e-mail de test.")
    if len(result) > maximum:
        raise ValueError(f"Le SMTP_CHECK accepte au maximum {maximum} adresses de test.")
    return result


def _decode_header_value(value: str | None) -> str:
    if not value:
        return ""
    try:
        return str(make_header(decode_header(value)))
    except Exception:
        return str(value)


def _safe_error(error: BaseException) -> str:
    detail = " ".join(str(error).split())
    detail = re.sub(
        r"(?i)(password|passwd|pass|secret)\s*[=:]\s*\S+",
        r"\1=[masqué]",
        detail,
    )
    return detail[:220] or type(error).__name__


class SmtpCheckManager:
    def __init__(self, app_dir: str, coordinator: SecureCoordinator | None = None):
        self.app_dir = Path(app_dir)
        self.settings_path = self.app_dir / "smtp_check_accounts.json"
        self.coordinator = coordinator or SecureCoordinator(app_dir)
        self.lock = threading.RLock()
        self.stop_event = threading.Event()
        self.thread: threading.Thread | None = None
        self.on_validated = None
        self.state = self._empty_state()

    @staticmethod
    def _empty_state() -> dict:
        return {
            "running": False,
            "phase": "idle",
            "run_id": None,
            "check_send": False,
            "started_at": None,
            "finished_at": None,
            "expected": 0,
            "expected_accounts": 0,
            "sent": 0,
            "send_failures": 0,
            "removed_smtp": 0,
            "removal_error": None,
            "received": 0,
            "smtp_results": [],
            "mailboxes": [],
            "messages": [],
            "error": None,
            "warnings": [],
            "accounts": [],
            "terminal_count": 0,
            "validated_count": 0,
            "stop_reason": None,
            "imap_verified": False,
        }

    def _read_settings(self) -> dict:
        try:
            data = json.loads(self.settings_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            data = {}
        recipients = data.get("recipients") if isinstance(data.get("recipients"), list) else []
        accounts = data.get("accounts") if isinstance(data.get("accounts"), list) else []
        return {"recipients": recipients, "accounts": accounts}

    def public_settings(self) -> dict:
        data = self._read_settings()
        accounts = []
        for index, account in enumerate(data["accounts"]):
            password = str(account.get("password") or "")
            accounts.append({
                "index": index,
                "email": str(account.get("email") or ""),
                "server": str(account.get("server") or ""),
                "port": int(account.get("port") or 993),
                "password_set": bool(password),
                "password_masked": "••••••••" if password else "",
            })
        return {"recipients": data["recipients"], "accounts": accounts}

    def save_settings(self, recipients: object, accounts: object) -> dict:
        clean_recipients = _email_addresses(recipients)
        if not isinstance(accounts, list) or not accounts:
            raise ValueError("Ajoutez au moins un compte IMAP de réception.")
        if len(accounts) > 10:
            raise ValueError("Le SMTP_CHECK accepte au maximum 10 comptes IMAP.")

        existing = {
            str(item.get("email") or "").strip().lower(): item
            for item in self._read_settings()["accounts"]
        }
        clean_accounts = []
        account_emails: set[str] = set()
        for raw in accounts:
            if not isinstance(raw, dict):
                raise ValueError("Un compte IMAP est invalide.")
            address = str(raw.get("email") or "").strip()
            server = str(raw.get("server") or "").strip()
            password = str(raw.get("password") or "")
            normalized = address.lower()
            if not password and normalized in existing:
                password = str(existing[normalized].get("password") or "")
            try:
                port = int(raw.get("port") or 993)
            except (TypeError, ValueError) as exc:
                raise ValueError(f"Port IMAP invalide pour {address or 'un compte'}.") from exc
            if "@" not in address or not server or not password:
                raise ValueError(
                    "Chaque compte IMAP doit contenir une adresse, un mot de passe et un serveur."
                )
            if normalized in account_emails:
                raise ValueError(f"Le compte IMAP {address} est présent plusieurs fois.")
            if port < 1 or port > 65535:
                raise ValueError(f"Port IMAP invalide pour {address}.")
            account_emails.add(normalized)
            clean_accounts.append({
                "email": address,
                "password": password,
                "server": server,
                "port": port,
            })

        missing = [
            recipient for recipient in clean_recipients
            if recipient.lower() not in account_emails
        ]
        if missing:
            raise ValueError(
                "Connectez une boîte IMAP pour chaque destinataire de test : "
                + ", ".join(missing)
            )

        payload = {"recipients": clean_recipients, "accounts": clean_accounts}
        descriptor, temporary_path = tempfile.mkstemp(
            prefix=".smtp-check-", suffix=".json", dir=self.app_dir, text=True
        )
        try:
            with os.fdopen(descriptor, "w", encoding="utf-8") as output:
                json.dump(payload, output, indent=2, ensure_ascii=False)
                output.flush()
                os.fsync(output.fileno())
            try:
                os.chmod(temporary_path, 0o600)
            except OSError:
                pass
            os.replace(temporary_path, self.settings_path)
        except Exception:
            try:
                os.unlink(temporary_path)
            except OSError:
                pass
            raise
        self._update(imap_verified=False)
        return self.public_settings()

    def snapshot(self) -> dict:
        with self.lock:
            return json.loads(json.dumps(self.state))

    def _update(self, **values) -> None:
        with self.lock:
            self.state.update(values)

    def _append_messages(self, messages: list[dict]) -> list[dict]:
        """Merge IMAP matches without allowing concurrent workers to clobber them."""
        if not messages:
            with self.lock:
                return list(self.state["messages"])
        with self.lock:
            by_id = {
                str(item.get("id") or ""): item
                for item in self.state["messages"]
            }
            for message in messages:
                mailbox = str(message.get("inbox_email") or "").strip().lower()
                uid = str(message.get("uid") or "").strip()
                if not mailbox or not uid:
                    fallback_id = str(message.get("id") or "").strip()
                    if fallback_id:
                        by_id.setdefault(fallback_id, dict(message))
                    continue
                stable_id = f"{mailbox}:{uid}"
                merged = dict(message)
                merged["id"] = stable_id
                by_id.setdefault(stable_id, merged)
            self.state["messages"] = list(by_id.values())
            self.state["received"] = len(self.state["messages"])
            return list(self.state["messages"])

    def _worker_start_gate(self, start_gate: dict) -> bool:
        """Rate-limit actual worker entry, including executor-queued work."""
        with start_gate["lock"]:
            now = time.monotonic()
            target = max(now, start_gate["next_start"])
            start_gate["next_start"] = target + 1.0
            if "starts" in start_gate:
                start_gate["starts"].append(target)
        if target > now:
            self.stop_event.wait(target - now)
        return not self.stop_event.is_set()

    @staticmethod
    def _read_smtp_accounts(path: Path, default_port: int) -> list[dict]:
        try:
            lines = path.read_text(encoding="utf-8").splitlines()
        except OSError as exc:
            raise ValueError(f"Le fichier SMTP « {path.name} » est introuvable.") from exc
        accounts = []
        for line_number, raw in enumerate(lines, 1):
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split(":")
            if len(parts) < 3:
                continue
            address = parts[0].strip()
            password = parts[1]
            if len(parts) >= 4 and parts[-1].strip().isdigit():
                server = ":".join(parts[2:-1]).strip()
                port = int(parts[-1].strip())
            else:
                server = ":".join(parts[2:]).strip()
                port = default_port
            if "@" not in address or not password or not server:
                continue
            accounts.append({
                "index": len(accounts),
                "line": line_number,
                "email": address,
                "password": password,
                "server": server,
                "port": port,
                "raw": line,
            })
        if not accounts:
            raise ValueError("Aucun compte SMTP valide n’a été trouvé dans smtp.txt.")
        return accounts

    @staticmethod
    def _remove_failed_smtp_accounts(path: Path, failed_accounts: list[dict]) -> int:
        """Retire atomiquement les lignes exactes des comptes totalement en échec."""
        failed_lines = {
            str(account.get("raw") or "").strip()
            for account in failed_accounts
            if str(account.get("raw") or "").strip()
        }
        if not failed_lines:
            return 0
        try:
            original_lines = path.read_text(encoding="utf-8").splitlines()
        except OSError as exc:
            raise RuntimeError("Impossible de relire smtp.txt pour retirer les échecs.") from exc

        kept_lines = []
        removed = 0
        for line in original_lines:
            if line.strip() in failed_lines:
                removed += 1
            else:
                kept_lines.append(line)
        if not removed:
            return 0

        descriptor, temporary_path = tempfile.mkstemp(
            prefix=".smtp-check-list-", suffix=".txt", dir=path.parent, text=True
        )
        try:
            with os.fdopen(descriptor, "w", encoding="utf-8") as output:
                output.write("\n".join(kept_lines))
                if kept_lines:
                    output.write("\n")
                output.flush()
                os.fsync(output.fileno())
            os.replace(temporary_path, path)
        except Exception:
            try:
                os.unlink(temporary_path)
            except OSError:
                pass
            raise
        return removed

    def _preflight_messages(
        self,
        mailbox: dict,
        client: imaplib.IMAP4_SSL,
        metadata: list[dict],
    ) -> list[dict]:
        metadata_by_id = {
            str(item.get("message_id") or "").strip(): item
            for item in metadata
        }
        status, payload = client.uid("search", None, "ALL")
        if str(status).upper() != "OK":
            raise RuntimeError("Recherche IMAP refusée.")
        found = []
        for uid in (payload[0] if payload else b"").split()[-250:]:
            uid_text = uid.decode("ascii", "replace")
            status, content = client.uid("fetch", uid, "(RFC822)")
            if str(status).upper() != "OK":
                continue
            raw = next(
                (
                    item[1]
                    for item in content or []
                    if isinstance(item, tuple) and len(item) > 1
                ),
                None,
            )
            if not raw:
                continue
            message = email.message_from_bytes(raw)
            message_id = str(message.get("Message-ID") or "").strip()
            metadata_row = metadata_by_id.get(message_id)
            subject = _decode_header_value(message.get("Subject"))
            stage1 = (
                str(message.get("X-Yoda-SMTP-Stage") or "").strip() == "1"
                and bool(str(message.get("X-Yoda-SMTP-Check") or "").strip())
                and bool(str(message.get("X-Yoda-SMTP-Account") or "").strip())
                and (
                    "SMTP_CHECK" in subject.upper()
                    or "STAGE-1" in subject.upper()
                )
            )
            if metadata_row:
                stage = int(metadata_row["stage"])
                smtp_account = str(metadata_row["account_email"])
                recipient = str(metadata_row["recipient"])
                correlation = message_id
            elif stage1:
                stage = 1
                smtp_account = str(message.get("X-Yoda-SMTP-Account") or "")
                recipient = parseaddr(str(message.get("To") or ""))[1]
                correlation = str(message.get("X-Yoda-SMTP-Correlation") or "")
            else:
                continue
            found.append({
                "id": f"{mailbox['email'].lower()}:{uid_text}",
                "uid": uid_text,
                "inbox_email": mailbox["email"],
                "from": _decode_header_value(message.get("From")),
                "to": _decode_header_value(message.get("To")) or recipient,
                "subject": subject,
                "date": _decode_header_value(message.get("Date")),
                "smtp_account": smtp_account,
                "stage": stage,
                "correlation": correlation,
                "received_at": datetime.now(timezone.utc).isoformat(),
            })
        return found

    def validate_imap_connections(self) -> dict:
        """Validate every configured mailbox and hydrate the inbox preview."""
        settings = self._read_settings()
        results = []
        all_messages = []
        metadata_getter = getattr(
            self.coordinator, "smtp_check_message_metadata", None
        )
        metadata = metadata_getter() if metadata_getter else []
        for mailbox in settings["accounts"]:
            client = None
            error_detail = None
            matched = []
            try:
                client = self._open_imap(mailbox)
                matched = self._preflight_messages(mailbox, client, metadata)
                all_messages.extend(matched)
            except Exception as exc:
                error_detail = _safe_error(exc)
            finally:
                if client is not None:
                    try:
                        client.logout()
                    except Exception:
                        pass
            results.append({
                "email": mailbox["email"],
                "server": mailbox["server"],
                "port": mailbox["port"],
                "connected": error_detail is None,
                "error": error_detail,
                "matched": len(matched),
            })
        self._append_messages(all_messages)
        with self.lock:
            self.state["mailboxes"] = results
            self.state["received"] = len(self.state["messages"])
            self.state["imap_verified"] = bool(results) and all(
                item["connected"] for item in results
            )
        return {
            "ok": bool(results) and all(item["connected"] for item in results),
            "mailboxes": results,
            "messages": self.snapshot()["messages"],
        }

    def start(self, config: dict, check_send: bool = False) -> dict:
        with self.lock:
            if self.thread and self.thread.is_alive():
                raise RuntimeError("Un SMTP_CHECK est déjà en cours.")
            settings = self._read_settings()
            recipients = _email_addresses(settings["recipients"])
            if not settings["accounts"]:
                raise ValueError("Configurez les boîtes IMAP de test avant le lancement.")
            preflight = self.validate_imap_connections()
            if not preflight["ok"]:
                details = "; ".join(
                    f"{item['email']}: {item['error'] or 'connexion refusée'}"
                    for item in preflight["mailboxes"]
                    if not item["connected"]
                )
                raise ValueError(
                    "Pré-validation IMAP refusée — aucun SMTP_CHECK lancé. "
                    + details
                )
            smtp_filename = str(config.get("SMTP_ACCOUNTS_FILE") or "smtp.txt").strip()
            smtp_path = Path(smtp_filename)
            if not smtp_path.is_absolute():
                smtp_path = self.app_dir / smtp_path
            smtp_accounts = self._read_smtp_accounts(
                smtp_path, int(config.get("AUTH_SMTP_PORT") or 587)
            )
            run_id = uuid.uuid4().hex
            self.stop_event.clear()
            previous_messages = self.snapshot()["messages"]
            previous_mailboxes = self.snapshot()["mailboxes"]
            self.state = self._empty_state()
            self.state.update({
                "running": True,
                "phase": "preparing",
                "run_id": run_id,
                "check_send": bool(check_send),
                "started_at": datetime.now(timezone.utc).isoformat(),
                "expected": len(smtp_accounts) * len(recipients) * 2,
                "expected_accounts": len(smtp_accounts),
                "messages": previous_messages,
                "received": len(previous_messages),
                "mailboxes": previous_mailboxes,
                "imap_verified": True,
            })
            run_config = config.copy()
            run_config["_SMTP_CHECK_SEND"] = bool(check_send)
            self.thread = threading.Thread(
                target=self._run,
                args=(run_config, settings, smtp_accounts, recipients, run_id),
                daemon=True,
                name="smtp-check",
            )
            self.thread.start()
            return self.snapshot()

    def stop(self) -> dict:
        self.stop_event.set()
        self._update(phase="stopping")
        return self.snapshot()

    def _message_html(self, config: dict) -> str:
        message_filename = str(config.get("MESSAGE_FILE") or "message.html").strip()
        message_path = Path(message_filename)
        if not message_path.is_absolute():
            message_path = self.app_dir / message_path
        try:
            html = message_path.read_text(encoding="utf-8")
        except OSError as exc:
            raise ValueError(f"La lettre « {message_filename} » est introuvable.") from exc
        if str(config.get("LETTER_RANDOM", "false")).lower() == "true":
            links_path = self.app_dir / str(config.get("LINKS_FILE") or "liens.txt")
            try:
                link = next(
                    line.strip()
                    for line in links_path.read_text(encoding="utf-8").splitlines()
                    if line.strip() and not line.lstrip().startswith("#")
                )
            except (OSError, StopIteration):
                link = ""
            html = build_letter_message(config, link)
        return html

    def _delivery_template(self, config: dict, html: str) -> dict:
        if str(config.get("LETTER_TO_IMG", "false")).lower() != "true":
            return {"html": html, "image_path": None, "preview": ""}
        message_path = str(config.get("MESSAGE_FILE") or "message.html")
        logo_path = str(config.get("LOGO_FILE") or "")
        image_path = render_html_to_png(
            html,
            source_path=message_path,
            logo_path=logo_path,
        )
        preview = unicodedata.normalize(
            "NFC", str(config.get("LETTER_PREVIEW_TEXT") or "")
        )
        preview = "".join(
            character
            for character in preview.replace("\u00a0", " ")
            if character in "\t "
            or unicodedata.category(character) not in {"Cc", "Cf"}
        ).strip()
        return {"html": "", "image_path": image_path, "preview": preview}

    @staticmethod
    def _build_message(
        account: dict,
        recipient: str,
        subject: str,
        run_id: str,
        delivery: dict,
        stage: int,
        sender_name: str = "",
        config: dict | None = None,
    ) -> MIMEMultipart:
        # Keep the old helper contract for integrations that call it directly,
        # while production SMTP_CHECK messages use the explicit stage format.
        legacy_headers = config is None and "password" not in account
        effective_config = config or {}
        root = MIMEMultipart("related")
        if int(stage) == 1:
            root["From"] = account["email"]
            root["Subject"] = "SMTP_CHECK STAGE-1"
        else:
            visible_from = str(effective_config.get("VISIBLE_FROM") or "").strip()
            if visible_from and "@" in parseaddr(visible_from)[1]:
                root["From"] = visible_from
            else:
                root["From"] = (
                    formataddr((sender_name, account["email"]))
                    if sender_name
                    else account["email"]
                )
            root["Subject"] = subject
        root["To"] = recipient
        root["Date"] = formatdate(localtime=True)
        root["Message-ID"] = make_msgid(
            domain=account["email"].rsplit("@", 1)[-1]
        )
        if int(stage) == 1:
            root["X-Yoda-SMTP-Check"] = run_id
            root["X-Yoda-SMTP-Account"] = account["email"]
            root["X-Yoda-SMTP-Stage"] = "1"
            root["X-Yoda-SMTP-Correlation"] = (
                f"{run_id}:{account['email'].lower()}:1"
            )
        elif legacy_headers:
            root["X-Yoda-SMTP-Check"] = run_id
            root["X-Yoda-SMTP-Account"] = account["email"]
            root["X-Yoda-SMTP-Stage"] = str(stage)
            root["X-Yoda-SMTP-Correlation"] = (
                f"{run_id}:{account['email'].lower()}:{stage}"
            )
        elif int(stage) == 2:
            reply_to = str(effective_config.get("REPLY_TO") or "").strip()
            if "@" in reply_to:
                root["Reply-To"] = reply_to
            unsubscribe_mailto = str(
                effective_config.get("UNSUBSCRIBE_MAILTO") or ""
            ).strip()
            unsubscribe_url = str(effective_config.get("UNSUBSCRIBE_URL") or "").strip()
            unsubscribe = []
            if "@" in unsubscribe_mailto:
                unsubscribe.append(f"<mailto:{unsubscribe_mailto}>")
            if unsubscribe_url.startswith(("http://", "https://")):
                unsubscribe.append(f"<{unsubscribe_url}>")
            if unsubscribe:
                root["List-Unsubscribe"] = ", ".join(unsubscribe)
                if unsubscribe_url.startswith(("http://", "https://")):
                    root["List-Unsubscribe-Post"] = "List-Unsubscribe=One-Click"

        if delivery["image_path"]:
            alternative = MIMEMultipart("alternative")
            root.attach(alternative)
            preview = delivery["preview"] or "Test de réception SMTP_CHECK"
            if delivery["preview"]:
                alternative.attach(MIMEText(preview, "plain", "utf-8"))
            cid = f"yoda-smtp-check-{uuid.uuid4().hex}"
            image_html = (
                '<html><body style="margin:0;padding:0;">'
                f'<img src="cid:{cid}" alt="" '
                'style="display:block;border:0;width:100%;max-width:720px;height:auto;">'
                "</body></html>"
            )
            alternative.attach(MIMEText(image_html, "html", "utf-8"))
            image_part = MIMEApplication(
                Path(delivery["image_path"]).read_bytes(), _subtype="png"
            )
            image_part.add_header("Content-ID", f"<{cid}>")
            image_part.add_header(
                "Content-Disposition", "inline", filename="letter.png"
            )
            root.attach(image_part)
        else:
            root.attach(MIMEText(delivery["html"], "html", "utf-8"))
        return root

    @staticmethod
    def _send_one(
        account: dict,
        recipients: list[str],
        subject: str,
        run_id: str,
        delivery: dict,
        stop_event: threading.Event,
        stage: int = 1,
        sender_name: str = "",
        config: dict | None = None,
    ) -> dict:
        server: smtplib.SMTP | None = None
        delivered = 0
        failures = []
        message_ids = {}
        cancelled = False
        try:
            if stop_event.is_set():
                cancelled = True
                return {
                    "smtp_index": account["index"],
                    "smtp_email": account["email"],
                    "server": account["server"],
                    "port": account["port"],
                    "sent": 0,
                    "failed": 0,
                    "failures": [],
                    "cancelled": True,
                }
            if int(account["port"]) == 465:
                server = open_smtp(
                    account["server"],
                    account["port"],
                    timeout=10,
                    ssl_context=ssl.create_default_context(),
                )
            else:
                server = open_smtp(account["server"], account["port"], timeout=10)
            establish_tls(
                server,
                account["server"],
                account["port"],
                required=int(account["port"]) != 465,
            )
            server.login(account["email"], account["password"])
            for recipient in recipients:
                if stop_event.is_set():
                    cancelled = True
                    break
                try:
                    message = SmtpCheckManager._build_message(
                        account, recipient, subject, run_id, delivery, stage,
                        sender_name, config,
                    )
                    server.sendmail(
                        account["email"], [recipient], message.as_string()
                    )
                    message_ids[recipient.lower()] = str(
                        message.get("Message-ID") or ""
                    ).strip()
                    delivered += 1
                except Exception as exc:
                    failures.append({
                        "recipient": recipient,
                        "error": _safe_error(exc),
                    })
        except Exception as exc:
            if stop_event.is_set():
                cancelled = True
                failures = []
            else:
                failures = [
                    {"recipient": recipient, "error": _safe_error(exc)}
                    for recipient in recipients
                ]
        finally:
            if server is not None:
                try:
                    server.quit()
                except Exception:
                    try:
                        server.close()
                    except Exception:
                        pass
        return {
            "smtp_index": account["index"],
            "smtp_email": account["email"],
            "server": account["server"],
            "port": account["port"],
            "sent": delivered,
            "failed": len(failures),
            "failures": failures,
            "message_ids": message_ids,
            "cancelled": cancelled,
        }

    @staticmethod
    def _open_imap(account: dict) -> imaplib.IMAP4_SSL:
        client = imaplib.IMAP4_SSL(
            account["server"],
            int(account.get("port") or 993),
            ssl_context=ssl.create_default_context(),
            timeout=10,
        )
        client.login(account["email"], account["password"])
        status, _ = client.select("INBOX")
        if str(status).upper() != "OK":
            raise RuntimeError("La boîte INBOX est inaccessible.")
        return client

    def _poll_mailbox(
        self,
        account: dict,
        run_id: str,
        stage: int | set[str] = 1,
        known: set[str] | None = None,
        smtp_account_email: str | None = None,
        expected_message_ids: set[str] | dict[str, str] | None = None,
    ) -> tuple[list[dict], str | None]:
        # Keep the pre-coordinator three-argument helper usable by existing
        # integrations: _poll_mailbox(account, run_id, known).
        if known is None and isinstance(stage, set):
            known = stage
            stage = 1
        if known is None:
            known = set()
        client: imaplib.IMAP4_SSL | None = None
        found = []
        try:
            client = self._open_imap(account)
            status, payload = client.uid("search", None, "ALL")
            if str(status).upper() != "OK":
                return [], "Recherche IMAP refusée."
            uids = (payload[0] if payload else b"").split()[-250:]
            for uid in reversed(uids):
                uid_text = uid.decode("ascii", "replace")
                unique = f"{account['email'].lower()}:{stage}:{uid_text}"
                if unique in known:
                    continue
                status, content = client.uid("fetch", uid, "(RFC822)")
                if str(status).upper() != "OK":
                    continue
                raw = next(
                    (
                        item[1]
                        for item in content or []
                        if isinstance(item, tuple) and len(item) > 1
                    ),
                    None,
                )
                if not raw:
                    continue
                message = email.message_from_bytes(raw)
                message_id = str(message.get("Message-ID") or "").strip()
                if expected_message_ids is not None:
                    if message_id not in expected_message_ids:
                        continue
                    expected_recipient = (
                        expected_message_ids.get(message_id)
                        if isinstance(expected_message_ids, dict)
                        else None
                    )
                    actual_recipient = parseaddr(
                        str(message.get("To") or "")
                    )[1].lower()
                    if expected_recipient and actual_recipient != expected_recipient.lower():
                        continue
                else:
                    # Compatibility path for the pre-correlator helper API.
                    if str(message.get("X-Yoda-SMTP-Check") or "").strip() != run_id:
                        continue
                    if (
                        smtp_account_email
                        and str(message.get("X-Yoda-SMTP-Account") or "").strip().lower()
                        != smtp_account_email.lower()
                    ):
                        continue
                    if str(message.get("X-Yoda-SMTP-Stage") or "").strip() != str(stage):
                        continue
                    message_account = str(
                        message.get("X-Yoda-SMTP-Account") or ""
                    ).strip().lower()
                    if str(message.get("X-Yoda-SMTP-Correlation") or "").strip() != (
                        f"{run_id}:{(smtp_account_email or message_account).lower()}:{stage}"
                    ):
                        continue
                legacy_correlation = str(
                    message.get("X-Yoda-SMTP-Correlation") or ""
                )
                attributed_account = (
                    smtp_account_email
                    if expected_message_ids is not None and smtp_account_email
                    else str(
                        message.get("X-Yoda-SMTP-Account")
                        or message.get("From")
                        or ""
                    )
                )
                found.append({
                    "id": uuid.uuid4().hex,
                    "uid": uid_text,
                    "inbox_email": account["email"],
                    "from": _decode_header_value(message.get("From")),
                    "to": _decode_header_value(message.get("To")),
                    "subject": _decode_header_value(message.get("Subject")),
                    "date": _decode_header_value(message.get("Date")),
                    "smtp_account": attributed_account,
                    "stage": int(stage),
                    "correlation": (
                        message_id
                        if expected_message_ids is not None
                        else legacy_correlation
                    ),
                    "received_at": datetime.now(timezone.utc).isoformat(),
                })
                known.add(unique)
            return found, None
        except Exception as exc:
            return [], _safe_error(exc)
        finally:
            if client is not None:
                try:
                    client.logout()
                except Exception:
                    pass

    def _run_account(
        self,
        account: dict,
        settings: dict,
        recipients: list[str],
        config: dict,
        run_id: str,
        delivery: dict,
        subject_base: str,
        sender_name: str,
        state: dict,
        result: dict,
        remove_lock: threading.Lock,
        start_gate: dict,
    ) -> None:
        """Run one account's two-stage state machine in its own worker."""
        known: set[str] = set()
        confirm_timeout = max(
            1.0, float(config.get("SMTP_CHECK_CONFIRM_TIMEOUT", 600))
        )

        def set_state(**values):
            with self.lock:
                state.update(values)

        def set_result(**values):
            with self.lock:
                result.update(values)

        def add_warning(warning):
            with self.lock:
                self.state["warnings"].append(warning)

        def refresh_state():
            with self.lock:
                self.state["terminal_count"] = sum(
                    item["status"] in {"validated", "failed"}
                    for item in self.state["accounts"]
                )
                self.state["validated_count"] = sum(
                    item["status"] == "validated"
                    for item in self.state["accounts"]
                )

        def add_result(stage_result: dict):
            with self.lock:
                result["stages"].append(stage_result)
                result["sent"] += stage_result["sent"]
                result["failed"] += stage_result["failed"]
                self.state["sent"] += stage_result["sent"]
                self.state["send_failures"] += stage_result["failed"]

        def campaign_complete() -> bool:
            checker = getattr(self.coordinator, "campaign_complete", None)
            if checker is None:
                return False
            try:
                return bool(
                    checker(self.coordinator.campaign_id_for_run(run_id))
                )
            except Exception:
                return False

        def stop_for_campaign() -> bool:
            if campaign_complete():
                self._update(stop_reason="campaign_complete")
                self.stop_event.set()
                return True
            return False

        # Submission cadence is only a hint once an executor queue exists.
        # This gate is enforced by the worker itself, so queued workers cannot
        # burst when an executor slot becomes available.
        if not self._worker_start_gate(start_gate):
            set_result(cancelled=True)
            return
        if stop_for_campaign():
            set_result(cancelled=True)
            return

        def poll_stage(
            stage: int,
            expected_message_ids: set[str] | dict[str, str] | None = None,
        ) -> bool:
            deadline = time.monotonic() + confirm_timeout
            while not self.stop_event.is_set() and time.monotonic() < deadline:
                if stop_for_campaign():
                    return False
                new_messages = []
                mailbox_states = []
                for mailbox in settings["accounts"]:
                    try:
                        found, error_detail = self._poll_mailbox(
                            mailbox, run_id, stage, known, account["email"],
                            expected_message_ids,
                        )
                    except TypeError as exc:
                        # Existing embedders may still provide the five-argument
                        # polling hook.
                        if "positional" not in str(exc) and "argument" not in str(exc):
                            raise
                        found, error_detail = self._poll_mailbox(
                            mailbox, run_id, stage, known, account["email"]
                        )
                    new_messages.extend(found)
                    mailbox_states.append({
                        "email": mailbox["email"],
                        "smtp_account": account["email"],
                        "stage": stage,
                        "connected": error_detail is None,
                        "error": error_detail,
                    })
                current_messages = self._append_messages(new_messages)
                with self.lock:
                    self.state["mailboxes"] = [
                        item for item in self.state["mailboxes"]
                        if not (
                            item.get("smtp_account") == account["email"]
                            and item.get("stage") == stage
                        )
                    ] + mailbox_states
                recipients_seen = {
                    parseaddr(str(item.get("to") or ""))[1].lower()
                    or str(item.get("to") or "").strip().lower()
                    for item in current_messages
                    if item.get("smtp_account", "").lower()
                    == account["email"].lower()
                    and item.get("stage") == stage
                }
                self._update(
                    phase="listening",
                    received=len(current_messages),
                )
                if {item.lower() for item in recipients}.issubset(recipients_seen):
                    self.coordinator.update_stage(
                        run_id, account, stage, "confirmed"
                    )
                    return True
                self.stop_event.wait(
                    max(0.1, float(config.get("CHECKV2_POLL_INTERVAL", 3)))
                )
            return False

        if self.stop_event.is_set():
            set_result(cancelled=True)
            return
        # Stage 1 is always the first network operation for this worker.
        stage_one = self._send_one(
            account, recipients,
            "SMTP_CHECK STAGE-1",
            run_id, delivery, self.stop_event, 1, "", config=config,
        )
        stage_one["stage"] = 1
        add_result(stage_one)
        record_messages = getattr(
            self.coordinator, "record_smtp_check_messages", None
        )
        if record_messages:
            record_messages(
                run_id, account["email"], 1, stage_one.get("message_ids", {})
            )
        if stage_one.get("cancelled"):
            set_result(cancelled=True)
            return
        self.coordinator.update_stage(
            run_id, account, 1,
            "sent" if stage_one["sent"] else "failed",
            "" if stage_one["sent"] else
            "Stage 1 SMTP delivery failed for every recipient.",
        )
        set_state(stage1="sent" if stage_one["sent"] else "failed")
        refresh_state()
        if not stage_one["sent"]:
            smtp_filename = str(config.get("SMTP_ACCOUNTS_FILE") or "smtp.txt").strip()
            smtp_path = Path(smtp_filename)
            if not smtp_path.is_absolute():
                smtp_path = self.app_dir / smtp_path
            try:
                with remove_lock:
                    removed = self._remove_failed_smtp_accounts(
                        smtp_path, [account]
                    )
                self._update(removed_smtp=self.snapshot()["removed_smtp"] + removed)
            except Exception as exc:
                self._update(removal_error=_safe_error(exc))
            set_state(status="failed")
            refresh_state()
            return
        if not poll_stage(1):
            if self.stop_event.is_set():
                set_result(cancelled=True)
                return
            warning = "Stage 1 non confirmé par les boîtes IMAP configurées."
            self.coordinator.update_stage(run_id, account, 1, "failed", warning)
            set_state(stage1="failed", status="failed")
            add_warning({
                "account": account["email"], "stage": 1, "message": warning,
            })
            refresh_state()
            return
        set_state(stage1="confirmed")

        # Stage 2 is impossible until poll_stage(1) returns True.
        if stop_for_campaign():
            set_result(cancelled=True)
            return
        stage_two = self._send_one(
            account, recipients,
            subject_base,
            run_id, delivery, self.stop_event, 2, sender_name, config=config
        )
        stage_two["stage"] = 2
        add_result(stage_two)
        if record_messages:
            record_messages(
                run_id, account["email"], 2, stage_two.get("message_ids", {})
            )
        if stage_two.get("cancelled"):
            set_result(cancelled=True)
            return
        self.coordinator.update_stage(
            run_id, account, 2,
            "sent" if stage_two["sent"] else "failed",
        )
        set_state(stage2="sent" if stage_two["sent"] else "failed")
        refresh_state()
        stage_two_ids = {
            message_id: recipient
            for recipient, message_id in stage_two.get("message_ids", {}).items()
            if message_id
        }
        if not stage_two["sent"] or not poll_stage(2, stage_two_ids):
            if self.stop_event.is_set():
                set_result(cancelled=True)
                return
            warning = (
                "Échec du stage 2 : changez les en-têtes et "
                "SENDER_NAME avant de réessayer."
            )
            self.coordinator.update_stage(run_id, account, 2, "failed", warning)
            set_state(stage2="failed", status="failed")
            add_warning({
                "account": account["email"], "stage": 2, "message": warning,
            })
            refresh_state()
            return
        set_state(stage2="confirmed", status="validated")
        self.coordinator.publish_validated(run_id, account)
        if config.get("_SMTP_CHECK_SEND", False) and self.on_validated is not None:
            try:
                self.on_validated(account)
            except Exception:
                pass
        refresh_state()

    def _run(
        self,
        config: dict,
        settings: dict,
        smtp_accounts: list[dict],
        recipients: list[str],
        run_id: str,
    ) -> None:
        """Schedule workers one second apart; workers poll independently."""
        image_path = None
        try:
            html = self._message_html(config)
            delivery = self._delivery_template(config, html)
            image_path = delivery.get("image_path")
            subject_base = str(config.get("EMAIL_SUBJECT") or "Test SMTP").strip()
            sender_name = str(config.get("SENDER_NAME") or "").strip()
            cached_getter = getattr(
                self.coordinator, "cached_validated_accounts", None
            )
            cached_accounts = (
                cached_getter(smtp_accounts) if cached_getter else []
            )
            cached_keys = {
                self.coordinator.account_key_for_account(account)
                for account in cached_accounts
            }
            self.coordinator.begin_run(run_id, smtp_accounts)
            states = [
                {
                    "smtp_index": account["index"],
                    "email": account["email"],
                    "stage1": "pending",
                    "stage2": "pending",
                    "status": "pending",
                }
                for account in smtp_accounts
            ]
            results = [
                {
                    "smtp_index": account["index"],
                    "smtp_email": account["email"],
                    "server": account["server"],
                    "port": account["port"],
                    "stages": [],
                    "sent": 0,
                    "failed": 0,
                    "cancelled": False,
                }
                for account in smtp_accounts
            ]
            key_for_account = getattr(
                self.coordinator, "account_key_for_account", None
            )
            for account, state, result in zip(
                smtp_accounts, states, results
            ):
                key = (
                    key_for_account(account)
                    if key_for_account
                    else ""
                )
                if key in cached_keys:
                    state.update({
                        "stage1": "confirmed",
                        "stage2": "confirmed",
                        "status": "validated",
                    })
                    result["stages"] = [
                        {"stage": 1, "sent": 0, "failed": 0, "confirmed": True, "cached": True},
                        {"stage": 2, "sent": 0, "failed": 0, "confirmed": True, "cached": True},
                    ]
            seed_cached = getattr(
                self.coordinator, "seed_cached_validated", None
            )
            if seed_cached and cached_accounts:
                seed_cached(run_id, cached_accounts)
                if (
                    config.get("_SMTP_CHECK_SEND", False)
                    and self.on_validated is not None
                ):
                    for account in cached_accounts:
                        try:
                            self.on_validated(account)
                        except Exception:
                            pass
            self._update(
                phase="sending",
                expected_accounts=len(smtp_accounts),
                accounts=states,
                smtp_results=results,
                terminal_count=sum(
                    item["status"] in {"validated", "failed"}
                    for item in states
                ),
                validated_count=sum(
                    item["status"] == "validated" for item in states
                ),
            )
            remove_lock = threading.Lock()
            start_gate = {"lock": threading.Lock(), "next_start": 0.0}
            futures = []
            max_workers = min(30, max(1, len(smtp_accounts)))
            with ThreadPoolExecutor(max_workers=max_workers) as executor:
                next_start = time.monotonic()
                for account, state, result in zip(
                    smtp_accounts, states, results
                ):
                    if state["status"] == "validated":
                        continue
                    if self.stop_event.is_set():
                        break
                    checker = getattr(self.coordinator, "campaign_complete", None)
                    if checker is not None:
                        try:
                            if checker(
                                self.coordinator.campaign_id_for_run(run_id)
                            ):
                                self._update(stop_reason="campaign_complete")
                                self.stop_event.set()
                                break
                        except Exception:
                            pass
                    wait_for = next_start - time.monotonic()
                    if wait_for > 0:
                        self.stop_event.wait(wait_for)
                    if self.stop_event.is_set():
                        break
                    # Submit only after the cadence gate.  A worker may still
                    # be waiting on IMAP while the next one starts.
                    future = executor.submit(
                        self._run_account,
                        account, settings, recipients, config, run_id,
                        delivery, subject_base, sender_name, state, result,
                        remove_lock, start_gate,
                    )
                    futures.append((future, state))
                    next_start = time.monotonic() + 1.0
                for future, state in futures:
                    try:
                        future.result()
                    except Exception as exc:
                        with self.lock:
                            state["status"] = "failed"
                            state["stage1"] = "failed"
                            state["stage2"] = "failed"
                        self._update(error=_safe_error(exc), phase="error")
            if self.stop_event.is_set():
                with self.lock:
                    for state in states:
                        if state["status"] == "pending":
                            state["status"] = "stopped"
                            state["stage1"] = "stopped"
                            state["stage2"] = "stopped"
                reason = self.snapshot().get("stop_reason")
                phase = (
                    "campaign_complete"
                    if reason == "campaign_complete"
                    else "stopped"
                )
                self._update(
                    phase=phase,
                    accounts=states,
                    terminal_count=sum(
                        item["status"] in {"validated", "failed", "stopped"}
                        for item in states
                    ),
                    validated_count=sum(
                        item["status"] == "validated" for item in states
                    ),
                )
                self.coordinator.finish_run(
                    run_id,
                    "campaign_complete" if reason == "campaign_complete" else "stopped",
                )
            else:
                self._update(phase="complete", accounts=states)
                self.coordinator.finish_run(run_id, "complete")
        except (ValueError, LetterImageError) as exc:
            self._update(phase="error", error=_safe_error(exc))
            try:
                self.coordinator.finish_run(run_id, "error", _safe_error(exc))
            except Exception:
                pass
        except Exception as exc:
            self._update(phase="error", error=_safe_error(exc))
            try:
                self.coordinator.finish_run(run_id, "error", _safe_error(exc))
            except Exception:
                pass
        finally:
            if image_path:
                try:
                    os.unlink(image_path)
                except OSError:
                    pass
            self._update(
                running=False,
                finished_at=datetime.now(timezone.utc).isoformat(),
            )

    def delete_message(self, message_id: str) -> dict:
        with self.lock:
            message = next(
                (item for item in self.state["messages"] if item["id"] == message_id),
                None,
            )
        if not message:
            raise ValueError("Message introuvable.")
        account = next(
            (
                item for item in self._read_settings()["accounts"]
                if str(item.get("email") or "").lower()
                == message["inbox_email"].lower()
            ),
            None,
        )
        if not account:
            raise ValueError("Le compte IMAP associé n’est plus configuré.")
        client: imaplib.IMAP4_SSL | None = None
        try:
            client = self._open_imap(account)
            status, _ = client.uid(
                "store", message["uid"].encode("ascii"), "+FLAGS", r"(\Deleted)"
            )
            if str(status).upper() != "OK":
                raise RuntimeError("Le serveur IMAP a refusé la suppression.")
            client.expunge()
        finally:
            if client is not None:
                try:
                    client.logout()
                except Exception:
                    pass
        with self.lock:
            self.state["messages"] = [
                item for item in self.state["messages"] if item["id"] != message_id
            ]
            self.state["received"] = len(self.state["messages"])
        return self.snapshot()

    def delete_all_messages(self) -> dict:
        message_ids = [item["id"] for item in self.snapshot()["messages"]]
        errors = []
        for message_id in message_ids:
            try:
                self.delete_message(message_id)
            except Exception as exc:
                errors.append(_safe_error(exc))
        if errors:
            raise RuntimeError(
                f"{len(errors)} message(s) n’ont pas pu être supprimés : {errors[0]}"
            )
        return self.snapshot()