<?php
srand(time());
ini_set("memory_limit", "512M");
$client_ip = file_get_contents("http://ipecho.net/plain");
//echo $client_ip."\n";
echo "\nPUBLIC IP : ".$client_ip."\n";


$rdns = gethostbyaddr($client_ip);
if($rdns){
    echo "PUBLIC IP RDNS : ".$rdns."\n";
}else{
    echo "ERROR CANT GET PTR ADDRESS : ".$rdns."\n";
}

$myfile = fopen("start.txt", "w") or die("Unable to open file!");
$txt = "0";
fwrite($myfile, $txt);
fclose($myfile);




function read_smtp_response($socket, $chunkSize = 1024) {
  $response = '';
  while ($line = fgets($socket, $chunkSize)) {
      $response .= $line;
      // Check if this is the last line (SMTP response codes are 3-digit, followed by space for the last line)
      if (preg_match('/^\d{3}[\s]/', $line)){
          break;
      }
  }
  return $response;
}



function obfuscateSpanTextRegex($html) {
    return preg_replace_callback(
        '/<span>(.*?)<\/span>/i',
        function ($matches) {
            return '<span>' . obfuxt($matches[1]) . '</span>';
        },
        $html
    );
}


function pause($message = "Press Enter to continue...") {
    echo $message;
    fgets(STDIN);
    $myfile = fopen("start.txt", "w") or die("Unable to open file!");
    $txt = "1";
    fwrite($myfile, $txt);
    fclose($myfile);

}

//$queue = msg_get_queue(876324578786);
//$queue = msg_get_queue(ftok(__FILE__, 'b'));
/*
if($argv[6] || $argv[5] == 1){
  $myfile = fopen("start.txt", "w") or die("Unable to open file!");
  $txt = "1";
  fwrite($myfile, $txt);
  fclose($myfile);  
}
*/



$folder = "threadinfo/".$argv[2];



foreach (glob($folder . "/*") as $file) {
    if (is_file($file)) {
      if($argv[6]){
        unlink($file); // Delete the file
      }
    }
}

//unlink("filterOVH");


error_reporting(E_ALL);
ini_set('display_errors', 1);
ob_implicit_flush(true);

if (!function_exists('pcntl_fork')) {
  die("PCNTL extension is not available on this system.\n");
}


$config = fopen("config.txt", "r") or die("NO CONFIG FILE config.txt");
$configs = fread($config,filesize("config.txt"));    
fclose($config);

if(strpos($configs,"{@rdns}") !== false){       
  $configs = str_replace("{@rdns}",$rdns,$configs);                                 
}

retrygen:
$parts = explode('~', $configs);
$senderemail = $parts[1];

$spdss = substr(str_shuffle('azertyuiopqsdfghjklmwxcvbn'),0,3);
$senderemail = str_replace("{@3sgen}",$spdss,$senderemail);
$senderemail = str_replace("{@3gen}",$spdss,$senderemail);
$senderemail = str_replace("{@","",$senderemail);


$sendertld = strstr($senderemail, "@");
$sendertld = substr($sendertld, 1);

echo "\nSENDER TLD : ".$sendertld."\n";

if(strpos($sendertld,"googleusercontent.com") > -1){
   goto downn;
}


if(checkdnsrr($sendertld,"A")){
  if(checkdnsrr($sendertld, "MX")){


    if(checkdnsrr($sendertld, "TXT")){
      echo "\nHAS TXT\n";
      goto retrygen;
    }


    getmxrr($sendertld, $mx_reords, $mx_wight);
    for($ii=0;$ii<1;$ii++){  //count($mx_reords)
      if(count($mx_reords) > 0){
        $mxs[$mx_reords[$ii]] = $mx_wight[$ii];
      }            
    }
    $serre = $mx_reords[0];
    if(strlen($serre) > 4 ){
      echo "\n $serre HAS MX NORMAL\n";
      if(checkdnsrr($serre,"A")){

        $ippuserdomain = "";
        $records = dns_get_record($serre, DNS_A);
        if ($records) {
            foreach ($records as $record) {
                $ippuserdomain = $record['ip'];
                break;
            }
        }
        if($ippuserdomain == "127.0.0.1"){
          echo "\nFAKE IP MX\n";
          sleep(5);
          goto retrygen;
        }else{
          echo "\nGOOD IP ".$ippuserdomain."\n";
        }


      }else{
        goto retrygen;
      }

    }else{
      echo "\n ($serre) ERROR MX\n";
      goto retrygen;
    }    

  }else{
      goto retrygen;
  }
}else{
    goto retrygen;
}



downn:


$serverre = $parts[23];
$adddns = $parts[0];

if($argv[5] > 1 && strlen($serverre) < 1){
    //echo "\n Could not SEND BCC WHEN MX NOT DEFINE \n";
    //exit;
}

$hostseerrv = "84.247.166.223";

//echo $serverre."\n";


  if($adddns){

  $socket = socket_create(AF_INET, SOCK_DGRAM, 0) or die("Could not create socket\n");
  $result = socket_connect($socket, $hostseerrv, 53) or die("Could not connect EMAIL SERVER TO HELP US GET SPF\n");
  if($result){
      echo "\nSUCCESS: CONNECTED TO DNS SERVER TO HELP US GET SPF FROM DNS\n";
  }
  //$result = socket_read($socket, 1024) or die("Could not read server response\n");
  //echo "EMAIL SERVER : ".$result."\n";
  $helpstring = "HELPMEWITH DOMAIN AND IP : ".$sendertld.":".$client_ip.":".$argv[3];
  echo $helpstring."\nWAITING FOR IT TO CHECK IF EXIST IF NOT HELP ADD\n";
  socket_write($socket, $helpstring, strlen($helpstring)) or die("Could not send data to server\n");
  $result = socket_read($socket, 1024) or die("Could not read server response\n");
  echo "\n".$result;

  if(strpos($result, 'NO ZONE') !== false ){ 
      //exit;
      sleep(2);
      //socket_close($socket);
  }
  if(strpos($result, 'IP NOT EXIST IN') !== false){
      sleep(2);
  }
  socket_close($socket);
  }





$serverre = "";


sleep(1);

$emaillist = "notification.client@free.fr";

if($argv[6]){
 $emaillis = fopen($argv[2], "r") or die("NO EMAIL LIST FILE : ".$argv[2]."\n");
 $emaillist = fread($emaillis,filesize($argv[2]));
 fclose($emaillis); 
}





$smlconfig = "";
if(strlen($argv[1]) > 1){

    echo "\nCLIENT: CONNECTING TO ".$hostseerrv." DBS SERVER\n";
    $smlconfig = file_get_contents("http://".$hostseerrv."/".$argv[1]);

    echo "DBS SERVER : ".$smlconfig."\n"; 
    if(strpos($smlconfig,$argv[1]) !== false){
      echo "\nEXIST DBS NAMES ".$argv[1]."\n";
    }else{
        echo "\nNOT EXIST DBS NAMES ".$argv[1]."\n";       
        exit;
    }  


}else{
  echo "INCORRECT DBS NAMES FORMAT = ".$argv[1]."\n";
}

$filesname = $parts[27];
if(strlen($filesname) > 0){   
    $bfille = base64_encode(file_get_contents($filesname));
    $datatype = strstr($filesname, ".");$datatype = substr($datatype, 1);
    if($datatype == "jpeg" || $datatype == "jpg"){
        $datatype = "image/jpeg";
    }
    if($datatype == "png"){
        $datatype = "image/png";
    }
    if($datatype == "pdf"){
        $datatype = "application/pdf";
    }
    if($datatype == "svg"){
        $datatype = "image/svg+xml";
    }
    if($datatype == "ico"){
        $datatype = "image/x-icon";
    }
    if($datatype == "gif"){
        $datatype = "image/gif";
    }  
}

echo "\nCLIENT: CONNECTING TO ".$hostseerrv." LINK DBS SERVER\n";
$sml= "";

if(1){
  $sml = file_get_contents("http://".$hostseerrv."/all/redirect/index.txt");
}

$vallent = substr_count($emaillist, "\n");
$vallent++;






$emailstartpoint = 0;

echo "\nVersion : ".PHP_OS."\n";
if(PHP_OS == "Linux"){
 $userparts = explode("\n", $emaillist);
}else if(PHP_OS == "WINNT"){
 $userparts = explode("\r\n", $emaillist);
}else{
 echo "\nUNKNOWN OS VERSION Contact Darleen\n";
 exit;
}

$desktopname = substr(str_shuffle('AZERTYUIOPQSDFGHJKLMWWXCVBN234567890'),0,rand()%15);
$prefix = (rand()%255).".".(rand()%255).".".(rand()%255).".".(rand()%255);







if($argv[5] > 1 && $argv[7] > 1){
 echo "\nBCC not support with threading\n";
 //exit(1);
}

if($argv[7] > $vallent && $argv[6]){
  $argv[7] = $vallent;
}

$active_children = 0;


$tmail = ceil($vallent/$argv[7]);
$startpoint = 0;



echo "\nTOTAL THREAD = ".$argv[7]." | EMAIL ALOCATED PAR THREAD = $tmail \n";
sleep(2);

for($i = 1; $i <= $argv[7]; $i++){




  if($argv[6]){
    $startpoint += $tmail;
  }else{
    $startpoint = $tmail;
  }

  $myid = $i;
  $pid = pcntl_fork();

  if($pid == -1){
    die("Could not fork");
  }elseif($pid == 0){  



if($argv[6]){

    if($myid == 1){

    }else{
      for(;;){
          $start = fopen("start.txt", "r") or die("error"); 
          $starts = fread($start,1);
          fclose($start);
          if(strpos($starts,"1") !== false){
               break;
          }
      }
    }
}



    echo "\nTHREAD ".$myid.": TTL email par thread ".$tmail." ; EMAIL start point : ".($startpoint-$tmail)."\n";


    beginnn:

    $doneeemail = fopen("threadinfo/".$argv[2]."/".$myid."-done", "a") or die("Unable to open file!");
    //fwrite($doneeemail, "\n");




    $ttcount = 0;
    $emalinvalid = 0;
    $emalivalidout = 0;
    $rejectedmail = 0;
    $tunov = 0;
    $mxerro = 0;
    $errsoc = 0;
    $errip = 0;
    $errip2 = 0;
    $breakforempt = 0;
    $breakforempt2 = 0;
    $soccrrect = 0;
    $erossll = 0;
    $erossll2 = 0;
    $contmout = 0;

    $validmail = "";
    $valmaill = 0;





    for($oposi=0;$oposi<$tmail;$oposi++){
      //begicontinue:
      if($startpoint-$tmail+$oposi == $vallent){
        break;          
      }



      $useremail = $userparts[$startpoint-$tmail+$oposi];

      $userreplace = $parts[29];

      if(strlen($userreplace) > 0 && $myid !== 1 ){   //!str_contains($useremail, 'contact@service-tennis.fr')
        $useruser = strtok($useremail, '@');
        $useremail = str_replace($useruser,$userreplace,$useremail);       
      }else{
        if($oposi+1 == 1){
        }else{
          $useruser = strtok($useremail, '@');
          $useremail = str_replace($useruser,$userreplace,$useremail);
        }
      }


      //sleep(2);
      //echo "\nTHREAD $myid: ".($oposi+1).": | ".$tmail."  -|-  ".$ttcount."           ".$useremail;

      //exit;

      if(strlen($useremail) < 1 || strpos($useremail, "@") == false || strpos($useremail, ".") == false){
        echo "\nTHREAD $myid: ".($oposi+1).": USEREMAIL NOT WEL FORMATED ON LINE : ".($startpoint-$tmail+$oposi+1)."    ".$useremail."\n\n";
        continue;
      }


      $configs = fopen("config.txt", "r") or die("NO CONFIG FILE config.txt");
      $config = fread($configs,filesize("config.txt"));    
      fclose($configs);

      if(strpos($config,"{@1gen}") !== false){       
        $config = str_replace("{@1gen}",substr(str_shuffle('azertyuiopqsdfghjklmwxcvbn1234567890'),0,1),$config);                                 
      }

      if(strpos($config,"{@2gen}") !== false){       
          $config = str_replace("{@2gen}",substr(str_shuffle('azertyuiopqsdfghjklmwxcvbn'),0,2),$config);                                 
      }
      if(strpos($config,"{@2GEN}") !== false){       
          $config = str_replace("{@2GEN}",substr(str_shuffle('AZERTYUIOPQSDFGHJKLMWXCVBN'),0,2),$config);                                 
      }
      if(strpos($config,"{@3gen}") !== false){       
          $config = str_replace("{@3gen}",substr(str_shuffle('azertyuiopqsdfghjklmwxcvbn'),0,3),$config);                                 
      }
      if(strpos($config,"{@4gen}") !== false){       
        $config = str_replace("{@4gen}",substr(str_shuffle('a1z2e3r4ty5ui6op7qs8df9gh0jklmwxcvbn'),0,4),$config);                                 
      }
      if(strpos($config,"{@3GEN}") !== false){       
          $config = str_replace("{@3GEN}",substr(str_shuffle('AZERTYUIOPQSDFGHJKLMWXCVBN'),0,3),$config);                                 
      }
      if(strpos($config,"{@3sgen}") !== false){       
          $config = str_replace("{@3sgen}",$spdss,$config);                                 
      }
      if(strpos($config,"{@publicip}") !== false){       
          $config = str_replace("{@publicip}",$client_ip,$config);                                 
      }

      if(strpos($config,"{@rdns}") !== false){       
        $config = str_replace("{@rdns}",$rdns,$config);                                 
      }

      if(strpos($config,"{@randomip}") !== false){       
          $config = str_replace("{@randomip}",$prefix,$config);                                 
      }

      if(strpos($config,"{@mix}") !== false){       
          $config = str_replace("{@mix}",substr(str_shuffle('AZERTYUIO1P2Q3S4D5F6G7H8J9K0LMWXCVBNazertyuiopqsdfghjklmwxcvbn'),0,rand()%40),$config);
      }
      if(strpos($config,"{@bigmix}") !== false){       
          $config = str_replace("{@bigmix}",substr(str_shuffle('AZER-TYUIO1-P2Q3S4D5-F6G7H-8J9-K0LMWX-CVBN'),0,rand()%40),$config);                                 
      }


      $useruser = strtok($useremail, '@');
      if(strpos($config,"{@user}") !== false){
          $config = str_replace("{@user}",$useruser,$config);
      }

      $usertld = strstr($useremail, '@');$usertld = substr($usertld, 1);
      if(strpos($config,"{@usertld}") !== false){           
          $config = str_replace("{@usertld}",$usertld,$config);                                 
      }
      if(strpos($config,"{@toemail}") !== false){           
          $config = str_replace("{@toemail}",$useremail,$config);                                 
      }
      if(strpos($config,"{@sendertld}") !== false){           
        $config = str_replace("{@sendertld}",$sendertld,$config);                                 
      }
      if(strpos($config,"{@gen-name}") !== false){      
         $firstNames = ["support","demande","info","contact","service"];

         $lastNames = ["client","aide","assistance","commercial","commande","facturation","paiement","technique","sav","réclamation","urgence","secrétariat","admin","projet","ressources"];

        $fname = $firstNames[array_rand($firstNames)];

        $lname = $lastNames[array_rand($lastNames)];        
        $config = str_replace("{@gen-name}",$fname."-".$lname,$config);                                 
      }


      $configparts = explode('~', $config);





      $senderemail = $configparts[1];
      $sendername = $configparts[2];
      if($argv[8]){

        if(strpos($sendername,"=") !== false){
          $sendername = obfuxt($sendername);
          $sendername = str_replace("=","",$sendername);
        }


      }

      if(strpos($config,"{@sendermail}") !== false){           
          $config = str_replace("{@sendermail}",$senderemail,$config);                                 
      }


      $senderemailheader = $configparts[4];

      if(strpos($senderemailheader,"{@sendermail}") !== false){           
        $senderemailheader = str_replace("{@sendermail}",$senderemail,$senderemailheader);                                 
      }else{
        if($argv[8]){

          if(strpos($senderemailheader,"=") !== false){
            $senderemailheader = obfuxt($senderemailheader);
            $senderemailheader = str_replace("=","",$senderemailheader);
          }

        }
      }


      $reptoemail = $configparts[5];
      if(strpos($reptoemail,"{@sendermail}") !== false){           
        $reptoemail = str_replace("{@sendermail}",$senderemail,$reptoemail);                                 
      }

      $gmessder = $configparts[6];
      $headertobcc = $configparts[7];
      $headerxorigatip = $configparts[8];
      $headerxpriority = $configparts[9];
      $headerxmailer = $configparts[10];
      $genheader1 = $configparts[11];
      $genheader2 = $configparts[12];
      $headerubscrieremail = $configparts[13];
      $headerubscrierlink = $configparts[14];
      $service = $configparts[15];
      $links = $configparts[16];
      $accsscountry = $configparts[17];
      $visitnumber = $configparts[18];
      $multiorsingle = $configparts[19];
      $helodata = $configparts[20];
      $boundryys = $configparts[21];
      $bamessenctype = $configparts[22];
      $serverre = $configparts[23];
      if(strpos($helodata,"{@sendertld}") !== false){           
        $helodata = str_replace("{@sendertld}",$sendertld,$helodata);                                 
      }
      $dbsname = $configparts[25];
      $filesname = $configparts[27];


      $subject = $configparts[3];

      if($argv[8]){

        if(strpos($subject,"=") !== false){
          $subject = obfuxt($subject);
          $subject = str_replace("=","",$subject);
        }



      }else{



      if($bamessenctype == 1){
        $subject = "=?utf-8?b?".base64_encode($subject)."?=";
        //$subject = $subject;
      }else if($bamessenctype == 2){
        $subject = "=?utf-8?q?".qp_safe_encode_stream($subject)."?=";
      }

      }











      $soccrrect++;

      //$myfile2 = fopen("Trysend", "a") or die("Unable to open file!");
      //$txt2 = "$useremail\n";

      $uppps34 = 0;
      uppp11:






        if(strlen($serverre) < 1 ){



          getmxrr($usertld, $mx_records, $mx_weight);
          for($ii=0;$ii<1;$ii++){  //count($mx_records)
            if(count($mx_records) > 0){
              $mxs[$mx_records[$ii]] = $mx_weight[$ii];
            }            
          }

          if(count($mx_records) > 0 && strlen($mx_records[0]) > 2){
            $serverre = $mx_records[0];




          }else{
              echo "\nTHREAD $myid: ".($oposi+1).": Could not resolve MX = ".$usertld."\n"; 

              $uppps34++;
              if($uppps34 < 3){
                sleep(1);
                goto uppp11;
              }
              $uppps34 = 0;

              $mxerro++;
              fwrite($doneeemail, "$useremail\n");
              continue;
          }          
        }








      echo "\n\nTHREAD $myid: ".($oposi+1).": $tmail : ".($startpoint-$tmail+$oposi+1)." | $useremail | $serverre \n";



      /*
      if(strpos($serverre,"retarus.com") !== false && $argv[5] == 1){
        $tunov++;
        fwrite($doneeemail, "$useremail\n");  
        continue;
      }
      */





      $partds = explode('.', $serverre);
      $coudnt = count($partds);
      $domsain = "";
      if($coudnt >= 2) {
          $domsain = $partds[$coudnt - 2] . '.' . $partds[$coudnt - 1];
      }else{
          $domsain = $serverre; // fallback if malformed
      }    

/*
      if(strlen($configparts[23]) > 1 && strpos($configparts[23],$domsain) !== false && $argv[5] == 1){

      }
      */




      if($oposi+1 == 1 && strpos($configparts[24],$domsain) !== false){          
         $myfile = fopen("start.txt", "w") or die("Unable to open file!");
         $txt = "1";
         fwrite($myfile, $txt);
         fclose($myfile);
      }



      if(strpos($configparts[24],$domsain) !== false && $argv[5] == 1 && $argv[6] == 1 && !str_contains($useremail, 'contact@service-tennis.fr')){

        $myfile = fopen("EXTRACT-".$domsain, "a") or die("Unable to open file!");
        $txt = "$useremail\n";
        if(flock($myfile, LOCK_EX)) { // Acquire an exclusive lock
            fwrite($myfile, $txt);
            fflush($myfile); // Flush output to file
            flock($myfile, LOCK_UN); // Release the lock
        }else {
            echo "Couldn't lock the file.\n";
        }
        fclose($myfile);

        $tunov++;
        fwrite($doneeemail, "$useremail\n");  
        continue;
      }



      if($serverre){

        $sendertld2 = $sendertld;
        $sendertld = $configparts[26];
        if(strlen($helodata) < 1 ){
            $helodata = $rdns;
            if(strlen($rdns) < 3){
                $helodata = $sendertld2;
            }
        }        
        echo "\nTHREAD $myid: ".($oposi+1).": HELO HOSTNAME : ".$helodata."\n";



        if(strlen($sendertld) < 1 ){
          $sendertld = $sendertld2;
        }

        if(strlen($senderemail) < 1 || strpos($senderemail, "@") == false || strpos($senderemail, ".") == false){
          //echo "\nTHREAD $myid: ".($oposi+1).": SENDEREMAIL NOT WEL FORMATED ".$senderemail;    
          continue;
        }
        $datee = date(DATE_RFC2822);
        $messages = fopen("message.txt", "r") or die("NO MESSAGE FILE message.txt");
        $message = fread($messages,filesize("message.txt"));    
        fclose($messages);

        if($argv[8]){


         $messages = obfuscateSpanTextRegex($message);
         $message = $messages;


        }


        $message = str_replace("{@mix}",substr(str_shuffle('AZERTYUIO1P2Q3S4D5F6G7H8J9K0LMWXCVBNazertyuiopqsdfghjklmwxcvbn'),0,rand()%35),$message);
        $message = str_replace("{@toemail}",$useremail,$message);
        $message = str_replace("{@user}",$useruser,$message);

        if(strpos($message,"<svg") !== false){

          if(preg_match('/<svg.*<\/svg>/is', $message, $matches)) {
              $svgContent = $matches[0];

              $svgContent2 = <<<SVG
              $svgContent
              SVG;
              $base64Svg = base64_encode($svgContent2);
              $svgDataUri = "data:image/svg+xml;base64,$base64Svg";
          }  
          $message = str_replace($svgContent, $svgDataUri, $message);

        }      



        $disposition = "";
        if(strpos($message,"cid:") !== false){
            $disposition = "inline";
        }else{
            $disposition = "attachment";
        }
        $cidd = substr(str_shuffle('AZERTYUIO1P2Q3S4D5F6G7H8J9K0LMWXCVBNazertyuiopqsdfghjklmwxcvbn'),0,rand()%40);
        $message = str_replace("cid:","cid:".$cidd,$message);
        if(strlen($message) < 1){
          echo "\nTHREAD ".$myid." : MESSAGE EMPTY OR MALFORM\n";
          exit;
        }
        //$message = str_replace("  "," ",$message);

        if(strpos($links,"s=") !== false){
          $links = str_replace("s=","",$links);
          $links = "https://".$links;
          if(strpos($message,"{@url}") !== false){
              $message = str_replace("{@url}",$links,$message);
          }
          if(strpos($message,"{@ul}") !== false){
            $message = str_replace("{@ul}",$links,$message);
          }
        }else{
          $links = str_replace("s=","",$links);
          $links = "http://".$links;
          if(strpos($message,"{@url}") !== false){
              $message = str_replace("{@url}",$links,$message);
          } 
          if(strpos($message,"{@ul}") !== false){
            $message = str_replace("{@ul}",$links,$message);
          }     
        }

        $resp = substrringrespond($message,"href=\""); 

        $resp = explode('~', $resp); 
        $val = $resp[1];        
        $conti = 1;        
        for($oo = 2;$oo < $val+2; $oo++ ){
            $values = $resp[$oo];
            $domain = "";
            sscanf($values, "http://%[^?]", $domain);
            sscanf($values, "https://%[^?]", $domain);            
            //echo "\n DDD = ".$domain."\n";
            /*
            if(substr_count($domain, ".") > 1 && strpos("/",$domain) == true){
                $values = substr($domain, strpos($domain,".")+1);
            }else{
                $values = $domain;
            }
            */
            if(substr_count($domain, ".") > 1){
                $values = substr($domain, strpos($domain,".")+1);
            }else{
                $values = $domain;
            }
            //echo "\nDOMAIN  = ".$values;
            if(strpos($sml,$values) !== false){                                    
            }else{
                echo "\nClick DOMAIN NOT EXIST in dbs DOMAIN = ".$values."\n";
                $conti = 0;break;
            }
        }

        if($conti){
          //echo "\n\nGOOD DOMAIN LIST BY CLIENT CONTINUE\n\n";
        }else{
         continue;
        }

        $useremail = strtolower($useremail);
        $useremailinlink = "mail@bcc";
        if($argv[5] == 1){
           $useremailinlink = $useremail;
        }
        $encode = "=_=";
        if(strpos($message,"{@messageidlink}") !== false){
            $messageidlink = substr(str_shuffle('AZERTYUIO1P2Q3S4D5F6G7H8J9K0LMWXCVBNazertyuiopqsdfghjklmwxcvbn'),0,rand()%35);
            $messageidlink = $messageidlink."/".$service."/".$useremailinlink."/".$dbsname."/".$accsscountry."/".$visitnumber;
            $encode = encode(base64_encode($messageidlink));
            $message = str_replace("{@messageidlink}",$encode,$message);
            $links = str_replace("{@messageidlink}",$encode,$links);
        }
        if(strpos($message,"{@messageid}") !== false){
            $encode = base64_encode($useremail." ".$dbsname);
            $message = str_replace("{@messageid}",$encode,$message);
            $links = str_replace("{@messageidlink}",$encode,$links);
        }
        //echo "\nLINK GENERATE = ".$encode."\n";
        echo "\nTHREAD $myid: ".($oposi+1).": LINK GENERATE = ".$links."\n";




        $boundy = $boundryys;                      
        $typemessage = "";
        /*
        $message = str_replace("  "," ",$message);
        $message = str_replace("\r","",$message);
        $message = str_replace("\n","\r\n",$message);
        $message = str_replace("\r\n\r\n","\r\n",$message);
        $message = str_replace("\r\n\r\n\r\n","\r\n",$message);
        $message = str_replace("  \r\n","\r\n",$message);
        $message = str_replace("\r\n  ","\r\n",$message);
        $message = str_replace("\r\n ","\r\n",$message);
        */

        if($multiorsingle){
          $htmnot = "";

          if(strpos($message,"<") !== false && strpos($message,">") !== false){
              $filtermessage = strip_tags($message);

              $htmnot = $filtermessage;  
              //$htmnot = substr($htmnot, 0, 0);
              //$htmnot = substr($htmnot, 0, strlen($htmnot));     




          }else{
              $htmnot = $message;
              $message = "<div> ".$message."<div>";
          }

          if($bamessenctype == 1){
            $message = base64_encode($message);
            $message = rtrim(chunk_split($message, 76, "\r\n"));

            $htmnot = base64_encode($htmnot);
            $htmnot = rtrim(chunk_split($htmnot, 76, "\r\n"));


          }
          if($bamessenctype == 2){
              $message = qp_safe_encode_stream($message);
              $htmnot = qp_safe_encode_stream($htmnot);
          }
          if(strlen($filesname) > 0){
              $boundybigin = $boundy;
              $bodymesage = "";
              $xboundr = substr(str_shuffle('AZERTYUIO1P2Q3S4D5F6G7H8J9K0LMWXCVBNazertyuiopqsdfghjklmwxcvbn'),0,rand()%35);
              $bodymesage = $boundybigin."\r\nContent-Type: multipart/alternative; boundary=\"";
              $bodymesage = $bodymesage.$xboundr."\""."\r\n\r\n--".$xboundr."\r\nContent-Type: text/plain; charset=\"UTF-8\"";
              if($bamessenctype == 1){
                  $bodymesage = $bodymesage."\r\nContent-Transfer-Encoding: base64\r\n\r\n";
              }else if($bamessenctype == 2){
                  $bodymesage = $bodymesage."\r\nContent-Transfer-Encoding: quoted-printable\r\n\r\n";
              }else{
                  $bodymesage = $bodymesage."\r\nContent-Transfer-Encoding: 7bit\r\n\r\n";
              }
              $bodymesage = $bodymesage.$htmnot."\r\n--"."".$xboundr."\r\nContent-Type: text/html; charset=\"UTF-8\"";
              if($bamessenctype == 1){
                  $bodymesage = $bodymesage."\r\nContent-Transfer-Encoding: base64\r\n\r\n";
              }else if($bamessenctype == 2){
                  $bodymesage = $bodymesage."\r\nContent-Transfer-Encoding: quoted-printable\r\n\r\n";
              }else{
                  $bodymesage = $bodymesage."\r\nContent-Transfer-Encoding: 7bit\r\n\r\n";
              }
              $bodymesage = $bodymesage.$message."\r\n--"."".$xboundr."--\r\n"."--".$boundy."\r\nContent-Type: ".$datatype."; name=\"".$filesname."\""."\r\nContent-Disposition: ".$disposition."; filename=\"".$filesname."\""."\r\nContent-ID: <".$cidd.">"."\r\nContent-Transfer-Encoding: base64\r\n\r\n";
              $bfilles = chunk_split($bfille,76,"\r\n");
              $bfilles = substr($bfilles, 0, -2);
              $bodymesage = $bodymesage.$bfilles."\r\n--".$boundy;
              $message = "--".$bodymesage."--";
              $bfilles = "";
          }else{
              $boundybigin = $boundy;
              $bodymesage = "";                
              $bodymesage = $boundybigin."\r\nContent-Type: text/plain; charset=\"UTF-8\"";
              if($bamessenctype == 1){
                  $bodymesage = $bodymesage."\r\nContent-Transfer-Encoding: base64\r\n\r\n";
              }else if($bamessenctype == 2){
                  $bodymesage = $bodymesage."\r\nContent-Transfer-Encoding: quoted-printable\r\n\r\n";
              }else{
                  $bodymesage = $bodymesage."\r\nContent-Transfer-Encoding: 7bit\r\n\r\n";
              }                  

              $bodymesage = $bodymesage.$htmnot."\r\n--".$boundy."\r\nContent-Type: text/html; charset=\"UTF-8\"";
              if($bamessenctype == 1){
                  $bodymesage = $bodymesage."\r\nContent-Transfer-Encoding: base64\r\n\r\n";
              }else if($bamessenctype == 2){
                  $bodymesage = $bodymesage."\r\nContent-Transfer-Encoding: quoted-printable\r\n\r\n";
              }else{
                  $bodymesage = $bodymesage."\r\nContent-Transfer-Encoding: 7bit\r\n\r\n";
              }
              $bodymesage = $bodymesage.$message."\r\n--".$boundy;
              $message = "--".$bodymesage."--";
          }

        }else{
            if(strpos($message,"<") !== false && strpos($message,">") !== false){
               $typemessage = "html";
            }else{
               $typemessage = "plain";
            }
            /*
            $message = str_replace("\r","",$message);
            $message = str_replace("\n","\r\n",$message);
            */

            if($bamessenctype == 1){
                $message = base64_encode($message);
                $message = chunk_split($message,73,"\r\n ");
                $message = substr($message, 0, -3);
            }
            if($bamessenctype == 2){
                $message = qp_safe_encode_stream($message);
            }
        }

        $justvalue = "^";
        $headerValues = "";
        $retsun = RandomNumberGenerator(1,15,15); 
        $valint = substr_count($retsun,' ');
        //echo "\nTHREAD $myid: ".($oposi+1).": ALGORYTHM RETURN VALUE TABLE: ".$retsun."\n";

        if($argv[6]){


        }else{
          $myfile = fopen("start.txt", "w") or die("Unable to open file!");
          $txt = "0";
          fwrite($myfile, $txt);
          fclose($myfile);
        }


        for($o = 1;$o < $valint+1;$o++){
          $tlable = explode(' ', $retsun);
          $tlable = $tlable[$o];
          //echo "\n".$tlable;
          if($tlable == "1"){


              if(strlen($sendername) > 0){
                //$from = "From: ".$sendername." <".$senderemailheader.">~";
                $from = "From: =?UTF-8?B?".base64_encode($sendername)."?= <".$senderemailheader.">~";

              }else{
                  $from = "From: ".$senderemailheader."~";
              }

                $headerValues = $headerValues.$from;
                $from = $from.":";
                $from = explode(':', $from);
                $from = $from[1];
                $from = substr($from, 1);
                //$from[strlen($from)-1] = "\0";
                $from = substr($from, 0, -1);
                $justvalue = $justvalue.$from."^";

          }else if($tlable == "2"){
            $suject = "Subject: ".$subject."~";
            $headerValues = $headerValues.$suject;
            $suject = $suject.":";
            $suject = explode(':', $suject);
            $suject = $suject[1];
            $suject = substr($suject, 1);
            //$suject[strlen($suject)-1] = "\0";
            $suject = substr($suject, 0, -1);
            $justvalue = $justvalue.$suject."^";
          }else if($tlable == "3"){
            $dd = "Date: ".$datee."~";
            $headerValues = $headerValues.$dd;
            $justvalue = $justvalue.$datee."^";
          }else if($tlable == "4"){
           if($argv[5] == 1){
              $to = "To: ".$useremail."~";
              $headerValues = $headerValues.$to;
              $justvalue = $justvalue.$useremail."^";
           }else{
              if(strlen($headertobcc) > 0){
                  $to = "To: ".$headertobcc."~";
                  $headerValues = $headerValues.$to;
                  $justvalue = $justvalue."".$headertobcc."^";
              }
           }
          }else if($tlable == "5"){

          }else if($tlable == "6"){
            $mime = "MIME-Version: 1.0~";
            $headerValues = $headerValues.$mime;
            $justvalue = $justvalue."1.0"."^";
          }else if($tlable == "7"){


            if(strlen($reptoemail) > 0){



              if($bamessenctype == 1){
                $repto = "Reply-To: =?utf-8?b?".base64_encode("\"".$sendername."\"")."?= <".$reptoemail.">~";
              }else if($bamessenctype == 2){
                $repto = "Reply-To: =?utf-8?q?".qp_safe_encode_stream("\"".$sendername."\"")."?= <".$reptoemail.">~";
              }else{
                $repto = "Reply-To: \"".$sendername."\" <".$reptoemail.">~";
              }

              if($repto == "."){
                $repto = "";
              }

              $headerValues = $headerValues.$repto;
              $repto = $repto.":";
              $repto = explode(':', $repto);
              $repto = $repto[1];
              $repto = substr($repto, 1);
              //$repto[strlen($repto)-1] = "\0";
              $repto = substr($repto, 0, -1);
              $justvalue = $justvalue.$repto."^";

            }
          }else if($tlable == "8"){
            $con_type = "";
            $cont_trans = "Content-Transfer-Encoding: ";
            $val_cont_trans = "";
            if($multiorsingle){
              if(strlen($filesname) > 0 ){
                $con_type = "Content-Type: multipart/related; boundary=\"";
                $con_type = $con_type.$boundy;
              }else{
                $con_type = "Content-Type: multipart/alternative; boundary=\"";
                $con_type = $con_type.$boundy;
              }

            }else{
              $con_type = "Content-Type: text/".$typemessage."; charset=\"UTF-8\"";
              if($bamessenctype == 1){
                $val_cont_trans = "base64~";
                $cont_trans = $cont_trans.$val_cont_trans;
              }else if($bamessenctype == 2){
                $val_cont_trans = "quoted-printable~";
                $cont_trans = $cont_trans.$val_cont_trans;
              }else{
                $val_cont_trans = "7bit~";
                $cont_trans = $cont_trans.$val_cont_trans;
              }
            }
            if($multiorsingle){
              $con_type = $con_type."\"";
            }
            $con_type = $con_type."~";
            $headerValues = $headerValues.$con_type;
            if($multiorsingle){
            }else{
              $headerValues = $headerValues.$cont_trans;
            } 
            $con_type = $con_type.":";
            $con_type = explode(':', $con_type);
            $con_type = $con_type[1];
            $con_type = substr($con_type, 1);
            //$con_type[strlen($con_type)-1] = "\0";
            $con_type = substr($con_type, 0, -1);
            $justvalue = $justvalue.$con_type."^";
            if($multiorsingle){
            }else{
              $cont_trans = $cont_trans.":";
              $cont_trans = explode(':', $cont_trans);
              $cont_trans = $cont_trans[1];
              $cont_trans = substr($cont_trans, 1);
              //$cont_trans[strlen($cont_trans)-1] = "\0";
              $cont_trans = substr($cont_trans, 0, -1);
              $justvalue = $justvalue.$cont_trans."^";                
            }
          }else if($tlable == "9"){
            if(strlen($headerxpriority) > 0){
              $xpri = "X-Priority: ".$headerxpriority."~";
              $headerValues = $headerValues.$xpri;
              $justvalue = $justvalue.$headerxpriority."^"; 
            }
          }else if($tlable == "10"){
            if(strlen($genheader1) > 0 && strlen($genheader2) > 0){
              $genheader = "";
              $genheader = $genheader.$genheader1.": ".$genheader2."~";
              $headerValues = $headerValues.$genheader;
              $justvalue = $justvalue.$genheader2."^";                
            }
          }else if($tlable == "11"){
            if(strlen($headerxmailer) > 0){
              $xmaioler = "X-mailer: ".$headerxmailer."~";
              $headerValues = $headerValues.$xmaioler;
              $justvalue = $justvalue.$headerxmailer."^"; 
            }
          }else if($tlable == "12"){
            if(strlen($headerxorigatip) > 0){
              $xip = "X-Originating-IP: ".$headerxorigatip."~";
              $headerValues = $headerValues.$xip;
              $justvalue = $justvalue.$headerxorigatip."^"; 
            }

          }else if($tlable == "13"){

/*
            $headerreturnpath = "<".$senderemail.">";
            if(strlen($headerreturnpath) > 0){
              $aniz = "Return-Path: ".$headerreturnpath."~";
              $headerValues = $headerValues.$aniz;
              $justvalue = $justvalue.$headerreturnpath."^"; 
            }

            */







          if($configparts[28]){
             $resi2 = "by ".$sendertld." id ".substr(str_shuffle('AZERTYUIO1P2Q3S4D5F6G7H8J9K0LMWXCVBNazertyuiopqsdfghjklmwxcvbn'),0,rand()%40)." for <".$useremail.">; ".$datee." (envelope-from <".$senderemail.">)";
            $reci = "X-Received: ".$resi2."~";
            $headerValues = $headerValues.$reci;
            $justvalue = $justvalue.$resi2."^";

          }







  /*          
            $headerorganisation = $desktopname;              
            if(strlen($headerorganisation) > 0){
              $aniz = "Organization: ".$headerorganisation."~";
              $headerValues = $headerValues.$aniz;
              $justvalue = $justvalue.$headerorganisation."^"; 
            }
*/

/*

            $ovhremote = $headerxorigatip;              
            if(strlen($ovhremote) > 0){
              $ansiz = "X-OVH-Remote: ".$ovhremote."~";
              $headerValues = $headerValues.$ansiz;
              $justvalue = $justvalue.$ovhremote."^"; 
            }



*/




          }else if($tlable == "14"){




            if($configparts[28]){
            $resi2 = "from ".$desktopname." (HELO ".$sendertld.") ([".$headerxorigatip."]) by ".$rdns." with ESMTP id ".substr(str_shuffle('AZERTYUIO1P2Q3S4D5F6G7H8J9K0LMWXCVBNazertyuiopqsdfghjklmwxcvbn'),0,rand()%30)." for <".$useremail.">; ".$datee;
            $reci = "Received: ".$resi2."~";
            $headerValues = $headerValues.$reci;
            $justvalue = $justvalue.$resi2."^";

            }





/*
            $resi2 = "from ".$desktopname." (".$desktopname." [".$headerxorigatip."]) by ".$usertld." (Postfix) with ESMTPS id ".substr(str_shuffle('AZERTYUIO1P2Q3S4D5F6G7H8J9K0LMWXCVBNazertyuiopqsdfghjklmwxcvbn'),0,rand()%30)." for <".$useremail.">; ".$datee;
            $reci = "Received: ".$resi2."~";
            $headerValues = $headerValues.$reci;
            $justvalue = $justvalue.$resi2."^";

            */

            if(strlen($headerubscrierlink) > 0 && strlen($headerubscrieremail) > 0){


              $hedersuscr = "List-Unsubscribe: <mailto:".$senderemail.">, <https://".$headerubscrierlink."/?un=".base64_encode($useremail).">~";
              $headerValues = $headerValues.$hedersuscr;
              $justvalue = $justvalue."<mailto:".$senderemail.">, <https://".$headerubscrierlink."/?un=".base64_encode($useremail).">^";


              $hedersuscr = "List-Unsubscribe-Post: List-Unsubscribe=One-Click~";
              $headerValues = $headerValues.$hedersuscr;
              $justvalue = $justvalue."List-Unsubscribe=One-Click^";


            }





          }else if($tlable == "15"){
            //(using TLSv1.2 with cipher ECDHE-RSA-AES128-GCM-SHA256 (128/128 bits)) (No client certificate requested)   
            // 


            if(strlen($gmessder) > 0){
              $gmesval = "Message-ID: <".$gmessder.">~";
              $headerValues = $headerValues.$gmesval;
              $gmesval = $gmesval.":";
              $gmesval = explode(':', $gmesval);
              $gmesval = $gmesval[1];
              $gmesval = substr($gmesval, 1);
              //$gmesval[strlen($gmesval)-1] = "\0";
              $gmesval = substr($gmesval, 0, -1);
              $justvalue = $justvalue.$gmesval."^";
            }

          }else{

          }
        }

        $count = substr_count($headerValues,'~');
        $linesdkim = "";
        $headerValues = "~".$headerValues;

        for($x = 1;$x<$count+1;$x++){
          $singlz = explode('~', $headerValues);
          $singlz = $singlz[$x];
          $singlz = ":".$singlz;

          $singlz = explode(':', $singlz);
          $singlz = $singlz[1];
          $linesdkim = $linesdkim.$singlz.":"; 
        }

        $linesdkim = substr($linesdkim, 0, -1);


        $message = str_replace("  "," ",$message);
        $message = preg_replace("/\r\n|\n|\r/", "\r\n", $message);
        $message = preg_replace("/[ \t]+/", " ", $message);
        $message = preg_replace("/ \r\n/", "\r\n", $message);
        $message = rtrim($message, "\r\n") . "\r\n";

        //echo $message;
        //exit;



        $packstring = base64_encode(pack('H*', hash('sha256', $message)));
        $linesdkim = strtolower($linesdkim);
        $DKIMtime = time();        
        //$dkimSignatureHeader = "v=1; a=rsa-sha256; s=default; c=relaxed/simple; d=$sendertld; t=$DKIMtime; q=dns/txt; l=".strlen($message)."; h=$linesdkim; bh=$packstring; b=";
        $dkimSignatureHeader = "v=1; a=rsa-sha256; c=relaxed/relaxed; d=$sendertld; s=default; h=$linesdkim; bh=$packstring; b=";
        $dkiim = "DKIM-Signature: ".$dkimSignatureHeader;


        $tocanonicalise = $headerValues.$dkiim."~";        
        $justvalue = $justvalue.$dkimSignatureHeader."^";



        $linesdkim = "";
        $vac = "";
        $couts = substr_count($tocanonicalise,'~');
        for($x = 1;$x<$couts;$x++){
          $singlz = explode('~', $tocanonicalise);
          $singlz = $singlz[$x];
          $singlz = ":".$singlz;
          $heade = explode(':', $singlz);$heade = $heade[1];
          $heade = strtolower($heade);
          $vallld = explode('^', $justvalue);$vallld = $vallld[$x];
          $vallld = "^".$vallld;          
          $heade = $heade.":";          
          $vallld = substr($vallld, 1);
          $vallld = $vallld."~";
          $vac = $vac.$heade.$vallld;         
        }








        $tocanonicalise = substr($tocanonicalise, 1, -1);
        $vac = substr($vac, 0, -1);
        $tocanonicalise = str_replace("~","\r\n",$tocanonicalise);
        $vac = str_replace("~","\r\n",$vac);





         $justvalue = "";


        if(!defined('PKCS7_TEXT')) {
          if ($this->exceptions) {
              throw new Exception($this->lang('extension_missing') . 'openssl');
          }
        }


        $privKeyStr = file_get_contents("pkey.pem");
        $privKey = openssl_pkey_get_private($privKeyStr);
        openssl_sign($vac, $signature, $privKey, 'sha256WithRSAEncryption');
        unset($privKey);
        $signature = base64_encode($signature);
        $vac = "";$privKeyStr = "";
        //$signature = chunk_split($signature,73,"\r\n\t");
        //$signature = substr($signature, 0, -3); //not include in C

         //$tocanonicalise =  $signature."\r\n".$tocanonicalise;
        $tocanonicalise = str_replace(" b="," b=".$signature,$tocanonicalise);

        //echo $tocanonicalise;
        //exit;

        $tocanonicalise = $tocanonicalise."\r\n".$message."\r\n.\r\n";


        //$signature = "";
        /*
        $dkim = strstr($tocanonicalise, "DKIM-Signature: ");
        $posss = strpos($tocanonicalise, 'DKIM-Signature:');
        $tocanonicalise = substr($tocanonicalise, 0, $posss);

        $poos = 0;$poos2 = 0; $current = 5; $current2 = 8;   $dkim2 = "";

        for($ss = 0;$ss<strlen($dkim);$ss++){          
          if($dkim[$ss] == ' '){
            $poos++;
          }
          if($poos == $current){
            $dkim2 = $dkim2."\r\n\t";
            $poos = 0;
            $current = 4;
          }          
          if($dkim[$ss] == ':'){
            $poos2++;
          }
          if($poos2 == $current2){
            //$dkim2 = $dkim2."\r\n\t ";
            $poos2 = 0;            
          }

          if($dkim[$ss].$dkim[$ss+1].$dkim[$ss+2] == 'bh='){
            $dkim2 = $dkim2."\r\n\t";
          }
          if($dkim[$ss].$dkim[$ss+1] == 'b='){
            $dkim2 = $dkim2."\r\n\t";
            break;
          }
          $dkim2 = $dkim2.$dkim[$ss];
        }
          */

        /*
        $signature = "b=".$signature;
        //$signature = chunk_split($signature,73,"\r\n\t ");
        //$signature = substr($signature, 0, -4); //not include in C
        $dkim2 = $dkim2.$signature;
        $dkim2 = str_replace(" s=","s=",$dkim2);
        //$dkim2 = str_replace(" h=","h=",$dkim2);
        //to fix
        $dkim2 = str_replace(" bh=","bh=",$dkim2);
        $dkim2 = str_replace("; \r\n",";\r\n",$dkim2);

        */





        //echo "\nTHREAD $myid: ".($oposi+1).": EMAIL 404 COUNT ".$emalinvalid." TO RESET TO 0 ON IPREINFORCE\n";
        //echo "\nSTARTING\n";


        //sleep($delaynum);





        $uppps = 0;

        uppp:


        $socket = stream_socket_client($serverre .':'.'25', $errno, $errstr, '5', STREAM_CLIENT_CONNECT | STREAM_CLIENT_PERSISTENT);



        if(!$socket){
          echo "ERREUR SOCKET 1 : $errno - $errstr<br />\n";
          //stream_socket_shutdown($socket,STREAM_SHUT_WR);
          //fclose($socket);
          //
          if($errno == 0){
            $uppps++;
            if($uppps < 3){
              sleep(1);
              goto uppp;
            }
            $uppps = 0;

            $mxerro++;
            fwrite($doneeemail, "$useremail\n");  
          }else if($errno == 110){

            $uppps++;
            if($uppps < 5){
              goto uppp;
            }
            $uppps = 0;

            $contmout++;
            fwrite($doneeemail, "$useremail\n"); 
          }else{
            $uppps++;
            if($uppps < 3){
              goto uppp;
            }
            $uppps = 0;           

            $errsoc++;
            fwrite($doneeemail, "$useremail\n");  

          }


          continue;          
        }else{

        }



        if($socket){  
        }else{

          $uppps++;
          if($uppps < 3){
            goto uppp;
          }
          $uppps = 0;


          echo "ERREUR 2 : $errno - $errstr<br />\n";
          stream_socket_shutdown($socket,STREAM_SHUT_WR);
          fclose($socket);
          $errsoc++;
          fwrite($doneeemail, "$useremail\n");
          continue;
        }



        $result = read_smtp_response($socket);

        echo "\nTHREAD $myid: ".($oposi+1).": ".$serverre.": ".$result; 



        if(strpos($result,"220 ") !== false){            
          if(strpos($result,"errors") !== false || strpos($result,"5.7.1") !== false || strpos($result,"521 ") !== false){
            stream_socket_shutdown($socket,STREAM_SHUT_WR);
            fclose($socket);
            $errip++;
            fwrite($doneeemail, "$useremail\n");  

            continue;
          }

        }else{

          stream_socket_shutdown($socket,STREAM_SHUT_WR);
          fclose($socket);

          if(strlen($result) > 0 ){
            echo "\nTHREAD $myid: ".($oposi+1).": SMTP SERVICE NOT AVAILABLE = ".$usertld."\n";

            $uppps++;
            if($uppps < 3){
              goto uppp;
            }
            $uppps = 0;


            $errip++;
            fwrite($doneeemail, "$useremail\n");  
          }else{
            echo "\nTHREAD $myid: ".($oposi+1).": BREACKING FOR EMPTY RESPONSE  $useremail \n";




            $uppps++;
            if($uppps < 3){
              goto uppp;
            }
            $uppps = 0;



            $breakforempt++;
            fwrite($doneeemail, "$useremail\n");
          }  


          continue;
        }



        $helodata = "EHLO ".$helodata."\r\n";        
        $rett = fwrite($socket, $helodata);
        //echo "\nTHREAD $myid: ".($oposi+1).": TTL write = ".$rett."\n";
        if($rett){          
        }else{
          stream_socket_shutdown($socket,STREAM_SHUT_WR);
          fclose($socket);
          continue;
        }


        $result = read_smtp_response($socket); 
        echo "\nTHREAD $myid: ".($oposi+1).": ".$serverre.": ".$result."\n"; 
        //$result = read_smtp_response($socket); 
        //echo "\nTHREAD $myid: ".($oposi+1).": ".$serverre.": ".$result."\n"; 



        if(strpos($result,"STARTTLS") !== false){

          fwrite($socket, "STARTTLS\r\n");
          $result = read_smtp_response($socket);
          echo "\nTHREAD $myid: ".($oposi+1).": FOR TLS1 ".$myid." : ".$serverre.": ".$result."";


          if(strpos($result,"2.0.0") !== false || strpos($result,"220 ") !== false){
            //stream_context_set_option($socket, 'ssl', 'ciphers', 'AES256-SHA');


            stream_context_set_option($socket, 'ssl', 'ciphers', 'HIGH:!aNULL:!MD5');
            stream_context_set_option($socket, 'ssl', 'verify_peer', false);
            stream_context_set_option($socket, 'ssl', 'verify_peer_name', false);
            stream_context_set_option($socket, 'ssl', 'allow_self_signed', true);
            stream_context_set_option($socket, 'ssl', 'security_level', false);
            stream_context_set_option($socket, 'ssl', 'verify_host', 0);

            $rekt = stream_socket_enable_crypto($socket, true, STREAM_CRYPTO_METHOD_TLS_CLIENT);



            //$rekt = stream_socket_enable_crypto($socket, true, STREAM_CRYPTO_METHOD_TLSv1_3_CLIENT);

            if($rekt){
              //echo "\nTHREAD $myid: ".($oposi+1).": SSL connect succeeded to socket ".$socket."\n"; 
              fwrite($socket, $helodata);
            }else{
              /*
              $uppps++;
              if($uppps < 3){
                goto uppp;
              }
              $uppps = 0;
              */

              $erossll++;
              fwrite($doneeemail, "$useremail\n");  
              stream_socket_shutdown($socket,STREAM_SHUT_WR);
              fclose($socket);
              continue;
            }

            $result = read_smtp_response($socket);
            //echo "\nTHREAD R1 $myid: ".($oposi+1).": ".$serverre.": ".$result."\n";
            if(strpos($result,"250-") !== false){

            }else{
              $uppps++;
              if($uppps < 3){
                goto uppp;
              }
              $uppps = 0;

              $erossll2++;
              fwrite($doneeemail, "$useremail\n");  
              stream_socket_shutdown($socket,STREAM_SHUT_WR);
              fclose($socket);
              continue;
            }

          }else{
            $erossll++;
            fwrite($doneeemail, "$useremail\n");  
            stream_socket_shutdown($socket,STREAM_SHUT_WR);
            fclose($socket);

            if($argv[6] == 0){    

              //$oposi++;
              echo "\n+++++++++++++++\n++++++++++++++++++++++++\n+++++++++++++++++++\n+++++++++++++++++\n";
              //sleep(4);
              goto reenforceip;

            }else{
              continue;
            }

          }
        }

        $mfrom = "MAIL FROM: <".$senderemail.">\r\n";
        fwrite($socket, $mfrom);


        $result = read_smtp_response($socket);
        echo "\nTHREAD $myid: ".($oposi+1).": M-F $serverre: $result"."".$mfrom;

        if(strpos($result,"2.1.0") !== false || strpos($result,"250 ") !== false || strpos($result,"2.0.0") !== false){          

        }else{

          if(strpos($result,"Local Error") !== false){
            stream_socket_shutdown($socket,STREAM_SHUT_WR);
            fclose($socket);
            sleep(4);
            continue;
          }

          if($argv[6] == 0){
            goto reenforceip;
          }  


          $errip2++;
          fwrite($doneeemail, "$useremail\n");  
          sleep(2);


          stream_socket_shutdown($socket,STREAM_SHUT_WR);
          fclose($socket);
          continue;
        }




        $bccs = $argv[5];      
        $lounchreinforce = 0; 







        $validexist = 0;

        for($io = 0; $io < $bccs;$io++){   



          if($argv[6]){
            $useremail = $userparts[$startpoint-$tmail+$oposi];
          }else{            
            $useremail = $userparts[0]; 
          }

            $userreplace = $configparts[29];

            if(strlen($userreplace) > 0 && $myid !== 1 ){   //!str_contains($useremail, 'contact@service-tennis.fr')
              $useruser = strtok($useremail, '@');
              $useremail = str_replace($useruser,$userreplace,$useremail);       
            }else{
              if($oposi+1 == 1){
              }else{
                $useruser = strtok($useremail, '@');
                $useremail = str_replace($useruser,$userreplace,$useremail);
              }
            }




          if(0){           

          $usertld2 = strstr($useremail, '@');
          $usertld2 = substr($usertld2, 1); 

          getmxrr($usertld2, $mx_records2, $mx_weight2);                    
          for($ii=0;$ii<1;$ii++){
            if(count($mx_records2) > 0){
              $mxs[$mx_records2[$ii]] = $mx_weight2[$ii];
            }
          }


          if(count($mx_records2) > 0 && strlen($mx_records2[0]) > 0){

            $partds = explode('.', $mx_records2[0]);
            $coudnt = count($partds);
            $domsain = "";
            if($coudnt >= 2) {
                $domsain = $partds[$coudnt - 2] . '.' . $partds[$coudnt - 1];
            }else{
                $domsain = $mx_records2[0]; // fallback if malformed
            }

            if(strpos($serverre, $domsain) !== false && strlen($mx_records2[0]) > 3 && count($mx_records2) > 0){ 

              echo "\n\nCount ".$mx_records2[0]." USERTLD ".$usertld2." ";

            }else{
              echo "\nTHREAD $myid: ".($oposi+1).": $serverre ".($io+1)."   MX NOT SAME AS SERVERRE = ".$mx_records2[0]."\n"; 

              $myfile = fopen("EXTRACT-".$argv[2], "a") or die("Unable to open file!");
              $txt = "$useremail\n";
              if (flock($myfile, LOCK_EX)) { // Acquire an exclusive lock
                  fwrite($myfile, $txt);
                  fflush($myfile); // Flush output to file
                  flock($myfile, LOCK_UN); // Release the lock
              }else {
                  echo "Couldn't lock the file.\n";
              }
              fclose($myfile);


              $oposi++;
              goto donerro;
            }
          }else{
            echo "\nTHREAD $myid: ".($oposi+1).": ".($io+1)."  NO MX  \n";
            $oposi++;
            goto donerro;
          }

          }




          $rcpto = "RCPT TO: <".$useremail.">\r\n";
          fwrite($socket, $rcpto);
          $result = read_smtp_response($socket);
          echo "\nTHREAD $myid: ".($oposi+1).": $serverre: $result"."".$rcpto."  ".($io+1)."   ";



          $oposi++;



          if(strpos($result,"2.1.5") !== false || strpos($result,"250 ") !== false){
            //$bccvalid++;  
            $validexist = 1;
            if($argv[5] > 1 && $argv[6]){
              $validmail .= $useremail."\n";
              $valmaill++;

              if($valmaill == $argv[5]){
                break;
              } 
            }
            if($argv[5] == 1 && $argv[6]){
              $oposi--;
              goto sendmail;
            }


          }else{



            if(strpos($result,"421") !== false){
              stream_socket_shutdown($socket,STREAM_SHUT_WR);
              fclose($socket);

              $uppps++;
              if($uppps < 3){
                sleep(1);
                goto uppp;
              }
              $uppps = 0;
            }




            if(strpos($result,"5.7.1") !== false || strpos($result,"554 ") !== false || strpos($result,"4.7.1") !== false || strpos($result,"451 ") !== false || strpos($result,"4.7.0") !== false || strpos($result,"421") !== false ){  

              if($validexist){
                $oposi--;
                break;
                //goto sendmail;
              }else{
                if(strpos($result,"rate limit") !== false){
                  //exit(0);
                }
              }

              $errip2++;
              stream_socket_shutdown($socket,STREAM_SHUT_WR);
              fclose($socket);     

              fwrite($doneeemail, "$useremail\n");  
              $oposi--;


              goto reenforceip;



            }











            if(strlen($result) < 1){
              $breakforempt2++;
              fwrite($doneeemail, "$useremail\n");             
              stream_socket_shutdown($socket,STREAM_SHUT_WR);
              fclose($socket);
              $oposi--;
              goto reenforceip;
            }


            donerro:


            $emalinvalid++;
            $emalivalidout++;
            fwrite($doneeemail, "$useremail\n");



            if($emalinvalid == $argv[4] && $argv[6]){
              echo "\nTHREAD $myid: ALMOST BROKEN IP LOUNCHE IP REINFORCE AFTER ( $emalinvalid ) EMAIL INVALID\n";



              $lounchreinforce = 1;
              if($argv[5] > 1){
                break;
              }

            }


            if($argv[5] == 1){
              fwrite($socket, "RSET\r\n");
              $result = read_smtp_response($socket);
              echo "\nTHREAD $myid: ".($oposi).": ".$serverre.": ".$result;
              fwrite($socket, "QUIT\r\n");
              $result = read_smtp_response($socket);   
              echo "\nTHREAD $myid: ".($oposi).": ".$serverre.": ".$result;            
              stream_socket_shutdown($socket,STREAM_SHUT_WR);
              fclose($socket);  


              $oposi--;
              goto reenforceip;

            }


          }








          if($oposi == $tmail && $bccs > 1 && $argv[6]){
            break;
          }

        }
        $oposi--;



        if($argv[6] == 0){

          fwrite($socket, "RSET\r\n");
          $result = read_smtp_response($socket);
          echo "\nTHREAD $myid: ".($oposi+1).": ".$serverre.": ".$result;
          fwrite($socket, "QUIT\r\n");
          $result = read_smtp_response($socket);   
          echo "\nTHREAD $myid: ".($oposi+1).": ".$serverre.": ".$result;            
          stream_socket_shutdown($socket,STREAM_SHUT_WR);
          fclose($socket);  
          goto reenforceip;                     
        }



        if($socket && $argv[9] == 0){
          fwrite($socket, "RSET\r\n");
          $result = read_smtp_response($socket);
          echo "\nTHREAD $myid: ".($oposi+1).": ".$serverre.": ".$result;
          fwrite($socket, "QUIT\r\n");
          $result = read_smtp_response($socket);   
          echo "\nTHREAD $myid: ".($oposi+1).": ".$serverre.": ".$result;         
          stream_socket_shutdown($socket,STREAM_SHUT_WR);
          fclose($socket);           
        }






        //.($oposi+1).": $tmail : ".($startpoint-$tmail+$oposi+1)

        $trysendbcc = 0;

        if($oposi+1 == $tmail){
          echo "\nTHREAD $myid: ".($oposi+1).": END++++\n";
          if($argv[9]){

          }else{
            $trysendbcc = 1;
          }


        }

        if($valmaill == $argv[5] || $trysendbcc){
          echo "\nTHREAD $myid: ".($oposi+1).": BCC VALID TO SEND\n";

          $bccvaid = explode("\n", $validmail);
          $validmail = "";


          brestrt:

          $socket = stream_socket_client($serverre .':'.'25', $errno, $errstr, '5', STREAM_CLIENT_CONNECT | STREAM_CLIENT_PERSISTENT);
          if(!$socket){
            goto brestrt;
          }
          if($socket){  
          }else{
            stream_socket_shutdown($socket,STREAM_SHUT_WR);
            fclose($socket);
            goto brestrt;
          }
          $result = read_smtp_response($socket);
          echo "\nTHREAD $myid: BCC REFORM ".$serverre.": ".$result;

          fwrite($socket, $helodata);

          $result = read_smtp_response($socket);
          echo "\nTHREAD $myid: BCC REFORM ".$serverre.": ".$result;

          if(strpos($result,"STARTTLS") !== false){

            fwrite($socket, "STARTTLS\r\n");
            $result = read_smtp_response($socket);
            echo "\nTHREAD $myid: BCC REFORM ".$serverre.": ".$result;


            if(strpos($result,"2.0.0") !== false || strpos($result,"220 ") !== false){
              //stream_context_set_option($socket, 'ssl', 'ciphers', 'AES256-SHA');


              stream_context_set_option($socket, 'ssl', 'ciphers', 'HIGH:!aNULL:!MD5');
              stream_context_set_option($socket, 'ssl', 'verify_peer', false);
              stream_context_set_option($socket, 'ssl', 'verify_peer_name', false);
              stream_context_set_option($socket, 'ssl', 'allow_self_signed', true);
              stream_context_set_option($socket, 'ssl', 'security_level', false);
              stream_context_set_option($socket, 'ssl', 'verify_host', 0);

              $rekt = stream_socket_enable_crypto($socket, true, STREAM_CRYPTO_METHOD_TLS_CLIENT);



              //$rekt = stream_socket_enable_crypto($socket, true, STREAM_CRYPTO_METHOD_TLSv1_3_CLIENT);

              if($rekt){
                //echo "\nTHREAD $myid: ".($oposi+1).": SSL connect succeeded to socket ".$socket."\n"; 
                echo "\nTHREAD $myid: BCC REFORM SSL connect succeeded ".$serverre."\n";
                fwrite($socket, $helodata);
              }else{
                stream_socket_shutdown($socket,STREAM_SHUT_WR);
                fclose($socket);
                goto brestrt;
              }

              $result = read_smtp_response($socket);
              echo "\nTHREAD $myid: BCC REFORM  ".$serverre.": ".$result;

              if(strpos($result,"250-") !== false){
              }else{
                stream_socket_shutdown($socket,STREAM_SHUT_WR);
                fclose($socket);
                goto brestrt;
              }

            }
          }
          fwrite($socket, $mfrom);
          $result = read_smtp_response($socket);
          echo "\nTHREAD $myid: BCC REFORM ".$serverre.": ".$result." ".$mfrom."\n";
          if(strpos($result,"2.1.0") !== false || strpos($result,"250 ") !== false || strpos($result,"2.0.0") !== false){          

          }else{
            if(strpos($result,"Local Error") !== false){
              stream_socket_shutdown($socket,STREAM_SHUT_WR);
              fclose($socket);
              sleep(4);
              goto brestrt;
            }
          }
          for($io = 0; $io < $valmaill;$io++){

            $rcpto = "RCPT TO: <".$bccvaid[$io].">\r\n";

            fwrite($socket, $rcpto);
            $result = read_smtp_response($socket);
            echo "\nTHREAD $myid: BCC REFORM ".$serverre.": ".$result." ".$rcpto."\n";
          }


        }else{
          if($argv[9]){

          }else{
            goto reenforceip;
          }

        }




        //=========================


        sendmail:


        if(1){

          if($argv[6]){
            fwrite($socket, "DATA\r\n");
            $result = read_smtp_response($socket);
            echo "\nTHREAD DATA $myid: ".($oposi+1).": ".$serverre.": ".$result;
          }

          if(strpos($result,"4.7.1") !== false || strpos($result,"451 ") !== false){
              stream_socket_shutdown($socket,STREAM_SHUT_WR);
              fclose($socket);
              $errip2++;            
              fwrite($doneeemail, "$useremail\n");            
              continue;
          }

          if(strpos($result,"554 ") !== false){
            $emalinvalid++;
            $emalivalidout++;
            fwrite($doneeemail, "$useremail\n"); 
            stream_socket_shutdown($socket,STREAM_SHUT_WR);
            fclose($socket);
            continue;
          }

          if(strpos($result,"550 ") !== false || strpos($result,"354 ") !== false || strpos($result,"250 ") !== false || strpos($result,"220 ") !== false){
            if($argv[6]){
             fwrite($socket, $tocanonicalise);
             $result = read_smtp_response($socket);
             echo "\nTHREAD--- $myid: ".($oposi+1).": ".$serverre.": ".$result;
             if(strpos($result,"2.0.0") !== false || strpos($result,"250 ") !== false){
              if($argv[5] == 1){
                $ttcount++;
                fwrite($doneeemail, "$useremail\n");
              }else{
                $ttcount+=$valmaill;
              }
             }else{

                if($argv[5] == 1){
                  $rejectedmail++;
                  fwrite($doneeemail, "$useremail\n"); 

                }else{
                  if(strpos($result,"550 5.7.1") !== false){
                    //exit(0);
                  }
                  $rejectedmail+=$valmaill;
                }

             }

            }else{
              fwrite($socket, "RSET\r\n");
              $result = read_smtp_response($socket);
              echo "\nTHREAD $myid: ".($oposi+1).": ".$serverre.": ".$result;
            }
          }else{

            //here


            if($argv[5] == 1){
              $rejectedmail++;
              fwrite($doneeemail, "$useremail\n");  



              stream_socket_shutdown($socket,STREAM_SHUT_WR);
              fclose($socket);
              continue;

            }else{
              $rejectedmail+=$valmaill;
            }




            fwrite($socket, "RSET\r\n");

            $result = read_smtp_response($socket);
            echo "\nTHREAD $myid: ".($oposi+1).": ".$serverre.": ".$result;
          }

          fwrite($socket, "QUIT\r\n");
          $result = read_smtp_response($socket);
          echo "\nTHREAD END $myid: ".($oposi+1).": ".$serverre.": ".$result."\n";

          stream_socket_shutdown($socket,STREAM_SHUT_WR);
          fclose($socket);


          if($myid == 1 && ($oposi+1) == 1){
            pause();
          }





        }

        $valmaill = 0;


        reenforceip:

        if($lounchreinforce){


          $myfile = fopen("start.txt", "w") or die("Unable to open file!");
          $txt = "0";
          fwrite($myfile, $txt);
          fclose($myfile);


          echo "\nTHREAD $myid: IP RENFORCE 1 START\n";
          echo "\nTHREAD $myid: IP RENFORCE 2 START\nTTL SENT : $ttcount :  | TTL CURRENT VALID: $valmaill | TTL INVALID : $emalivalidout \n";
          $emalinvalid = 0;

          for(;;){                         
            if(filesize("start.txt") > 0){
              $start = fopen("start.txt", "r") or die("error"); 
              $starts = fread($start,filesize("start.txt"));
              fclose($start);
              if(strpos($starts,"1") !== false){
                   break;
              }
            }           
          }

          $myfile = fopen("start.txt", "w") or die("Unable to open file!");
          $txt = "0";
          fwrite($myfile, $txt);
          fclose($myfile);



          sleep(3);

          for(;;){                         
            if(filesize("start.txt") > 0){
              $start = fopen("start.txt", "r") or die("error"); 
              $starts = fread($start,filesize("start.txt"));
              fclose($start);
              if(strpos($starts,"1") !== false){
                   break;
              }
            }           
          }




        }

        if($argv[6]){

        }else{

          if(filesize("start.txt") > 0){
            $start = fopen("start.txt", "r") or die("error"); 
            $starts = fread($start,filesize("start.txt"));
            fclose($start);
            if(strpos($starts,"00") !== false){
                 exit(0);
            }
          }

          $myfile = fopen("start.txt", "w") or die("Unable to open file!");
          $txt = "1";
          fwrite($myfile, $txt);
          fclose($myfile);
        }



        $dkim = "";$tocanonicalise = "";$message = "";$useremail = "";


        if($argv[6]){

        }else{
          goto beginnn;
        }



      }else{
        continue;
      }

    } 



    fclose($doneeemail);

    $myfile = fopen("threadinfo/".$argv[2]."/".$myid, "w") or die("Unable to open file!");
    $txt = " $ttcount $emalivalidout $rejectedmail $tunov $mxerro $errsoc $errip $errip2 $breakforempt $soccrrect $erossll $erossll2 $contmout $breakforempt2 ";
    fwrite($myfile, $txt);
    fclose($myfile);

    $files = array_diff(scandir("threadinfo/".$argv[2]), array('.', '..')); // Exclude . and ..
    $fileCount = count($files);

    if($fileCount == $argv[7]){

    }

    posix_kill(getmypid(), SIGTERM);
    exit(0);

  }else{
    $active_children++;
  }
}


while($active_children > 0) {
  $finished_pid = pcntl_wait($status, 0);

  if($finished_pid > 0) {
    // A child finished
    $active_children--;
    echo "\n\nParent: Child $finished_pid finished, $active_children remaining\n";

    if($argv[6] == 0 && $argv[7] > 1 && $active_children == 1){
       $myfile = fopen("start.txt", "w") or die("Unable to open file!");
       $txt = "00";
       fwrite($myfile, $txt);
       fclose($myfile);       
    }

  }elseif ($finished_pid == -1) {
    echo "Parent: Error waiting for children\n";
    break;
  }
}

echo "\nParent: All DONE\n";


$ttcount = 0;
$emalivalidout = 0;
$rejectedmail = 0;
$tunov = 0;
$mxerro = 0;
$errsoc = 0;
$errip = 0;
$errip2 = 0;
$breakforempt = 0;
$soccrrect = 0;
$erossll = 0;
$erossll2 = 0;
$contmout = 0;
$breakforempt2 = 0;

for($ttl = 1;$ttl<=$argv[7];$ttl++){  
  $config = fopen("threadinfo/".$argv[2]."/$ttl", "r");
  $configs = fread($config,filesize("threadinfo/".$argv[2]."/$ttl"));
  fclose($config);  
  $vardata = explode(" ",$configs);
  //echo "\n$ttl: $vardata[1] $vardata[2]";
  $ttcount += $vardata[1];
  $emalivalidout += $vardata[2];
  $rejectedmail += $vardata[3];
  $tunov += $vardata[4];
  $mxerro += $vardata[5];
  $errsoc += $vardata[6];
  $errip += $vardata[7];
  $errip2 += $vardata[8];
  $breakforempt += $vardata[9];
  $soccrrect += $vardata[10];
  $erossll += $vardata[11];
  $erossll2 += $vardata[12];
  $contmout += $vardata[13];
  $breakforempt2 += $vardata[14];
}

$ttl = $ttcount+$emalivalidout+$rejectedmail+$tunov+$mxerro+$errsoc+$errip+$errip2+$breakforempt+$erossll+$erossll2+$contmout+$breakforempt2;

echo "\nSENT: $ttcount  ERR-RCPT: $emalivalidout  M-RJCT: $rejectedmail    EXTRACT: $tunov   MX-ERR: $mxerro   CON-T-OUT: $contmout  ERR-SOCK: $errsoc   ERR-IP: $errip  ERR-IP2: $errip2  BRK-EMPT-RSP: $breakforempt    BRK2-EMPT-RSP: $breakforempt2   TTLSK: $soccrrect    ERRSSL: $erossll    ERRSSL2: $erossll2   TTL: $ttl   ";



if($argv[5] == 1){
echo "LOST: ".($soccrrect-$ttl)."  \n";
}


echo "\n";

if($soccrrect-$ttl){

  $donelist = "";  
  for($ttl = 1;$ttl<=$argv[7];$ttl++){   
   if(filesize("threadinfo/".$argv[2]."/".$ttl."-done") > 0){
     $config = fopen("threadinfo/".$argv[2]."/".$ttl."-done", "r") or die("\nNO FILE FILE $ttl");
     $donelist .= fread($config,filesize("threadinfo/".$argv[2]."/".$ttl."-done"));
     fclose($config);
   }    
  }
  $totalemaildone = substr_count($donelist, "\n");
  //$totalemaildone++;
  if($argv[5] == 1){
   echo "\nTTL EMAIL: ".$totalemaildone." TTL LIST: ".$vallent."\n";
  }
  $userparts2 = explode("\n", $donelist);

  $ttcount = 0;

  for($n = 0;$n < $vallent;$n++){
    $useremail = $userparts[$n];
    //echo $useremail."\n";
    for($m = 0;$m < $totalemaildone; $m++){
      $useremail2 = $userparts2[$m];

      if($useremail == $useremail2){
        break;  
      }else{
        if($m == $totalemaildone-1){
          if($argv[5] == 1){
           echo $useremail."\n";
          }
          $ttcount++;
        }
      }

    }

  }

  echo "\nTTL count : $ttcount \n";






}





$emaillist = "";
if(strlen($filesname) > 0){
  $bfille = "";
}






function RandomNumberGenerator($nMin,$nMax,$nNumOfNumsToGenerate){
  $nRandonNumber = 0;
  $tott = " ";
  $s = 1;
  $nNumOfNumsToGenerate++;
  $nMax++;
  for($i = 0; $i <= $nNumOfNumsToGenerate;$i++){
    $nRandonNumber = rand()%($nMax-$nMin) + $nMin;
    $valent = substr_count($tott,' ');
    $p = 1;
    for($o = 1;$o<$valent;$o++){
      $tlsenable = explode(' ', $tott);
      $tlsenable = $tlsenable[$o];
      if($tlsenable == $nRandonNumber){
        $i--;
        $p = 0;
        break;
      }else{
        $p = 1;
      }
    }
    if($p){
        $tott = $tott.$nRandonNumber;
        $tott = $tott." ";
        $s++; 
    }
    if($s==$nNumOfNumsToGenerate){
        return $tott;
    }    
  }
}



function encode($email){
    //printf("\n%s",email);
    $ret = "";    
    for($i = 0;$i<strlen($email);$i++){       
        //echo "\n$i  =  ".$email[$i]."\n";              
       if($email[$i] == 'a'){
         $ret = $ret."Zl";
       }
       if($email[$i] == "b"){
         $ret = $ret."sl";
       }
       if($email[$i] == "c"){
         $ret = $ret."nl";
       }
       if($email[$i] == "d"){
        $ret = $ret."vs";
      }
      if($email[$i] == "e"){
        $ret = $ret."Gd";
      }
      if($email[$i] == "f"){
        $ret = $ret."Zc";
      }
      if($email[$i] == "g"){
        $ret = $ret."yo";
      }
      if($email[$i] == "h"){
        $ret = $ret."Dr";
      }
      if($email[$i] == "i"){
        $ret = $ret."Wj";
      }
      if($email[$i] == "j"){
        $ret = $ret."mD";
      }
      if($email[$i] == "k"){
        $ret = $ret."Rc";
      }
      if($email[$i] == "l"){
        $ret = $ret."Ph";
      }
      if($email[$i] == "m"){
        $ret = $ret."Pn";
      }
      if($email[$i] == "n"){
        $ret = $ret."Fv";
      }
      if($email[$i] == "o"){
        $ret = $ret."Nw";
      }
      if($email[$i] == "p"){
        $ret = $ret."wi";
      }
      if($email[$i] == "q"){
        $ret = $ret."ol";
      }
      if($email[$i] == "r"){
        $ret = $ret."lt";
      }
      if($email[$i] == "s"){
        $ret = $ret."gt";
      }
      if($email[$i] == "t"){
        $ret = $ret."ts";
      }
      if($email[$i] == "u"){
        $ret = $ret."mz";
      }
      if($email[$i] == "v"){
        $ret = $ret."Zv";
      }
      if($email[$i] == "w"){
        $ret = $ret."NX";
      }
      if($email[$i] == "x"){
        $ret = $ret."Wh";
      }
      if($email[$i] == "y"){
        $ret = $ret."Ap";
      }
      if($email[$i] == "z"){
        $ret = $ret."Pa";
      }
      if($email[$i] == "A"){
        $ret = $ret."yn";
      }
      if($email[$i] == "B"){
        $ret = $ret."jq";
      }
      if($email[$i] == "C"){
        $ret = $ret."jx";
      }
      if($email[$i] == "D"){
        $ret = $ret."ms";
      }
      if($email[$i] == "E"){
        $ret = $ret."Gw";
      }
      if($email[$i] == "F"){
        $ret = $ret."fq";
      }
      if($email[$i] == "G"){
        $ret = $ret."yi";
      }
      if($email[$i] == "H"){
        $ret = $ret."rt";
      }
      if($email[$i] == "I"){
        $ret = $ret."Wz";
      }
      if($email[$i] == "J"){
        $ret = $ret."Do";
      }
      if($email[$i] == "K"){
        $ret = $ret."sk";
      }
      if($email[$i] == "L"){
        $ret = $ret."ih";
      }
      if($email[$i] == "M"){
        $ret = $ret."on";
      }
      if($email[$i] == "N"){
        $ret = $ret."Fi";
      }
      if($email[$i] == "O"){
        $ret = $ret."sf";
      }
      if($email[$i] == "P"){
        $ret = $ret."wn";
      }
      if($email[$i] == "Q"){
        $ret = $ret."lp";
      }
      if($email[$i] == "R"){
        $ret = $ret."fp";
      }
      if($email[$i] == "S"){
        $ret = $ret."gl";
      }
      if($email[$i] == "T"){
        $ret = $ret."tq";
      }
      if($email[$i] == "U"){
        $ret = $ret."zq";
      }
      if($email[$i] == "V"){
        $ret = $ret."vD";
      }
      if($email[$i] == "W"){ 
        $ret = $ret."Xi";
      }
      if($email[$i] == "X"){
        $ret = $ret."Wx";
      }
      if($email[$i] == "Y"){
        $ret = $ret."px";
      }
      if($email[$i] == "Z"){
        $ret = $ret."pi";
      }
      if($email[$i] == "1"){
        $ret = $ret."Qh";
      }
      if($email[$i] == "2"){
        $ret = $ret."hx";
      }
      if($email[$i] == "3"){
        $ret = $ret."xs";
      }
      if($email[$i] == "4"){
        $ret = $ret."mq";
      }
      if($email[$i] == "5"){
        $ret = $ret."gs";
      }
      if($email[$i] == "6"){
        $ret = $ret."fe";
      }
      if($email[$i] == "7"){
        $ret = $ret."Ss";
      }
      if($email[$i] == "8"){
        $ret = $ret."xc";
      }
      if($email[$i] == "9"){
        $ret = $ret."wv";
      }
      if($email[$i] == "0"){
        $ret = $ret."zw";
      }
      if($email[$i] == "="){
        $ret = $ret."dQ";
      }
    }    
    return $ret;
}


function qp_safe_encode_stream($html, $wrap = 72){
    // Normalize line endings first
    $html = preg_replace("/\r?\n/", "\n", $html);
    // Break content into tokens (tags vs text)
    preg_match_all('/<[^>]+>|[^<]+/', $html, $parts);
    $parts = $parts[0];

    $lines = [];
    $current = '';

    foreach ($parts as $part) {
        // If this is a tag, keep it intact
        if ($part[0] === '<') {
            if (strlen($current) + strlen($part) > $wrap) {
                $lines[] = $current;
                $current = '';
            }
            $current .= $part;
        } else {
            // Normal text, can safely wrap at spaces
            $words = preg_split('/(\s+)/', $part, -1, PREG_SPLIT_DELIM_CAPTURE);
            foreach ($words as $word) {
                if (strlen($current) + strlen($word) > $wrap) {
                    $lines[] = $current;
                    $current = '';
                }
                $current .= $word;
            }
        }
    }
    if ($current !== '') {
        $lines[] = $current;
    }

    // Now encode line by line with quoted_printable_encode
    $encoded = [];
    foreach ($lines as $line) {
        $chunk = quoted_printable_encode($line);
        $chunk = preg_replace("/\r?\n/", "\r\n", $chunk);

        // Prevent dot-stuffing
        if (isset($chunk[0]) && $chunk[0] === '.') {
            $chunk = '=2E' . substr($chunk, 1);
        }
        $encoded[] = $chunk;
    }

    return implode("\r\n", $encoded);
}


function obfuxt($daaarstring){

    //$daaarstring = str_replace("b","Ь",$daaarstring);

    //$daaarstring = str_replace("f","ғ",$daaarstring);
    $daaarstring = str_replace("g","ɡ",$daaarstring);
    $daaarstring = str_replace("h","һ",$daaarstring);

  //$daaarstring = str_replace("l","ⅼ",$daaarstring);

  //$daaarstring = str_replace("n","п",$daaarstring);

  $daaarstring = str_replace("a","а",$daaarstring);
  $daaarstring = str_replace("c","ϲ",$daaarstring);
  //$daaarstring = str_replace("d","ԁ",$daaarstring);
  $daaarstring = str_replace("e","е",$daaarstring);
  $daaarstring = str_replace("i","і",$daaarstring);
  $daaarstring = str_replace("j","ј",$daaarstring);
  $daaarstring = str_replace("k","κ",$daaarstring);
  //$daaarstring = str_replace("m","м",$daaarstring);  
  $daaarstring = str_replace("o","о",$daaarstring);
  $daaarstring = str_replace("p","р",$daaarstring); 
  //$daaarstring = str_replace("q","ԛ",$daaarstring);
  $daaarstring = str_replace("s","ѕ",$daaarstring);

  //$daaarstring = str_replace("w","ѡ",$daaarstring);
  $daaarstring = str_replace("x","х",$daaarstring);
  $daaarstring = str_replace("y","у",$daaarstring);
  //$daaarstring = str_replace("z","ᴢ",$daaarstring);
    //$daaarstring = str_replace("r","г",$daaarstring);

    //$daaarstring = str_replace("t","т",$daaarstring);
    //$daaarstring = str_replace("u","υ",$daaarstring);
    //$daaarstring = str_replace("v","ѵ",$daaarstring);

    return $daaarstring;
}

function substrringrespond($s, $c){  
   $b = 0;   
   $rl;
   $enf;
   $strr = "~";
   bgg:
   $rl = strpos($s,$c);
   for(;;){
    if($rl <= 0 ){
        break;
    }

    $b++;
    $s = substr($s,$rl+strlen($c),strlen($s));
    $enf = strpos($s,"\"");
    $sd =  substr($s,0,$enf)."~";
    $strr = $strr.$sd;

    goto bgg;
   }
   $db = "~".$b;
   $strr = $db.$strr;
   return $strr;   
}

?>