"""Client SendByte Africa pour les envois transactionnels de YODA."""

import base64
import html
import mimetypes
import os
import re

import requests


API_URL = "https://api.sendbyte.africa/v1/emails"
REQUEST_TIMEOUT_SECONDS = 45


class SendByteError(RuntimeError):
    """Erreur exploitable renvoyée par l'API SendByte."""

    def __init__(self, message, *, status_code=None, retry_after=None, request_id=None):
        super().__init__(message)
        self.status_code = status_code
        self.retry_after = retry_after
        self.request_id = request_id


def _get_api_key():
    api_key = os.environ.get("SENDBYTE_API_KEY", "").strip()
    if not api_key:
        raise SendByteError(
            "La clé SENDBYTE_API_KEY est absente. Ajoutez-la aux secrets du projet "
            "avant d'activer SendByte."
        )
    return api_key


def html_to_text(content):
    """Produit une version texte simple pour les clients non HTML."""
    without_tags = re.sub(r"<[^>]+>", " ", content or "")
    normalized = re.sub(r"\s+", " ", html.unescape(without_tags)).strip()
    return normalized or "Message envoyé via SendByte."


def build_attachments(paths):
    """Encode les fichiers locaux au format attendu par SendByte."""
    attachments = []
    for path in paths or []:
        if not os.path.isfile(path):
            continue
        with open(path, "rb") as file:
            attachments.append({
                "filename": os.path.basename(path),
                "content": base64.b64encode(file.read()).decode("ascii"),
                "content_type": mimetypes.guess_type(path)[0] or "application/octet-stream",
            })
    return attachments


def _error_from_response(response):
    try:
        body = response.json()
    except ValueError:
        body = {}

    details = body.get("error", body) if isinstance(body, dict) else {}
    if isinstance(details, dict):
        message = details.get("message") or details.get("code")
    else:
        message = str(details)
    message = message or response.text.strip() or "Requête SendByte refusée."

    retry_after = None
    if response.headers.get("Retry-After"):
        try:
            retry_after = max(0.0, float(response.headers["Retry-After"]))
        except ValueError:
            pass

    request_id = response.headers.get("x-request-id")
    suffix = f" (requête {request_id})" if request_id else ""
    return SendByteError(
        f"SendByte ({response.status_code}): {message}{suffix}",
        status_code=response.status_code,
        retry_after=retry_after,
        request_id=request_id,
    )


def send_email(*, sender, recipients, subject, html_content, text_content=None,
               reply_to=None, headers=None, attachments=None, idempotency_key=None):
    """Envoie un message via POST /v1/emails."""
    if not sender or "@" not in sender:
        raise SendByteError(
            "SENDBYTE_FROM doit contenir une adresse d’expédition vérifiée dans SendByte."
        )

    to_addresses = [address for address in recipients if address and "@" in address]
    if not to_addresses:
        raise SendByteError("Aucun destinataire valide pour SendByte.")
    if not subject:
        raise SendByteError("Le sujet SendByte est obligatoire.")

    payload = {
        "from": sender,
        "to": to_addresses,
        "subject": subject,
        "html": html_content or "",
        "text": text_content or html_to_text(html_content),
    }
    if reply_to and "@" in reply_to:
        payload["reply_to"] = reply_to
    if headers:
        payload["headers"] = {str(key): str(value) for key, value in headers.items()}
    if attachments:
        payload["attachments"] = build_attachments(attachments)
    if idempotency_key:
        payload["idempotency_key"] = str(idempotency_key)

    try:
        response = requests.post(
            API_URL,
            headers={
                "Authorization": f"Bearer {_get_api_key()}",
                "Content-Type": "application/json",
                "Accept": "application/json",
            },
            json=payload,
            timeout=REQUEST_TIMEOUT_SECONDS,
        )
    except requests.Timeout as exc:
        raise SendByteError("La requête SendByte a expiré.") from exc
    except requests.RequestException as exc:
        raise SendByteError(f"Connexion à SendByte impossible : {exc}") from exc

    if response.status_code not in (200, 201):
        raise _error_from_response(response)

    try:
        return response.json()
    except ValueError as exc:
        raise SendByteError("Réponse invalide de SendByte.") from exc