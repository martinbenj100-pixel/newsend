const fs = require("node:fs");

const userAgent = process.env.npm_config_user_agent || "";
if (!userAgent.startsWith("pnpm/")) {
  console.error(
    "Use pnpm to install this workspace: corepack enable && pnpm install",
  );
  process.exit(1);
}

for (const lockfile of ["package-lock.json", "yarn.lock"]) {
  try {
    fs.rmSync(lockfile, { force: true });
  } catch (error) {
    console.error(`Unable to remove ${lockfile}: ${error.message}`);
    process.exit(1);
  }
}