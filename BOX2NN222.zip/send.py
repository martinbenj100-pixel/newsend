#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# send.py - YODA SEND MIX SMTP V4.5 - Avec IP Reinforce

import smtplib
import atexit
import dns.resolver
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.utils import formataddr, make_msgid, formatdate, parseaddr
from email.mime.base import MIMEBase
from email import encoders
import mimetypes
import socks
import socket
import requests
from smtp_connection import establish_tls, open_smtp
from resend_client import ResendError, send_email as send_resend_email
from sendbyte_client import SendByteError, send_email as send_sendbyte_email
from checkv2 import run_checkv2
from inline_logo import (
    download_logo_image,
    extract_base64_logo_image,
    find_logo_image_source,
    replace_logo_image_source,
)
import os
import time
import math
import re
import sys
import hashlib
import base64
import quopri
import random
import string
import threading
import queue
import json
import signal
import uuid
import unicodedata
import tempfile
from collections import deque
from datetime import datetime, timedelta
from concurrent.futures import ThreadPoolExecutor, as_completed
from letter_system import build_letter_message
from letter_to_image import LetterImageError, render_html_to_png
from urllib.parse import quote
from html import escape as html_escape
from secure_coordinator import SecureCoordinator


def _configure_console_encoding():
    """Force une sortie UTF-8 compatible avec les consoles Windows."""
    for stream in (sys.stdout, sys.stderr):
        if stream is not None and hasattr(stream, "reconfigure"):
            try:
                stream.reconfigure(encoding="utf-8", errors="replace")
            except (OSError, ValueError):
                pass


_configure_console_encoding()
PROJECT_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(PROJECT_DIR)

# DKIM signing réel (comme send.php avec openssl_sign)
try:
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import padding as crypto_padding
    DKIM_SIGNING_AVAILABLE = True
except ImportError:
    DKIM_SIGNING_AVAILABLE = False

# ===============================================
# CODES COULEURS ANSI
# ===============================================

class Colors:
    RED = '\033[91m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    MAGENTA = '\033[95m'
    CYAN = '\033[96m'
    WHITE = '\033[97m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'
    RESET = '\033[0m'

def print_colored(message, color=Colors.WHITE):
    """Affiche un message avec une couleur spécifique"""
    print(f"{color}{message}{Colors.RESET}")

# ===============================================
# FICHIER DE CONTRÔLE IP REINFORCE
# ===============================================

CONTROL_FILE = os.path.join(PROJECT_DIR, "control.json")
CONTROL_LOCK = threading.Lock()
REINFORCE_TRIGGER_LOCK = threading.Lock()
REINFORCE_ERRORS = 0
REINFORCE_THRESHOLD = 10
REINFORCE_ACTIVE = False
CLEAN_EMAILS = []
CURRENT_EMAIL_INDEX = 0
RECIPIENT_EMAILS = []

def init_control_file():
    """Initialise le fichier de contrôle"""
    with CONTROL_LOCK:
        data = {
            "status": "running",
            "mode": "send",
            "stop_target": None,
            "current_email": "",
            "email_index": 0,
            "error_count": 0,
            "max_errors": 10,
            "reinforce_duration": 60,
            "reinforce_start": None,
            "reinforce_end": None,
            "total_sent": 0,
            "total_errors": 0,
            "total_recipients": 0,
            "processed_count": 0,
            "warmup_sent": 0,
            "warmup_success": 0,
            "warmup_failed": 0,
            "last_update": datetime.now().isoformat()
        }
        with open(CONTROL_FILE, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2)

def update_control_file(**kwargs):
    """Met à jour le fichier de contrôle"""
    with CONTROL_LOCK:
        try:
            if os.path.exists(CONTROL_FILE):
                with open(CONTROL_FILE, 'r', encoding='utf-8') as f:
                    data = json.load(f)
            else:
                data = {"status": "running", "mode": "send", "email_index": 0, "error_count": 0}

            for key, value in kwargs.items():
                data[key] = value

            data["last_update"] = datetime.now().isoformat()
            temp_path = f"{CONTROL_FILE}.{os.getpid()}.{threading.get_ident()}.tmp"
            with open(temp_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2)
                f.flush()
                os.fsync(f.fileno())
            os.replace(temp_path, CONTROL_FILE)
        except Exception as e:
            print_colored(f"[⚠️] Erreur mise à jour control file: {e}", Colors.YELLOW)

def record_campaign_result(recipient_email, success, count=1):
    """Enregistre atomiquement des destinataires définitivement traités."""
    count = max(0, int(count))
    recorded = False
    with CONTROL_LOCK:
        try:
            data = read_control_file()
            data["current_email"] = recipient_email
            data["processed_count"] = int(data.get("processed_count", 0)) + count
            data["email_index"] = data["processed_count"]
            key = "total_sent" if success else "total_errors"
            data[key] = int(data.get(key, 0)) + count
            data["last_update"] = datetime.now().isoformat()
            temp_path = f"{CONTROL_FILE}.{os.getpid()}.{threading.get_ident()}.tmp"
            with open(temp_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2)
                f.flush()
                os.fsync(f.fileno())
            os.replace(temp_path, CONTROL_FILE)
            recorded = True
        except Exception as e:
            print_colored(f"[⚠️] Erreur compteur dashboard: {e}", Colors.YELLOW)
    if success and recorded:
        _record_test_mail_success(count)

def set_campaign_totals(sent, errors, processed=None, current_email=None):
    """Synchronise les totaux finaux des modes utilisant des files de retry."""
    sent = max(0, int(sent))
    errors = max(0, int(errors))
    processed = sent + errors if processed is None else max(0, int(processed))
    values = {
        "total_sent": sent,
        "total_errors": errors,
        "processed_count": processed,
        "email_index": processed,
    }
    if current_email is not None:
        values["current_email"] = current_email
    update_control_file(**values)

def read_control_file():
    """Lit le fichier de contrôle"""
    try:
        if os.path.exists(CONTROL_FILE):
            with open(CONTROL_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
    except Exception as e:
        print_colored(f"[⚠️] Erreur lecture control file: {e}", Colors.YELLOW)
    return {"status": "running", "mode": "send", "email_index": 0, "error_count": 0}

def stop_requested_for(data, target):
    """Indique si l'ordre d'arrêt concerne ce processus précis."""
    if data.get("status") != "stopped":
        return False
    return data.get("stop_target") in (None, "", "all", target)

def wait_for_reinforce_complete(request_id=None):
    """Attend que le reinforce soit terminé (mode send)"""
    print_colored(f"[⏳] En attente de la fin du reinforce...", Colors.YELLOW)
    last_remaining = None
    started_waiting = time.monotonic()
    configured_duration = max(1, int(CONFIG.get('REINFORCE_DURATION', 60)))
    max_wait = max(
        configured_duration + 120,
        int(CONFIG.get('REINFORCE_WAIT_TIMEOUT_SECONDS', configured_duration + 120))
    )
    while True:
        data = read_control_file()
        status = data.get("status", "running")
        mode = data.get("mode", "send")
        completed_id = data.get("reinforce_completed_id")

        request_completed = request_id is None or completed_id == request_id
        if status == "running" and mode == "send" and request_completed:
            print_colored(f"[✅] Reinforce terminé, reprise de l'envoi", Colors.GREEN)
            return True
        elif stop_requested_for(data, "send"):
            print_colored(f"[🛑] Programme arrêté", Colors.RED)
            return False
        elif status == "reinforce" and mode == "reinforce":
            reinforce_duration = data.get("reinforce_duration", 60)
            reinforce_start = data.get("reinforce_start")
            if reinforce_start:
                elapsed = (datetime.now() - datetime.fromisoformat(reinforce_start)).seconds
                remaining = max(0, reinforce_duration - elapsed)
                if remaining != last_remaining and (
                    remaining % 10 == 0 or remaining < 10
                ):
                    print_colored(f"[⏳] Reinforce en cours... {remaining}s restantes", Colors.YELLOW)
                    last_remaining = remaining

        if time.monotonic() - started_waiting >= max_wait:
            current_request_id = data.get("reinforce_request_id")
            if request_id is None or current_request_id == request_id:
                update_control_file(
                    status="running",
                    mode="send",
                    reinforce_end=datetime.now().isoformat(),
                    reinforce_completed_id=current_request_id,
                )
            print_colored(
                f"[⚠️] Délai Reinforce dépassé ({max_wait}s) — reprise automatique de l'envoi",
                Colors.YELLOW,
            )
            return False

        time.sleep(2)

def trigger_reinforce_and_wait(current_email, email_index, error_count):
    """Signale un cycle Reinforce et attend le relais correspondant."""
    with REINFORCE_TRIGGER_LOCK:
        current_data = read_control_file()
        if (
            current_data.get("status") == "reinforce"
            and current_data.get("mode") == "reinforce"
        ):
            request_id = current_data.get("reinforce_request_id")
        else:
            request_id = uuid.uuid4().hex
            update_control_file(
                status="reinforce",
                mode="reinforce",
                current_email=current_email,
                email_index=email_index,
                error_count=error_count,
                reinforce_request_id=request_id,
                reinforce_completed_id=None,
                reinforce_start=datetime.now().isoformat(),
                reinforce_end=None,
                reinforce_duration=CONFIG.get('REINFORCE_DURATION', 60)
            )
    return wait_for_reinforce_complete(request_id)

# ===============================================
# SURVEILLANCE EN TEMPS RÉEL AVEC WATCHDOG
# ===============================================

try:
    from watchdog.observers import Observer
    from watchdog.events import FileSystemEventHandler
    WATCHDOG_AVAILABLE = True
except ImportError:
    WATCHDOG_AVAILABLE = False
    print_colored("[⚠️] Watchdog non installé. Utilisation de la vérification rapide.", Colors.YELLOW)
    print_colored("[📦] Pour installer: pip install watchdog", Colors.CYAN)

class ControlFileHandler(FileSystemEventHandler):
    """Handler pour surveiller les changements du fichier control.json"""

    def __init__(self, callback):
        self.callback = callback
        self.last_content = None
        self.last_modified = 0
        self.file_path = CONTROL_FILE

    def on_modified(self, event):
        """Appelé quand un fichier est modifié"""
        if not event.is_directory and event.src_path.endswith(self.file_path):
            self.process_file_change()

    def on_created(self, event):
        """Appelé quand un fichier est créé"""
        if not event.is_directory and event.src_path.endswith(self.file_path):
            self.process_file_change()

    def process_file_change(self):
        """Traite le changement de fichier"""
        try:
            if os.path.exists(self.file_path):
                current_modified = os.path.getmtime(self.file_path)
                if current_modified > self.last_modified:
                    # Attendre que l'écriture soit complète (fichier peut être vide momentanément)
                    for _ in range(5):
                        with open(self.file_path, 'r') as f:
                            content = f.read().strip()
                        if content:
                            break
                        time.sleep(0.05)
                    if not content:
                        return
                    if content != self.last_content:
                        self.last_content = content
                        self.last_modified = current_modified
                        data = json.loads(content)
                        self.callback(data)
        except Exception as e:
            print_colored(f"[⚠️] Erreur lecture control file: {e}", Colors.YELLOW)

def start_watchdog(callback):
    """Démarre la surveillance en temps réel du fichier control.json"""
    if not WATCHDOG_AVAILABLE:
        print_colored("[⚠️] Watchdog non disponible, utilisation de la vérification rapide", Colors.YELLOW)
        return None

    event_handler = ControlFileHandler(callback)
    observer = Observer()
    observer.schedule(event_handler, path='.', recursive=False)
    observer.start()
    print_colored(f"[📡] Surveillance en temps réel de {CONTROL_FILE} activée", Colors.GREEN)
    return observer

# ===============================================
# VARIABLES GLOBALES PRINCIPALES
# ===============================================

SERVER_RDNS = None
MX_CACHE = {}
MX_SELECTION_COUNTERS = {}
MX_SELECTION_LOCK = threading.Lock()
CONFIG = {}
FIXED_USERS = []
SENDER_DOMAINS = []
SMTP_ACCOUNTS = []
VALID_SMTP_ACCOUNTS = []
AUTH_COORDINATOR = None
AUTH_CAMPAIGN_ID = os.environ.get("YODA_AUTH_CAMPAIGN_ID") or None
AUTH_LEASE_OWNER = os.environ.get("YODA_AUTH_LEASE_OWNER") or None
AUTH_SMTP_STATE_LOCK = threading.RLock()
AUTH_SMTP_FAILURE_LIMIT = 3
TEST_MAIL_LOCK = threading.Lock()
TEST_MAIL_SUCCESS_COUNT = 0


def _release_auth_campaign_lease():
    if AUTH_COORDINATOR is not None and AUTH_CAMPAIGN_ID and AUTH_LEASE_OWNER:
        try:
            AUTH_COORDINATOR.release_campaign_lease(
                AUTH_CAMPAIGN_ID, AUTH_LEASE_OWNER
            )
        except Exception:
            pass


atexit.register(_release_auth_campaign_lease)

# NOUVELLE VARIABLE GLOBALE POUR LES LIENS
AVAILABLE_LINKS = []

# Pool de connexions SMTP optimisé avec ROTATION FORCÉE ET PERSISTANCE
SMTP_CONNECTIONS = {}
SMTP_CONNECTION_USAGE = {}
SMTP_LOCK = threading.Lock()
CONNECTION_STATS = {
    'total_connections_created': 0,
    'connections_reused': 0,
    'connections_saved': 0,
    'active_connections': 0,
    'connections_rotated': 0
}

# Connexion SMTP pour le mode normal (non-AUTH)
NORMAL_MODE_CONNECTION = None
NORMAL_MODE_CONNECTION_TARGET = None
NORMAL_MODE_CONNECTION_LOCK = threading.Lock()

# NOUVELLES VARIABLES GLOBALES POUR LA REDISTRIBUTION INTELLIGENTE
MULTI_PORT_EMAIL_QUEUE = queue.Queue()
MULTI_PORT_FAILED_QUEUE = queue.Queue()
MULTI_PORT_CONNECTIONS = {}
MULTI_PORT_STATS = {
    'active_ports': 0,
    'total_connections': 0,
    'emails_sent_per_port': {},
    'errors_per_port': {},
    'start_time_per_port': {},
    'redistributed_emails': 0,
    'total_redistribution_cycles': 0,
    'port_success_rates': {},
    'port_last_success': {}
}
MULTI_PORT_LOCK = threading.Lock()
REDISTRIBUTION_ACTIVE = False
REDISTRIBUTION_THREAD = None

# NOUVELLES VARIABLES GLOBALES POUR LE MODE MULTITHREAD NORMAL
MULTITHREAD_STATS = {
    'total_threads': 0,
    'active_threads': 0,
    'emails_per_thread': {},
    'errors_per_thread': {},
    'thread_success_rates': {}
}
MULTITHREAD_LOCK = threading.Lock()

# Variables globales pour le comptage
email_counter = 0
success_counter = 0
error_counter = 0
start_time = None
EMAILS_PER_DELAY = 300
DELAY_SECONDS = 1
BCC_BATCHES_BEFORE_PAUSE = 50
BCC_PAUSE_SECONDS = 10

# Variables globales pour la rotation des ports
current_port_index = 0
port_email_counter = 0
port_error_counter = 0
consecutive_errors = 0
PORT_RANGE_START = 30000
PORT_RANGE_END = 30003
EMAILS_PER_PORT_ROTATION = 1
ERRORS_PER_PORT_ROTATION = 2
max_consecutive_errors = 2000

# Variables globales pour la rotation des domaines
current_domain_index = 0
domain_email_counter = 0

# Variables globales pour le mode AUTH
auth_email_counter = 0
auth_success_counter = 0
auth_error_counter = 0
actual_emails_sent = 0

# Variables globales pour les modes séquentiel et simultané
current_smtp_index = 0
smtp_rotation_counter = 0
SMTP_ROTATION_LOCK = threading.Lock()
MAX_CONNECTION_REUSE = 10

# Variables globales pour la rotation des IPs et headers dynamiques
IP_POOLS = []
current_ip_index = 0
MAIL_SERVERS_POOL = []
USER_AGENTS_POOL = []
SPAM_ASSASSIN_VERSIONS = []
ANTIVIRUS_ENGINES = []
MTA_VERSIONS = []
CLOUDFLARE_IPS = []
GOOGLE_IPS = []
AMAZON_IPS = []
MICROSOFT_IPS = []
ENTERPRISE_DOMAINS = []

# NOUVELLES VARIABLES GLOBALES POUR LE WARMUP EN BOUCLE
WARMUP_ACTIVE = False
WARMUP_THREAD = None
WARMUP_STATS = {
    'total_warmups': 0,
    'successful_warmups': 0,
    'failed_warmups': 0,
    'domains_warmed': set(),
    'last_warmup_time': None,
    'warmup_errors': []
}
WARMUP_LOCK = threading.Lock()

def print_banner():
    """Affiche une bannière de démarrage"""
    banner = f"""
{Colors.CYAN}{Colors.BOLD}
╔══════════════════════════════════════════════════════════════╗
║                   YODA SEND MIX SMTP V4.5                    ║
║    🔄 REDISTRIBUTION INTELLIGENTE EN TEMPS RÉEL NOUVELLE !   ║
║         Enhanced with INTELLIGENT EMAIL REDISTRIBUTION      ║
║            🚀 RÉUTILISATION OPTIMALE DES CONNEXIONS 🚀      ║
║            🛡️ MAXIMUM ANTI-SPAM HEADERS PROTECTION 🛡️       ║
║          📧 MODE PERSISTANT POUR PERFORMANCE MAXIMALE      ║
║         ⚡ REDISTRIBUTION AUTO + DÉBIT PARAMÉTRABLE ⚡       ║
║         📊 DIVISION AUTOMATIQUE LISTE PAR SMTP BCC 📊       ║
║         🎨 PRÉSERVATION TOTALE DU HTML ET CSS 🎨           ║
║         🔗 NOUVEAU: REMPLACEMENT ALÉATOIRE DES LIENS 🔗    ║
║         ⚡ NOUVEAU: MODE MULTITHREAD HAUTE PERFORMANCE ⚡   ║
║         🌡️ NOUVEAU: WARMUP MX AVANCÉ EN BOUCLE 🌡️        ║
║         🛡️ NOUVEAU: IP REINFORCE AVEC WARMUP CLEAN 🛡️    ║
║         🌡️ NOUVEAU: WARMUP INITIAL AU DÉMARRAGE 🌡️       ║
╚══════════════════════════════════════════════════════════════╝
{Colors.RESET}
    """
    print(banner)

def load_links():
    """Charge la liste des liens depuis le fichier liens.txt"""
    global AVAILABLE_LINKS
    try:
        links_file = CONFIG.get('LINKS_FILE', 'liens.txt')
        if os.path.exists(links_file):
            with open(links_file, 'r', encoding='utf-8') as f:
                AVAILABLE_LINKS = [line.strip() for line in f if line.strip() and not line.startswith('#')]
            print_colored(f"[+] {len(AVAILABLE_LINKS)} liens chargés depuis {links_file}", Colors.GREEN)
            if AVAILABLE_LINKS:
                for i, link in enumerate(AVAILABLE_LINKS[:5]):
                    print_colored(f"    → {link}", Colors.CYAN)
                if len(AVAILABLE_LINKS) > 5:
                    print_colored(f"    ... et {len(AVAILABLE_LINKS) - 5} autres liens", Colors.CYAN)
            else:
                print_colored(f"[!] Le fichier {links_file} est vide", Colors.YELLOW)
        else:
            print_colored(f"[!] Fichier {links_file} non trouvé", Colors.YELLOW)
            AVAILABLE_LINKS = []
    except Exception as e:
        print_colored(f"[-] Erreur chargement des liens: {e}", Colors.RED)
        AVAILABLE_LINKS = []

def get_random_link():
    """Retourne un lien aléatoire de la liste"""
    if not AVAILABLE_LINKS:
        print_colored(f"[⚠️] Aucun lien disponible, utilisation d'un lien par défaut", Colors.YELLOW)
        return "https://example.com"
    return random.choice(AVAILABLE_LINKS)


def get_optional_random_link():
    """Retourne un lien HTTP(S) de liens.txt, ou rien lorsque le fichier est inactif."""
    valid_links = [
        link for link in AVAILABLE_LINKS
        if re.match(r'^https?://[^\s<>"]+$', link, flags=re.IGNORECASE)
    ]
    if not valid_links:
        return ''
    return random.choice(valid_links)


def prepare_delivery_content(html_content):
    """Prépare le HTML final et, si activé, son unique image CID."""
    if not CONFIG.get('LETTER_TO_IMG', False):
        return {'html': html_content, 'inline_assets': []}

    message_path = str(CONFIG.get('MESSAGE_FILE', 'message.html')).strip()
    logo_path = str(CONFIG.get('LOGO_FILE', '')).strip()
    preview_text = unicodedata.normalize(
        'NFC', str(CONFIG.get('LETTER_PREVIEW_TEXT', ''))
    )
    preview_text = ''.join(
        character
        for character in preview_text.replace('\u00a0', ' ')
        if character in '\t ' or unicodedata.category(character) not in {'Cc', 'Cf'}
    ).strip()
    try:
        image_path = render_html_to_png(
            html_content,
            source_path=message_path,
            logo_path=logo_path,
        )
    except LetterImageError:
        raise
    except Exception as exc:
        raise LetterImageError(f"Erreur de conversion de la lettre : {exc}") from exc

    content_id = f'yoda-letter-{uuid.uuid4().hex}'
    image_html = (
        f'<img src="cid:{content_id}" alt="" '
        'style="display:block;border:0;width:100%;max-width:720px;height:auto;">'
    )
    destination = get_optional_random_link()
    if destination:
        image_html = (
            f'<a href="{html_escape(destination, quote=True)}" target="_blank" '
            'style="display:block;text-decoration:none;">'
            f'{image_html}</a>'
        )
        print_colored('[+] Letter to image : image CID cliquable avec un lien de liens.txt', Colors.CYAN)
    else:
        print_colored('[+] Letter to image : image CID sans lien (liens.txt vide ou absent)', Colors.CYAN)

    preheader_html = ''
    if preview_text:
        escaped_preview = html_escape(preview_text, quote=False)
        preheader_html = (
            '<div aria-hidden="true" style="display:none!important;visibility:hidden;'
            'opacity:0;color:transparent;font-size:1px;line-height:1px;height:0;'
            'width:0;max-height:0;max-width:0;overflow:hidden;mso-hide:all;">'
            f'{escaped_preview}'
            '</div>'
        )

    return {
        'html': (
            '<html><body style="margin:0;padding:0;">'
            f'{preheader_html}{image_html}</body></html>'
        ),
        'text': preview_text,
        'inline_assets': [{
            'path': image_path,
            'cid': content_id,
            'filename': 'letter.png',
        }],
    }


def attach_delivery_content(msg, content):
    """Ajoute le contenu HTML et, si disponible, le texte d'aperçu de la boîte mail."""
    html_part = MIMEText(content['html'], 'html', 'utf-8')
    html_part.set_charset('utf-8')
    preview_text = str(content.get('text') or '').strip()
    inline_assets = content.get('inline_assets', [])

    if preview_text:
        alternative = MIMEMultipart('alternative')
        alternative.attach(MIMEText(preview_text, 'plain', 'utf-8'))
        related = MIMEMultipart('related')
        related.attach(html_part)
        alternative.attach(related)
        msg.attach(alternative)
        msg._yoda_inline_assets_container = related
    else:
        msg.attach(html_part)

    msg._yoda_inline_assets = inline_assets


def cleanup_delivery_content(content):
    """Supprime les rendus temporaires après leur encodage dans le message."""
    for asset in content.get('inline_assets', []):
        try:
            os.unlink(asset.get('path', ''))
        except OSError:
            pass


def replace_random_links_in_content(content):
    """Remplace ##lien## dans le contenu par des liens aléatoires.
    Si LETTER_RANDOM=true, génère un template et une reformulation uniques
    par destinataire (template aléatoire + synonymes différents à chaque appel)."""
    if CONFIG.get('LETTER_RANDOM', False):
        cta_link = get_random_link() if AVAILABLE_LINKS else ''
        letter_config = CONFIG
        if (
            not CONFIG.get('LOGO_CID_ENABLED', True)
            and str(CONFIG.get('LOGO', '')).strip().lower().startswith('cid:')
        ):
            letter_config = dict(CONFIG)
            letter_config['LOGO'] = ''
            print_colored(
                "[!] Logo CID désactivé, mais aucune URL directe n'est configurée "
                "dans LOGO : le template aléatoire sera envoyé sans logo.",
                Colors.YELLOW,
            )
        return build_letter_message(letter_config, cta_link)
    if not content:
        return content
    if '##lien##' not in content:
        return content
    modified_content = content
    while '##lien##' in modified_content:
        random_link = get_random_link()
        modified_content = modified_content.replace('##lien##', random_link, 1)
    return modified_content

def print_multithread_stats():
    """Affiche les statistiques du mode multithread normal"""
    with MULTITHREAD_LOCK:
        if MULTITHREAD_STATS['total_threads'] == 0:
            return
        stats = f"""
{Colors.BOLD}{Colors.GREEN}┌─ STATISTIQUES MODE MULTITHREAD NORMAL ─────────────────────┐{Colors.RESET}
{Colors.CYAN}│ 🧵 Threads configurés           : {MULTITHREAD_STATS['total_threads']:>6}                    │{Colors.RESET}
{Colors.YELLOW}│ 🔥 Threads actifs               : {MULTITHREAD_STATS['active_threads']:>6}                    │{Colors.RESET}
        """
        for thread_id, count in MULTITHREAD_STATS['emails_per_thread'].items():
            errors = MULTITHREAD_STATS['errors_per_thread'].get(thread_id, 0)
            total_attempts = count + errors
            success_rate = (count / total_attempts * 100) if total_attempts > 0 else 0
            stats += f"{Colors.GREEN}│ 📧 Thread {thread_id:<3} - Succès        : {count:>6} ({success_rate:>5.1f}% réussite)      │{Colors.RESET}\n"
        stats += f"{Colors.BOLD}{Colors.GREEN}└──────────────────────────────────────────────────────────────┘{Colors.RESET}"
        print(stats)

def print_connection_pool_stats():
    """Affiche les statistiques du pool de connexions SMTP avec rotation"""
    with SMTP_LOCK:
        stats = f"""
{Colors.BOLD}{Colors.GREEN}┌─ STATISTIQUES POOL DE CONNEXIONS SMTP (PERSISTANTES) ───────┐{Colors.RESET}
{Colors.CYAN}│ 🔗 Connexions totales créées     : {CONNECTION_STATS['total_connections_created']:>6}                    │{Colors.RESET}
{Colors.GREEN}│ ♻️  Connexions réutilisées       : {CONNECTION_STATS['connections_reused']:>6}                    │{Colors.RESET}
{Colors.MAGENTA}│ 🔄 Connexions avec rotation      : {CONNECTION_STATS['connections_rotated']:>6}                    │{Colors.RESET}
{Colors.YELLOW}│ 📡 Connexions actives            : {CONNECTION_STATS['active_connections']:>6}                    │{Colors.RESET}
{Colors.RED}│ 🚫 Limite d'usage par connexion  : {MAX_CONNECTION_REUSE:>6}                    │{Colors.RESET}
{Colors.CYAN}│ 💾 Mode persistant               : {'ACTIVÉ' if not CONFIG.get('USE_BCC_MODE', False) else 'BCC MODE':>6}                    │{Colors.RESET}
{Colors.BOLD}{Colors.GREEN}└──────────────────────────────────────────────────────────────┘{Colors.RESET}
        """
        print(stats)

def print_multi_port_stats():
    """Affiche les statistiques des connexions multi-ports avec redistribution"""
    with MULTI_PORT_LOCK:
        if not MULTI_PORT_STATS['active_ports']:
            return
        stats = f"""
{Colors.BOLD}{Colors.MAGENTA}┌─ STATISTIQUES MULTI-PORTS + REDISTRIBUTION INTELLIGENTE ────┐{Colors.RESET}
{Colors.CYAN}│ 🌐 Ports actifs simultanés      : {MULTI_PORT_STATS['active_ports']:>6}                    │{Colors.RESET}
{Colors.GREEN}│ 🔗 Connexions totales           : {MULTI_PORT_STATS['total_connections']:>6}                    │{Colors.RESET}
{Colors.YELLOW}│ 🔄 Emails redistribués          : {MULTI_PORT_STATS['redistributed_emails']:>6}                    │{Colors.RESET}
{Colors.MAGENTA}│ 🔁 Cycles de redistribution     : {MULTI_PORT_STATS['total_redistribution_cycles']:>6}                    │{Colors.RESET}
        """
        for port, count in MULTI_PORT_STATS['emails_sent_per_port'].items():
            errors = MULTI_PORT_STATS['errors_per_port'].get(port, 0)
            total_attempts = count + errors
            success_rate = (count / total_attempts * 100) if total_attempts > 0 else 0
            stats += f"{Colors.YELLOW}│ 📧 Port {port:<5} - Succès      : {count:>6} ({success_rate:>5.1f}% de réussite)    │{Colors.RESET}\n"
        stats += f"{Colors.BOLD}{Colors.MAGENTA}└──────────────────────────────────────────────────────────────┘{Colors.RESET}"
        print(stats)

def print_warmup_stats():
    """Affiche les statistiques du warmup en boucle"""
    with WARMUP_LOCK:
        if WARMUP_STATS['total_warmups'] == 0:
            return
        stats = f"""
{Colors.BOLD}{Colors.CYAN}┌─ STATISTIQUES WARMUP MX EN BOUCLE ─────────────────────────┐{Colors.RESET}
{Colors.CYAN}│ 🌡️ Warmups totaux              : {WARMUP_STATS['total_warmups']:>6}                    │{Colors.RESET}
{Colors.GREEN}│ ✅ Warmups réussis             : {WARMUP_STATS['successful_warmups']:>6}                    │{Colors.RESET}
{Colors.RED}│ ❌ Warmups échoués             : {WARMUP_STATS['failed_warmups']:>6}                    │{Colors.RESET}
{Colors.MAGENTA}│ 🌐 Domaines uniques warmés     : {len(WARMUP_STATS['domains_warmed']):>6}                    │{Colors.RESET}
{Colors.YELLOW}│ ⏱️ Dernier warmup              : {WARMUP_STATS['last_warmup_time']:>6}                    │{Colors.RESET}
{Colors.BOLD}{Colors.CYAN}└──────────────────────────────────────────────────────────────┘{Colors.RESET}
        """
        print(stats)

def print_reinforce_stats():
    """Affiche les statistiques IP Reinforce"""
    control_data = read_control_file()
    stats = f"""
{Colors.BOLD}{Colors.MAGENTA}┌─ STATISTIQUES IP REINFORCE ─────────────────────────────────┐{Colors.RESET}
{Colors.CYAN}│ 📊 Statut                    : {control_data.get('status', 'unknown'):>6}                    │{Colors.RESET}
{Colors.CYAN}│ 📧 Mode                     : {control_data.get('mode', 'unknown'):>6}                    │{Colors.RESET}
{Colors.YELLOW}│ ❌ Erreurs actuelles         : {control_data.get('error_count', 0):>6}                    │{Colors.RESET}
{Colors.GREEN}│ ✅ Emails envoyés            : {control_data.get('total_sent', 0):>6}                    │{Colors.RESET}
{Colors.RED}│ ❌ Emails échoués            : {control_data.get('total_errors', 0):>6}                    │{Colors.RESET}
{Colors.GREEN}│ 🌡️ Warmups réussis           : {control_data.get('warmup_success', 0):>6}                    │{Colors.RESET}
{Colors.RED}│ 🌡️ Warmups échoués           : {control_data.get('warmup_failed', 0):>6}                    │{Colors.RESET}
{Colors.CYAN}│ 📍 Dernier email            : {control_data.get('current_email', 'N/A'):>6}                    │{Colors.RESET}
{Colors.YELLOW}│ 🔄 Dernière mise à jour     : {control_data.get('last_update', 'N/A'):>6}                    │{Colors.RESET}
{Colors.BOLD}{Colors.MAGENTA}└──────────────────────────────────────────────────────────────┘{Colors.RESET}
    """
    print(stats)

# ===============================================
# FONCTIONS D'ENVOI MULTITHREAD
# ===============================================

def send_email_multithreaded_worker(thread_id, recipient_emails_batch, subject, message, attachments=None):
    """Worker thread pour le mode multithread normal"""
    global email_counter, success_counter, error_counter, REINFORCE_ERRORS

    thread_success = 0
    thread_errors = 0
    max_retries = max(1, int(CONFIG.get('MAX_RETRIES', 5)))
    retry_delay = max(0.0, float(CONFIG.get('RETRY_DELAY', 1)))

    with MULTITHREAD_LOCK:
        MULTITHREAD_STATS['active_threads'] += 1
        MULTITHREAD_STATS['emails_per_thread'][thread_id] = 0
        MULTITHREAD_STATS['errors_per_thread'][thread_id] = 0

    print_colored(f"[🧵] Thread {thread_id} démarré: {len(recipient_emails_batch)} emails assignés", Colors.CYAN)

    try:
        for i, recipient_email in enumerate(recipient_emails_batch, 1):
            delivered = False
            last_error = None
            sender_email = "expéditeur indisponible"

            for attempt in range(1, max_retries + 1):
                server = None
                try:
                    # Vérifier le statut du reinforce avant chaque nouvelle tentative.
                    if not CONFIG.get('USE_AUTH_MODE', False):
                        control_data = read_control_file()
                        if control_data.get("status") == "reinforce" and control_data.get("mode") == "reinforce":
                            print_colored(f"[⏸️] Reinforce en cours, en attente...", Colors.YELLOW)
                            wait_for_reinforce_complete()

                    sender_email = get_sender_email(recipient_email)
                    personalized_message = replace_random_links_in_content(message)
                    token = generate_token()
                    final_subject = build_final_subject(subject, token)

                    recipient_domain = recipient_email.split('@')[1]
                    mail_server = get_mx_record(recipient_domain)
                    if not mail_server:
                        raise Exception(f"Impossible de résoudre MX pour {recipient_domain}")
                    server_port = 25

                    server = create_smtp_connection(mail_server, server_port)
                    if not server:
                        raise Exception("Impossible d'établir une connexion SMTP")

                    msg = MIMEMultipart()
                    msg['From'] = get_visible_from_header(sender_email)
                    msg['To'] = recipient_email
                    msg['Subject'] = final_subject
                    msg['Date'] = formatdate(localtime=True)
                    msg['Message-ID'] = generate_message_id_enhanced(sender_email.split('@')[1])
                    msg = add_ultra_enhanced_anti_spam_headers(msg, sender_email, recipient_email, token)
                    msg['X-Thread-ID'] = str(thread_id)
                    delivery_content = prepare_delivery_content(personalized_message)
                    attach_delivery_content(msg, delivery_content)
                    if attachments:
                        attach_files(msg, attachments)
                    server.sendmail(sender_email, [recipient_email], finalize_email(msg, sender_email))

                    thread_success += 1
                    record_campaign_result(recipient_email, True)
                    timestamp = datetime.now().strftime("%H:%M:%S")
                    print_colored(
                        f"[{timestamp}] ✓ T{thread_id}: {sender_email} → {recipient_email} "
                        f"[tentative {attempt}/{max_retries}] [Ref-{token}] [HTML+LIENS] via {mail_server}",
                        Colors.GREEN
                    )
                    with MULTITHREAD_LOCK:
                        MULTITHREAD_STATS['emails_per_thread'][thread_id] += 1
                    update_control_file(error_count=REINFORCE_ERRORS)
                    delivered = True
                    break
                except Exception as e:
                    last_error = e
                    timestamp = datetime.now().strftime("%H:%M:%S")
                    if attempt < max_retries:
                        print_colored(
                            f"[{timestamp}] ⚠️ T{thread_id}: {sender_email} → {recipient_email} "
                            f"- tentative {attempt}/{max_retries} échouée : {e}",
                            Colors.YELLOW
                        )
                        if retry_delay > 0.0:
                            time.sleep(retry_delay)
                finally:
                    if server is not None:
                        close_smtp_connection(server)

            if delivered:
                time_per_email = CONFIG.get('TIME_PER_EMAIL_SECONDS', 1.0)
                if time_per_email > 0.0:
                    time.sleep(time_per_email)
            else:
                thread_errors += 1
                record_campaign_result(recipient_email, False)
                with MULTITHREAD_LOCK:
                    REINFORCE_ERRORS += 1
                    reinforce_error_count = REINFORCE_ERRORS
                    max_errors = CONFIG.get('MAX_ERRORS_BEFORE_REINFORCE', 10)
                    should_trigger_reinforce = (
                        reinforce_error_count >= max_errors
                        and CONFIG.get('USE_IP_REINFORCE', False)
                        and not CONFIG.get('USE_AUTH_MODE', False)
                    )
                    if should_trigger_reinforce:
                        REINFORCE_ERRORS = 0
                timestamp = datetime.now().strftime("%H:%M:%S")
                print_colored(
                    f"[{timestamp}] ❌ T{thread_id}: {sender_email} → {recipient_email} "
                    f"- échec définitif après {max_retries} tentative(s) : {last_error}",
                    Colors.RED
                )

                # Vérifier le seuil d'erreurs pour IP Reinforce (jamais en mode AUTH)
                if should_trigger_reinforce:
                    print_colored(f"[{timestamp}] ⚠️ SEUIL D'ERREURS ATTEINT ({reinforce_error_count}/{max_errors})", Colors.RED)
                    print_colored(f"[{timestamp}] 🔄 Déclenchement du reinforce...", Colors.MAGENTA)
                    current_idx = 0
                    if recipient_email in RECIPIENT_EMAILS:
                        current_idx = RECIPIENT_EMAILS.index(recipient_email)
                    trigger_reinforce_and_wait(
                        recipient_email, current_idx, reinforce_error_count
                    )

                with MULTITHREAD_LOCK:
                    MULTITHREAD_STATS['errors_per_thread'][thread_id] += 1
                save_failed_email(recipient_email)

        with MULTITHREAD_LOCK:
            global success_counter, error_counter, email_counter
            success_counter += thread_success
            error_counter += thread_errors
            email_counter += len(recipient_emails_batch)

    finally:
        with MULTITHREAD_LOCK:
            MULTITHREAD_STATS['active_threads'] -= 1
            total_attempts = thread_success + thread_errors
            if total_attempts > 0:
                MULTITHREAD_STATS['thread_success_rates'][thread_id] = (thread_success / total_attempts) * 100

    print_colored(f"[🏁] Thread {thread_id} terminé: {thread_success} succès, {thread_errors} erreurs", Colors.GREEN)
    return thread_success

def send_emails_multithreaded_normal_mode(recipient_emails, subject, message, attachments=None):
    """Mode multithread normal pour haute performance"""
    global start_time, email_counter, success_counter, error_counter

    start_time = time.time()
    email_counter = 0
    success_counter = 0
    error_counter = 0

    num_threads = CONFIG.get('THREADS', 200)
    time_per_email = CONFIG.get('TIME_PER_EMAIL_SECONDS', 1.0)

    print_colored(f"\n[🚀] DÉMARRAGE MODE MULTITHREAD NORMAL HAUTE PERFORMANCE V4.5", Colors.BOLD)
    print_colored(f"[⚡] {num_threads} threads simultanés configurés", Colors.GREEN)
    print_colored(f"[📧] {len(recipient_emails)} emails à distribuer entre les threads", Colors.CYAN)
    print_colored(f"[⏱️] Débit configuré: {1/time_per_email:.1f} emails/seconde par thread", Colors.MAGENTA)
    print_colored(f"[🎯] Vitesse théorique maximale: {num_threads * (1/time_per_email):.0f} emails/seconde", Colors.BOLD)
    print_colored(f"[🛡️] Headers ultra-renforcés sur tous les threads", Colors.MAGENTA)
    print_colored(f"[🎨] HTML préservé sans modification", Colors.BOLD)
    print_colored(f"[🔗] Liens aléatoires différents pour chaque email", Colors.BOLD)
    print_colored(f"[📡] Résolution MX dynamique par thread", Colors.CYAN)

    with MULTITHREAD_LOCK:
        MULTITHREAD_STATS['total_threads'] = num_threads
        MULTITHREAD_STATS['active_threads'] = 0
        MULTITHREAD_STATS['emails_per_thread'] = {}
        MULTITHREAD_STATS['errors_per_thread'] = {}
        MULTITHREAD_STATS['thread_success_rates'] = {}

    emails_per_thread = len(recipient_emails) // num_threads
    remainder = len(recipient_emails) % num_threads

    thread_email_batches = []
    start_idx = 0
    for thread_id in range(num_threads):
        batch_size = emails_per_thread + (1 if thread_id < remainder else 0)
        end_idx = start_idx + batch_size
        if start_idx < len(recipient_emails):
            email_batch = recipient_emails[start_idx:end_idx]
            if email_batch:
                thread_email_batches.append((thread_id, email_batch))
        start_idx = end_idx

    effective_threads = len(thread_email_batches)
    print_colored(f"[📊] Distribution: {effective_threads} threads effectifs utilisés", Colors.CYAN)

    print_colored(f"[⚡] LANCEMENT SIMULTANÉ DE {effective_threads} THREADS...", Colors.BOLD)

    with ThreadPoolExecutor(max_workers=effective_threads) as executor:
        futures = []
        for thread_id, email_batch in thread_email_batches:
            future = executor.submit(send_email_multithreaded_worker, thread_id, email_batch, subject, message, attachments)
            futures.append(future)

        completed = 0
        for future in as_completed(futures):
            try:
                future.result()
                completed += 1
                if completed % max(1, effective_threads // 10) == 0 or completed == effective_threads:
                    progress = (completed / effective_threads) * 100
                    print_colored(f"[📊] Progression: {completed}/{effective_threads} threads terminés ({progress:.1f}%)", Colors.YELLOW)
            except Exception as e:
                print_colored(f"[❌] Erreur dans un thread: {e}", Colors.RED)
                completed += 1

    elapsed_time = time.time() - start_time
    actual_rate = email_counter / elapsed_time if elapsed_time > 0 else 0
    theoretical_max_rate = num_threads * (1/time_per_email)
    efficiency = (actual_rate / theoretical_max_rate) * 100 if theoretical_max_rate > 0 else 0

    print_colored(f"\n[🏁] MODE MULTITHREAD NORMAL HAUTE PERFORMANCE TERMINÉ", Colors.BOLD)
    print_colored(f"[📊] Temps total: {elapsed_time:.2f}s", Colors.CYAN)
    print_colored(f"[⚡] Vitesse réelle: {actual_rate:.2f} emails/seconde", Colors.MAGENTA)
    print_colored(f"[🎯] Vitesse théorique: {theoretical_max_rate:.0f} emails/seconde", Colors.CYAN)
    print_colored(f"[📈] Efficacité obtenue: {efficiency:.1f}%", Colors.YELLOW)
    print_colored(f"[✅] Succès: {success_counter}, Échecs: {error_counter}", Colors.GREEN)
    print_multithread_stats()

# ===============================================
# FONCTIONS DE DIVISION ET ENVOI BCC
# ===============================================

def divide_emails_by_smtp_accounts(recipient_emails):
    """Divise automatiquement la liste des emails par le nombre de comptes SMTP disponibles"""
    if not VALID_SMTP_ACCOUNTS:
        print_colored("[❌] Aucun compte SMTP valide disponible pour la division", Colors.RED)
        return []

    num_smtp_accounts = len(VALID_SMTP_ACCOUNTS)
    total_emails = len(recipient_emails)

    print_colored(f"\n[📊] DIVISION AUTOMATIQUE DE LA LISTE PAR SMTP", Colors.BOLD)
    print_colored(f"[📧] Total emails à diviser: {total_emails}", Colors.CYAN)
    print_colored(f"[🔐] Comptes SMTP disponibles: {num_smtp_accounts}", Colors.CYAN)

    base_batch_size = total_emails // num_smtp_accounts
    remainder = total_emails % num_smtp_accounts

    print_colored(f"[📊] Taille de base par lot: {base_batch_size}", Colors.YELLOW)
    if remainder > 0:
        print_colored(f"[📊] Emails restants à répartir: {remainder}", Colors.YELLOW)

    smtp_email_batches = []
    start_index = 0

    for i, smtp_account in enumerate(VALID_SMTP_ACCOUNTS):
        batch_size = base_batch_size + (1 if i < remainder else 0)
        end_index = start_index + batch_size
        email_batch = recipient_emails[start_index:end_index]
        smtp_email_batches.append({
            'smtp_account': smtp_account,
            'emails': email_batch,
            'batch_number': i + 1
        })
        smtp_server_display = smtp_account.get('smtp_server', 'auto-détecté')
        print_colored(f"[📦] Lot {i+1}: {len(email_batch)} emails → {smtp_account['email']} [{smtp_server_display}]", Colors.GREEN)
        start_index = end_index

    print_colored(f"[✅] Division terminée: {len(smtp_email_batches)} lots créés", Colors.GREEN)
    return smtp_email_batches

def send_bcc_batch_for_smtp_account(smtp_batch_data, subject, message, attachments=None):
    """Envoie un lot d'emails BCC pour un compte SMTP spécifique"""
    smtp_account = smtp_batch_data['smtp_account']
    emails = smtp_batch_data['emails']
    batch_number = smtp_batch_data['batch_number']

    if not emails:
        print_colored(f"[⚠️] Lot {batch_number} vide pour {smtp_account['email']}", Colors.YELLOW)
        return 0, 0

    print_colored(f"\n[🚀] DÉMARRAGE LOT {batch_number}: {len(emails)} emails via {smtp_account['email']}", Colors.BOLD)

    bcc_batch_size = CONFIG.get('BCC_BATCH_SIZE', 50)
    time_per_email = CONFIG.get('TIME_PER_EMAIL_SECONDS', 1.0)

    email_sub_batches = []
    for i in range(0, len(emails), bcc_batch_size):
        sub_batch = emails[i:i + bcc_batch_size]
        email_sub_batches.append(sub_batch)

    print_colored(f"[📦] Lot {batch_number} divisé en {len(email_sub_batches)} sous-batches BCC de max {bcc_batch_size} emails", Colors.CYAN)

    success_count = 0
    error_count = 0

    for sub_batch_num, sub_batch in enumerate(email_sub_batches, 1):
        print_colored(f"[📧] Lot {batch_number}.{sub_batch_num}: Envoi BCC de {len(sub_batch)} emails...", Colors.CYAN)
        start_time = time.time()
        success = send_bcc_email_with_auth(smtp_account, sub_batch, subject, message, attachments)
        if success:
            success_count += len(sub_batch)
            for recipient in sub_batch:
                complete_coordinator_recipient(recipient, True)
            print_colored(f"[✅] Lot {batch_number}.{sub_batch_num}: {len(sub_batch)} emails envoyés avec succès", Colors.GREEN)
        else:
            error_count += len(sub_batch)
            for recipient in sub_batch:
                complete_coordinator_recipient(recipient, False)
            print_colored(f"[❌] Lot {batch_number}.{sub_batch_num}: Échec de l'envoi de {len(sub_batch)} emails", Colors.RED)

        elapsed_time = time.time() - start_time
        required_time = len(sub_batch) * time_per_email
        if elapsed_time < required_time:
            sleep_time = required_time - elapsed_time
            print_colored(f"[⏱️] Pause de {sleep_time:.1f}s pour respecter le débit configuré", Colors.YELLOW)
            time.sleep(sleep_time)

        if sub_batch_num < len(email_sub_batches):
            if sub_batch_num % BCC_BATCHES_BEFORE_PAUSE == 0:
                print_colored(f"[⏸️] Pause automatique de {BCC_PAUSE_SECONDS}s après {sub_batch_num} sous-batches", Colors.YELLOW)
                time.sleep(BCC_PAUSE_SECONDS)

    print_colored(f"[🏁] LOT {batch_number} TERMINÉ: {success_count} succès, {error_count} erreurs", Colors.BOLD)
    return success_count, error_count

def send_emails_with_divided_smtp_bcc_mode(recipient_emails, subject, message, attachments=None):
    """Mode BCC avec division automatique de la liste par comptes SMTP (SANS DOUBLONS)"""
    global auth_email_counter, auth_success_counter, auth_error_counter, start_time, actual_emails_sent

    start_time = time.time()
    auth_email_counter = 0
    auth_success_counter = 0
    auth_error_counter = 0
    actual_emails_sent = 0

    if not VALID_SMTP_ACCOUNTS:
        print_colored("[-] Aucun compte SMTP valide disponible", Colors.RED)
        return

    original_count = len(recipient_emails)
    print_colored(f"\n[📋] LISTE ORIGINALE: {original_count} emails chargés", Colors.CYAN)

    print_colored(f"\n[🚀] MODE BCC AVEC DIVISION AUTOMATIQUE PAR SMTP V4.5", Colors.BOLD)
    print_colored(f"[📧] {len(recipient_emails)} emails à diviser entre {len(VALID_SMTP_ACCOUNTS)} comptes SMTP", Colors.CYAN)
    print_colored(f"[🔐] Chaque compte SMTP recevra son lot distinct d'emails", Colors.MAGENTA)
    print_colored(f"[📮] Mode BCC: Batches de {CONFIG.get('BCC_BATCH_SIZE', 50)} destinataires maximum", Colors.YELLOW)
    print_colored(f"[🔗] Liens aléatoires: Chaque email aura des liens différents", Colors.BOLD)

    smtp_email_batches = divide_emails_by_smtp_accounts(recipient_emails)
    if not smtp_email_batches:
        print_colored("[❌] Échec de la division des emails", Colors.RED)
        return

    total_unique_emails = sum(len(batch['emails']) for batch in smtp_email_batches)
    print_colored(f"[✅] EMAILS UNIQUES À ENVOYER: {total_unique_emails}", Colors.GREEN)

    use_sequential_mode = CONFIG.get('USE_SEQUENTIAL_MODE', True)
    max_simultaneous_smtp = CONFIG.get('MAX_SIMULTANEOUS_SMTP', 3)

    if use_sequential_mode:
        print_colored(f"\n[🔄] MODE SÉQUENTIEL: Traitement des lots un par un", Colors.GREEN)
        for batch_data in smtp_email_batches:
            success_count, error_count = send_bcc_batch_for_smtp_account(batch_data, subject, message, attachments)
            auth_success_counter += success_count
            auth_error_counter += error_count
            auth_email_counter += len(batch_data['emails'])
            if batch_data['batch_number'] % 3 == 0 or batch_data['batch_number'] == len(smtp_email_batches):
                print_statistics_auth()
    else:
        print_colored(f"\n[⚡] MODE SIMULTANÉ: {min(max_simultaneous_smtp, len(smtp_email_batches))} lots en parallèle", Colors.GREEN)
        def process_batch_thread(batch_data):
            return send_bcc_batch_for_smtp_account(batch_data, subject, message, attachments)
        batches_processed = 0
        while batches_processed < len(smtp_email_batches):
            current_batches = smtp_email_batches[batches_processed:batches_processed + max_simultaneous_smtp]
            print_colored(f"\n[⚡] Traitement simultané de {len(current_batches)} lots:", Colors.MAGENTA)
            with ThreadPoolExecutor(max_workers=len(current_batches)) as executor:
                futures = [executor.submit(process_batch_thread, batch) for batch in current_batches]
                for future in as_completed(futures):
                    try:
                        success_count, error_count = future.result()
                        auth_success_counter += success_count
                        auth_error_counter += error_count
                    except Exception as e:
                        print_colored(f"[❌] Erreur dans un thread simultané: {e}", Colors.RED)
            for batch in current_batches:
                auth_email_counter += len(batch['emails'])
            batches_processed += len(current_batches)
            print_statistics_auth()
            if batches_processed < len(smtp_email_batches):
                pause_time = CONFIG.get('TIME_PER_EMAIL_SECONDS', 1.0) * 2
                print_colored(f"[⏸️] Pause de {pause_time}s entre les groupes simultanés", Colors.YELLOW)
                time.sleep(pause_time)

    close_all_smtp_connections()
    elapsed_time = time.time() - start_time
    actual_rate = auth_email_counter / elapsed_time if elapsed_time > 0 else 0

    print_colored(f"\n[🏁] MODE BCC DIVISÉ PAR SMTP TERMINÉ", Colors.BOLD)
    print_colored(f"[📋] Emails dans la liste originale: {original_count}", Colors.CYAN)
    print_colored(f"[📧] Emails uniques traités: {total_unique_emails}", Colors.CYAN)
    print_colored(f"[✅] Emails envoyés avec succès: {actual_emails_sent}", Colors.GREEN)
    print_colored(f"[❌] Emails en erreur: {auth_error_counter}", Colors.RED)
    print_colored(f"[⏱️] Temps total: {elapsed_time:.2f}s", Colors.CYAN)
    print_colored(f"[⚡] Vitesse réelle: {actual_rate:.2f} emails/seconde", Colors.MAGENTA)
    print_statistics_auth()
    print_connection_pool_stats()

# ===============================================
# FONCTIONS MULTI-PORTS
# ===============================================

def initialize_email_queues(recipient_emails):
    """Initialise les files d'attente pour la redistribution intelligente"""
    global MULTI_PORT_EMAIL_QUEUE, MULTI_PORT_FAILED_QUEUE
    while not MULTI_PORT_EMAIL_QUEUE.empty():
        try:
            MULTI_PORT_EMAIL_QUEUE.get_nowait()
        except queue.Empty:
            break
    while not MULTI_PORT_FAILED_QUEUE.empty():
        try:
            MULTI_PORT_FAILED_QUEUE.get_nowait()
        except queue.Empty:
            break
    for email in recipient_emails:
        MULTI_PORT_EMAIL_QUEUE.put(email)
    print_colored(f"[📋] {len(recipient_emails)} emails ajoutés à la file d'attente de redistribution", Colors.GREEN)

def get_best_performing_port():
    """Retourne le port avec le meilleur taux de succès récent"""
    with MULTI_PORT_LOCK:
        best_port = None
        best_rate = -1
        current_time = time.time()
        for port in MULTI_PORT_CONNECTIONS.keys():
            sent = MULTI_PORT_STATS['emails_sent_per_port'].get(port, 0)
            errors = MULTI_PORT_STATS['errors_per_port'].get(port, 0)
            total = sent + errors
            if total > 0:
                success_rate = sent / total
                last_success = MULTI_PORT_STATS['port_last_success'].get(port, 0)
                time_factor = max(0.5, 1 - (current_time - last_success) / 60)
                adjusted_rate = success_rate * time_factor
                if adjusted_rate > best_rate:
                    best_rate = adjusted_rate
                    best_port = port
        return best_port

def redistribution_monitor_thread():
    """Thread de surveillance et redistribution automatique des emails échoués"""
    global REDISTRIBUTION_ACTIVE
    print_colored(f"[🔄] Thread de redistribution intelligente démarré", Colors.CYAN)
    while REDISTRIBUTION_ACTIVE:
        try:
            try:
                failed_email_data = MULTI_PORT_FAILED_QUEUE.get(timeout=1)
            except queue.Empty:
                continue
            best_port = get_best_performing_port()
            if best_port is not None:
                with MULTI_PORT_LOCK:
                    MULTI_PORT_STATS['redistributed_emails'] += 1
                    MULTI_PORT_STATS['total_redistribution_cycles'] += 1
                email, original_port, error_msg = failed_email_data
                print_colored(f"[🔄] REDISTRIBUTION: {email} du port {original_port} → port {best_port}", Colors.YELLOW)
                MULTI_PORT_EMAIL_QUEUE.put((email, best_port, True))
            else:
                MULTI_PORT_FAILED_QUEUE.put(failed_email_data)
                time.sleep(0.5)
        except Exception as e:
            print_colored(f"[❌] Erreur dans le thread de redistribution: {e}", Colors.RED)
            time.sleep(1)
    print_colored(f"[✅] Thread de redistribution intelligente arrêté", Colors.GREEN)

def start_redistribution_monitor():
    """Démarre le thread de surveillance et redistribution"""
    global REDISTRIBUTION_ACTIVE, REDISTRIBUTION_THREAD
    REDISTRIBUTION_ACTIVE = True
    REDISTRIBUTION_THREAD = threading.Thread(target=redistribution_monitor_thread, daemon=True)
    REDISTRIBUTION_THREAD.start()
    print_colored(f"[🚀] Système de redistribution intelligente activé", Colors.GREEN)

def stop_redistribution_monitor():
    """Arrête le thread de surveillance et redistribution"""
    global REDISTRIBUTION_ACTIVE, REDISTRIBUTION_THREAD
    REDISTRIBUTION_ACTIVE = False
    if REDISTRIBUTION_THREAD:
        REDISTRIBUTION_THREAD.join(timeout=5)
    print_colored(f"[🛑] Système de redistribution intelligente arrêté", Colors.YELLOW)

def initialize_multi_port_connections():
    """Initialise les connexions simultanées sur plusieurs ports SOCKS5"""
    global MULTI_PORT_CONNECTIONS, MULTI_PORT_STATS
    if not CONFIG.get('USE_MULTI_PORT_MODE', False):
        return False
    proxy_host = CONFIG.get('PROXY_HOST', '127.0.0.1')
    start_port = CONFIG.get('MULTI_PORT_START', 30000)
    num_ports = CONFIG.get('MULTI_PORT_COUNT', 3)
    print_colored(f"\n[🚀] INITIALISATION MODE MULTI-PORTS AVEC REDISTRIBUTION V4.5", Colors.BOLD)
    successful_connections = 0
    with MULTI_PORT_LOCK:
        MULTI_PORT_CONNECTIONS.clear()
        MULTI_PORT_STATS = {
            'active_ports': 0,
            'total_connections': 0,
            'emails_sent_per_port': {},
            'errors_per_port': {},
            'start_time_per_port': {},
            'redistributed_emails': 0,
            'total_redistribution_cycles': 0,
            'port_success_rates': {},
            'port_last_success': {}
        }
        for i in range(num_ports):
            port = start_port + i
            try:
                test_socket = socks.socksocket()
                test_socket.set_proxy(socks.SOCKS5, proxy_host, port)
                test_socket.settimeout(10)
                try:
                    test_socket.connect(("google.com", 80))
                    test_socket.close()
                    MULTI_PORT_CONNECTIONS[port] = {
                        'host': proxy_host,
                        'port': port,
                        'smtp_server': None,
                        'active': True,
                        'connection_count': 0,
                        'last_activity': time.time(),
                        'consecutive_errors': 0
                    }
                    MULTI_PORT_STATS['emails_sent_per_port'][port] = 0
                    MULTI_PORT_STATS['errors_per_port'][port] = 0
                    MULTI_PORT_STATS['start_time_per_port'][port] = time.time()
                    MULTI_PORT_STATS['port_success_rates'][port] = 100.0
                    MULTI_PORT_STATS['port_last_success'][port] = time.time()
                    successful_connections += 1
                    print_colored(f"[✅] Port {port}: Connexion proxy opérationnelle", Colors.GREEN)
                except Exception as e:
                    print_colored(f"[❌] Port {port}: Échec du test de connexion - {e}", Colors.RED)
            except Exception as e:
                print_colored(f"[❌] Port {port}: Impossible de créer la connexion proxy - {e}", Colors.RED)
        MULTI_PORT_STATS['active_ports'] = successful_connections
        MULTI_PORT_STATS['total_connections'] = successful_connections
    if successful_connections > 0:
        print_colored(f"\n[🎉] {successful_connections} connexions proxy simultanées établies avec succès !", Colors.GREEN)
        return True
    else:
        print_colored(f"[❌] Aucune connexion proxy réussie. Mode Multi-Ports désactivé.", Colors.RED)
        CONFIG['USE_MULTI_PORT_MODE'] = False
        return False

def get_smtp_connection_for_port(port, mail_server, server_port):
    """Crée une connexion SMTP spécifique pour un port proxy donné"""
    try:
        port_config = MULTI_PORT_CONNECTIONS[port]
        proxy_socket = socks.socksocket()
        proxy_socket.set_proxy(socks.SOCKS5, port_config['host'], port_config['port'])
        original_socket = socket.socket
        socket.socket = lambda family=socket.AF_INET, type=socket.SOCK_STREAM, proto=0: proxy_socket
        try:
            server = smtplib.SMTP(mail_server, port=server_port, timeout=60)
            if CONFIG.get('DEBUG_MODE', False):
                server.set_debuglevel(1)
            server.ehlo(SERVER_RDNS)
            establish_tls(
                server,
                mail_server,
                server_port,
                required=CONFIG.get('SMTP_REQUIRE_TLS', True),
            )
            socket.socket = original_socket
            print_colored(f"[📡] Connexion SMTP établie pour port {port} vers {mail_server}:{server_port}", Colors.GREEN)
            return server
        except Exception as e:
            socket.socket = original_socket
            raise e
    except Exception as e:
        print_colored(f"[❌] Erreur création connexion SMTP pour port {port}: {e}", Colors.RED)
        return None

def send_email_with_intelligent_port(port, recipient_email, subject, message, attachments=None, is_redistribution=False):
    """Envoie un email en utilisant un port proxy spécifique avec gestion intelligente"""
    try:
        personalized_message = replace_random_links_in_content(message)
        sender_email = get_sender_email(recipient_email)
        sender_name = CONFIG.get('SENDER_NAME', '')
        token = generate_token()
        final_subject = build_final_subject(subject, token)
        if CONFIG.get('USE_FIXED_SMTP', True):
            mail_server = CONFIG.get('SMTP_SERVER', 'smtp.vialis.net')
            server_port = CONFIG.get('SMTP_PORT', 25)
        else:
            recipient_domain = recipient_email.split('@')[1]
            mail_server = get_mx_record(recipient_domain)
            if not mail_server:
                raise Exception(f"Impossible de résoudre MX pour {recipient_domain}")
            server_port = 25
        server = get_smtp_connection_for_port(port, mail_server, server_port)
        if not server:
            raise Exception("Impossible d'établir une connexion SMTP")
        try:
            msg = MIMEMultipart()
            msg['From'] = get_visible_from_header(sender_email)
            msg['To'] = recipient_email
            msg['Subject'] = final_subject
            msg['Date'] = formatdate(localtime=True)
            msg['Message-ID'] = generate_message_id_enhanced(sender_email.split('@')[1])
            msg = add_ultra_enhanced_anti_spam_headers(msg, sender_email, recipient_email, token)
            msg['X-Proxy-Port'] = str(port)
            if is_redistribution:
                msg['X-Redistribution'] = 'True'
            delivery_content = prepare_delivery_content(personalized_message)
            attach_delivery_content(msg, delivery_content)
            if attachments:
                attach_files(msg, attachments)
            server.sendmail(sender_email, [recipient_email], finalize_email(msg, sender_email))
            with MULTI_PORT_LOCK:
                MULTI_PORT_STATS['emails_sent_per_port'][port] = MULTI_PORT_STATS['emails_sent_per_port'].get(port, 0) + 1
                MULTI_PORT_STATS['port_last_success'][port] = time.time()
                MULTI_PORT_CONNECTIONS[port]['last_activity'] = time.time()
                MULTI_PORT_CONNECTIONS[port]['consecutive_errors'] = 0
                sent = MULTI_PORT_STATS['emails_sent_per_port'][port]
                errors = MULTI_PORT_STATS['errors_per_port'].get(port, 0)
                total = sent + errors
                if total > 0:
                    MULTI_PORT_STATS['port_success_rates'][port] = (sent / total) * 100
            timestamp = datetime.now().strftime("%H:%M:%S")
            redistrib_info = " [REDISTRIBUÉ]" if is_redistribution else ""
            print_colored(f"[{timestamp}] ✓ PORT-{port}: {sender_email} → {recipient_email} [Ref-{token}] [HTML+LIENS]{redistrib_info}", Colors.GREEN)
            record_campaign_result(recipient_email, True)
            return True
        finally:
            try:
                server.quit()
            except:
                try:
                    server.close()
                except:
                    pass
    except Exception as e:
        with MULTI_PORT_LOCK:
            MULTI_PORT_STATS['errors_per_port'][port] = MULTI_PORT_STATS['errors_per_port'].get(port, 0) + 1
            MULTI_PORT_CONNECTIONS[port]['consecutive_errors'] = MULTI_PORT_CONNECTIONS[port].get('consecutive_errors', 0) + 1
        timestamp = datetime.now().strftime("%H:%M:%S")
        print_colored(f"[{timestamp}] ❌ PORT-{port}: {sender_email} → {recipient_email} - {e}", Colors.RED)
        MULTI_PORT_FAILED_QUEUE.put((recipient_email, port, str(e)))
        return False

def smart_port_worker_thread(port, worker_id):
    """Worker thread intelligent pour un port spécifique avec redistribution"""
    print_colored(f"[🌐] Worker PORT-{port} (Worker-{worker_id}) démarré", Colors.CYAN)
    emails_processed = 0
    time_per_email = CONFIG.get('TIME_PER_EMAIL_SECONDS', 1.0)
    while True:
        try:
            try:
                email_data = MULTI_PORT_EMAIL_QUEUE.get(timeout=2)
                if isinstance(email_data, tuple):
                    if len(email_data) == 3:
                        email, preferred_port, is_priority = email_data
                        if preferred_port != port and not is_priority:
                            MULTI_PORT_EMAIL_QUEUE.put(email_data)
                            continue
                        recipient_email = email
                        is_redistribution = is_priority
                    else:
                        recipient_email, _ = email_data
                        is_redistribution = True
                else:
                    recipient_email = email_data
                    is_redistribution = False
            except queue.Empty:
                with MULTI_PORT_LOCK:
                    total_pending = MULTI_PORT_EMAIL_QUEUE.qsize() + MULTI_PORT_FAILED_QUEUE.qsize()
                if total_pending == 0:
                    break
                else:
                    continue
            start_send_time = time.time()
            success = send_email_with_intelligent_port(port, recipient_email, 
                                                     CONFIG.get('EMAIL_SUBJECT', ''), 
                                                     CONFIG.get('_MESSAGE_CONTENT', ''), 
                                                     CONFIG.get('_ATTACHMENTS', None),
                                                     is_redistribution)
            emails_processed += 1
            elapsed_send_time = time.time() - start_send_time
            if time_per_email > 0.0 and elapsed_send_time < time_per_email:
                time.sleep(time_per_email - elapsed_send_time)
            MULTI_PORT_EMAIL_QUEUE.task_done()
        except Exception as e:
            print_colored(f"[❌] Erreur dans worker PORT-{port}: {e}", Colors.RED)
            break
    print_colored(f"[✅] Worker PORT-{port} (Worker-{worker_id}) terminé: {emails_processed} emails traités", Colors.GREEN)
    return emails_processed

def send_emails_multi_port_intelligent_mode(recipient_emails, subject, message, attachments=None):
    """NOUVELLE FONCTION: Mode multi-ports avec redistribution intelligente en temps réel"""
    global start_time, email_counter, success_counter, error_counter
    start_time = time.time()
    email_counter = 0
    success_counter = 0
    error_counter = 0
    if not MULTI_PORT_CONNECTIONS:
        print_colored("[❌] Aucune connexion multi-ports disponible", Colors.RED)
        return
    initialize_email_queues(recipient_emails)
    CONFIG['EMAIL_SUBJECT'] = subject
    CONFIG['_MESSAGE_CONTENT'] = message
    CONFIG['_ATTACHMENTS'] = attachments
    active_ports = list(MULTI_PORT_CONNECTIONS.keys())
    num_ports = len(active_ports)
    time_per_email = CONFIG.get('TIME_PER_EMAIL_SECONDS', 1.0)
    print_colored(f"\n[🚀] DÉMARRAGE MODE MULTI-PORTS INTELLIGENT V4.5", Colors.BOLD)
    print_colored(f"[⚡] {num_ports} ports actifs avec redistribution automatique", Colors.GREEN)
    print_colored(f"[📧] {len(recipient_emails)} emails en file d'attente partagée", Colors.CYAN)
    print_colored(f"[⏱️] Débit configuré: {1/time_per_email:.1f} emails/seconde par port", Colors.MAGENTA)
    print_colored(f"[🔄] Redistribution automatique des échecs activée", Colors.BOLD)
    start_redistribution_monitor()
    print_colored(f"\n[🚀] LANCEMENT INTELLIGENT SUR {num_ports} PORTS:", Colors.BOLD)
    with ThreadPoolExecutor(max_workers=num_ports) as executor:
        futures = []
        for worker_id, port in enumerate(active_ports, 1):
            future = executor.submit(smart_port_worker_thread, port, worker_id)
            futures.append((port, future))
            print_colored(f"[🌐] Worker PORT-{port} lancé (Worker-{worker_id})", Colors.CYAN)
        total_processed = 0
        completed_workers = 0
        for port, future in futures:
            try:
                worker_result = future.result()
                total_processed += worker_result
                completed_workers += 1
                print_colored(f"[✅] Worker PORT-{port} terminé avec succès", Colors.GREEN)
            except Exception as e:
                print_colored(f"[❌] Erreur dans worker PORT-{port}: {e}", Colors.RED)
                completed_workers += 1
        print_colored(f"[⏳] Attente de la fin du traitement de tous les emails...", Colors.YELLOW)
        MULTI_PORT_EMAIL_QUEUE.join()
    stop_redistribution_monitor()
    final_retry_count = 0
    max_final_retries = 3
    while not MULTI_PORT_FAILED_QUEUE.empty() and final_retry_count < max_final_retries:
        final_retry_count += 1
        print_colored(f"[🔄] Phase finale de redistribution #{final_retry_count}...", Colors.YELLOW)
        failed_emails_batch = []
        while not MULTI_PORT_FAILED_QUEUE.empty():
            try:
                failed_emails_batch.append(MULTI_PORT_FAILED_QUEUE.get_nowait())
            except queue.Empty:
                break
        if not failed_emails_batch:
            break
        print_colored(f"[🔄] Tentative finale de {len(failed_emails_batch)} emails échoués...", Colors.CYAN)
        for email, original_port, error_msg in failed_emails_batch:
            best_port = get_best_performing_port()
            if best_port and best_port != original_port:
                print_colored(f"[🔄] RETRY FINAL: {email} du port {original_port} → port {best_port}", Colors.YELLOW)
                if send_email_with_intelligent_port(best_port, email, subject, message, attachments, True):
                    with MULTI_PORT_LOCK:
                        MULTI_PORT_STATS['redistributed_emails'] += 1
                else:
                    for retry_port in active_ports:
                        if retry_port != best_port and retry_port != original_port:
                            print_colored(f"[🔄] RETRY ULTIME: {email} → port {retry_port}", Colors.YELLOW)
                            if send_email_with_intelligent_port(retry_port, email, subject, message, attachments, True):
                                with MULTI_PORT_LOCK:
                                    MULTI_PORT_STATS['redistributed_emails'] += 1
                                break
                            time.sleep(0.2)
        time.sleep(1)
    with MULTI_PORT_LOCK:
        total_success = sum(MULTI_PORT_STATS['emails_sent_per_port'].values())
        total_errors = sum(MULTI_PORT_STATS['errors_per_port'].values())
        final_failed = MULTI_PORT_FAILED_QUEUE.qsize()
    success_counter = total_success
    error_counter = final_failed
    email_counter = len(recipient_emails)
    elapsed_time = time.time() - start_time
    actual_rate = email_counter / elapsed_time if elapsed_time > 0 else 0
    redistribution_efficiency = (MULTI_PORT_STATS['redistributed_emails'] / max(1, total_errors)) * 100
    print_colored(f"\n[🏁] MODE MULTI-PORTS INTELLIGENT TERMINÉ", Colors.BOLD)
    print_colored(f"[📊] Temps total: {elapsed_time:.2f}s", Colors.CYAN)
    print_colored(f"[⚡] Vitesse réelle: {actual_rate:.2f} emails/seconde", Colors.MAGENTA)
    print_colored(f"[✅] Succès: {total_success}, Échecs finaux: {final_failed}", Colors.GREEN)
    print_colored(f"[🔄] Emails redistribués: {MULTI_PORT_STATS['redistributed_emails']}", Colors.YELLOW)
    print_colored(f"[📈] Efficacité redistribution: {redistribution_efficiency:.1f}%", Colors.MAGENTA)
    if final_failed == 0:
        print_colored(f"[🎉] OBJECTIF ATTEINT: ZÉRO ÉCHEC FINAL grâce à la redistribution !", Colors.BOLD)
    set_campaign_totals(total_success, final_failed)
    print_multi_port_stats()

def send_emails_multi_port_mode(recipient_emails, subject, message, attachments=None):
    """FONCTION MISE À JOUR: Mode multi-ports avec redistribution intelligente"""
    send_emails_multi_port_intelligent_mode(recipient_emails, subject, message, attachments)

def send_emails_multi_port_auth_mode(recipient_emails, subject, message, attachments=None):
    """Mode multi-ports avec authentification SMTP et redistribution intelligente"""
    global start_time, auth_email_counter, auth_success_counter, auth_error_counter
    start_time = time.time()
    auth_email_counter = 0
    auth_success_counter = 0
    auth_error_counter = 0
    if not MULTI_PORT_CONNECTIONS:
        print_colored("[❌] Aucune connexion multi-ports disponible pour le mode AUTH", Colors.RED)
        return
    if not VALID_SMTP_ACCOUNTS:
        print_colored("[❌] Aucun compte SMTP valide pour le mode AUTH", Colors.RED)
        return
    initialize_email_queues(recipient_emails)
    active_ports = list(MULTI_PORT_CONNECTIONS.keys())
    num_ports = len(active_ports)
    time_per_email = CONFIG.get('TIME_PER_EMAIL_SECONDS', 1.0)
    print_colored(f"\n[🚀] DÉMARRAGE MODE MULTI-PORTS AUTH INTELLIGENT V4.5", Colors.BOLD)
    print_colored(f"[⚡] {num_ports} ports actifs avec comptes SMTP", Colors.GREEN)
    print_colored(f"[📧] {len(recipient_emails)} emails en file d'attente AUTH", Colors.CYAN)
    print_colored(f"[🔐] {len(VALID_SMTP_ACCOUNTS)} comptes SMTP authentifiés", Colors.CYAN)
    start_redistribution_monitor()
    CONFIG['EMAIL_SUBJECT'] = subject
    CONFIG['_MESSAGE_CONTENT'] = message
    CONFIG['_ATTACHMENTS'] = attachments

    def auth_port_worker_thread(port_account_data):
        port, smtp_account = port_account_data
        worker_emails_processed = 0
        smtp_server_display = smtp_account.get('smtp_server', 'auto-détecté')
        print_colored(f"[🔐] Worker AUTH PORT-{port} démarré avec {smtp_account['email']} [{smtp_server_display}]", Colors.CYAN)
        original_socket = socket.socket
        try:
            port_config = MULTI_PORT_CONNECTIONS[port]
            socks.set_default_proxy(socks.SOCKS5, port_config['host'], port_config['port'])
            socket.socket = socks.socksocket
            smtp_connection = create_smtp_connection_auth_new(smtp_account)
            if not smtp_connection:
                print_colored(f"[❌] Impossible de créer la connexion AUTH pour port {port}", Colors.RED)
                return 0
            try:
                while True:
                    try:
                        email_data = MULTI_PORT_EMAIL_QUEUE.get(timeout=2)
                        if isinstance(email_data, tuple):
                            if len(email_data) == 3:
                                email, preferred_port, is_priority = email_data
                                if preferred_port != port and not is_priority:
                                    MULTI_PORT_EMAIL_QUEUE.put(email_data)
                                    continue
                                recipient_email = email
                                is_redistribution = is_priority
                            else:
                                recipient_email, _ = email_data
                                is_redistribution = True
                        else:
                            recipient_email = email_data
                            is_redistribution = False
                    except queue.Empty:
                        total_pending = MULTI_PORT_EMAIL_QUEUE.qsize() + MULTI_PORT_FAILED_QUEUE.qsize()
                        if total_pending == 0:
                            break
                        continue
                    start_send_time = time.time()
                    success = send_auth_email_with_intelligent_port(port, smtp_connection, smtp_account, 
                                                                  recipient_email, subject, message, 
                                                                  attachments, is_redistribution)
                    worker_emails_processed += 1
                    elapsed_send_time = time.time() - start_send_time
                    if elapsed_send_time < time_per_email:
                        time.sleep(time_per_email - elapsed_send_time)
                    MULTI_PORT_EMAIL_QUEUE.task_done()
            finally:
                try:
                    smtp_connection.quit()
                except:
                    try:
                        smtp_connection.close()
                    except:
                        pass
        finally:
            socket.socket = original_socket
        print_colored(f"[🏁] Worker AUTH PORT-{port} terminé: {worker_emails_processed} emails", Colors.GREEN)
        return worker_emails_processed

    port_account_pairs = []
    for i, port in enumerate(active_ports):
        smtp_account = VALID_SMTP_ACCOUNTS[i % len(VALID_SMTP_ACCOUNTS)]
        port_account_pairs.append((port, smtp_account))
        smtp_server_display = smtp_account.get('smtp_server', 'auto-détecté')
        print_colored(f"[📧] Port {port}: AUTH via {smtp_account['email']} [{smtp_server_display}]", Colors.CYAN)
    print_colored(f"[⚡] Démarrage simultané de {len(port_account_pairs)} workers AUTH...", Colors.BOLD)
    with ThreadPoolExecutor(max_workers=len(port_account_pairs)) as executor:
        futures = [executor.submit(auth_port_worker_thread, pair) for pair in port_account_pairs]
        MULTI_PORT_EMAIL_QUEUE.join()
        total_processed = 0
        for future in as_completed(futures):
            try:
                worker_result = future.result()
                total_processed += worker_result
            except Exception as e:
                print_colored(f"[❌] Erreur dans un worker AUTH: {e}", Colors.RED)
    stop_redistribution_monitor()
    final_retry_auth(active_ports, subject, message, attachments)
    with MULTI_PORT_LOCK:
        total_success = sum(MULTI_PORT_STATS['emails_sent_per_port'].values())
        final_failed = MULTI_PORT_FAILED_QUEUE.qsize()
    auth_success_counter = total_success
    auth_error_counter = final_failed
    auth_email_counter = len(recipient_emails)
    elapsed_time = time.time() - start_time
    actual_rate = auth_email_counter / elapsed_time if elapsed_time > 0 else 0
    print_colored(f"\n[🏁] MODE MULTI-PORTS AUTH INTELLIGENT TERMINÉ", Colors.BOLD)
    print_colored(f"[📊] Temps total: {elapsed_time:.2f}s", Colors.CYAN)
    print_colored(f"[⚡] Vitesse réelle AUTH: {actual_rate:.2f} emails/seconde", Colors.MAGENTA)
    print_colored(f"[✅] AUTH Succès: {total_success}, Échecs finaux: {final_failed}", Colors.GREEN)
    set_campaign_totals(total_success, final_failed)
    print_multi_port_stats()

def send_auth_email_with_intelligent_port(port, smtp_connection, smtp_account, recipient_email, subject, message, attachments, is_redistribution):
    """Envoie un email AUTH via un port spécifique avec gestion intelligente"""
    try:
        if not auth_campaign_lease_alive():
            return False
        personalized_message = replace_random_links_in_content(message)
        sender_email = smtp_account['email']
        sender_name = CONFIG.get('SENDER_NAME', '')
        token = generate_token()
        final_subject = build_final_subject(subject, token)
        msg = MIMEMultipart()
        msg['From'] = get_visible_from_header(sender_email)
        msg['To'] = recipient_email
        msg['Subject'] = final_subject
        msg['Date'] = formatdate(localtime=True)
        msg['Message-ID'] = generate_message_id_enhanced(sender_email.split('@')[1])
        msg = add_ultra_enhanced_anti_spam_headers(msg, sender_email, recipient_email, token)
        msg['X-Proxy-Port'] = str(port)
        if is_redistribution:
            msg['X-Redistribution'] = 'True'
        delivery_content = prepare_delivery_content(personalized_message)
        attach_delivery_content(msg, delivery_content)
        if attachments:
            attach_files(msg, attachments)
        smtp_connection.sendmail(sender_email, [recipient_email], finalize_email(msg, sender_email))
        mark_auth_smtp_success(smtp_account)
        with MULTI_PORT_LOCK:
            MULTI_PORT_STATS['emails_sent_per_port'][port] = MULTI_PORT_STATS['emails_sent_per_port'].get(port, 0) + 1
            MULTI_PORT_STATS['port_last_success'][port] = time.time()
            MULTI_PORT_CONNECTIONS[port]['consecutive_errors'] = 0
        timestamp = datetime.now().strftime("%H:%M:%S")
        redistrib_info = " [REDISTRIBUÉ]" if is_redistribution else ""
        print_colored(f"[{timestamp}] ✓ AUTH-PORT-{port}: {sender_email} → {recipient_email} [Ref-{token}] [HTML+LIENS]{redistrib_info}", Colors.GREEN)
        record_campaign_result(recipient_email, True)
        complete_coordinator_recipient(recipient_email, True)
        return True
    except Exception as e:
        if isinstance(e, (
            smtplib.SMTPAuthenticationError,
            smtplib.SMTPConnectError,
            smtplib.SMTPServerDisconnected,
            smtplib.SMTPHeloError,
            smtplib.SMTPNotSupportedError,
        )):
            mark_auth_smtp_failure(smtp_account)
        with MULTI_PORT_LOCK:
            MULTI_PORT_STATS['errors_per_port'][port] = MULTI_PORT_STATS['errors_per_port'].get(port, 0) + 1
            MULTI_PORT_CONNECTIONS[port]['consecutive_errors'] = MULTI_PORT_CONNECTIONS[port].get('consecutive_errors', 0) + 1
        timestamp = datetime.now().strftime("%H:%M:%S")
        print_colored(f"[{timestamp}] ❌ AUTH-PORT-{port}: {smtp_account['email']} → {recipient_email} - {e}", Colors.RED)
        MULTI_PORT_FAILED_QUEUE.put((recipient_email, port, str(e)))
        complete_coordinator_recipient(recipient_email, False)
        return False

def final_retry_auth(active_ports, subject, message, attachments):
    """Phase de retry finale pour le mode AUTH"""
    if MULTI_PORT_FAILED_QUEUE.empty():
        return
    print_colored(f"[🔄] Phase finale AUTH: Redistribution des derniers échecs...", Colors.YELLOW)
    retry_count = 0
    max_retries = 3
    while not MULTI_PORT_FAILED_QUEUE.empty() and retry_count < max_retries:
        retry_count += 1
        failed_batch = []
        while not MULTI_PORT_FAILED_QUEUE.empty():
            try:
                failed_batch.append(MULTI_PORT_FAILED_QUEUE.get_nowait())
            except queue.Empty:
                break
        if not failed_batch:
            break
        print_colored(f"[🔄] Retry AUTH #{retry_count}: {len(failed_batch)} emails", Colors.CYAN)
        for email, original_port, error_msg in failed_batch:
            for port in active_ports:
                if port != original_port:
                    smtp_account = VALID_SMTP_ACCOUNTS[hash(email) % len(VALID_SMTP_ACCOUNTS)]
                    original_socket = socket.socket
                    try:
                        port_config = MULTI_PORT_CONNECTIONS[port]
                        socks.set_default_proxy(socks.SOCKS5, port_config['host'], port_config['port'])
                        socket.socket = socks.socksocket
                        smtp_connection = create_smtp_connection_auth_new(smtp_account)
                        if smtp_connection:
                            try:
                                if send_auth_email_with_intelligent_port(port, smtp_connection, smtp_account, 
                                                                       email, subject, message, attachments, True):
                                    with MULTI_PORT_LOCK:
                                        MULTI_PORT_STATS['redistributed_emails'] += 1
                                    break
                            finally:
                                try:
                                    smtp_connection.quit()
                                except:
                                    pass
                    finally:
                        socket.socket = original_socket
                    time.sleep(0.2)

def close_multi_port_connections():
    """Ferme toutes les connexions multi-ports"""
    global MULTI_PORT_CONNECTIONS
    with MULTI_PORT_LOCK:
        if MULTI_PORT_CONNECTIONS:
            print_colored(f"[🔄] Fermeture de {len(MULTI_PORT_CONNECTIONS)} connexions multi-ports...", Colors.YELLOW)
            MULTI_PORT_CONNECTIONS.clear()
            MULTI_PORT_STATS['active_ports'] = 0
            print_colored(f"[✅] Connexions multi-ports fermées", Colors.GREEN)

# ===============================================
# FONCTIONS HEADERS ET IP POOLS
# ===============================================

def initialize_enhanced_ip_pools():
    """Initialise les pools d'IPs et autres données avec des informations ultra-réalistes"""
    global IP_POOLS, MAIL_SERVERS_POOL, USER_AGENTS_POOL
    global SPAM_ASSASSIN_VERSIONS, ANTIVIRUS_ENGINES, MTA_VERSIONS
    global CLOUDFLARE_IPS, GOOGLE_IPS, AMAZON_IPS, MICROSOFT_IPS, ENTERPRISE_DOMAINS

    CLOUDFLARE_IPS = [
        "104.16.0.0", "104.17.0.0", "104.18.0.0", "104.19.0.0", "104.20.0.0",
        "104.21.0.0", "104.22.0.0", "104.23.0.0", "104.24.0.0", "104.25.0.0",
        "172.64.0.0", "172.65.0.0", "172.66.0.0", "172.67.0.0", "172.68.0.0"
    ]
    GOOGLE_IPS = [
        "74.125.224.0", "74.125.225.0", "74.125.226.0", "74.125.227.0",
        "209.85.128.0", "209.85.129.0", "209.85.130.0", "209.85.131.0",
        "216.58.192.0", "216.58.193.0", "216.58.194.0", "216.58.195.0"
    ]
    AMAZON_IPS = [
        "52.0.0.0", "52.1.0.0", "52.2.0.0", "52.3.0.0", "52.4.0.0",
        "54.0.0.0", "54.1.0.0", "54.2.0.0", "54.3.0.0", "54.4.0.0"
    ]
    MICROSOFT_IPS = [
        "40.76.0.0", "40.77.0.0", "40.78.0.0", "40.79.0.0", "40.80.0.0",
        "52.96.0.0", "52.97.0.0", "52.98.0.0", "52.99.0.0", "52.100.0.0"
    ]

    IP_POOLS = []
    for base_ip in CLOUDFLARE_IPS[:10]:
        base = base_ip.rsplit('.', 2)[0]
        for _ in range(5):
            third = random.randint(1, 254)
            fourth = random.randint(1, 254)
            IP_POOLS.append(f"{base}.{third}.{fourth}")
    for base_ip in GOOGLE_IPS[:10]:
        base = base_ip.rsplit('.', 2)[0]
        for _ in range(5):
            third = random.randint(1, 254)
            fourth = random.randint(1, 254)
            IP_POOLS.append(f"{base}.{third}.{fourth}")
    for base_ip in AMAZON_IPS[:10]:
        base = base_ip.rsplit('.', 2)[0]
        for _ in range(5):
            third = random.randint(1, 254)
            fourth = random.randint(1, 254)
            IP_POOLS.append(f"{base}.{third}.{fourth}")
    for base_ip in MICROSOFT_IPS[:10]:
        base = base_ip.rsplit('.', 2)[0]
        for _ in range(5):
            third = random.randint(1, 254)
            fourth = random.randint(1, 254)
            IP_POOLS.append(f"{base}.{third}.{fourth}")

    MAIL_SERVERS_POOL = [
        'mail.protection.outlook.com', 'smtp-relay.gmail.com', 'mailfence.com',
        'mx1.mailgun.org', 'mx2.mailgun.org', 'aspmx.l.google.com',
        'aspmx2.googlemail.com', 'mx1.improvmx.com', 'mx2.improvmx.com',
        'mail.protonmail.ch', 'mx.yandex.net', 'mx.zoho.com'
    ]
    USER_AGENTS_POOL = [
        'Microsoft Outlook 16.0.15601.20148', 'Microsoft Outlook 15.0.5495.1000',
        'Mozilla Thunderbird 102.15.1', 'Mozilla Thunderbird 91.13.0',
        'Apple Mail (16.0)', 'Apple Mail (15.0)', 'Apple Mail (14.0)',
        'Gmail Web Client 2023.10.16', 'Outlook Web App 16.0.15601'
    ]
    SPAM_ASSASSIN_VERSIONS = ["3.4.6", "4.0.0", "4.0.1", "3.4.5"]
    ANTIVIRUS_ENGINES = ["ClamAV 0.105.1", "ClamAV 0.104.4", "ClamAV 0.103.9"]
    MTA_VERSIONS = ["Postfix 3.7.2", "Postfix 3.6.7", "Exim 4.96", "Exim 4.95", "Sendmail 8.17.1"]
    print_colored(f"[+] {len(IP_POOLS)} IPs ultra-réalistes initialisées", Colors.GREEN)

def get_random_ip():
    """Retourne une IP aléatoire du pool avec rotation"""
    global current_ip_index
    if not IP_POOLS:
        initialize_enhanced_ip_pools()
    ip = IP_POOLS[current_ip_index % len(IP_POOLS)]
    current_ip_index += 1
    return ip

def generate_random_hostname():
    """Génère un hostname aléatoire ultra-crédible"""
    prefixes = ['mx', 'mail', 'smtp', 'relay', 'gateway', 'server', 'host', 'node']
    suffixes = ['mailserver.com', 'relay.net', 'mx.org', 'gateway.net', 'mail.local', 'smtp.local']
    numbers = random.randint(1, 999)
    prefix = random.choice(prefixes)
    suffix = random.choice(suffixes)
    return f"{prefix}{numbers}.{suffix}"

# ===============================================
# FONCTIONS PORTÉES DEPUIS send.php
# ===============================================

def obfuxt(text):
    """
    Substitution homoglyphe Unicode - même table que send.php obfuxt()
    Remplace les lettres latines par des caractères Unicode visuellement identiques
    pour éviter la détection par signature de texte.
    """
    table = {
        'a': 'а',  # Cyrillique а
        'c': 'ϲ',  # Sigma grec lunaire
        'e': 'е',  # Cyrillique е
        'g': 'ɡ',  # Latin script g
        'h': 'һ',  # Cyrillique shha
        'i': 'і',  # Cyrillique і
        'j': 'ј',  # Cyrillique ј
        'k': 'κ',  # Grec kappa
        'o': 'о',  # Cyrillique о
        'p': 'р',  # Cyrillique р
        's': 'ѕ',  # Cyrillique dze
        'x': 'х',  # Cyrillique х
        'y': 'у',  # Cyrillique у
    }
    return ''.join(table.get(c, c) for c in text)

def obfuxt_partial(text):
    """Applique obfuxt sur une partie aléatoire des mots (évite les patterns trop uniformes)"""
    words = text.split(' ')
    result = []
    for word in words:
        if random.choice([True, False]):
            result.append(obfuxt(word))
        else:
            result.append(word)
    return ' '.join(result)

def encode_subject_base64(subject):
    """Encode le sujet en base64 UTF-8 - send.php bamessenctype=1"""
    encoded = base64.b64encode(subject.encode('utf-8')).decode('ascii')
    return f"=?UTF-8?B?{encoded}?="

def encode_subject_qp(subject):
    """Encode le sujet en Quoted-Printable UTF-8 - send.php bamessenctype=2"""
    encoded = quopri.encodestring(subject.encode('utf-8')).decode('ascii')
    encoded = encoded.replace(' ', '_').replace('\n', '').replace('\r', '').replace('=\r\n', '')
    return f"=?UTF-8?Q?{encoded}?="

def apply_subject_encoding(subject):
    """
    Applique l'encodage de sujet selon SUBJECT_ENCODING dans la config :
      0 = plain (défaut)
      1 = base64  =?UTF-8?B?...?=
      2 = quoted-printable  =?UTF-8?Q?...?=
    """
    mode = CONFIG.get('SUBJECT_ENCODING', 0)
    if mode == 1:
        return encode_subject_base64(subject)
    elif mode == 2:
        return encode_subject_qp(subject)
    return subject

def build_final_subject(base_subject, token):
    """
    Construit le sujet final avec token + obfuscation + encodage
    Centralise la logique de sujet pour tous les modes d'envoi.
    """
    final = base_subject
    if CONFIG.get('ADD_TOKEN_TO_SUBJECT', True):
        final = f"{base_subject} - {token}"
    if CONFIG.get('OBFUXT_SUBJECT', False):
        final = obfuxt_partial(final)
    return apply_subject_encoding(final)

def generate_x_received_header(sender_email, recipient_email):
    """
    Génère le header X-Received - identique à send.php configparts[28] ligne 1209 :
    'by {sendertld} id {random} for <{useremail}>; {date} (envelope-from <{senderemail}>)'
    """
    sender_domain = sender_email.split('@')[1]
    random_id = ''.join(random.choices(string.ascii_uppercase + string.digits, k=random.randint(20, 35)))
    timestamp = formatdate(localtime=True)
    return f"by {sender_domain} id {random_id} for <{recipient_email}>; {timestamp} (envelope-from <{sender_email}>)"

# --- DKIM réel (RSA-SHA256, relaxed/relaxed) ---

def _dkim_canonicalize_body(body):
    """Canonicalisation body DKIM relaxed : normalise CRLF, strip trailing spaces/lines"""
    body = body.replace('\r\n', '\n').replace('\r', '\n')
    lines = [line.rstrip() for line in body.split('\n')]
    while lines and lines[-1] == '':
        lines.pop()
    return '\r\n'.join(lines) + '\r\n'

def _dkim_canonicalize_header(name, value):
    """Canonicalisation header DKIM relaxed : nom en minuscule, espaces réduits"""
    name_c = name.strip().lower()
    value_c = re.sub(r'\s+', ' ', value.strip())
    return f"{name_c}:{value_c}\r\n"

def dkim_sign_email_string(email_str, sender_domain, selector='default', pkey_path='pkey.pem'):
    """
    Signe un email avec DKIM RSA-SHA256 relaxed/relaxed.
    Équivalent de send.php lignes 1341-1407 (openssl_sign + pkey.pem).
    Retourne la chaîne email avec le header DKIM-Signature préfixé.
    Si la clé n'existe pas ou qu'une erreur survient, retourne l'email non signé.
    """
    if not DKIM_SIGNING_AVAILABLE:
        return email_str
    if not os.path.exists(pkey_path):
        return email_str
    try:
        # Normaliser les fins de ligne
        email_str_norm = email_str.replace('\r\n', '\n')

        # Séparer headers et body
        if '\n\n' in email_str_norm:
            headers_raw, body_raw = email_str_norm.split('\n\n', 1)
        else:
            return email_str

        # Body hash (relaxed)
        canonical_body = _dkim_canonicalize_body(body_raw)
        bh = base64.b64encode(hashlib.sha256(canonical_body.encode('utf-8')).digest()).decode()

        # Parser les headers de l'email
        header_lines = headers_raw.split('\n')
        parsed_headers = {}  # name_lower -> (original_name, original_value)
        i = 0
        while i < len(header_lines):
            line = header_lines[i]
            if line and not line[0] in (' ', '\t') and ':' in line:
                name, _, value = line.partition(':')
                name_lower = name.strip().lower()
                # Récupérer les lignes de continuation
                j = i + 1
                while j < len(header_lines) and header_lines[j] and header_lines[j][0] in (' ', '\t'):
                    value += ' ' + header_lines[j].strip()
                    j += 1
                if name_lower not in parsed_headers:
                    parsed_headers[name_lower] = (name.strip(), value.strip())
            i += 1

        # Headers à inclure dans la signature (comme send.php $linesdkim)
        candidates = ['from', 'to', 'subject', 'date', 'message-id', 'mime-version',
                      'content-type', 'reply-to', 'sender']
        h_list = [h for h in candidates if h in parsed_headers]
        h_field = ':'.join(h_list)

        # DKIM-Signature sans b= (corps à signer)
        dkim_val = (
            f"v=1; a=rsa-sha256; c=relaxed/relaxed; "
            f"d={sender_domain}; s={selector}; "
            f"h={h_field}; bh={bh}; b="
        )

        # Canonicaliser les headers signés + DKIM-Signature
        canonical_headers = ''
        for h in h_list:
            orig_name, orig_value = parsed_headers[h]
            canonical_headers += _dkim_canonicalize_header(orig_name, orig_value)
        canonical_headers += _dkim_canonicalize_header('DKIM-Signature', dkim_val)
        canonical_headers = canonical_headers.rstrip('\r\n')

        # Charger la clé RSA - gère PKCS#1 brut (sans headers PEM) comme send.php
        with open(pkey_path, 'rb') as f:
            raw_key = f.read()
        key_str = raw_key.decode('ascii').strip()
        if not key_str.startswith('-----'):
            # Clé base64 brute (format send.php pkey.pem) → envelopper en PEM PKCS#1
            key_str = "-----BEGIN RSA PRIVATE KEY-----\n" + key_str + "\n-----END RSA PRIVATE KEY-----\n"
        private_key = serialization.load_pem_private_key(key_str.encode('ascii'), password=None)

        signature = private_key.sign(
            canonical_headers.encode('utf-8'),
            crypto_padding.PKCS1v15(),
            hashes.SHA256()
        )
        b_value = base64.b64encode(signature).decode()

        dkim_header = f"DKIM-Signature: {dkim_val}{b_value}"
        return dkim_header + '\r\n' + email_str

    except Exception as e:
        return email_str  # Fallback sans DKIM si erreur

def finalize_email(msg, sender_email):
    """
    Finalise l'email avant envoi :
    - Applique une signature DKIM locale seulement si elle a été explicitement
      activée. Dans la majorité des cas, le fournisseur SMTP signe déjà le
      message avec la clé publiée pour le domaine.
    Retourne la chaîne email prête pour server.sendmail()
    """
    attach_inline_assets(msg, getattr(msg, '_yoda_inline_assets', []))
    attach_inline_logo(msg)
    msg_str = msg.as_string()
    if CONFIG.get('DKIM_ENABLED', False) and CONFIG.get('DKIM_MANUAL_SIGNING', False):
        sender_domain = str(
            CONFIG.get('DKIM_SIGNING_DOMAIN', '')
            or sender_email.split('@')[1]
        ).strip()
        selector = CONFIG.get('DKIM_SELECTOR', 'default')
        pkey_path = CONFIG.get('DKIM_PRIVATE_KEY_FILE', 'pkey.pem')
        msg_str = dkim_sign_email_string(msg_str, sender_domain, selector, pkey_path)
    return msg_str


def attach_inline_assets(msg, assets):
    """Ajoute les images CID préparées pour un message SMTP puis libère leurs fichiers."""
    container = getattr(msg, '_yoda_inline_assets_container', msg)
    for asset in assets or []:
        path = str(asset.get('path') or '')
        content_id = str(asset.get('cid') or '').strip().strip('<>')
        if not path or not content_id or not os.path.isfile(path):
            continue
        try:
            content_type, encoding = mimetypes.guess_type(path)
            if not content_type or encoding or not content_type.startswith('image/'):
                raise ValueError('format d’image inline invalide')
            maintype, subtype = content_type.split('/', 1)
            with open(path, 'rb') as image_file:
                image_part = MIMEBase(maintype, subtype)
                image_part.set_payload(image_file.read())
            encoders.encode_base64(image_part)
            image_part.add_header('Content-ID', f'<{content_id}>')
            image_part.add_header(
                'Content-Disposition',
                f'inline; filename="{asset.get("filename") or os.path.basename(path)}"',
            )
            container.attach(image_part)
        except Exception as exc:
            raise LetterImageError(f"Impossible d'intégrer l'image CID : {exc}") from exc
        finally:
            try:
                os.unlink(path)
            except OSError:
                pass


def attach_inline_logo(msg):
    """Ajoute le logo configuré comme image CID affichée dans le HTML."""
    if not CONFIG.get('LOGO_CID_ENABLED', True):
        return
    logo_path = str(CONFIG.get('LOGO_FILE', '')).strip()
    if not logo_path or not os.path.isfile(logo_path):
        return

    cid_reference = 'cid:yoda-email-logo'
    html_uses_logo = any(
        part.get_content_type() == 'text/html'
        and cid_reference in part.get_payload(decode=True).decode(
            part.get_content_charset() or 'utf-8', errors='replace'
        )
        for part in msg.walk()
    )
    if not html_uses_logo:
        return

    if any(part.get('Content-ID') == '<yoda-email-logo>' for part in msg.walk()):
        return

    ctype, encoding = mimetypes.guess_type(logo_path)
    if not ctype or encoding or not ctype.startswith('image/'):
        print_colored(f"[-] Format de logo invalide : {logo_path}", Colors.RED)
        return

    maintype, subtype = ctype.split('/', 1)
    try:
        with open(logo_path, 'rb') as logo_file:
            logo_part = MIMEBase(maintype, subtype)
            logo_part.set_payload(logo_file.read())
        encoders.encode_base64(logo_part)
        logo_part.add_header('Content-ID', '<yoda-email-logo>')
        logo_part.add_header(
            'Content-Disposition',
            f'inline; filename="{os.path.basename(logo_path)}"',
        )
        container = getattr(msg, '_yoda_inline_assets_container', msg)
        container.attach(logo_part)
    except Exception as exc:
        print_colored(f"[-] Impossible d'intégrer le logo : {exc}", Colors.RED)

def generate_message_id_enhanced(domain):
    """Génère un Message-ID ultra-réaliste et unique"""
    timestamp = int(time.time())
    microseconds = int(time.time() * 1000000) % 1000000
    random_part = ''.join(random.choices(string.ascii_lowercase + string.digits, k=16))
    process_id = random.randint(1000, 99999)
    thread_id = random.randint(100, 999)
    formats = [
        f"<{timestamp}.{microseconds}.{random_part}.{process_id}@{domain}>",
        f"<{random_part}-{timestamp}-{process_id}-{thread_id}@{domain}>",
        f"<{timestamp}{random_part}{process_id}@mail.{domain}>",
        f"<MSG_{timestamp}_{random_part}_{process_id}@{domain}>",
        f"<{random_part}.{timestamp}.{process_id}.{thread_id}@mx.{domain}>",
        f"<E{process_id}U{thread_id}P{timestamp}R{random_part[:8]}@{domain}>"
    ]
    return random.choice(formats)

def generate_ultra_realistic_authentication_results(sender_domain, sender_ip):
    """
    Génère un header Authentication-Results cohérent avec l'état réel du message.
    - Si DKIM_ENABLED : toujours dkim=pass (cohérent avec le vrai DKIM-Signature présent)
    - Si DKIM désactivé : résultat aléatoire mais jamais dkim=fail avec dmarc=fail ensemble
    """
    auth_results = []

    # SPF : résultats positifs/neutres uniquement (pas de fail qui contredit la livraison)
    spf_results = [
        ('pass',     f'domain of {sender_domain} designates {sender_ip} as permitted sender'),
        ('pass',     f'{sender_domain}: {sender_ip} is authorized'),
        ('neutral',  f'{sender_domain}: {sender_ip} is neither permitted nor denied'),
        ('softfail', f'{sender_domain}: transitioning {sender_ip}'),
    ]
    spf_result, spf_reason = random.choice(spf_results)
    auth_results.append(f"spf={spf_result} ({spf_reason})")

    # DKIM : pass forcé si DKIM réel activé, sinon aléatoire sans "fail"
    dkim_enabled = CONFIG.get('DKIM_ENABLED', False) if 'CONFIG' in dir() else False
    selector = CONFIG.get('DKIM_SELECTOR', 'default') if 'CONFIG' in dir() else 'default'
    if dkim_enabled:
        # Cohérent avec le DKIM-Signature: réel dans l'email
        dkim_reasons = [
            ('pass', 'signature was verified',        '2048-bit key; rsa'),
            ('pass', 'Good signature from domain',    '2048-bit RSA key'),
        ]
        dkim_result, dkim_reason, key_info = random.choice(dkim_reasons)
    else:
        dkim_results = [
            ('pass',    'signature was verified',      '2048-bit key'),
            ('pass',    'Good signature from domain',  '1024-bit key'),
            ('neutral', 'message not signed',          'no key'),
        ]
        dkim_result, dkim_reason, key_info = random.choice(dkim_results)
    auth_results.append(
        f"dkim={dkim_result} ({dkim_reason}) header.d={sender_domain} header.s={selector}; {key_info}"
    )

    # DMARC : pass uniquement (fail serait incohérent si SPF/DKIM passent)
    dmarc_results = [
        ('pass', 'p=quarantine', 'alignment check passed'),
        ('pass', 'p=none',       'policy evaluation passed'),
    ]
    dmarc_result, policy, reason = random.choice(dmarc_results)
    auth_results.append(
        f"dmarc={dmarc_result} ({reason}) header.from={sender_domain} policy.dmarc={policy}"
    )

    auth_servers = [
        f"mx.{sender_domain}",
        f"mail-{random.choice(['relay', 'filter', 'scanner'])}.{sender_domain}",
        random.choice(MAIL_SERVERS_POOL),
    ]
    return f"{random.choice(auth_servers)}; " + "; ".join(auth_results)

def generate_ultra_realistic_received_header(sender_ip, sender_domain, recipient_domain):
    """
    Génère un header Received simulant un hop INTERNE au domaine expéditeur.

    Logique correcte de la chaîne Received :
      [Notre fake]  from <poste> by <relai-interne-du-domaine>   ← hop fictif avant internet
      [Ajouté réel] from <notre-IP-réelle> by <MX-destinataire>  ← ajouté par free.fr

    SERVER_RDNS ne doit PAS apparaître ici : c'est notre IP sortante, pas un relai intermédiaire.
    Le 'by' doit être un serveur SMTP interne du domaine expéditeur (smtp.ge.org, mail.ge.org…).
    """
    session_id = ''.join(random.choices(string.ascii_uppercase + string.digits, k=random.randint(12, 18)))
    queue_id   = ''.join(random.choices(string.ascii_uppercase + string.digits, k=random.randint(10, 15)))

    # Noms de postes clients internes crédibles
    desktop_prefixes = ['DESKTOP', 'LAPTOP', 'PC', 'WS', 'HOST', 'NODE']
    desktop_suffix   = ''.join(random.choices(string.ascii_uppercase + string.digits, k=random.randint(6, 10)))
    desktop_name     = f"{random.choice(desktop_prefixes)}-{desktop_suffix}"

    # IPs privées crédibles pour le réseau interne de l'expéditeur
    private_subnets = ['10.0.', '10.1.', '10.10.', '192.168.1.', '192.168.0.', '172.16.']
    internal_ip = random.choice(private_subnets) + f"{random.randint(2,254)}"

    # Relai SMTP interne du domaine expéditeur (jamais notre IP réelle)
    relay_names = ['smtp', 'mail', 'relay', 'mta', 'outbound', 'mx-out']
    by_server = f"{random.choice(relay_names)}.{sender_domain}"

    # MTA et protocoles
    mta_variants = [
        f"Postfix 3.{random.randint(6,8)}.{random.randint(0,4)}",
        f"Exim 4.{random.randint(94,97)}",
        f"Sendmail 8.17.{random.randint(1,3)}"
    ]
    mta      = random.choice(mta_variants)
    protocol = random.choice(['ESMTPS', 'ESMTP'])
    tls_ver  = random.choice(['TLSv1.3', 'TLSv1.2'])
    cipher   = random.choice([
        'TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384',
        'TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256',
    ])
    timestamp = formatdate(localtime=True)

    formats = [
        # Format classique Postfix/Exim : from poste (domaine [IP-privée]) by relai-interne
        f"from {desktop_name} ({sender_domain} [{internal_ip}])"
        f" by {by_server} ({mta}) with {protocol} id {queue_id}"
        f" for <{recipient_domain}>; {timestamp}",

        # Format avec TLS explicite
        f"from {desktop_name} ({sender_domain} [{internal_ip}])"
        f" by {by_server} with {protocol} (version={tls_ver}, cipher={cipher})"
        f" id {session_id} for <{recipient_domain}>; {timestamp}",

        # Format Sendmail-style
        f"from {sender_domain} ([{internal_ip}])"
        f" by {by_server} with {protocol} id {queue_id}-{session_id[:8]}"
        f" for <{recipient_domain}>; {timestamp}",
    ]
    return random.choice(formats)

def generate_ultra_realistic_spam_headers(sender_email, recipient_email, token):
    """Génère des headers anti-spam ultra-réalistes et détaillés"""
    headers = {}
    spam_scores = [
        f"No, score={random.uniform(-5.0, 0.9):.1f} required={random.uniform(5.0, 15.0):.1f} tests=BAYES_{random.randint(0, 99):02d},HTML_MESSAGE,RCVD_IN_DNSWL_LOW autolearn=ham version={random.choice(SPAM_ASSASSIN_VERSIONS)}",
        f"No, score={random.uniform(-2.0, 1.9):.1f} tagged_above=-999 required=5 tests=[BAYES_{random.randint(0, 99):02d}={random.uniform(-1.0, 1.0):.1f}, DKIM_SIGNED=0.1, DKIM_VALID=-0.1, HTML_MESSAGE=0.0, SPF_PASS=-0.001]"
    ]
    headers['X-Spam-Status'] = random.choice(spam_scores)
    # X-Spam-Level : 0 étoile si DKIM actif (score négatif attendu), sinon 0-1 max
    dkim_on = CONFIG.get('DKIM_ENABLED', False) if 'CONFIG' in dir() else False
    headers['X-Spam-Level'] = '' if dkim_on else ('*' * random.randint(0, 1))
    headers['X-Spam-Checker-Version'] = f"SpamAssassin {random.choice(SPAM_ASSASSIN_VERSIONS)} on {generate_random_hostname()}"
    return headers

def generate_ultra_realistic_security_headers(sender_email, recipient_email, sender_ip):
    """Génère des headers de sécurité ultra-réalistes"""
    headers = {}
    if random.choice([True, False, False]):
        antivirus = random.choice(ANTIVIRUS_ENGINES)
        scan_time = f"{random.uniform(0.1, 2.5):.3f}s"
        headers['X-Virus-Scanned'] = f"by {antivirus} on {generate_random_hostname()} ({scan_time})"
    scanner_info = [
        f"MailScanner on {generate_random_hostname()}",
        f"Symantec Email Security.cloud Protection Engine",
        f"Proofpoint on behalf of {generate_random_hostname()}"
    ]
    headers['X-Content-Filtered-By'] = random.choice(scanner_info)
    headers['X-Scanned-By'] = f"MIMEDefang {random.uniform(2.80, 2.85):.2f} on {generate_random_hostname()}"
    ip_formats = [
        f"[{sender_ip}]",
        f"{sender_ip}",
        f"[{sender_ip}] (Authenticated sender: {sender_email})"
    ]
    headers['X-Originating-IP'] = random.choice(ip_formats)
    return headers

def generate_enterprise_headers(sender_email, recipient_email, token):
    """Génère des headers d'entreprise ultra-réalistes"""
    headers = {}
    if random.choice([True, False]):
        exchange_versions = [
            "15.2.986.22", "15.1.2507.12", "15.0.1497.2", "16.0.15330.20"
        ]
        headers['X-MS-Exchange-MessageSentRepresentingType'] = "1"
        headers['X-MS-Exchange-Organization-MessageDirectionality'] = "Outbound"
        headers['X-MS-Has-Attach'] = random.choice(['yes', 'no'])
        headers['X-MS-Exchange-Organization-AuthSource'] = f"exchange.{sender_email.split('@')[1]}"
        headers['X-MS-Exchange-Organization-AuthAs'] = "Internal"
    if random.choice([True, False]):
        headers['X-Google-DKIM-Signature'] = f"v=1; a=rsa-sha256; c=relaxed/relaxed; d=1e100.net; s={random.randint(2020, 2024)}0101"
        headers['X-Gm-Message-State'] = ''.join(random.choices(string.ascii_letters + string.digits, k=50))
    return headers

def generate_ultra_enhanced_headers(sender_email, recipient_email, token):
    """
    Retourne uniquement des en-têtes déclaratifs et véridiques.

    Les en-têtes Received, Return-Path, Authentication-Results, X-Spam-* et
    X-Originating-IP sont générés et contrôlés par les serveurs d'envoi et de
    réception. Les fabriquer dans le message est un signal de falsification
    pour les fournisseurs de messagerie et peut nuire à la délivrabilité.

    Un en-tête List-Unsubscribe n'est ajouté que lorsqu'une destination réelle
    est configurée. Cette application ne fabrique jamais d'URL ni d'adresse de
    désinscription.
    """
    headers = {}
    reply_to = str(CONFIG.get('REPLY_TO', '')).strip()
    if '@' in reply_to:
        headers['Reply-To'] = reply_to

    unsubscribe_mailto = str(CONFIG.get('UNSUBSCRIBE_MAILTO', '')).strip()
    unsubscribe_url = str(CONFIG.get('UNSUBSCRIBE_URL', '')).strip()
    unsubscribe_destinations = []
    if '@' in unsubscribe_mailto:
        unsubscribe_destinations.append(f'<mailto:{unsubscribe_mailto}>')
    if unsubscribe_url.startswith(('https://', 'http://')):
        unsubscribe_destinations.append(f'<{unsubscribe_url}>')
    if unsubscribe_destinations:
        headers['List-Unsubscribe'] = ', '.join(unsubscribe_destinations)
        if unsubscribe_url.startswith(('https://', 'http://')):
            headers['List-Unsubscribe-Post'] = 'List-Unsubscribe=One-Click'
    return headers

def add_ultra_enhanced_anti_spam_headers(msg, sender_email, recipient_email, token):
    """
    Compatibilité avec les modes d'envoi existants : ajoute uniquement les
    en-têtes standards réellement configurés, dans un ordre déterministe.
    """
    enhanced_headers = generate_ultra_enhanced_headers(sender_email, recipient_email, token)
    for header_name, header_value in enhanced_headers.items():
        msg[header_name] = header_value
    if CONFIG.get('DEBUG_MODE', False):
        print_colored(f"[DEBUG] {len(enhanced_headers)} en-tête(s) de délivrabilité configuré(s)", Colors.MAGENTA)
    return msg

# ===============================================
# FONCTIONS SMTP AUTH
# ===============================================

def get_next_smtp_account_sequential():
    """Retourne le prochain compte SMTP en mode séquentiel avec VRAIE ROTATION"""
    global current_smtp_index, smtp_rotation_counter
    with SMTP_ROTATION_LOCK:
        if not VALID_SMTP_ACCOUNTS:
            return None
        account = VALID_SMTP_ACCOUNTS[current_smtp_index]
        print_colored(f"[🔄] ROTATION SÉQUENTIELLE: Sélection du compte {current_smtp_index + 1}/{len(VALID_SMTP_ACCOUNTS)}: {account['email']}", Colors.YELLOW)
        current_smtp_index = (current_smtp_index + 1) % len(VALID_SMTP_ACCOUNTS)
        smtp_rotation_counter += 1
        if current_smtp_index == 0 and smtp_rotation_counter > 0:
            print_colored(f"[🔄] CYCLE COMPLET: Retour au premier compte après {len(VALID_SMTP_ACCOUNTS)} rotations", Colors.MAGENTA)
        return account

def get_smtp_accounts_simultaneous(num_accounts):
    """Retourne un groupe de comptes SMTP pour le mode simultané avec VRAIE ROTATION"""
    global current_smtp_index, smtp_rotation_counter
    with SMTP_ROTATION_LOCK:
        if not VALID_SMTP_ACCOUNTS:
            return []
        accounts = []
        num_to_get = min(num_accounts, len(VALID_SMTP_ACCOUNTS))
        print_colored(f"[⚡] ROTATION SIMULTANÉE: Sélection de {num_to_get} comptes différents", Colors.YELLOW)
        for i in range(num_to_get):
            account_index = (current_smtp_index + i) % len(VALID_SMTP_ACCOUNTS)
            account = VALID_SMTP_ACCOUNTS[account_index]
            accounts.append(account)
            print_colored(f"    → Compte {i+1}: {account['email']} (position {account_index + 1}/{len(VALID_SMTP_ACCOUNTS)})", Colors.CYAN)
        current_smtp_index = (current_smtp_index + num_to_get) % len(VALID_SMTP_ACCOUNTS)
        smtp_rotation_counter += num_to_get
        return accounts

def get_fresh_smtp_connection(account, force_new=False):
    """Récupère une connexion SMTP avec réutilisation intelligente"""
    email = account['email']

    # Si FORCE_NEW_CONNECTION_PER_EMAIL=true : nouvelle connexion à chaque email, pas de cache
    if CONFIG.get('FORCE_NEW_CONNECTION_PER_EMAIL', False):
        with SMTP_LOCK:
            if email in SMTP_CONNECTIONS:
                try:
                    SMTP_CONNECTIONS[email].quit()
                except:
                    try:
                        SMTP_CONNECTIONS[email].close()
                    except:
                        pass
                del SMTP_CONNECTIONS[email]
                if email in SMTP_CONNECTION_USAGE:
                    del SMTP_CONNECTION_USAGE[email]
                CONNECTION_STATS['active_connections'] -= 1
        server = create_smtp_connection_auth_new(account)
        if server:
            print_colored(f"[🔌] Nouvelle connexion SMTP (mode 1-par-email) : {email}", Colors.CYAN)
        return server

    with SMTP_LOCK:
        if CONFIG.get('USE_BCC_MODE', False) and force_new and email in SMTP_CONNECTIONS:
            print_colored(f"[🔄] Fermeture forcée de la connexion existante pour {email} (BCC mode)", Colors.YELLOW)
            try:
                SMTP_CONNECTIONS[email].quit()
            except:
                try:
                    SMTP_CONNECTIONS[email].close()
                except:
                    pass
            del SMTP_CONNECTIONS[email]
            if email in SMTP_CONNECTION_USAGE:
                del SMTP_CONNECTION_USAGE[email]
            CONNECTION_STATS['active_connections'] -= 1
            CONNECTION_STATS['connections_rotated'] += 1
        if email in SMTP_CONNECTIONS:
            usage_count = SMTP_CONNECTION_USAGE.get(email, 0)
            connection_limit = MAX_CONNECTION_REUSE if CONFIG.get('USE_BCC_MODE', False) else MAX_CONNECTION_REUSE * 5
            if usage_count >= connection_limit:
                print_colored(f"[🔄] Connexion {email} atteint sa limite ({usage_count}/{connection_limit}), fermeture forcée", Colors.YELLOW)
                try:
                    SMTP_CONNECTIONS[email].quit()
                except:
                    try:
                        SMTP_CONNECTIONS[email].close()
                    except:
                        pass
                del SMTP_CONNECTIONS[email]
                del SMTP_CONNECTION_USAGE[email]
                CONNECTION_STATS['active_connections'] -= 1
                CONNECTION_STATS['connections_rotated'] += 1
            else:
                server = SMTP_CONNECTIONS[email]
                try:
                    server.noop()
                    SMTP_CONNECTION_USAGE[email] = usage_count + 1
                    CONNECTION_STATS['connections_reused'] += 1
                    if not CONFIG.get('USE_BCC_MODE', False):
                        print_colored(f"[♻️] Réutilisation connexion persistante : {email} (usage: {SMTP_CONNECTION_USAGE[email]}/{connection_limit})", Colors.GREEN)
                    else:
                        print_colored(f"[🔄] Réutilisation connexion SMTP : {email} (usage: {SMTP_CONNECTION_USAGE[email]}/{connection_limit})", Colors.GREEN)
                    return server
                except Exception as e:
                    print_colored(f"[⚠️] Connexion SMTP expirée pour {email}, recréation...", Colors.YELLOW)
                    del SMTP_CONNECTIONS[email]
                    if email in SMTP_CONNECTION_USAGE:
                        del SMTP_CONNECTION_USAGE[email]
                    CONNECTION_STATS['active_connections'] -= 1
    server = create_smtp_connection_auth_new(account)
    if server:
        with SMTP_LOCK:
            SMTP_CONNECTIONS[email] = server
            SMTP_CONNECTION_USAGE[email] = 1
            CONNECTION_STATS['total_connections_created'] += 1
            CONNECTION_STATS['active_connections'] += 1
            CONNECTION_STATS['connections_saved'] = CONNECTION_STATS['connections_reused']
        print_colored(f"[📡] Nouvelle connexion SMTP créée : {email} [{account.get('smtp_server', 'auto-détecté')}]", Colors.CYAN)
        if not CONFIG.get('USE_BCC_MODE', False):
            print_colored(f"[💾] MODE PERSISTANT: Cette connexion sera réutilisée pour plusieurs emails", Colors.MAGENTA)
    return server

def create_smtp_connection_auth_new(account):
    """Crée une nouvelle connexion SMTP authentifiée avec serveur spécifique"""
    email = account['email']
    password = account['password']
    smtp_server, smtp_port = _resolve_auth_smtp_endpoint(account)
    try:
        print_colored(f"[📡] Utilisation du serveur SMTP : {smtp_server}", Colors.CYAN)
        print_colored(f"[🔗] Connexion à {smtp_server}:{smtp_port} pour {email}", Colors.CYAN)
        server = open_smtp(smtp_server, smtp_port, timeout=60)
        if CONFIG.get('DEBUG_MODE', False):
            server.set_debuglevel(1)
        establish_tls(server, smtp_server, smtp_port, required=True)
        server.login(email, password)
        print_colored(f"[✅] Connexion SMTP authentifiée réussie : {email} via {smtp_server}", Colors.GREEN)
        return server
    except Exception as e:
        print_colored(f"[-] Erreur création connexion SMTP {email} via {smtp_server}: {e}", Colors.RED)
        return None

def close_all_smtp_connections():
    """Ferme toutes les connexions SMTP persistantes à la fin"""
    print_colored(f"[🔄] Fermeture de toutes les connexions SMTP persistantes...", Colors.YELLOW)
    with SMTP_LOCK:
        closed_count = 0
        for email, server in SMTP_CONNECTIONS.items():
            try:
                server.quit()
                closed_count += 1
                print_colored(f"[✓] Connexion fermée : {email}", Colors.GREEN)
            except Exception as e:
                print_colored(f"[⚠️] Erreur fermeture connexion {email}: {e}", Colors.YELLOW)
                try:
                    server.close()
                    closed_count += 1
                except:
                    pass
        SMTP_CONNECTIONS.clear()
        SMTP_CONNECTION_USAGE.clear()
        CONNECTION_STATS['active_connections'] = 0
        print_colored(f"[✅] {closed_count} connexions SMTP fermées", Colors.GREEN)

def get_normal_mode_smtp_connection(mail_server, server_port):
    """Récupère ou crée une connexion SMTP persistante pour le mode normal"""
    global NORMAL_MODE_CONNECTION, NORMAL_MODE_CONNECTION_TARGET
    requested_target = (str(mail_server).lower(), int(server_port))
    with NORMAL_MODE_CONNECTION_LOCK:
        if CONFIG.get('USE_BCC_MODE', False):
            return create_smtp_connection(mail_server, server_port)
        if NORMAL_MODE_CONNECTION:
            if NORMAL_MODE_CONNECTION_TARGET == requested_target:
                try:
                    NORMAL_MODE_CONNECTION.noop()
                    print_colored(f"[♻️] Réutilisation connexion persistante normale : {mail_server}:{server_port}", Colors.GREEN)
                    return NORMAL_MODE_CONNECTION
                except Exception:
                    print_colored(f"[⚠️] Connexion normale expirée, recréation...", Colors.YELLOW)
            else:
                print_colored(
                    f"[🔄] Changement de MX : {NORMAL_MODE_CONNECTION_TARGET} → {requested_target}",
                    Colors.CYAN,
                )
            try:
                NORMAL_MODE_CONNECTION.quit()
            except Exception:
                try:
                    NORMAL_MODE_CONNECTION.close()
                except Exception:
                    pass
            NORMAL_MODE_CONNECTION = None
            NORMAL_MODE_CONNECTION_TARGET = None
        print_colored(f"[📡] Création nouvelle connexion persistante : {mail_server}:{server_port}", Colors.CYAN)
        NORMAL_MODE_CONNECTION = create_smtp_connection(mail_server, server_port)
        if NORMAL_MODE_CONNECTION:
            NORMAL_MODE_CONNECTION_TARGET = requested_target
            print_colored(f"[💾] MODE PERSISTANT: Cette connexion sera réutilisée pour tous les emails", Colors.MAGENTA)
        return NORMAL_MODE_CONNECTION

def close_normal_mode_connection():
    """Ferme la connexion SMTP du mode normal"""
    global NORMAL_MODE_CONNECTION, NORMAL_MODE_CONNECTION_TARGET
    with NORMAL_MODE_CONNECTION_LOCK:
        if NORMAL_MODE_CONNECTION:
            try:
                NORMAL_MODE_CONNECTION.quit()
                print_colored(f"[✓] Connexion normale fermée", Colors.GREEN)
            except Exception as e:
                print_colored(f"[⚠️] Erreur fermeture connexion normale: {e}", Colors.YELLOW)
                try:
                    NORMAL_MODE_CONNECTION.close()
                except:
                    pass
            finally:
                NORMAL_MODE_CONNECTION = None
                NORMAL_MODE_CONNECTION_TARGET = None

def generate_characters_from_hashtags(text):
    """Génère des caractères aléatoires basés sur les hashtags dans le texte"""
    if not isinstance(text, str):
        return text
    result = ""
    i = 0
    while i < len(text):
        if text[i] == '#':
            hashtag_count = 0
            j = i
            while j < len(text) and text[j] == '#':
                hashtag_count += 1
                j += 1
            random_chars = ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(hashtag_count))
            result += random_chars
            i = j
        else:
            result += text[i]
            i += 1
    return result

def load_smtp_accounts():
    """Charge directement les comptes SMTP AUTH depuis le fichier configuré."""
    global SMTP_ACCOUNTS, AUTH_COORDINATOR
    try:
        AUTH_COORDINATOR = SecureCoordinator(PROJECT_DIR)
    except Exception as error:
        AUTH_COORDINATOR = None
        print_colored(
            f"[-] Coordinateur AUTH indisponible : {type(error).__name__}",
            Colors.RED,
        )
    load_legacy_smtp_accounts()
    # Le chargeur historique remet AUTH_COORDINATOR à None pour CHECKV2.
    # En campagne AUTH normale, on conserve le coordinateur de destinataires.
    if not CONFIG.get("_CHECKV2_ACTIVE", False) and AUTH_COORDINATOR is None:
        try:
            AUTH_COORDINATOR = SecureCoordinator(PROJECT_DIR)
        except Exception:
            pass
    print_colored(
        f"[+] {len(SMTP_ACCOUNTS)} comptes SMTP AUTH chargés depuis "
        f"{CONFIG.get('_SMTP_ACCOUNT_SOURCE', CONFIG.get('SMTP_ACCOUNTS_FILE', 'smtp.txt'))}",
        Colors.GREEN,
    )


def load_legacy_smtp_accounts():
    """Load CHECKV2's historical smtp.txt AUTH source.

    CHECKV2 validates candidates itself and intentionally retains its legacy
    SMTP transport.  Normal AUTH campaigns never call this loader.
    """
    global SMTP_ACCOUNTS, AUTH_COORDINATOR
    SMTP_ACCOUNTS = []
    AUTH_COORDINATOR = None
    configured_smtp_file = str(CONFIG.get("SMTP_ACCOUNTS_FILE") or "smtp.txt").strip()
    smtp_file = (
        configured_smtp_file
        if os.path.isabs(configured_smtp_file)
        else os.path.join(PROJECT_DIR, configured_smtp_file)
    )
    print_colored(
        f"[*] Lecture SMTP AUTH : {smtp_file}",
        Colors.CYAN,
    )
    try:
        file = open(smtp_file, "r", encoding="utf-8")
        CONFIG["_SMTP_ACCOUNT_SOURCE"] = configured_smtp_file
        with file:
            for raw in file:
                line = raw.strip()
                if not line or line.startswith("#"):
                    continue
                parts = line.split(":")
                if len(parts) < 2:
                    continue
                email = parts[0].strip()
                password = parts[1].strip()
                if "@" not in email or not password:
                    continue
                account = {
                    "email": email,
                    "password": password,
                    "smtp_server": None,
                    "raw": line,
                }
                if len(parts) >= 3:
                    if parts[-1].strip().isdigit() and len(parts) >= 4:
                        account["smtp_port"] = int(parts[-1].strip())
                        account["smtp_server"] = ":".join(parts[2:-1]).strip()
                    else:
                        account["smtp_server"] = ":".join(parts[2:]).strip()
                SMTP_ACCOUNTS.append(account)
        CONFIG["_COORDINATED_ACCOUNTS"] = False
    except OSError as error:
        CONFIG["_COORDINATED_ACCOUNTS"] = False
        print_colored(
            f"[-] Impossible de lire {smtp_file} : "
            f"{type(error).__name__} ({error})",
            Colors.RED,
        )


def refresh_validated_smtp_accounts() -> list[dict]:
    """Retourne le pool AUTH validé par connexion, sans dépendre de SMTP_CHECK."""
    return VALID_SMTP_ACCOUNTS


def _auth_smtp_state_path():
    return os.path.join(PROJECT_DIR, "auth_smtp_state.json")


def _resolve_auth_smtp_endpoint(account):
    """Retourne le serveur et le port réellement utilisés par le mode AUTH."""
    email = str(account.get("email") or "").strip()
    smtp_server = str(account.get("smtp_server") or "").strip()
    configured_port = account.get("smtp_port")
    if configured_port not in (None, ""):
        try:
            return smtp_server, int(configured_port)
        except (TypeError, ValueError):
            pass

    if smtp_server:
        lowered = smtp_server.lower()
        if any(provider in lowered for provider in (
            "gmail", "outlook", "office365", "yahoo", "alwaysdata"
        )):
            return smtp_server, 587
        return smtp_server, int(CONFIG.get("AUTH_SMTP_PORT", 587))

    configured_server = str(CONFIG.get("AUTH_SMTP_SERVER", "smtp-mail.outlook.com"))
    if configured_server == "AUTO":
        domain = email.rsplit("@", 1)[-1].lower()
        if any(provider in domain for provider in ("outlook", "hotmail", "live")):
            return "smtp-mail.outlook.com", 587
        if "gmail" in domain:
            return "smtp.gmail.com", 587
        if "yahoo" in domain:
            return "smtp.mail.yahoo.com", 587
        if "alwaysdata" in domain:
            return f"smtp-{email.split('@', 1)[0]}.alwaysdata.net", 587
    return configured_server, int(CONFIG.get("AUTH_SMTP_PORT", 587))


def _auth_smtp_account_key(account):
    server, port = _resolve_auth_smtp_endpoint(account)
    identity = "\0".join((
        str(account.get("email") or "").strip().lower(),
        str(account.get("password") or ""),
        str(server or "").strip().lower(),
        str(port),
    ))
    return hashlib.sha256(identity.encode("utf-8")).hexdigest()


def _read_auth_smtp_state():
    try:
        with open(_auth_smtp_state_path(), "r", encoding="utf-8") as state_file:
            data = json.load(state_file)
    except (OSError, ValueError, TypeError):
        data = {}
    accounts = data.get("accounts")
    return {
        "version": 1,
        "accounts": accounts if isinstance(accounts, dict) else {},
    }


def _write_auth_smtp_state(state):
    state_path = _auth_smtp_state_path()
    descriptor, temporary_path = tempfile.mkstemp(
        prefix=".auth-smtp-state-",
        suffix=".json",
        dir=os.path.dirname(state_path),
        text=True,
    )
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8") as output:
            json.dump(state, output, indent=2, ensure_ascii=False)
            output.flush()
            os.fsync(output.fileno())
        try:
            os.chmod(temporary_path, 0o600)
        except OSError:
            pass
        os.replace(temporary_path, state_path)
    except Exception:
        try:
            os.unlink(temporary_path)
        except OSError:
            pass
        raise


def _auth_smtp_state_record(account, failure_count=0):
    server, port = _resolve_auth_smtp_endpoint(account)
    return {
        "email": str(account.get("email") or "").strip(),
        "server": server,
        "port": port,
        "validated": True,
        "failure_count": max(0, int(failure_count)),
        "validated_at": datetime.now().isoformat(),
    }


def _remove_auth_smtp_account(account):
    """Retire atomiquement un compte défaillant du fichier SMTP configuré."""
    configured_file = str(CONFIG.get("SMTP_ACCOUNTS_FILE") or "smtp.txt").strip()
    smtp_path = (
        configured_file
        if os.path.isabs(configured_file)
        else os.path.join(PROJECT_DIR, configured_file)
    )
    target_raw = str(account.get("raw") or "").strip()
    try:
        with open(smtp_path, "r", encoding="utf-8") as source:
            original_lines = source.read().splitlines()
    except OSError as error:
        print_colored(
            f"[-] Impossible de retirer {account.get('email')} de {configured_file}: {error}",
            Colors.RED,
        )
        return False

    kept_lines = []
    removed = False
    for line in original_lines:
        if not removed and target_raw and line.strip() == target_raw:
            removed = True
            continue
        kept_lines.append(line)
    if not removed:
        return False

    descriptor, temporary_path = tempfile.mkstemp(
        prefix=".smtp-auth-list-",
        suffix=".txt",
        dir=os.path.dirname(smtp_path),
        text=True,
    )
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8") as output:
            output.write("\n".join(kept_lines))
            if kept_lines:
                output.write("\n")
            output.flush()
            os.fsync(output.fileno())
        os.replace(temporary_path, smtp_path)
    except Exception as error:
        try:
            os.unlink(temporary_path)
        except OSError:
            pass
        print_colored(
            f"[-] Impossible de mettre à jour {configured_file}: {error}",
            Colors.RED,
        )
        return False

    account_key = _auth_smtp_account_key(account)
    with SMTP_ROTATION_LOCK:
        SMTP_ACCOUNTS[:] = [
            item for item in SMTP_ACCOUNTS
            if _auth_smtp_account_key(item) != account_key
        ]
        VALID_SMTP_ACCOUNTS[:] = [
            item for item in VALID_SMTP_ACCOUNTS
            if _auth_smtp_account_key(item) != account_key
        ]
    print_colored(
        f"[🗑️] SMTP retiré après {AUTH_SMTP_FAILURE_LIMIT} échecs : "
        f"{account.get('email')}",
        Colors.RED,
    )
    return True


def mark_auth_smtp_success(account):
    """Réinitialise le compteur seulement après un précédent échec."""
    account_key = _auth_smtp_account_key(account)
    with AUTH_SMTP_STATE_LOCK:
        state = _read_auth_smtp_state()
        existing = state["accounts"].get(account_key)
        if existing and int(existing.get("failure_count", 0)) == 0:
            return
        state["accounts"][account_key] = _auth_smtp_state_record(account)
        _write_auth_smtp_state(state)


def mark_auth_smtp_failure(account):
    """Compte les échecs consécutifs et retire le SMTP au troisième."""
    account_key = _auth_smtp_account_key(account)
    with AUTH_SMTP_STATE_LOCK:
        state = _read_auth_smtp_state()
        existing = state["accounts"].get(account_key) or _auth_smtp_state_record(account)
        failure_count = int(existing.get("failure_count", 0)) + 1
        existing["failure_count"] = failure_count
        existing["last_failure_at"] = datetime.now().isoformat()
        state["accounts"][account_key] = existing
        _write_auth_smtp_state(state)

        print_colored(
            f"[⚠️] SMTP défaillant {account.get('email')} : "
            f"tentative {failure_count}/{AUTH_SMTP_FAILURE_LIMIT}",
            Colors.YELLOW,
        )
        if failure_count < AUTH_SMTP_FAILURE_LIMIT:
            return False
        if not _remove_auth_smtp_account(account):
            return False
        state["accounts"].pop(account_key, None)
        _write_auth_smtp_state(state)
        return True


def complete_coordinator_recipient(recipient: str, success: bool) -> None:
    if AUTH_COORDINATOR is not None and AUTH_CAMPAIGN_ID:
        if AUTH_LEASE_OWNER:
            AUTH_COORDINATOR.renew_campaign_lease(
                AUTH_CAMPAIGN_ID, AUTH_LEASE_OWNER
            )
        AUTH_COORDINATOR.complete_recipient(
            AUTH_CAMPAIGN_ID, recipient, bool(success)
        )


def auth_campaign_lease_alive() -> bool:
    if not AUTH_LEASE_OWNER:
        return True
    return bool(
        AUTH_COORDINATOR
        and AUTH_CAMPAIGN_ID
        and AUTH_COORDINATOR.renew_campaign_lease(
            AUTH_CAMPAIGN_ID, AUTH_LEASE_OWNER
        )
    )


def wait_for_dynamic_auth_accounts() -> bool:
    return bool(VALID_SMTP_ACCOUNTS)


def bind_auth_campaign_identity() -> bool:
    """Utilise une identité propre à la campagne AUTH courante."""
    global AUTH_CAMPAIGN_ID
    if AUTH_COORDINATOR is None:
        return False
    if not AUTH_CAMPAIGN_ID:
        AUTH_CAMPAIGN_ID = f"auth:{uuid.uuid4().hex}"
    return True

def validate_smtp_account(account):
    """Valide un compte SMTP en tentant une connexion avec le serveur spécifique"""
    email = account['email']
    password = account['password']
    smtp_server, smtp_port = _resolve_auth_smtp_endpoint(account)
    try:
        server = open_smtp(smtp_server, smtp_port, timeout=30)
        establish_tls(server, smtp_server, smtp_port, required=True)
        server.login(email, password)
        server.quit()
        print_colored(f"[✓] Compte SMTP validé : {email} via {smtp_server}", Colors.GREEN)
        return True
    except Exception as e:
        print_colored(f"[✗] Compte SMTP invalide : {email} via {smtp_server or 'auto-détecté'} - {e}", Colors.RED)
        return False

def validate_all_smtp_accounts():
    """Réutilise les validations persistées et ne teste que les nouveaux comptes."""
    global VALID_SMTP_ACCOUNTS
    VALID_SMTP_ACCOUNTS = []
    if not SMTP_ACCOUNTS:
        return

    with AUTH_SMTP_STATE_LOCK:
        state = _read_auth_smtp_state()
    current_keys = {_auth_smtp_account_key(account) for account in SMTP_ACCOUNTS}
    pending_accounts = []
    for account in SMTP_ACCOUNTS:
        account_key = _auth_smtp_account_key(account)
        account["account_key"] = account_key
        cached = state["accounts"].get(account_key)
        if cached and cached.get("validated"):
            VALID_SMTP_ACCOUNTS.append(account)
        else:
            pending_accounts.append(account)

    reused_count = len(VALID_SMTP_ACCOUNTS)
    if reused_count:
        print_colored(
            f"[♻️] {reused_count} compte(s) SMTP déjà validé(s), test ignoré.",
            Colors.GREEN,
        )
    if not pending_accounts:
        print_colored(
            f"[+] {reused_count} comptes SMTP prêts sur {len(SMTP_ACCOUNTS)}",
            Colors.GREEN,
        )
        return

    print_colored(
        f"[*] Validation de {len(pending_accounts)} nouveau(x) compte(s) SMTP...",
        Colors.YELLOW,
    )
    max_validation_threads = min(5, len(pending_accounts))
    with ThreadPoolExecutor(max_workers=max_validation_threads) as executor:
        future_to_account = {executor.submit(validate_smtp_account, account): account 
                           for account in pending_accounts}
        for future in as_completed(future_to_account):
            account = future_to_account[future]
            try:
                is_valid = future.result()
                if is_valid:
                    VALID_SMTP_ACCOUNTS.append(account)
                    with AUTH_SMTP_STATE_LOCK:
                        state = _read_auth_smtp_state()
                        state["accounts"][_auth_smtp_account_key(account)] = (
                            _auth_smtp_state_record(account)
                        )
                        _write_auth_smtp_state(state)
                else:
                    mark_auth_smtp_failure(account)
            except Exception as e:
                print_colored(f"[-] Erreur validation {account['email']}: {e}", Colors.RED)
                mark_auth_smtp_failure(account)
    with AUTH_SMTP_STATE_LOCK:
        state = _read_auth_smtp_state()
        state["accounts"] = {
            key: value for key, value in state["accounts"].items()
            if key in current_keys
        }
        _write_auth_smtp_state(state)
    print_colored(f"[+] {len(VALID_SMTP_ACCOUNTS)} comptes SMTP validés sur {len(SMTP_ACCOUNTS)}", Colors.GREEN)

def save_valid_smtp_accounts():
    """Sauvegarde les comptes SMTP valides dans le fichier"""
    try:
        configured_smtp_file = str(CONFIG.get('SMTP_ACCOUNTS_FILE', 'smtp.txt')).strip()
        smtp_file = (
            configured_smtp_file
            if os.path.isabs(configured_smtp_file)
            else os.path.join(PROJECT_DIR, configured_smtp_file)
        )
        backup_file = f"{smtp_file}.backup"
        if os.path.exists(smtp_file):
            os.rename(smtp_file, backup_file)
            print_colored(f"[+] Sauvegarde créée : {backup_file}", Colors.CYAN)
        with open(smtp_file, 'w', encoding='utf-8') as f:
            f.write("# Comptes SMTP valides (mis à jour automatiquement)\n")
            f.write("# Format: email:password:smtp_server\n")
            for account in VALID_SMTP_ACCOUNTS:
                smtp_server = account.get('smtp_server', '')
                if smtp_server:
                    f.write(f"{account['email']}:{account['password']}:{smtp_server}\n")
                else:
                    f.write(f"{account['email']}:{account['password']}\n")
        print_colored(f"[+] Fichier {smtp_file} mis à jour avec {len(VALID_SMTP_ACCOUNTS)} comptes valides", Colors.GREEN)
    except Exception as e:
        print_colored(f"[-] Erreur sauvegarde comptes SMTP: {e}", Colors.RED)

def send_email_with_auth(account, recipient_email, subject, message, attachments=None):
    """Envoie un email avec authentification SMTP en utilisant les connexions persistantes"""
    global auth_email_counter, auth_success_counter, auth_error_counter, REINFORCE_ERRORS

    sender_email = account['email']
    sender_name = CONFIG.get('SENDER_NAME', '')

    if not auth_campaign_lease_alive():
        print_colored(
            "[⏸️] Bail AUTH expiré : envoi annulé pour éviter un doublon.",
            Colors.YELLOW,
        )
        return False

    # Vérifier le statut du reinforce — jamais en mode AUTH SMTP
    if not CONFIG.get('USE_AUTH_MODE', False):
        control_data = read_control_file()
        if control_data.get("status") == "reinforce" and control_data.get("mode") == "reinforce":
            print_colored(f"[⏸️] Reinforce en cours, en attente...", Colors.YELLOW)
            wait_for_reinforce_complete()

    try:
        server = get_fresh_smtp_connection(account, force_new=False)
        if not server:
            mark_auth_smtp_failure(account)
            auth_error_counter += 1
            auth_email_counter += 1
            if not CONFIG.get('_CHECKV2_ACTIVE', False):
                record_campaign_result(recipient_email, False)
            complete_coordinator_recipient(recipient_email, False)
            return False
        personalized_message = replace_random_links_in_content(message)
        token = generate_token()
        final_subject = build_final_subject(subject, token)
        msg = MIMEMultipart()
        msg['From'] = get_visible_from_header(sender_email)
        msg['To'] = recipient_email
        msg['Subject'] = final_subject
        msg['Date'] = formatdate(localtime=True)
        msg['Message-ID'] = generate_message_id_enhanced(sender_email.split('@')[1])
        msg = add_ultra_enhanced_anti_spam_headers(msg, sender_email, recipient_email, token)
        delivery_content = prepare_delivery_content(personalized_message)
        attach_delivery_content(msg, delivery_content)
        if attachments:
            attach_files(msg, attachments)
        server.sendmail(sender_email, [recipient_email], finalize_email(msg, sender_email))
        mark_auth_smtp_success(account)
        auth_success_counter += 1
        auth_email_counter += 1
        timestamp = datetime.now().strftime("%H:%M:%S")
        smtp_server_info = f" [{account.get('smtp_server', 'auto')}]" if account.get('smtp_server') else ""
        if CONFIG.get('USE_BCC_MODE', False):
            print_colored(f"[{timestamp}] ✓ AUTH: {sender_email} → {recipient_email} [Ref-{token}] [HTML+LIENS]{smtp_server_info}", Colors.GREEN)
        elif CONFIG.get('FORCE_NEW_CONNECTION_PER_EMAIL', False):
            print_colored(f"[{timestamp}] ✓ AUTH 1-PAR-EMAIL: {sender_email} → {recipient_email} [Ref-{token}] [HTML+LIENS]{smtp_server_info}", Colors.GREEN)
        else:
            print_colored(f"[{timestamp}] ✓ AUTH PERSISTANT: {sender_email} → {recipient_email} [Ref-{token}] [HTML+LIENS]{smtp_server_info}", Colors.GREEN)
        update_control_file(error_count=REINFORCE_ERRORS)
        if not CONFIG.get('_CHECKV2_ACTIVE', False):
            record_campaign_result(recipient_email, True)
        complete_coordinator_recipient(recipient_email, True)
        return True
    except Exception as e:
        if isinstance(e, (
            smtplib.SMTPAuthenticationError,
            smtplib.SMTPConnectError,
            smtplib.SMTPServerDisconnected,
            smtplib.SMTPHeloError,
            smtplib.SMTPNotSupportedError,
            OSError,
        )):
            mark_auth_smtp_failure(account)
        auth_error_counter += 1
        auth_email_counter += 1
        REINFORCE_ERRORS += 1
        timestamp = datetime.now().strftime("%H:%M:%S")
        smtp_server_info = f" [{account.get('smtp_server', 'auto')}]" if account.get('smtp_server') else ""
        print_colored(f"[{timestamp}] ✗ AUTH: {sender_email} → {recipient_email} - {e}{smtp_server_info}", Colors.RED)
        max_errors = CONFIG.get('MAX_ERRORS_BEFORE_REINFORCE', 10)
        # Reinforce jamais en mode AUTH SMTP
        if REINFORCE_ERRORS >= max_errors and CONFIG.get('USE_IP_REINFORCE', False) and not CONFIG.get('USE_AUTH_MODE', False):
            print_colored(f"[{timestamp}] ⚠️ SEUIL D'ERREURS ATTEINT ({REINFORCE_ERRORS}/{max_errors})", Colors.RED)
            print_colored(f"[{timestamp}] 🔄 Déclenchement du reinforce...", Colors.MAGENTA)
            current_idx = 0
            if recipient_email in RECIPIENT_EMAILS:
                current_idx = RECIPIENT_EMAILS.index(recipient_email)
            trigger_reinforce_and_wait(
                recipient_email, current_idx, REINFORCE_ERRORS
            )
            REINFORCE_ERRORS = 0
        with SMTP_LOCK:
            if sender_email in SMTP_CONNECTIONS:
                try:
                    SMTP_CONNECTIONS[sender_email].quit()
                except:
                    try:
                        SMTP_CONNECTIONS[sender_email].close()
                    except:
                        pass
                del SMTP_CONNECTIONS[sender_email]
                if sender_email in SMTP_CONNECTION_USAGE:
                    del SMTP_CONNECTION_USAGE[sender_email]
                CONNECTION_STATS['active_connections'] -= 1
                CONNECTION_STATS['connections_rotated'] += 1
        save_failed_email(recipient_email)
        if not CONFIG.get('_CHECKV2_ACTIVE', False):
            record_campaign_result(recipient_email, False)
        complete_coordinator_recipient(recipient_email, False)
        return False

def send_bcc_email_with_auth(account, recipient_emails_batch, subject, message, attachments=None):
    """Envoie un email en BCC avec authentification SMTP"""
    global auth_email_counter, auth_success_counter, auth_error_counter, actual_emails_sent, REINFORCE_ERRORS

    sender_email = account['email']
    sender_name = CONFIG.get('SENDER_NAME', '')
    visible_to_email = CONFIG.get('BCC_TO_ADDRESS', 'keevcloud@gmail.com')
    visible_to_name = CONFIG.get('BCC_TO_NAME', 'Keev Cloud')

    try:
        if not auth_campaign_lease_alive():
            return False
        server = get_fresh_smtp_connection(account, force_new=False)
        if not server:
            mark_auth_smtp_failure(account)
            return False
        personalized_message = replace_random_links_in_content(message)
        token = generate_token()
        final_subject = build_final_subject(subject, token)
        msg = MIMEMultipart()
        msg['From'] = get_visible_from_header(sender_email)
        msg['To'] = formataddr((visible_to_name, visible_to_email))
        msg['Bcc'] = ', '.join(recipient_emails_batch)
        msg['Subject'] = final_subject
        msg['Date'] = formatdate(localtime=True)
        msg['Message-ID'] = generate_message_id_enhanced(sender_email.split('@')[1])
        msg = add_ultra_enhanced_anti_spam_headers(msg, sender_email, recipient_emails_batch[0], token)
        msg['X-BCC-Recipients'] = str(len(recipient_emails_batch))
        delivery_content = prepare_delivery_content(personalized_message)
        attach_delivery_content(msg, delivery_content)
        if attachments:
            attach_files(msg, attachments)
        all_recipients = [visible_to_email] + recipient_emails_batch
        server.sendmail(sender_email, all_recipients, finalize_email(msg, sender_email))
        mark_auth_smtp_success(account)
        actual_emails_sent += len(recipient_emails_batch)
        record_campaign_result(recipient_emails_batch[-1], True, len(recipient_emails_batch))
        timestamp = datetime.now().strftime("%H:%M:%S")
        bcc_list = ", ".join(recipient_emails_batch[:3]) + ("..." if len(recipient_emails_batch) > 3 else "")
        smtp_server_info = f" [{account.get('smtp_server', 'auto')}]" if account.get('smtp_server') else ""
        print_colored(f"[{timestamp}] ✓ AUTH BCC: {sender_email} → {visible_to_email} + {len(recipient_emails_batch)} BCC ({bcc_list}) [Ref-{token}] [HTML+LIENS]{smtp_server_info}", Colors.GREEN)
        return True
    except Exception as e:
        if isinstance(e, (
            smtplib.SMTPAuthenticationError,
            smtplib.SMTPConnectError,
            smtplib.SMTPServerDisconnected,
            smtplib.SMTPHeloError,
            smtplib.SMTPNotSupportedError,
            OSError,
        )):
            mark_auth_smtp_failure(account)
        timestamp = datetime.now().strftime("%H:%M:%S")
        smtp_server_info = f" [{account.get('smtp_server', 'auto')}]" if account.get('smtp_server') else ""
        print_colored(f"[{timestamp}] ✗ AUTH BCC: {sender_email} → {len(recipient_emails_batch)} destinataires - {e}{smtp_server_info}", Colors.RED)
        with SMTP_LOCK:
            if sender_email in SMTP_CONNECTIONS:
                try:
                    SMTP_CONNECTIONS[sender_email].quit()
                except:
                    try:
                        SMTP_CONNECTIONS[sender_email].close()
                    except:
                        pass
                del SMTP_CONNECTIONS[sender_email]
                if sender_email in SMTP_CONNECTION_USAGE:
                    del SMTP_CONNECTION_USAGE[sender_email]
                CONNECTION_STATS['active_connections'] -= 1
                CONNECTION_STATS['connections_rotated'] += 1
        for email in recipient_emails_batch:
            save_failed_email(email)
        record_campaign_result(recipient_emails_batch[-1], False, len(recipient_emails_batch))
        return False

def send_emails_with_resend(recipient_emails, subject, message, attachments=None):
    """Envoie une campagne via l'API Resend connectée à Replit."""
    global email_counter, success_counter, error_counter, REINFORCE_ERRORS, start_time

    resend_from_config = str(CONFIG.get('RESEND_FROM', '')).strip()
    resend_reply_to = str(CONFIG.get('RESEND_REPLY_TO', '')).strip()
    configured_name, resend_from = parseaddr(resend_from_config)
    if not resend_from:
        resend_from = resend_from_config
    if '@' not in resend_from:
        raise ResendError(
            "RESEND_FROM est obligatoire et doit être une adresse vérifiée dans Resend."
        )
    sender_name = str(CONFIG.get('SENDER_NAME', '')).strip() or configured_name
    formatted_sender_name = format_sender_name(sender_name, resend_from)
    resend_sender = formataddr((formatted_sender_name, resend_from))

    if CONFIG.get('USE_BCC_MODE', False):
        print_colored(
            "[ℹ️] Resend envoie un message distinct par destinataire ; le mode BCC SMTP est ignoré.",
            Colors.YELLOW,
        )

    email_counter = success_counter = error_counter = 0
    REINFORCE_ERRORS = 0
    start_time = time.time()
    retry_limit = max(1, int(CONFIG.get('MAX_RETRIES', 3)))
    retry_delay = float(CONFIG.get('RETRY_DELAY', 1))
    try:
        time_per_email = max(
            0.0,
            float(CONFIG.get('TIME_PER_EMAIL_SECONDS', 1.0)),
        )
    except (TypeError, ValueError) as exc:
        raise ResendError(
            "TIME_PER_EMAIL_SECONDS doit être un nombre supérieur ou égal à 0."
        ) from exc
    if not math.isfinite(time_per_email):
        raise ResendError(
            "TIME_PER_EMAIL_SECONDS doit être un nombre supérieur ou égal à 0."
        )

    print_colored("[+] 🚀 MODE RESEND API ACTIVÉ", Colors.GREEN)
    print_colored(f"[+] Expéditeur Resend : {resend_sender}", Colors.CYAN)
    print_colored(f"[+] {len(recipient_emails)} email(s) à envoyer", Colors.CYAN)
    print_colored(
        f"[+] Débit Resend piloté par TIME_PER_EMAIL_SECONDS : "
        f"{time_per_email:g} seconde(s) entre chaque email",
        Colors.CYAN,
    )

    def send_one_resend_email(index, recipient_email):
        global email_counter, success_counter, error_counter, REINFORCE_ERRORS

        if stop_requested_for(read_control_file(), "send"):
            return False

        for attempt in range(1, retry_limit + 1):
            try:
                token = generate_token()
                personalized_message = replace_random_links_in_content(message)
                final_subject = build_final_subject(subject, token)
                delivery_headers = generate_ultra_enhanced_headers(
                    resend_from,
                    recipient_email,
                    token,
                )
                header_reply_to = delivery_headers.pop('Reply-To', '')
                delivery_content = prepare_delivery_content(personalized_message)
                try:
                    result = send_resend_email(
                        sender=resend_sender,
                        recipients=[recipient_email],
                        subject=final_subject,
                        html_content=delivery_content['html'],
                        text_content=delivery_content.get('text') or None,
                        reply_to=resend_reply_to or header_reply_to,
                        headers=delivery_headers,
                        attachments=attachments,
                        inline_attachments=delivery_content['inline_assets'],
                    )
                finally:
                    cleanup_delivery_content(delivery_content)
                success_counter += 1
                email_counter += 1
                sent_total = success_counter
                error_total = error_counter
                record_campaign_result(recipient_email, True)
                update_control_file(error_count=0)
                resend_id = result.get('id', 'accepté')
                print_colored(
                    f"[{datetime.now().strftime('%H:%M:%S')}] ✓ RESEND: {resend_from} → "
                    f"{recipient_email} [id:{resend_id}]",
                    Colors.GREEN,
                )
                return True
            except ResendError as exc:
                if attempt == retry_limit or not getattr(exc, "retryable", True):
                    error_counter += 1
                    REINFORCE_ERRORS += 1
                    email_counter += 1
                    error_total = error_counter
                    error_count = REINFORCE_ERRORS
                    sent_total = success_counter
                    save_failed_email(recipient_email)
                    record_campaign_result(recipient_email, False)
                    update_control_file(error_count=error_count)
                    if getattr(exc, "retryable", True):
                        print_colored(
                            f"[✗] RESEND: {recipient_email} — {exc}",
                            Colors.RED,
                        )
                    else:
                        print_colored(
                            f"[✗] RESEND arrêt immédiat (erreur non réessayable) : "
                            f"{recipient_email} — {exc}",
                            Colors.RED,
                        )
                    return False
                print_colored(
                    f"[⚠️] RESEND tentative {attempt}/{retry_limit} échouée : {exc}",
                    Colors.YELLOW,
                )
                time.sleep(retry_delay)
        return False

    for index, recipient_email in enumerate(recipient_emails, 1):
        if stop_requested_for(read_control_file(), "send"):
            print_colored("[🛑] Envoi arrêté par l'utilisateur.", Colors.YELLOW)
            break
        send_started = time.monotonic()
        try:
            send_one_resend_email(index, recipient_email)
        except Exception as exc:
            error_counter += 1
            email_counter += 1
            save_failed_email(recipient_email)
            record_campaign_result(recipient_email, False)
            print_colored(
                f"[✗] Erreur inattendue Resend pour {recipient_email} : {exc}",
                Colors.RED,
            )
        elapsed = time.monotonic() - send_started
        if elapsed < time_per_email:
            time.sleep(time_per_email - elapsed)

    print_colored(
        f"[✅] Resend terminé : {success_counter} envoyé(s), {error_counter} erreur(s).",
        Colors.GREEN,
    )


def send_emails_with_sendbyte(recipient_emails, subject, message, attachments=None):
    """Envoie une campagne via l'API SendByte Africa."""
    global email_counter, success_counter, error_counter, REINFORCE_ERRORS, start_time

    if CONFIG.get('LETTER_TO_IMG', False):
        raise SendByteError(
            "LETTER_TO_IMG nécessite actuellement Resend ou un transport SMTP, "
            "car SendByte ne fournit pas de format CID inline documenté."
        )

    sendbyte_from = str(CONFIG.get('SENDBYTE_FROM', '')).strip()
    sendbyte_reply_to = str(CONFIG.get('SENDBYTE_REPLY_TO', '')).strip()
    if '@' not in sendbyte_from:
        raise SendByteError(
            "SENDBYTE_FROM est obligatoire et doit être une adresse vérifiée dans SendByte."
        )

    if CONFIG.get('USE_BCC_MODE', False):
        print_colored(
            "[ℹ️] SendByte envoie un message distinct par destinataire ; le mode BCC SMTP est ignoré.",
            Colors.YELLOW,
        )

    email_counter = success_counter = error_counter = 0
    REINFORCE_ERRORS = 0
    start_time = time.time()
    retry_limit = max(1, int(CONFIG.get('MAX_RETRIES', 3)))
    retry_delay = max(0.0, float(CONFIG.get('RETRY_DELAY', 1)))
    time_per_email = max(0.0, float(CONFIG.get('TIME_PER_EMAIL_SECONDS', 1.0)))
    campaign_id = hashlib.sha256(
        f"{time.time_ns()}:{os.urandom(16).hex()}".encode("utf-8")
    ).hexdigest()

    print_colored("[+] 🚀 MODE SENDBYTE API ACTIVÉ", Colors.GREEN)
    print_colored(f"[+] Expéditeur SendByte : {sendbyte_from}", Colors.CYAN)
    print_colored(f"[+] {len(recipient_emails)} email(s) à envoyer", Colors.CYAN)

    for index, recipient_email in enumerate(recipient_emails, 1):
        if stop_requested_for(read_control_file(), "send"):
            print_colored("[🛑] Envoi arrêté par l'utilisateur.", Colors.YELLOW)
            break

        send_started = time.time()
        sent = False
        # Les valeurs doivent être figées avant le retry. SendByte réutilise la
        # clé d'idempotence si une première requête a été acceptée mais que sa
        # réponse a été perdue.
        token = generate_token()
        personalized_message = replace_random_links_in_content(message)
        final_subject = build_final_subject(subject, token)
        delivery_headers = generate_ultra_enhanced_headers(
            sendbyte_from,
            recipient_email,
            token,
        )
        header_reply_to = delivery_headers.pop('Reply-To', '')
        idempotency_key = hashlib.sha256(
            f"yoda-sendbyte:{campaign_id}:{recipient_email.lower()}".encode("utf-8")
        ).hexdigest()
        for attempt in range(1, retry_limit + 1):
            try:
                result = send_sendbyte_email(
                    sender=sendbyte_from,
                    recipients=[recipient_email],
                    subject=final_subject,
                    html_content=personalized_message,
                    reply_to=sendbyte_reply_to or header_reply_to,
                    headers=delivery_headers,
                    attachments=attachments,
                    idempotency_key=idempotency_key,
                )
                success_counter += 1
                email_counter += 1
                record_campaign_result(recipient_email, True)
                update_control_file(error_count=0)
                sendbyte_id = result.get('id', 'accepté')
                sandbox_suffix = " [sandbox]" if result.get("sandbox") else ""
                print_colored(
                    f"[{datetime.now().strftime('%H:%M:%S')}] ✓ SENDBYTE: {sendbyte_from} → "
                    f"{recipient_email} [id:{sendbyte_id}]{sandbox_suffix}",
                    Colors.GREEN,
                )
                sent = True
                break
            except SendByteError as exc:
                if attempt == retry_limit:
                    error_counter += 1
                    REINFORCE_ERRORS += 1
                    email_counter += 1
                    save_failed_email(recipient_email)
                    record_campaign_result(recipient_email, False)
                    update_control_file(error_count=REINFORCE_ERRORS)
                    print_colored(
                        f"[✗] SENDBYTE: {recipient_email} — {exc}",
                        Colors.RED,
                    )
                else:
                    wait_time = max(retry_delay, exc.retry_after or 0.0)
                    print_colored(
                        f"[⚠️] SENDBYTE tentative {attempt}/{retry_limit} échouée : {exc}",
                        Colors.YELLOW,
                    )
                    time.sleep(wait_time)

        elapsed = time.time() - send_started
        if sent and elapsed < time_per_email:
            time.sleep(time_per_email - elapsed)

    print_colored(
        f"[✅] SendByte terminé : {success_counter} envoyé(s), {error_counter} erreur(s).",
        Colors.GREEN,
    )


def send_emails_with_auth_mode(recipient_emails, subject, message, attachments=None):
    """Envoie les emails en mode authentification avec connexions intelligentes"""
    global auth_email_counter, auth_success_counter, auth_error_counter, start_time, actual_emails_sent
    global current_smtp_index, smtp_rotation_counter, REINFORCE_ERRORS

    source_recipient_count = len(recipient_emails)
    auth_email_counter = 0
    auth_success_counter = 0
    auth_error_counter = 0
    actual_emails_sent = 0
    start_time = time.time()
    REINFORCE_ERRORS = 0

    # Claim each recipient once in SQLite before any worker or mode-specific
    # dispatcher starts.  This is deliberately done before BCC, simultaneous,
    # and multi-port fan-out so no mode can process the same recipient twice.
    if AUTH_COORDINATOR is None:
        print_colored("[-] Coordinateur AUTH indisponible : campagne bloquée", Colors.RED)
        return
    global AUTH_CAMPAIGN_ID
    if not wait_for_dynamic_auth_accounts():
        return
    if not bind_auth_campaign_identity():
        print_colored(
            "[-] Bail AUTH expiré ou réservé par un autre processus.",
            Colors.RED,
        )
        return
    unique_recipients = []
    seen = set()
    claim_account = VALID_SMTP_ACCOUNTS[0].get("account_key", "validated-pool")
    for recipient in recipient_emails:
        normalized = str(recipient).strip().lower()
        if not normalized or normalized in seen:
            continue
        seen.add(normalized)
        if AUTH_COORDINATOR.claim_recipient(
            AUTH_CAMPAIGN_ID, str(recipient).strip(), claim_account
        ):
            unique_recipients.append(str(recipient).strip())
    recipient_emails = unique_recipients
    print_colored(
        f"[🔒] Coordinateur AUTH : {len(recipient_emails)} destinataires uniques réclamés",
        Colors.CYAN,
    )
    if not recipient_emails:
        print_colored("[-] Aucun destinataire non traité dans cette campagne", Colors.YELLOW)
        return
    refresh_validated_smtp_accounts()

    if source_recipient_count == 1:
        recipient = recipient_emails[0]
        smtp_accounts = list(VALID_SMTP_ACCOUNTS)
        if not smtp_accounts:
            print_colored("[-] Aucun compte SMTP AUTH valide.", Colors.YELLOW)
            return
        update_control_file(total_recipients=len(smtp_accounts))
        print_colored(
            f"[📨] Liste unique : chaque SMTP envoie 1 mail à {recipient} "
            f"({len(smtp_accounts)} envois prévus)",
            Colors.BOLD,
        )

        def send_once(account):
            return send_email_with_auth(
                account, recipient, subject, message, attachments
            )

        if CONFIG.get('USE_SEQUENTIAL_MODE', True):
            for index, account in enumerate(smtp_accounts):
                send_once(account)
                if index < len(smtp_accounts) - 1:
                    delay = max(
                        0.0,
                        float(CONFIG.get('TIME_PER_EMAIL_SECONDS', 1.0)),
                    )
                    if delay:
                        time.sleep(delay)
        else:
            try:
                worker_cap = max(
                    1, int(CONFIG.get('MAX_SIMULTANEOUS_SMTP', 3))
                )
            except (TypeError, ValueError):
                worker_cap = 1
            with ThreadPoolExecutor(
                max_workers=min(worker_cap, len(smtp_accounts))
            ) as executor:
                futures = [
                    executor.submit(send_once, account)
                    for account in smtp_accounts
                ]
                for future in as_completed(futures):
                    try:
                        future.result()
                    except Exception as exc:
                        print_colored(
                            f"[-] Erreur worker SMTP unique : {exc}",
                            Colors.RED,
                        )
        close_all_smtp_connections()
        print_colored(
            f"[✅] Liste unique terminée : {len(smtp_accounts)} SMTP traités",
            Colors.GREEN,
        )
        return

    if CONFIG.get('USE_MULTI_PORT_MODE', False):
        if not VALID_SMTP_ACCOUNTS:
            print_colored("[-] Aucun compte SMTP AUTH valide.", Colors.YELLOW)
            return
        print_colored(f"[🚀] MODE MULTI-PORTS AUTH INTELLIGENT SÉLECTIONNÉ", Colors.BOLD)
        send_emails_multi_port_auth_mode(recipient_emails, subject, message, attachments)
        return

    use_sequential_mode = CONFIG.get('USE_SEQUENTIAL_MODE', True)
    max_simultaneous_smtp = CONFIG.get('MAX_SIMULTANEOUS_SMTP', 3)
    use_bcc_mode = CONFIG.get('USE_BCC_MODE', False)

    current_smtp_index = 0
    smtp_rotation_counter = 0

    print_colored(f"[+] 🚀 MODE AUTH V4.5 - CONNEXIONS INTELLIGENTES + LIENS ALÉATOIRES", Colors.GREEN)
    print_colored(f"[+] 🔄 Rotation des comptes SMTP avec réutilisation optimale", Colors.MAGENTA)
    print_colored(f"[+] 🎨 HTML préservé sans modification", Colors.BOLD)
    print_colored(f"[+] 🔗 NOUVEAU: Liens aléatoires différents pour chaque email", Colors.BOLD)

    if use_bcc_mode:
        if not VALID_SMTP_ACCOUNTS:
            print_colored(
                "[-] BCC AUTH impossible : aucun compte valide chargé depuis smtp.txt.",
                Colors.RED,
            )
            return
        print_colored(f"[+] 🚫 MODE BCC: Connexions avec rotation normale", Colors.YELLOW)
        print_colored(f"[+] 📊 DIVISION AUTOMATIQUE DE LA LISTE PAR SMTP", Colors.BOLD)
        send_emails_with_divided_smtp_bcc_mode(recipient_emails, subject, message, attachments)
        return
    else:
        print_colored(f"[+] 💾 MODE PERSISTANT: Connexions réutilisées massivement", Colors.MAGENTA)

    print_colored(f"[+] 🛡️ PROTECTION ANTI-SPAM MAXIMALE avec headers ultra-réalistes", Colors.MAGENTA)
    print_colored(f"[+] 📧 FORMAT SMTP: email:password:smtp_server", Colors.MAGENTA)

    if use_sequential_mode:
        print_colored(f"[+] 🔄 MODE SÉQUENTIEL ACTIVÉ - Rotation intelligente", Colors.GREEN)
        print_colored(f"[+] {len(VALID_SMTP_ACCOUNTS)} comptes SMTP en rotation", Colors.CYAN)
        print_colored(f"[+] Mode individuel persistant: Réutilisation maximale des connexions", Colors.MAGENTA)
        send_emails_sequential_individual_mode(recipient_emails, subject, message, attachments)
    else:
        print_colored(f"[+] ⚡ MODE SIMULTANÉ ACTIVÉ - {max_simultaneous_smtp} SMTP en parallèle", Colors.GREEN)
        print_colored(f"[+] {len(VALID_SMTP_ACCOUNTS)} comptes SMTP disponibles", Colors.CYAN)
        print_colored(f"[+] Mode individuel simultané persistant: {max_simultaneous_smtp} comptes SMTP en parallèle", Colors.MAGENTA)
        send_emails_simultaneous_individual_mode(recipient_emails, subject, message, attachments, max_simultaneous_smtp)

    print_colored(f"[✅] Envoi terminé avec mode AUTH V4.5 + CONNEXIONS INTELLIGENTES + LIENS ALÉATOIRES", Colors.GREEN)

def _check_and_send_test_mail(counter):
    """Envoie un mail de test via le même transport que la campagne."""
    if not CONFIG.get('TEST_MAIL_ENABLED', False):
        return
    test_addr = CONFIG.get('TEST_MAIL_ADDRESS', '').strip()
    if not test_addr:
        return
    try:
        from email.mime.text import MIMEText as _MIMEText
        from email.mime.multipart import MIMEMultipart as _MIMEMultipart

        msg = _MIMEMultipart('alternative')
        msg['Subject'] = f'[TEST #{counter}] YODA MAILER — inbox check'
        msg['X-Mailer'] = 'YODA MAILER V4.5'

        if CONFIG.get('USE_SENDBYTE_API', False):
            from_addr = str(CONFIG.get('SENDBYTE_FROM', '')).strip()
            if '@' not in from_addr:
                raise ValueError('SENDBYTE_FROM invalide')
            html = f"<p>Mail de test #{counter} reçu — transport SendByte API.</p>"
            result = send_sendbyte_email(
                sender=from_addr,
                recipients=[test_addr],
                subject=msg['Subject'],
                html_content=html,
                text_content=f"Mail de test #{counter} reçu via SendByte API.",
                reply_to=str(CONFIG.get('SENDBYTE_REPLY_TO', '')).strip() or None,
            )
            print_colored(
                f"[📬] MAIL TEST #{counter} envoyé à {test_addr} via SendByte "
                f"(id: {result.get('id', 'accepté')})",
                Colors.GREEN,
            )
            return

        if CONFIG.get('USE_RESEND_API', False):
            configured_from = str(CONFIG.get('RESEND_FROM', '')).strip()
            configured_name, from_addr = parseaddr(configured_from)
            if '@' not in from_addr:
                raise ValueError('RESEND_FROM invalide')
            display_from = formataddr((
                str(CONFIG.get('SENDER_NAME', '')).strip()
                or configured_name
                or 'YODA Mailer',
                from_addr,
            ))
            html = f"<p>Mail de test #{counter} reçu — transport Resend API.</p>"
            result = send_resend_email(
                sender=display_from,
                recipients=[test_addr],
                subject=msg['Subject'],
                html_content=html,
                text_content=f"Mail de test #{counter} reçu via Resend API.",
                reply_to=str(CONFIG.get('RESEND_REPLY_TO', '')).strip() or None,
            )
            print_colored(
                f"[📬] MAIL TEST #{counter} envoyé à {test_addr} via Resend "
                f"(id: {result.get('id', 'accepté')})",
                Colors.GREEN,
            )
            return

        if CONFIG.get('USE_AUTH_MODE', False):
            if not VALID_SMTP_ACCOUNTS:
                raise RuntimeError('aucun compte SMTP AUTH disponible dans smtp.txt')
            acc = VALID_SMTP_ACCOUNTS[0]
            smtp_host = acc.get('smtp_server') or CONFIG.get('AUTH_SMTP_SERVER', 'AUTO')
            smtp_port = int(acc.get('smtp_port') or CONFIG.get('AUTH_SMTP_PORT', 587))
            from_addr = acc['email']
            msg['From'] = from_addr
            msg['To']   = test_addr
            html = f"<p>Mail de test #{counter} reçu ✅ — SMTP: {smtp_host}:{smtp_port} — Expéditeur: {from_addr}</p>"
            msg.attach(_MIMEText(html, 'html', 'utf-8'))
            if smtp_port == 465:
                import ssl as _ssl
                srv = open_smtp(smtp_host, smtp_port, timeout=20, ssl_context=_ssl.create_default_context())
            else:
                srv = open_smtp(smtp_host, smtp_port, timeout=20)
                establish_tls(
                    srv,
                    smtp_host,
                    smtp_port,
                    required=CONFIG.get('SMTP_REQUIRE_TLS', True),
                )
            srv.login(acc['email'], acc['password'])
        else:
            smtp_host = CONFIG.get('SMTP_SERVER', '')
            smtp_port = int(CONFIG.get('SMTP_PORT', 25))
            from_addr = f"{CONFIG.get('EMAIL_USERNAME','test')}@{CONFIG.get('SENDER_DOMAIN','test.com')}"
            msg['From'] = from_addr
            msg['To']   = test_addr
            html = f"<p>Mail de test #{counter} ✅ — SMTP: {smtp_host}:{smtp_port}</p>"
            msg.attach(_MIMEText(html, 'html', 'utf-8'))
            srv = open_smtp(smtp_host, smtp_port, timeout=20)

        srv.sendmail(from_addr, [test_addr], msg.as_string())
        srv.quit()
        print_colored(f"[📬] MAIL TEST #{counter} envoyé à {test_addr} via {smtp_host}:{smtp_port}", Colors.GREEN)
    except Exception as _e:
        print_colored(
            f"[⚠️] Erreur mail test #{counter}: "
            f"{type(_e).__name__}: {_e}",
            Colors.YELLOW,
        )


def _record_test_mail_success(count=1):
    """Déclenche les tests périodiques sur un compteur de succès thread-safe."""
    global TEST_MAIL_SUCCESS_COUNT
    if not CONFIG.get('TEST_MAIL_ENABLED', False):
        return
    with TEST_MAIL_LOCK:
        previous = TEST_MAIL_SUCCESS_COUNT
        TEST_MAIL_SUCCESS_COUNT += max(0, int(count))
        current = TEST_MAIL_SUCCESS_COUNT
        try:
            every_n = max(1, int(CONFIG.get('TEST_MAIL_EVERY', 50)))
        except (TypeError, ValueError):
            every_n = 50
        due = current // every_n > previous // every_n
    if due:
        _check_and_send_test_mail(current)


def send_emails_sequential_individual_mode(recipient_emails, subject, message, attachments=None):
    """Mode séquentiel individuel avec connexions persistantes"""
    global REINFORCE_ERRORS
    print_colored(f"[💾] DÉMARRAGE MODE SÉQUENTIEL PERSISTANT + LIENS ALÉATOIRES", Colors.MAGENTA)
    print_colored(f"[*] {len(recipient_emails)} emails à envoyer avec connexions réutilisées", Colors.CYAN)

    for i, recipient_email in enumerate(recipient_emails, 1):
        if not wait_for_dynamic_auth_accounts():
            complete_coordinator_recipient(recipient_email, False)
            continue
        refresh_validated_smtp_accounts()
        account = get_next_smtp_account_sequential()
        if not account:
            print_colored(f"[-] Aucun compte SMTP disponible pour {recipient_email}", Colors.RED)
            record_campaign_result(recipient_email, False)
            continue
        smtp_server_display = account.get('smtp_server', 'auto-détecté')
        rotation_info = f"(rotation {smtp_rotation_counter}, cycle {(smtp_rotation_counter-1)//len(VALID_SMTP_ACCOUNTS)+1})"
        print_colored(f"[📧] {i}/{len(recipient_emails)}: {recipient_email} → {account['email']} via {smtp_server_display} {rotation_info}", Colors.CYAN)
        success = send_email_with_auth(account, recipient_email, subject, message, attachments)
        complete_coordinator_recipient(recipient_email, success)
        if success:
            conn_mode = "1-par-email" if CONFIG.get('FORCE_NEW_CONNECTION_PER_EMAIL', False) else "connexion persistante"
            print_colored(f"[✓] Email {i} envoyé avec succès ({conn_mode} + liens aléatoires)", Colors.GREEN)
        else:
            print_colored(f"[✗] Échec envoi email {i}", Colors.RED)
        if i < len(recipient_emails):
            time.sleep(CONFIG.get('TIME_PER_EMAIL_SECONDS', 1.0))
        if i % 50 == 0:
            print_statistics_auth()
    print_colored(f"[✅] MODE SÉQUENTIEL PERSISTANT + LIENS ALÉATOIRES TERMINÉ", Colors.GREEN)

def send_emails_simultaneous_individual_mode(recipient_emails, subject, message, attachments, max_simultaneous_smtp):
    """Mode simultané avec une file partagée et des workers persistants.

    Les destinataires ne sont jamais pré-affectés à une vague ou à un compte.
    Cela permet aux workers encore sains de vider la file lorsqu'un compte est
    retiré après son seuil d'échecs.
    """
    print_colored(f"[⚡] DÉMARRAGE MODE SIMULTANÉ PERSISTANT + LIENS ALÉATOIRES", Colors.MAGENTA)
    print_colored(f"[*] {len(recipient_emails)} emails à envoyer avec {max_simultaneous_smtp} SMTP en parallèle", Colors.CYAN)
    if not wait_for_dynamic_auth_accounts():
        for pending in recipient_emails:
            complete_coordinator_recipient(pending, False)
        return
    refresh_validated_smtp_accounts()
    try:
        worker_cap = max(1, int(max_simultaneous_smtp))
    except (TypeError, ValueError):
        worker_cap = 1
    smtp_accounts = get_smtp_accounts_simultaneous(worker_cap)
    if not smtp_accounts:
        print_colored("[-] Aucun compte SMTP disponible", Colors.RED)
        for pending in recipient_emails:
            complete_coordinator_recipient(pending, False)
        return

    recipients = queue.Queue()
    for recipient in recipient_emails:
        recipients.put(recipient)
    active_accounts = {id(account): account for account in smtp_accounts}
    processed_lock = threading.Lock()
    processed = 0

    def account_is_active(account):
        with AUTH_SMTP_STATE_LOCK:
            return id(account) in active_accounts and account in VALID_SMTP_ACCOUNTS

    def send_account_worker(account):
        nonlocal processed
        while account_is_active(account):
            try:
                email = recipients.get_nowait()
            except queue.Empty:
                return
            try:
                success = send_email_with_auth(account, email, subject, message, attachments)
                complete_coordinator_recipient(email, success)
                with processed_lock:
                    processed += 1
            except Exception as exc:
                # A worker failure must not strand the item it just claimed.
                # The normal send function records its own failures; exceptions
                # raised before that point are returned to the shared queue.
                recipients.put(email)
                print_colored(f"[-] Erreur thread simultané: {exc}", Colors.RED)
            finally:
                recipients.task_done()
            if account_is_active(account):
                delay = max(0, float(CONFIG.get('TIME_PER_EMAIL_SECONDS', 1.0)))
                if delay:
                    time.sleep(delay)
            else:
                print_colored(
                    f"[⚠️] Compte {account.get('email', 'inconnu')} retiré : "
                    "les destinataires restants passent aux workers sains.",
                    Colors.YELLOW,
                )
                return

    worker_count = min(worker_cap, len(smtp_accounts))
    print_colored(
        f"[⚡] File partagée : {worker_count} workers SMTP persistants "
        f"(cap {worker_cap}), {recipients.qsize()} destinataires",
        Colors.MAGENTA,
    )
    with ThreadPoolExecutor(max_workers=worker_count) as executor:
        futures = [executor.submit(send_account_worker, account) for account in smtp_accounts[:worker_count]]
        for future in futures:
            try:
                future.result()
            except Exception as exc:
                print_colored(f"[-] Erreur worker simultané: {exc}", Colors.RED)
    # Workers may have opened persistent connections; always release them
    # before returning, including when one worker exits after account removal.
    close_all_smtp_connections()
    # No account can process more work; explicitly finalize anything left.
    while True:
        try:
            pending = recipients.get_nowait()
        except queue.Empty:
            break
        complete_coordinator_recipient(pending, False)
        recipients.task_done()
    print_colored(f"[📊] Traité {processed}/{len(recipient_emails)} emails avec file partagée", Colors.YELLOW)
    print_colored(f"[✅] MODE SIMULTANÉ PERSISTANT + LIENS ALÉATOIRES TERMINÉ", Colors.GREEN)

# ===============================================
# FONCTIONS DE ROTATION DES DOMAINES ET PORTS
# ===============================================

def load_sender_domains():
    """Charge la liste des domaines d'expéditeur depuis le fichier spécifié"""
    global SENDER_DOMAINS
    try:
        domain_file = CONFIG.get('SENDER_DOMAIN_List', 'dom.txt')
        if os.path.exists(domain_file):
            with open(domain_file, 'r', encoding='utf-8') as f:
                SENDER_DOMAINS = [line.strip() for line in f if line.strip() and not line.startswith('#') and '.' in line]
            print_colored(f"[+] {len(SENDER_DOMAINS)} domaines d'expéditeur chargés depuis {domain_file}", Colors.GREEN)
        else:
            print_colored(f"[!] Fichier {domain_file} non trouvé, utilisation du domaine par défaut", Colors.YELLOW)
            SENDER_DOMAINS = [CONFIG.get('SENDER_DOMAIN', 'vialis.net')]
    except Exception as e:
        print_colored(f"[-] Erreur chargement domaines d'expéditeur: {e}", Colors.RED)
        SENDER_DOMAINS = [CONFIG.get('SENDER_DOMAIN', 'vialis.net')]

def get_current_sender_domain():
    """Retourne le domaine d'expéditeur actuel.

    En mode direct, rDNS_SENDER_DOMAIN permet d'utiliser le nom PTR détecté
    comme domaine d'expéditeur. Sans cette option, la configuration habituelle
    (domaine fixe ou rotation) reste prioritaire.
    """
    global current_domain_index
    if CONFIG.get('rDNS_SENDER_DOMAIN', False) and SERVER_RDNS:
        return SERVER_RDNS.rstrip('.')
    if not CONFIG.get('SENDER_DOMAIN_ROTATE', False) or not SENDER_DOMAINS:
        return CONFIG.get('SENDER_DOMAIN', 'vialis.net')
    domain = SENDER_DOMAINS[current_domain_index % len(SENDER_DOMAINS)]
    return domain

def rotate_to_next_domain():
    """Passe au domaine suivant et remet les compteurs à zéro"""
    global current_domain_index, domain_email_counter
    if not CONFIG.get('SENDER_DOMAIN_ROTATE', False) or len(SENDER_DOMAINS) <= 1:
        return get_current_sender_domain()
    old_domain = get_current_sender_domain()
    current_domain_index += 1
    new_domain = get_current_sender_domain()
    print_colored(f"[🔄] Rotation de domaine {old_domain} → {new_domain}", Colors.YELLOW)
    domain_email_counter = 0
    return new_domain

def increment_domain_counter():
    """Incrémente le compteur d'emails pour le domaine actuel"""
    global domain_email_counter
    if CONFIG.get('SENDER_DOMAIN_ROTATE', False):
        domain_email_counter += 1

def get_envelope_sender_domain():
    """Retourne le domaine utilisé par le MAIL FROM / Return-Path."""
    if CONFIG.get('rDNS_SENDER_DOMAIN', False) and SERVER_RDNS:
        return get_current_sender_domain()
    configured_domain = str(CONFIG.get('ENVELOPE_SENDER_DOMAIN', '')).strip()
    return configured_domain or get_current_sender_domain()

def generate_token():
    """Génère un token de référence aléatoire avec gestion améliorée des hashtags"""
    token_format = CONFIG.get('TOKEN_FORMAT', 'Ref-####-########')
    token = generate_characters_from_hashtags(token_format)
    if CONFIG.get('DEBUG_MODE', False):
        print_colored(f"[DEBUG] Token généré: {token_format} → {token}", Colors.MAGENTA)
    return token

def generate_random_username():
    """Génère un nom d'utilisateur aléatoire avec support des hashtags"""
    username_format = CONFIG.get('USERNAME_FORMAT', '')
    if username_format and '#' in username_format:
        username = generate_characters_from_hashtags(username_format)
        return username
    prefixes = ['info', 'contact', 'support', 'service', 'admin', 'team', 'sales']
    suffixes = ['', '.pro', '.team', '.info', '.service']
    numbers = [''] + [str(random.randint(1, 999)) for _ in range(10)]
    base_name = random.choice(prefixes)
    if random.choice([True, False]):
        base_name += random.choice(numbers)
    base_name += random.choice(suffixes)
    return base_name

def load_fixed_users():
    """Charge la liste des utilisateurs fixes depuis user_fixe.txt"""
    global FIXED_USERS
    try:
        if os.path.exists('user_fixe.txt'):
            with open('user_fixe.txt', 'r', encoding='utf-8') as f:
                FIXED_USERS = [line.strip() for line in f if line.strip() and not line.startswith('#')]
            print_colored(f"[+] {len(FIXED_USERS)} utilisateurs fixes chargés", Colors.GREEN)
        else:
            print_colored("[*] Fichier user_fixe.txt non trouvé, mode utilisateur fixe simple utilisé", Colors.YELLOW)
    except Exception as e:
        print_colored(f"[-] Erreur chargement user_fixe.txt: {e}", Colors.RED)
        FIXED_USERS = []

def get_sender_email(recipient_email=None, domain_override=None):
    """Retourne l'email expéditeur selon le mode configuré avec support des hashtags"""
    username_mode = CONFIG.get('USERNAME_MODE', 'FIXED_SINGLE')
    if domain_override:
        domain = domain_override
    else:
        domain = get_envelope_sender_domain()
    if username_mode == 'RANDOM_GENERATED':
        username = generate_random_username()
        return f"{username}@{domain}"
    elif username_mode == 'FIXED_MULTIPLE' and FIXED_USERS:
        username = random.choice(FIXED_USERS)
        username = generate_characters_from_hashtags(username)
        return f"{username}@{domain}"
    else:
        username = CONFIG.get('EMAIL_USERNAME', 'info')
        username = generate_characters_from_hashtags(username)
        if '@' in username:
            local_part = username.split('@')[0]
            return f"{local_part}@{domain}"
        return f"{username}@{domain}"

def format_sender_name(name, email):
    """Formate le nom de l'expéditeur avec option d'ajouter le domaine"""
    name = generate_characters_from_hashtags(name)
    name = re.sub(r'[^\w\s.-]', '', name).strip()
    if not name:
        name = email.split('@')[0].capitalize()
    if CONFIG.get('INCLUDE_DOMAIN_IN_SENDER_NAME', False):
        domain = email.split('@')[1]
        name = f"{name} <{domain}>"
    return name

def get_visible_from_header(envelope_sender):
    """Construit le From visible sans modifier le MAIL FROM / Return-Path."""
    configured_from = str(CONFIG.get('VISIBLE_FROM', '')).strip()
    if configured_from:
        configured_name, visible_email = parseaddr(configured_from)
        if not visible_email:
            visible_email = configured_from
        if '@' not in visible_email:
            raise ValueError("VISIBLE_FROM doit contenir une adresse email valide.")
        sender_name = configured_name or str(CONFIG.get('SENDER_NAME', '')).strip()
        formatted_name = format_sender_name(sender_name, visible_email)
        return formataddr((formatted_name, visible_email))

    sender_name = str(CONFIG.get('SENDER_NAME', '')).strip()
    formatted_name = format_sender_name(sender_name, envelope_sender)
    return formataddr((formatted_name, envelope_sender))

# ===============================================
# FONCTIONS DE ROTATION DES PORTS
# ===============================================

def get_current_port():
    """Retourne le port actuel selon la rotation configurée"""
    global current_port_index, PORT_RANGE_START, PORT_RANGE_END
    if not CONFIG.get('PORT_ROTATE', False):
        return CONFIG.get('PROXY_PORT', 30000)
    port_range = PORT_RANGE_END - PORT_RANGE_START + 1
    current_port = PORT_RANGE_START + (current_port_index % port_range)
    return current_port

def init_port_counters():
    """Initialise correctement tous les compteurs de ports"""
    global port_email_counter, port_error_counter, consecutive_errors
    global current_port_index, PORT_RANGE_START, PORT_RANGE_END
    global EMAILS_PER_PORT_ROTATION, ERRORS_PER_PORT_ROTATION, max_consecutive_errors
    PORT_RANGE_START = CONFIG.get('PORT_RANGE_START', 30000)
    PORT_RANGE_END = CONFIG.get('PORT_RANGE_END', 30010)
    EMAILS_PER_PORT_ROTATION = CONFIG.get('EMAILS_PER_PORT_ROTATION', 50)
    ERRORS_PER_PORT_ROTATION = CONFIG.get('ERRORS_PER_PORT_ROTATION', 2)
    max_consecutive_errors = CONFIG.get('MAX_CONSECUTIVE_ERRORS', 2)
    current_port_index = 0
    port_email_counter = 0
    port_error_counter = 0
    consecutive_errors = 0

def should_rotate_port():
    """Vérifie si on doit changer de port"""
    global port_email_counter, port_error_counter, consecutive_errors
    if not CONFIG.get('PORT_ROTATE', False):
        return False
    emails_limit = CONFIG.get('EMAILS_PER_PORT_ROTATION', 50)
    errors_limit = CONFIG.get('ERRORS_PER_PORT_ROTATION', 2)
    should_rotate = (port_email_counter >= emails_limit) or \
                   (port_error_counter >= errors_limit) or \
                   (consecutive_errors >= max_consecutive_errors)
    return should_rotate

def rotate_to_next_port():
    """Passe au port suivant et remet les compteurs à zéro"""
    global current_port_index, port_email_counter, port_error_counter, consecutive_errors
    old_port = get_current_port()
    current_port_index += 1
    new_port = get_current_port()
    reason = ""
    if consecutive_errors >= max_consecutive_errors:
        reason = f"après {consecutive_errors} erreurs consécutives"
    elif port_email_counter >= CONFIG.get('EMAILS_PER_PORT_ROTATION', 50):
        reason = f"après {port_email_counter} emails envoyés"
    elif port_error_counter >= CONFIG.get('ERRORS_PER_PORT_ROTATION', 2):
        reason = f"après {port_error_counter} erreurs sur ce port"
    print_colored(f"[🔄] Rotation de port {old_port} → {new_port} ({reason})", Colors.YELLOW)
    port_email_counter = 0
    port_error_counter = 0
    consecutive_errors = 0
    return new_port

def increment_port_counters(success=True):
    """Incrémente les compteurs de port"""
    global port_email_counter, port_error_counter, consecutive_errors
    if not CONFIG.get('PORT_ROTATE', False):
        return
    if success:
        port_email_counter += 1
        consecutive_errors = 0
    else:
        port_error_counter += 1
        consecutive_errors += 1

def check_and_rotate_port_if_needed():
    """Vérifie et effectue la rotation des ports si nécessaire"""
    if CONFIG.get('PORT_ROTATE', False) and should_rotate_port():
        print_colored(f"[🔄] Rotation de port déclenchée automatiquement", Colors.YELLOW)
        return reconfigure_proxy_with_new_port()
    return False

def reconfigure_proxy_with_new_port():
    """Reconfigure le proxy avec le nouveau port après rotation"""
    if not CONFIG.get('USE_PROXY', False):
        return False
    try:
        new_port = rotate_to_next_port()
        proxy_host = CONFIG.get('PROXY_HOST', '127.0.0.1')
        print_colored(f"[🔄] Reconfiguration du proxy SOCKS5 sur {proxy_host}:{new_port}", Colors.CYAN)
        socks.set_default_proxy(socks.SOCKS5, proxy_host, new_port)
        socket.socket = socks.socksocket
        return True
    except Exception as e:
        print_colored(f"[-] Erreur reconfiguration proxy: {e}", Colors.RED)
        return False

def close_smtp_connection(server):
    """Ferme proprement une connexion SMTP"""
    if server:
        try:
            server.quit()
            print_colored(f"[📡] Connexion SMTP fermée", Colors.CYAN)
        except:
            try:
                server.close()
            except:
                pass

def create_smtp_connection(mail_server, server_port, max_attempts=1):
    """Crée une nouvelle connexion SMTP avec retry"""
    debug_mode = CONFIG.get('DEBUG_MODE', False)
    for attempt in range(1, max_attempts + 1):
        try:
            print_colored(f"[📡] Connexion SMTP vers {mail_server}:{server_port}...", Colors.YELLOW)
            server = open_smtp(mail_server, server_port, timeout=10)
            if debug_mode:
                server.set_debuglevel(1)
            server.ehlo(SERVER_RDNS)
            tls_active = establish_tls(
                server,
                mail_server,
                server_port,
                required=CONFIG.get('SMTP_REQUIRE_TLS', True),
            )
            if tls_active:
                print_colored(
                    f"[🔒] TLS activé vers {mail_server}:{server_port}",
                    Colors.GREEN,
                )
            print_colored(f"[📡] ✓ Connexion SMTP établie vers {mail_server}:{server_port}", Colors.GREEN)
            return server
        except Exception as e:
            print_colored(f"[-] ✗ Échec connexion SMTP #{attempt} vers {mail_server}:{server_port}: {e}", Colors.RED)
            if CONFIG.get('USE_PROXY', False) and CONFIG.get('PORT_ROTATE', False):
                increment_port_counters(success=False)
                if should_rotate_port():
                    print_colored(f"[🔄] Rotation de port nécessaire après échec de connexion", Colors.YELLOW)
                    reconfigure_proxy_with_new_port()
            if attempt < max_attempts:
                retry_delay = min(1, attempt * 2)
                print_colored(f"[⏳] Nouvelle tentative dans {retry_delay} secondes...", Colors.YELLOW)
                time.sleep(retry_delay)
    print_colored(f"[-] Abandon après {max_attempts} tentatives de connexion", Colors.RED)
    return None

# ===============================================
# FONCTIONS STATISTIQUES
# ===============================================

def print_statistics():
    """Affiche les statistiques en temps réel pour le mode normal"""
    if start_time is None:
        return
    current_time = time.time()
    elapsed = current_time - start_time
    rate = email_counter / elapsed if elapsed > 0 else 0

    multi_port_info = ""
    if CONFIG.get('USE_MULTI_PORT_MODE', False) and MULTI_PORT_STATS['active_ports'] > 0:
        multi_port_info = f"{Colors.MAGENTA}│ 🌐 Ports simultanés actifs  : {MULTI_PORT_STATS['active_ports']:>6}                    │{Colors.RESET}\n"
        multi_port_info += f"{Colors.MAGENTA}│ ⚡ Vitesse théorique ports  : {MULTI_PORT_STATS['active_ports']:>6} emails/s             │{Colors.RESET}\n"
        multi_port_info += f"{Colors.YELLOW}│ 🔄 Emails redistribués      : {MULTI_PORT_STATS['redistributed_emails']:>6}                    │{Colors.RESET}\n"

    multithread_info = ""
    if CONFIG.get('THREADS', 0) > 1 and not CONFIG.get('USE_AUTH_MODE', False) and not CONFIG.get('USE_FIXED_SMTP', False) and not CONFIG.get('USE_PROXY', False):
        multithread_info = f"{Colors.GREEN}│ 🧵 Threads configurés       : {CONFIG.get('THREADS', 1):>6}                    │{Colors.RESET}\n"
        multithread_info += f"{Colors.YELLOW}│ 🔥 Threads actifs           : {MULTITHREAD_STATS['active_threads']:>6}                    │{Colors.RESET}\n"

    port_info = ""
    if CONFIG.get('PORT_ROTATE', False) and CONFIG.get('USE_PROXY', False) and not CONFIG.get('USE_MULTI_PORT_MODE', False):
        current_port = get_current_port()
        port_info = f"{Colors.CYAN}│ 🔌 Port proxy actuel        : {current_port:>6}                    │{Colors.RESET}\n"
        port_info += f"{Colors.CYAN}│ 📧 Emails sur ce port       : {port_email_counter:>6}                    │{Colors.RESET}\n"
        port_info += f"{Colors.RED}│ ❌ Erreurs sur ce port      : {port_error_counter:>6}                    │{Colors.RESET}\n"
        port_info += f"{Colors.YELLOW}│ 🔢 Erreurs consécutives     : {consecutive_errors:>6}                    │{Colors.RESET}\n"

    domain_info = ""
    if CONFIG.get('SENDER_DOMAIN_ROTATE', False) and len(SENDER_DOMAINS) > 1:
        current_domain = get_current_sender_domain()
        domain_info = f"{Colors.MAGENTA}│ 🌐 Domaine expéditeur actuel: {current_domain:>25} │{Colors.RESET}\n"
        domain_info += f"{Colors.MAGENTA}│ 📨 Emails sur ce domaine    : {domain_email_counter:>6}                    │{Colors.RESET}\n"

    connection_info = ""
    if not CONFIG.get('USE_BCC_MODE', False):
        connection_info = f"{Colors.MAGENTA}│ 💾 Mode connexion           : PERSISTANT            │{Colors.RESET}\n"

    time_per_email = CONFIG.get('TIME_PER_EMAIL_SECONDS', 1.0)
    if time_per_email == 0.0:
        connection_info += f"{Colors.CYAN}│ ⏱️  Débit configuré          : {'ILLIMITÉ':>10}             │{Colors.RESET}\n"
    else:
        configured_rate = 1.0 / time_per_email
        connection_info += f"{Colors.CYAN}│ ⏱️  Débit configuré          : {configured_rate:>6.1f} emails/s             │{Colors.RESET}\n"

    mode_type = ""
    if CONFIG.get('USE_MULTI_PORT_MODE', False):
        mode_type = "MULTI-PORTS INTELLIGENT"
    elif CONFIG.get('THREADS', 0) > 1 and not CONFIG.get('USE_AUTH_MODE', False) and not CONFIG.get('USE_FIXED_SMTP', False) and not CONFIG.get('USE_PROXY', False):
        mode_type = "MULTITHREAD HAUTE PERFORMANCE"
    else:
        mode_type = "NORMAL"

    stats = f"""
{Colors.BOLD}{Colors.BLUE}┌─ STATISTIQUES EN TEMPS RÉEL (MODE {mode_type} + LIENS) ──────────────┐{Colors.RESET}
{Colors.GREEN}│ ✓ Emails envoyés avec succès : {success_counter:>6}                    │{Colors.RESET}
{Colors.RED}│ ✗ Emails en erreur          : {error_counter:>6}                    │{Colors.RESET}
{Colors.CYAN}│ ⚡ Total traité             : {email_counter:>6}                    │{Colors.RESET}
{Colors.YELLOW}│ ⏱️  Temps écoulé             : {elapsed:>6.1f}s                   │{Colors.RESET}
{Colors.MAGENTA}│ 📊 Vitesse moyenne          : {rate:>6.1f} emails/s             │{Colors.RESET}
{Colors.MAGENTA}│ 🛡️ Headers ultra-renforcés   : {Colors.BOLD}ACTIFS{Colors.RESET}{Colors.MAGENTA}                 │{Colors.RESET}
{Colors.BOLD}│ 🎨 HTML préservé sans modif  : {Colors.BOLD}GARANTI{Colors.RESET}{Colors.BOLD}                │{Colors.RESET}
{Colors.BOLD}│ 🔗 Liens aléatoires actifs   : {Colors.BOLD}GARANTI{Colors.RESET}{Colors.BOLD}                │{Colors.RESET}
{connection_info}{multithread_info}{multi_port_info}{port_info}{domain_info}{Colors.BOLD}{Colors.BLUE}└──────────────────────────────────────────────────────────────┘{Colors.RESET}
    """
    print(stats)

def print_statistics_auth():
    """Affiche les statistiques du mode AUTH avec connexions intelligentes"""
    current_time = time.time()
    elapsed = current_time - start_time if start_time else 0
    rate = auth_email_counter / elapsed if elapsed > 0 else 0

    if CONNECTION_STATS['total_connections_created'] > 0:
        optimization_percent = (CONNECTION_STATS['connections_saved'] / (CONNECTION_STATS['connections_saved'] + CONNECTION_STATS['total_connections_created'])) * 100
    else:
        optimization_percent = 0

    if CONFIG.get('USE_MULTI_PORT_MODE', False):
        mode_info = f"MULTI-PORTS ({MULTI_PORT_STATS['active_ports']}x)"
    else:
        mode_info = "SÉQUENTIEL" if CONFIG.get('USE_SEQUENTIAL_MODE', True) else "SIMULTANÉ"
        if not CONFIG.get('USE_SEQUENTIAL_MODE', True):
            max_simultaneous = CONFIG.get('MAX_SIMULTANEOUS_SMTP', 3)
            mode_info += f" ({max_simultaneous}x)"

    connection_mode = "BCC DIVISÉ" if CONFIG.get('USE_BCC_MODE', False) else "PERSISTANT"

    stats = f"""
{Colors.BOLD}{Colors.BLUE}┌─ STATISTIQUES MODE AUTH V4.5 ({mode_info} + {connection_mode} + LIENS) ────┐{Colors.RESET}
{Colors.GREEN}│ ✓ Emails envoyés avec succès : {auth_success_counter:>6}                    │{Colors.RESET}
{Colors.RED}│ ✗ Emails en erreur          : {auth_error_counter:>6}                    │{Colors.RESET}
{Colors.CYAN}│ ⚡ Total traité             : {auth_email_counter:>6}                    │{Colors.RESET}
{Colors.YELLOW}│ ⏱️  Temps écoulé             : {elapsed:>6.1f}s                   │{Colors.RESET}
{Colors.MAGENTA}│ 📊 Vitesse moyenne          : {rate:>6.1f} emails/s             │{Colors.RESET}
{Colors.CYAN}│ 📧 Comptes SMTP actifs       : {len(VALID_SMTP_ACCOUNTS):>6}                    │{Colors.RESET}
{Colors.CYAN}│ 🔄 Rotations SMTP effectuées : {smtp_rotation_counter:>6}                    │{Colors.RESET}
{Colors.RED}│ 🚫 Connexions avec rotation  : {CONNECTION_STATS['connections_rotated']:>6}                    │{Colors.RESET}
{Colors.GREEN}│ 🚀 Optimisation connexions   : {optimization_percent:>6.1f}%                   │{Colors.RESET}
{Colors.MAGENTA}│ 💾 Mode connexion            : {connection_mode:>10}               │{Colors.RESET}
{Colors.MAGENTA}│ 🛡️ Headers ultra-renforcés   : {Colors.BOLD}ACTIFS{Colors.RESET}{Colors.MAGENTA}                 │{Colors.RESET}
{Colors.BOLD}│ 🎨 HTML préservé sans modif  : {Colors.BOLD}GARANTI{Colors.RESET}{Colors.BOLD}                │{Colors.RESET}
{Colors.BOLD}│ 🔗 Liens aléatoires actifs   : {Colors.BOLD}GARANTI{Colors.RESET}{Colors.BOLD}                │{Colors.RESET}
{Colors.BOLD}{Colors.BLUE}└──────────────────────────────────────────────────────────────┘{Colors.RESET}
    """
    print(stats)

# ===============================================
# FONCTIONS DE CHARGEMENT CONFIG ET MAIN
# ===============================================

def load_clean_emails():
    """Charge la liste des emails clean depuis clean.txt pour le reinforce"""
    global CLEAN_EMAILS
    try:
        clean_file = CONFIG.get('CLEAN_EMAILS_FILE', 'clean.txt')
        if os.path.exists(clean_file):
            with open(clean_file, 'r', encoding='utf-8') as f:
                CLEAN_EMAILS = [line.strip() for line in f if line.strip() and not line.startswith('#') and '@' in line]
            print_colored(f"[+] {len(CLEAN_EMAILS)} emails clean chargés depuis {clean_file}", Colors.GREEN)
            if CLEAN_EMAILS:
                for i, email in enumerate(CLEAN_EMAILS[:5]):
                    print_colored(f"    → {email}", Colors.CYAN)
                if len(CLEAN_EMAILS) > 5:
                    print_colored(f"    ... et {len(CLEAN_EMAILS) - 5} autres", Colors.CYAN)
            else:
                print_colored(f"[!] Aucun email clean trouvé dans {clean_file}", Colors.YELLOW)
                CLEAN_EMAILS = []
        else:
            print_colored(f"[!] Fichier {clean_file} non trouvé", Colors.YELLOW)
            CLEAN_EMAILS = []
    except Exception as e:
        print_colored(f"[-] Erreur chargement clean.txt: {e}", Colors.RED)
        CLEAN_EMAILS = []

def warmup_mx_server(recipient_email, verbose=False):
    """Version basique du warmup : Simple connexion EHLO"""
    try:
        recipient_domain = recipient_email.split('@')[1]
        if verbose:
            print_colored(f"[🌡️] Warmup BASIC: Résolution MX pour {recipient_domain}...", Colors.CYAN)
        mail_server = get_mx_record(recipient_domain)
        if not mail_server:
            if verbose:
                print_colored(f"[❌] Aucun serveur MX pour {recipient_domain}", Colors.RED)
            return False
        if verbose:
            print_colored(f"[🌡️] Connexion à {mail_server}:25...", Colors.YELLOW)
        server = open_smtp(mail_server, 25, timeout=10)
        server.ehlo(SERVER_RDNS if SERVER_RDNS else 'localhost')
        server.quit()
        if verbose:
            print_colored(f"[✅] Warmup BASIC réussi avec {mail_server}", Colors.GREEN)
        return True
    except Exception as e:
        if verbose:
            print_colored(f"[❌] Warmup BASIC échoué: {e}", Colors.RED)
        return False

def warmup_mx_server_advanced(recipient_email, verbose=True):
    """
    Version avancée du warmup : Email complet avec headers anti-spam identiques
    à la fonction d'envoi principale (MAIL FROM + RCPT TO + DATA complet).
    """
    try:
        recipient_domain = recipient_email.split('@')[1]
        if verbose:
            print_colored(f"[🌡️] Warmup ADVANCED: Résolution MX pour {recipient_domain}...", Colors.CYAN)
        mail_server = get_mx_record(recipient_domain)
        if not mail_server:
            if verbose:
                print_colored(f"[❌] Aucun serveur MX pour {recipient_domain}", Colors.RED)
            return False
        if verbose:
            print_colored(f"[🌡️] Connexion à {mail_server}:25...", Colors.YELLOW)
        server = open_smtp(mail_server, 25, timeout=15)
        ehlo_name = SERVER_RDNS if SERVER_RDNS else 'localhost'
        server.ehlo(ehlo_name)
        sender_email = get_sender_email()
        sender_name = CONFIG.get('SENDER_NAME', 'Mail Service')
        token = generate_token()

        # Construction du message complet (même logique que l'envoi principal)
        msg = MIMEMultipart()
        msg['From'] = get_visible_from_header(sender_email)
        msg['To'] = recipient_email
        _warmup_subj = build_final_subject(CONFIG.get('EMAIL_SUBJECT', 'Information'), token)
        msg['Subject'] = generate_characters_from_hashtags(_warmup_subj)
        msg['Date'] = formatdate(localtime=True)
        msg['Message-ID'] = generate_message_id_enhanced(sender_email.split('@')[1])
        msg = add_ultra_enhanced_anti_spam_headers(msg, sender_email, recipient_email, token)

        # Corps HTML neutre et légitime
        warmup_html = (
            "<html><body style='font-family:Arial,sans-serif;color:#222;'>"
            "<p>Bonjour,</p>"
            "<p>Veuillez trouver ci-joint les informations demandées.</p>"
            "<p>Cordialement,<br>" + sender_name + "</p>"
            "</body></html>"
        )
        html_part = MIMEText(warmup_html, 'html', 'utf-8')
        html_part.set_charset('utf-8')
        msg.attach(html_part)

        # Envoi MAIL FROM
        code, response = server.mail(sender_email)
        if verbose:
            print_colored(f"[📤] MAIL FROM: {sender_email} (EHLO: {ehlo_name}) → Code: {code}", Colors.CYAN)
        if code >= 400:
            if verbose:
                print_colored(f"[❌] MAIL FROM échoué: {response}", Colors.RED)
            server.quit()
            return False

        # Envoi RCPT TO
        code, response = server.rcpt(recipient_email)
        if verbose:
            print_colored(f"[📥] RCPT TO: {recipient_email} → Code: {code}", Colors.CYAN)
        if code >= 400:
            if verbose:
                print_colored(f"[❌] RCPT TO échoué: {response}", Colors.RED)
            server.quit()
            return False

        # Envoi DATA complet avec headers
        try:
            _msg_str = finalize_email(msg, sender_email)
            server.data(_msg_str if isinstance(_msg_str, bytes) else _msg_str.encode('utf-8'))
            if verbose:
                print_colored(f"[📝] DATA: Email complet envoyé ({len(_msg_str)} octets)", Colors.CYAN)
        except Exception as e:
            if verbose:
                print_colored(f"[⚠️] DATA: {e}", Colors.YELLOW)

        server.quit()
        if verbose:
            print_colored(f"[✅] Warmup ADVANCED réussi avec {mail_server}", Colors.GREEN)
            print_colored(f"[📋] IP loguée avec headers complets (SPF/DKIM/DMARC simulés)", Colors.MAGENTA)
        return True
    except Exception as e:
        if verbose:
            print_colored(f"[❌] Warmup ADVANCED échoué: {e}", Colors.RED)
        return False

def execute_initial_warmup():
    """Exécute un warmup initial au démarrage du mode reinforce.
    Si WARM_BOUCLE=true : boucle sur tous les emails de clean.txt pendant
    BOUCLE_TIME minutes avant de passer en écoute.
    Sinon : comportement original (N warmups fixes).
    """
    global CLEAN_EMAILS

    print_colored(f"\n{'='*70}", Colors.CYAN)
    print_colored(f"[🌡️] WARMUP INITIAL - DÉMARRAGE", Colors.BOLD)
    print_colored(f"{'='*70}", Colors.CYAN)

    if not CLEAN_EMAILS:
        load_clean_emails()

    if not CLEAN_EMAILS:
        print_colored(f"[❌] Aucun email clean disponible pour le warmup initial", Colors.RED)
        print_colored(f"[⚠️] Veuillez remplir le fichier {CONFIG.get('CLEAN_EMAILS_FILE', 'clean.txt')}", Colors.YELLOW)
        return 0

    warmup_mode = CONFIG.get('WARMUP_MODE', 'ADVANCED')
    warm_boucle = CONFIG.get('WARM_BOUCLE', False)

    success_count = 0
    failed_count = 0
    total_sent = 0

    if warm_boucle:
        # ── WARM EN BOUCLE pendant BOUCLE_TIME minutes ──────────────────
        boucle_minutes = _parse_boucle_time(CONFIG.get('BOUCLE_TIME', 20))
        deadline = datetime.now() + timedelta(minutes=boucle_minutes)
        cycle = 0

        print_colored(f"[🔁] WARM_BOUCLE activé — durée: {boucle_minutes} min", Colors.BOLD)
        print_colored(f"[📊] Mode warmup: {warmup_mode}", Colors.CYAN)
        print_colored(f"[⚠️] La boucle tourne jusqu'à {deadline.strftime('%H:%M:%S')} avant passage en écoute", Colors.YELLOW)

        while datetime.now() < deadline:
            # Vérifier arrêt utilisateur
            ctrl = read_control_file()
            if stop_requested_for(ctrl, "reinforce"):
                print_colored(f"\n[🛑] Arrêt demandé pendant le warm initial", Colors.RED)
                return total_sent

            cycle += 1
            targets = CLEAN_EMAILS.copy()
            random.shuffle(targets)
            total = len(targets)
            remaining_secs = int((deadline - datetime.now()).total_seconds())

            print_colored(
                f"\n{'─'*70}\n"
                f"[🔁] Cycle #{cycle} — {total} email(s) — "
                f"Temps restant: {remaining_secs // 60}m {remaining_secs % 60}s\n"
                f"{'─'*70}",
                Colors.BOLD
            )

            for i, target in enumerate(targets, 1):
                if datetime.now() >= deadline:
                    break
                ctrl = read_control_file()
                if stop_requested_for(ctrl, "reinforce"):
                    print_colored(f"\n[🛑] Arrêt demandé, fin du cycle #{cycle}", Colors.RED)
                    return total_sent

                print_colored(f"[🌡️] [{i}/{total}] {target}", Colors.YELLOW)
                if warmup_mode.upper() == 'ADVANCED':
                    ok = warmup_mx_server_advanced(target, verbose=True)
                else:
                    ok = warmup_mx_server(target, verbose=True)

                total_sent += 1
                if ok:
                    success_count += 1
                else:
                    failed_count += 1

                update_control_file(
                    warmup_sent=total_sent,
                    warmup_success=success_count,
                    warmup_failed=failed_count
                )

            print_colored(
                f"[✅] Cycle #{cycle} terminé — {success_count} succès, {failed_count} échecs",
                Colors.GREEN
            )
            load_clean_emails()

        print_colored(
            f"\n[🌡️] WARM BOUCLE INITIAL TERMINÉ — {cycle} cycle(s) / "
            f"{boucle_minutes} min — {success_count} succès, {failed_count} échecs",
            Colors.GREEN
        )

    else:
        # ── Comportement ORIGINAL : N warmups fixes ──────────────────────
        warmup_count = CONFIG.get('REINFORCE_WARMUP_COUNT', 5)
        print_colored(f"[📊] Warmups à effectuer: {warmup_count}", Colors.CYAN)
        print_colored(f"[📊] Mode warmup: {warmup_mode}", Colors.CYAN)

        clean_emails_shuffled = CLEAN_EMAILS.copy()
        random.shuffle(clean_emails_shuffled)
        targets = clean_emails_shuffled[:warmup_count]

        for i, target in enumerate(targets, 1):
            print_colored(f"\n[🌡️] Warmup initial {i}/{warmup_count}: {target}", Colors.YELLOW)

            if warmup_mode.upper() == 'ADVANCED':
                ok = warmup_mx_server_advanced(target, verbose=True)
            else:
                ok = warmup_mx_server(target, verbose=True)

            total_sent += 1
            if ok:
                success_count += 1
            else:
                failed_count += 1

        update_control_file(
            warmup_sent=total_sent,
            warmup_success=success_count,
            warmup_failed=failed_count
        )

        print_colored(f"\n[🌡️] WARMUP INITIAL TERMINÉ: {success_count} succès, {failed_count} échecs", Colors.GREEN)

    print_colored(f"{'='*70}\n", Colors.CYAN)
    return success_count

def _parse_boucle_time(value):
    """Convertit BOUCLE_TIME en minutes (int). Accepte '20', '20 min', 20, etc."""
    try:
        return int(float(str(value).split()[0]))
    except Exception:
        return 20

def execute_reinforce():
    """Exécute le processus IP Reinforce.
    Si WARM_BOUCLE=true : boucle de warmup sur tous les emails clean pendant BOUCLE_TIME minutes.
    Sinon : comportement original (warmup fixe + attente REINFORCE_DURATION).
    """
    global REINFORCE_ERRORS, REINFORCE_ACTIVE, CLEAN_EMAILS

    print_colored(f"\n{'='*70}", Colors.MAGENTA)
    print_colored(f"[🔄] DÉMARRAGE DU PROCESSUS IP REINFORCE", Colors.BOLD)
    print_colored(f"{'='*70}", Colors.MAGENTA)

    control_data = read_control_file()
    request_id = control_data.get("reinforce_request_id")
    error_count = control_data.get("error_count", 0)
    current_email = control_data.get("current_email", "")
    email_index = control_data.get("email_index", 0)
    reinforce_duration = CONFIG.get('REINFORCE_DURATION', 60)
    warmup_count = CONFIG.get('REINFORCE_WARMUP_COUNT', 5)
    warmup_mode = CONFIG.get('WARMUP_MODE', 'ADVANCED')
    warm_boucle = CONFIG.get('WARM_BOUCLE', False)
    boucle_minutes = _parse_boucle_time(CONFIG.get('BOUCLE_TIME', 20))

    print_colored(f"[📊] Erreurs détectées: {error_count}", Colors.YELLOW)
    print_colored(f"[📊] Email en cours: {current_email}", Colors.YELLOW)
    print_colored(f"[📊] Index: {email_index}", Colors.YELLOW)
    print_colored(f"[📊] Mode warmup: {warmup_mode}", Colors.CYAN)
    if warm_boucle:
        print_colored(f"[🔁] WARM_BOUCLE activé — durée: {boucle_minutes} min", Colors.BOLD)
    else:
        print_colored(f"[📊] Durée du reinforce: {reinforce_duration}s", Colors.CYAN)
        print_colored(f"[📊] Warmups à effectuer: {warmup_count}", Colors.CYAN)

    if not CLEAN_EMAILS:
        load_clean_emails()

    if not CLEAN_EMAILS:
        print_colored(f"[❌] Aucun email clean disponible pour le reinforce", Colors.RED)
        print_colored(f"[⚠️] Veuillez remplir le fichier {CONFIG.get('CLEAN_EMAILS_FILE', 'clean.txt')}", Colors.YELLOW)
        update_control_file(
            status="running",
            mode="send",
            error_count=0,
            reinforce_completed_id=request_id,
            reinforce_end=datetime.now().isoformat()
        )
        return

    success_count = 0
    failed_count = 0

    if warm_boucle:
        # ── WARM EN BOUCLE : tourner sur tous les emails de clean.txt
        #    jusqu'à ce que BOUCLE_TIME minutes soient écoulées ──────────
        deadline = datetime.now() + timedelta(minutes=boucle_minutes)
        cycle = 0
        total_sent = 0

        while datetime.now() < deadline:
            cycle += 1
            targets = CLEAN_EMAILS.copy()
            random.shuffle(targets)
            total = len(targets)
            remaining_secs = int((deadline - datetime.now()).total_seconds())
            print_colored(
                f"\n[🔁] Cycle warm #{cycle} — {total} email(s) — "
                f"Temps restant: {remaining_secs // 60}m {remaining_secs % 60}s",
                Colors.BOLD
            )

            for i, target in enumerate(targets, 1):
                if datetime.now() >= deadline:
                    break
                # Vérifier si arrêt demandé
                ctrl = read_control_file()
                if stop_requested_for(ctrl, "reinforce"):
                    print_colored(f"[🛑] Arrêt demandé pendant le warm boucle reinforce", Colors.RED)
                    update_control_file(
                        status="running", mode="send",
                        error_count=0,
                        warmup_sent=total_sent,
                        warmup_success=success_count,
                        warmup_failed=failed_count,
                        reinforce_end=datetime.now().isoformat()
                    )
                    return

                print_colored(f"[🌡️] [{i}/{total}] {target}", Colors.YELLOW)
                if warmup_mode.upper() == 'ADVANCED':
                    ok = warmup_mx_server_advanced(target, verbose=True)
                else:
                    ok = warmup_mx_server(target, verbose=True)

                total_sent += 1
                if ok:
                    success_count += 1
                else:
                    failed_count += 1

                update_control_file(
                    warmup_sent=total_sent,
                    warmup_success=success_count,
                    warmup_failed=failed_count
                )

        print_colored(
            f"\n[🌡️] WARM BOUCLE TERMINÉ après {cycle} cycle(s) / "
            f"{boucle_minutes} min — {success_count} succès, {failed_count} échecs",
            Colors.GREEN
        )

    else:
        # ── Comportement ORIGINAL : warmup fixe + attente ───────────────
        clean_emails_shuffled = CLEAN_EMAILS.copy()
        random.shuffle(clean_emails_shuffled)
        targets = clean_emails_shuffled[:warmup_count]

        for i, target in enumerate(targets, 1):
            print_colored(f"\n[🌡️] Warmup reinforce {i}/{warmup_count}: {target}", Colors.YELLOW)

            if warmup_mode.upper() == 'ADVANCED':
                ok = warmup_mx_server_advanced(target, verbose=True)
            else:
                ok = warmup_mx_server(target, verbose=True)

            if ok:
                success_count += 1
            else:
                failed_count += 1

        update_control_file(
            warmup_sent=warmup_count,
            warmup_success=success_count,
            warmup_failed=failed_count
        )

        print_colored(f"\n[🌡️] WARMUP REINFORCE TERMINÉ: {success_count} succès, {failed_count} échecs", Colors.GREEN)

        print_colored(f"\n[⏳] Attente de {reinforce_duration} secondes avant la reprise...", Colors.YELLOW)
        for i in range(reinforce_duration, 0, -10):
            remaining = max(0, i)
            print_colored(f"    {remaining} secondes restantes...", Colors.CYAN)
            time.sleep(min(10, remaining))

    print_colored(f"\n[✅] REINFORCE TERMINÉ, reprise de l'envoi", Colors.GREEN)
    print_colored(f"{'='*70}\n", Colors.MAGENTA)

    update_control_file(
        status="running",
        mode="send",
        error_count=0,
        reinforce_completed_id=request_id,
        reinforce_end=datetime.now().isoformat()
    )

def run_warm_boucle():
    """
    Répète le warmup sur chaque email de clean.txt en continu pendant
    BOUCLE_TIME minutes puis s'arrête.
    Pas de pause, pas de cycle — le même email est chauffé encore et encore
    jusqu'à expiration du temps.
    Seul l'utilisateur peut interrompre avant la fin (Ctrl+C).
    """
    global CLEAN_EMAILS

    boucle_time = _parse_boucle_time(CONFIG.get('BOUCLE_TIME', 20))
    warmup_mode = CONFIG.get('WARMUP_MODE', 'ADVANCED')
    deadline = datetime.now() + timedelta(minutes=boucle_time)

    print_colored(f"\n{'='*70}", Colors.MAGENTA)
    print_colored(f"[🔁] WARM BOUCLE — durée: {boucle_time} min", Colors.BOLD)
    print_colored(f"[📊] Mode warmup   : {warmup_mode}", Colors.CYAN)
    print_colored(f"[📊] Fichier clean : {CONFIG.get('CLEAN_EMAILS_FILE', 'clean.txt')}", Colors.CYAN)
    print_colored(f"[📊] Fin prévue    : {deadline.strftime('%H:%M:%S')}", Colors.CYAN)
    print_colored(f"[⚠️] Arrêt anticipé : Ctrl+C uniquement", Colors.YELLOW)
    print_colored(f"{'='*70}\n", Colors.MAGENTA)

    load_clean_emails()

    if not CLEAN_EMAILS:
        print_colored(f"[❌] Aucun email dans {CONFIG.get('CLEAN_EMAILS_FILE', 'clean.txt')}", Colors.RED)
        return

    init_control_file()
    update_control_file(mode="warm_boucle", status="running")

    total_sent = 0
    total_ok = 0
    total_fail = 0

    # Index circulaire sur les emails de clean.txt
    emails = CLEAN_EMAILS[:]
    idx = 0

    try:
        while datetime.now() < deadline:
            remaining = int((deadline - datetime.now()).total_seconds())
            target = emails[idx % len(emails)]
            idx += 1
            total_sent += 1

            print_colored(
                f"[🌡️] #{total_sent} | {target} | "
                f"Restant: {remaining // 60}m {remaining % 60}s",
                Colors.YELLOW
            )

            if warmup_mode.upper() == 'ADVANCED':
                ok = warmup_mx_server_advanced(target, verbose=True)
            else:
                ok = warmup_mx_server(target, verbose=True)

            if ok:
                total_ok += 1
            else:
                total_fail += 1

            update_control_file(
                warmup_sent=total_sent,
                warmup_success=total_ok,
                warmup_failed=total_fail
            )

    except KeyboardInterrupt:
        print_colored(f"\n[🛑] Interruption par l'utilisateur (Ctrl+C)", Colors.RED)
        update_control_file(status="stopped", stop_target="reinforce")

    print_colored(f"\n{'='*70}", Colors.MAGENTA)
    print_colored(
        f"[🏁] WARM BOUCLE TERMINÉ — {total_sent} envois, "
        f"{total_ok} succès, {total_fail} échecs",
        Colors.GREEN
    )
    print_colored(f"{'='*70}\n", Colors.MAGENTA)


def run_reinforce_mode():
    """Mode reinforce : surveillance en temps réel avec warmup initial"""
    global REINFORCE_ACTIVE

    print_colored(f"\n{'='*70}", Colors.MAGENTA)
    print_colored(f"[🔄] MODE REINFORCE ACTIVÉ - Surveillance en temps réel", Colors.BOLD)
    print_colored(f"{'='*70}", Colors.MAGENTA)

    print_colored(f"[📊] Seuil d'erreurs: {CONFIG.get('MAX_ERRORS_BEFORE_REINFORCE', 10)}", Colors.CYAN)
    print_colored(f"[📊] Durée du reinforce: {CONFIG.get('REINFORCE_DURATION', 60)}s", Colors.CYAN)
    print_colored(f"[📊] Warmups: {CONFIG.get('REINFORCE_WARMUP_COUNT', 5)}", Colors.CYAN)
    print_colored(f"[📊] Mode warmup: {CONFIG.get('WARMUP_MODE', 'ADVANCED')}", Colors.CYAN)
    print_colored(f"[📊] Fichier clean: {CONFIG.get('CLEAN_EMAILS_FILE', 'clean.txt')}", Colors.CYAN)

    # ===============================================
    # WARMUP INITIAL AU DÉMARRAGE
    # ===============================================
    print_colored(f"\n[🌡️] EXÉCUTION DU WARMUP INITIAL...", Colors.BOLD)
    execute_initial_warmup()

    print_colored(f"[⏳] Attente de 2 secondes avant de commencer l'écoute...", Colors.YELLOW)
    time.sleep(2)

    load_clean_emails()

    if not CLEAN_EMAILS:
        print_colored(f"[⚠️] ATTENTION: Aucun email clean chargé", Colors.YELLOW)
        print_colored(f"[⚠️] Le reinforce ne pourra pas fonctionner sans emails clean", Colors.YELLOW)
        print_colored(f"[⚠️] Veuillez remplir {CONFIG.get('CLEAN_EMAILS_FILE', 'clean.txt')}", Colors.YELLOW)

    # Vérifier si un reinforce est déjà en attente AVANT d'écraser le fichier
    pending_data = read_control_file()
    pending_reinforce = (
        pending_data.get("status") == "reinforce" and
        pending_data.get("mode") == "reinforce"
    )
    if pending_reinforce:
        print_colored(f"[🔔] REINFORCE DÉJÀ EN ATTENTE DÉTECTÉ AU DÉMARRAGE !", Colors.BOLD)
        print_colored(f"[📊] Exécution immédiate avant de passer en écoute...", Colors.YELLOW)

    init_control_file()
    update_control_file(mode="reinforce", status="running")

    reinforce_count = 0
    reinforce_in_progress = False

    # Exécuter immédiatement si un reinforce était en attente avant le démarrage
    if pending_reinforce:
        reinforce_in_progress = True
        REINFORCE_ACTIVE = True
        request_id = pending_data.get("reinforce_request_id")
        try:
            execute_reinforce()
            reinforce_count += 1
        finally:
            REINFORCE_ACTIVE = False
            reinforce_in_progress = False
            latest = read_control_file()
            if not stop_requested_for(latest, "reinforce"):
                update_control_file(
                    status="running",
                    mode="send",
                    error_count=0,
                    reinforce_completed_id=request_id,
                    reinforce_end=datetime.now().isoformat()
                )
        print_colored(f"[✅] Reinforce initial terminé, passage en écoute", Colors.GREEN)

    def on_control_change(data):
        """Callback appelé à chaque changement de control.json"""
        global REINFORCE_ACTIVE
        nonlocal reinforce_count, reinforce_in_progress

        try:
            status = data.get("status", "running")
            mode = data.get("mode", "send")
            error_count = data.get("error_count", 0)
            max_errors = CONFIG.get('MAX_ERRORS_BEFORE_REINFORCE', 10)

            timestamp = datetime.now().strftime("%H:%M:%S")
            print_colored(f"[{timestamp}] 📡 Changement détecté - Statut: {status}, Erreurs: {error_count}/{max_errors}", Colors.CYAN)

            if status == "reinforce" and mode == "reinforce" and not reinforce_in_progress:
                reinforce_in_progress = True
                print_colored(f"\n[🔔] SIGNAL REINFORCE DÉTECTÉ EN TEMPS RÉEL !", Colors.BOLD)
                print_colored(f"[📊] Erreurs: {error_count}/{max_errors}", Colors.YELLOW)
                print_colored(f"[📊] Email: {data.get('current_email', 'Inconnu')}", Colors.YELLOW)

                REINFORCE_ACTIVE = True
                request_id = data.get("reinforce_request_id")
                try:
                    execute_reinforce()
                    reinforce_count += 1
                finally:
                    REINFORCE_ACTIVE = False
                    reinforce_in_progress = False
                    # Garantit le relais même si le warmup lève une erreur.
                    latest = read_control_file()
                    if not stop_requested_for(latest, "reinforce"):
                        update_control_file(
                            status="running",
                            mode="send",
                            error_count=0,
                            reinforce_completed_id=request_id,
                            reinforce_end=datetime.now().isoformat()
                        )

                print_colored(f"\n[✅] Reinforce #{reinforce_count} terminé, retour en écoute", Colors.GREEN)

            elif stop_requested_for(data, "reinforce"):
                print_colored(f"[🛑] Arrêt demandé", Colors.RED)
                if observer:
                    observer.stop()

        except Exception as e:
            print_colored(f"[❌] Erreur dans le callback: {e}", Colors.RED)

    # La boucle de lecture est volontairement utilisée même si watchdog est
    # installé.  Le fichier est partagé entre plusieurs processus et les
    # événements watchdog peuvent arriver pendant une écriture partielle ou
    # être manqués selon le filesystem du déploiement. La lecture du contenu
    # garantit que chaque identifiant de cycle est finalement traité.
    observer = None
    print_colored(
        f"[📡] Écoute fiable de {CONTROL_FILE} activée (vérification: 0.5s)",
        Colors.GREEN
    )
    last_content = None

    while True:
        try:
            if os.path.exists(CONTROL_FILE):
                with open(CONTROL_FILE, 'r', encoding='utf-8') as control_file:
                    content = control_file.read()

                if content and content != last_content:
                    try:
                        data = json.loads(content)
                    except json.JSONDecodeError:
                        # Une écriture concurrente peut être momentanément
                        # incomplète. On relira le même contenu au prochain
                        # passage sans le marquer comme traité.
                        data = None

                    if data is not None:
                        last_content = content
                        on_control_change(data)
                        if stop_requested_for(data, "reinforce"):
                            break

            time.sleep(0.5)

        except KeyboardInterrupt:
            print_colored(f"\n[🛑] Interruption par l'utilisateur", Colors.RED)
            update_control_file(status="stopped", stop_target="reinforce")
            break
        except Exception as e:
            print_colored(f"[❌] Erreur écoute control.json: {e}", Colors.RED)
            time.sleep(1)

    print_colored(f"\n[🏁] MODE REINFORCE TERMINÉ", Colors.GREEN)

# ===============================================
# FONCTIONS DE CHARGEMENT CONFIG ET MAIN (suite)
# ===============================================

def parse_config_file(config_path):
    config = {}
    try:
        with open(config_path, "r", encoding="utf-8") as file:
            for line in file:
                line = line.strip()
                if not line or line.startswith('#'):
                    continue
                parts = line.split('=', 1)
                if len(parts) == 2:
                    key = parts[0].strip()
                    import re as _re
                    value = _re.sub(r'\s+#.*$', '', parts[1].strip()).strip()
                    if value.lower() == 'true':
                        config[key] = True
                    elif value.lower() == 'false':
                        config[key] = False
                    elif value.isdigit():
                        config[key] = int(value)
                    else:
                        try:
                            # Accept French decimal notation (comma) as well as dot
                            config[key] = float(value.replace(',', '.'))
                        except ValueError:
                            config[key] = value

        config.setdefault('FORCE_NEW_CONNECTION_PER_EMAIL', False)
        config.setdefault('DEBUG_MODE', False)
        config.setdefault('SHOW_ERRORS_IN_PROGRESS', False)
        config.setdefault('MAX_RETRIES', 5)
        config.setdefault('RETRY_DELAY', 1)
        config.setdefault('USE_PROXY', False)
        config.setdefault('PROXY_HOST', '127.0.0.1')
        config.setdefault('PROXY_PORT', 30000)
        config.setdefault('SMTP_SERVER', 'smtp.vialis.net')
        config.setdefault('SMTP_PORT', 25)
        config.setdefault('SMTP_REQUIRE_TLS', True)
        config.setdefault('USE_FIXED_SMTP', True)
        config.setdefault('MX_TARGET_MODE', 'PRIMARY')
        config.setdefault('MX_TARGET_PATTERN', '')
        config.setdefault('TIME_PER_EMAIL_SECONDS', 1.0)
        config.setdefault('THREADS', 1)
        config.setdefault('USE_MULTI_PORT_MODE', False)
        config.setdefault('MULTI_PORT_START', 30000)
        config.setdefault('MULTI_PORT_COUNT', 3)
        config.setdefault('LINKS_FILE', 'liens.txt')
        config.setdefault('USE_AUTH_MODE', False)
        config.setdefault('USE_RESEND_API', False)
        config.setdefault('RESEND_FROM', '')
        config.setdefault('RESEND_REPLY_TO', '')
        config.setdefault('USE_SENDBYTE_API', False)
        config.setdefault('SENDBYTE_FROM', '')
        config.setdefault('SENDBYTE_REPLY_TO', '')
        config.setdefault('SMTP_ACCOUNTS_FILE', 'smtp.txt')
        config.setdefault('MAX_ACTIVE_SMTP', 5)
        config.setdefault('AUTH_SMTP_SERVER', 'AUTO')
        config.setdefault('AUTH_SMTP_PORT', 587)
        config.setdefault('USE_SEQUENTIAL_MODE', True)
        config.setdefault('MAX_SIMULTANEOUS_SMTP', 3)
        config.setdefault('TOKEN_LENGTH', 12)
        config.setdefault('TOKEN_FORMAT', 'Ref-####-########')
        config.setdefault('USERNAME_MODE', 'FIXED_SINGLE')
        config.setdefault('USERNAME_FORMAT', '')
        config.setdefault('SENDER_DOMAIN', 'vialis.net')
        config.setdefault('ENVELOPE_SENDER_DOMAIN', '')
        config.setdefault('VISIBLE_FROM', '')
        config.setdefault('rDNS_SENDER_DOMAIN', False)
        config.setdefault('ADD_TOKEN_TO_SUBJECT', True)
        config.setdefault('SENDER_DOMAIN_ROTATE', False)
        config.setdefault('SENDER_DOMAIN_List', 'dom.txt')
        config.setdefault('EMAILS_PER_DOMAIN_ROTATION', 100)
        config.setdefault('PORT_ROTATE', False)
        config.setdefault('EMAILS_PER_PORT_ROTATION', 50)
        config.setdefault('ERRORS_PER_PORT_ROTATION', 2)
        config.setdefault('PORT_RANGE_START', 30000)
        config.setdefault('PORT_RANGE_END', 30010)
        config.setdefault('MAX_CONSECUTIVE_ERRORS', 2)
        config.setdefault('USE_BCC_MODE', False)
        config.setdefault('BCC_TO_ADDRESS', 'keevcloud@gmail.com')
        config.setdefault('BCC_TO_NAME', 'Keev Cloud')
        config.setdefault('BCC_BATCH_SIZE', 50)
        config.setdefault('INCLUDE_DOMAIN_IN_SENDER_NAME', False)

        # NOUVEAUX PARAMÈTRES IP REINFORCE
        config.setdefault('USE_IP_REINFORCE', False)
        config.setdefault('MAX_ERRORS_BEFORE_REINFORCE', 10)
        config.setdefault('REINFORCE_WARMUP_COUNT', 5)
        config.setdefault('REINFORCE_DURATION', 60)
        config.setdefault('REINFORCE_WAIT_TIME', 3)
        config.setdefault('CLEAN_EMAILS_FILE', 'clean.txt')
        config.setdefault('WARMUP_MODE', 'ADVANCED')
        config.setdefault('CONTROL_FILE', 'control.json')

        # WARM EN BOUCLE INFINIE
        config.setdefault('WARM_BOUCLE', False)
        config.setdefault('BOUCLE_TIME', 20)

        # FONCTIONNALITÉS PORTÉES DEPUIS send.php
        # DKIM réel (RSA-SHA256 avec pkey.pem - comme send.php openssl_sign)
        # Activé par défaut si pkey.pem est présent dans le répertoire courant
        pkey_default = os.path.exists(config.get('DKIM_PRIVATE_KEY_FILE', 'pkey.pem')) or os.path.exists('pkey.pem')
        config.setdefault('DKIM_ENABLED', pkey_default)
        config.setdefault('DKIM_PRIVATE_KEY_FILE', 'pkey.pem')
        config.setdefault('DKIM_SELECTOR', 'default')
        config.setdefault('DKIM_SIGNING_DOMAIN', '')
        # Encodage du sujet (0=plain, 1=base64, 2=quoted-printable - comme send.php bamessenctype)
        config.setdefault('SUBJECT_ENCODING', 0)
        # Obfuscation homoglyphe du sujet (comme send.php obfuxt())
        config.setdefault('OBFUXT_SUBJECT', False)

        # SYSTÈME DE TEMPLATES LETTRE ALÉATOIRE
        config.setdefault('LETTER_RANDOM', False)
        config.setdefault('LETTER_TO_IMG', False)
        config.setdefault('LETTER_PREVIEW_TEXT', '')
        config.setdefault('LOGO_CID_ENABLED', True)
        config.setdefault('COLOR', '#e5001a')
        config.setdefault('LOGO', '')
        config.setdefault('LOGO_FILE', '')
        config.setdefault('COMPANY_NAME', '')
        config.setdefault('BASE_TEXT_FILE', 'base.txt')
        config.setdefault('MENTIONS_LEGALES', '')

        # VÉRIFICATION D'EXISTENCE DES ADRESSES EMAIL (SMTP VRFY via RCPT TO)
        config.setdefault('Check', False)
        config.setdefault('CHECK_TIMEOUT', 10)
        config.setdefault('CHECK_FROM', 'check@example.com')
        config.setdefault('GOOD_FILE', 'good.txt')
        config.setdefault('BAD_FILE', 'bad.txt')
        config.setdefault('CHECKV2_ENABLED', False)
        config.setdefault('CHECKV2_ACCOUNTS_FILE', 'imap.txt')
        config.setdefault('CHECKV2_MAILBOX_SCOPE', 'INBOX')
        config.setdefault('CHECKV2_MAX_CONCURRENT_ACCOUNTS', 20)
        config.setdefault('CHECKV2_INITIAL_WAIT', 60)
        config.setdefault('CHECKV2_POLL_INTERVAL', 3)
        config.setdefault('CHECKV2_BATCH_SIZE', 20)
        config.setdefault('CHECKV2_BATCH_WAIT', 20)
        config.setdefault('CHECKV2_RECENT_NDR_LIMIT', 10)
        config.setdefault('CHECKV2_MIN_ADAPTIVE_WAIT', 10)

        return config

    except Exception as e:
        print_colored(f"[-] Erreur lecture fichier de configuration: {e}", Colors.RED)
        sys.exit(1)

def verify_security_code(local_code):
    try:
        print_colored("[*] Vérification du code de sécurité...", Colors.YELLOW)
        response = requests.get("https://kevhillyas14.github.io/pass/moi.txt", timeout=10)
        if response.status_code == 200:
            remote_code = response.text.strip()
            if local_code == remote_code:
                print_colored("[+] Vérification du code de sécurité : OK", Colors.GREEN)
                return True
            else:
                print_colored("[-] Code de sécurité invalide. Exécution interrompue.", Colors.RED)
                return False
        else:
            print_colored(f"[-] Impossible de vérifier le code de sécurité. Status code: {response.status_code}", Colors.RED)
            return False
    except Exception as e:
        print_colored(f"[-] Erreur lors de la vérification du code de sécurité : {e}", Colors.RED)
        return False

def setup_proxy(config):
    if config.get('USE_PROXY', False) and not config.get('USE_MULTI_PORT_MODE', False):
        try:
            proxy_host = config.get('PROXY_HOST', '127.0.0.1')
            proxy_port = get_current_port()
            print_colored(f"[+] Configuration du proxy SOCKS5 sur {proxy_host}:{proxy_port}", Colors.CYAN)
            socks.set_default_proxy(socks.SOCKS5, proxy_host, proxy_port)
            socket.socket = socks.socksocket
            return True
        except Exception as e:
            print_colored(f"[-] Erreur configuration proxy: {e}", Colors.RED)
            return False
    return False

def get_ip_and_rdns():
    global SERVER_RDNS
    try:
        print_colored("[*] Récupération de l'adresse IP publique...", Colors.YELLOW)
        ip = requests.get("https://api.ipify.org", timeout=10).text
        try:
            SERVER_RDNS = socket.gethostbyaddr(ip)[0]
        except socket.herror:
            SERVER_RDNS = f"mx{ip.replace('.', '-')}.mailserver.com"
        print_colored(f"[+] Adresse IP publique : {ip}", Colors.GREEN)
        print_colored(f"[+] rDNS : {SERVER_RDNS}", Colors.GREEN)
        return ip, SERVER_RDNS
    except Exception as e:
        SERVER_RDNS = "mailserver-proxy.local"
        print_colored(f"[-] Erreur lors de la récupération de l'IP/rDNS : {e}", Colors.RED)
        return None, SERVER_RDNS

def read_html_file(file_path):
    try:
        with open(file_path, "r", encoding="utf-8") as html_file:
            content = html_file.read()
            print_colored(f"[+] Fichier HTML chargé : {file_path}", Colors.GREEN)
            print_colored(f"[🎨] HTML préservé sans modification - {len(content)} caractères", Colors.BOLD)
            link_count = content.count('##lien##')
            if link_count > 0:
                print_colored(f"[🔗] {link_count} pattern(s) ##lien## détecté(s) pour remplacement aléatoire", Colors.CYAN)
            else:
                print_colored(f"[ℹ️] Aucun pattern ##lien## détecté dans le HTML", Colors.YELLOW)
            return content
    except Exception as e:
        print_colored(f"[-] Erreur lecture fichier HTML : {e}", Colors.RED)
        return "<html><body>Erreur de chargement du contenu</body></html>"


def prepare_fixed_message_logo(message):
    """Conserve l'URL directe ou prépare le logo en CID selon la configuration."""
    if not CONFIG.get('LOGO_CID_ENABLED', True):
        print_colored(
            "[+] Logo CID désactivé : l'URL d'image du HTML est conservée.",
            Colors.CYAN,
        )
        return message
    logo_path = str(CONFIG.get('LOGO_FILE', '')).strip()
    image_source = find_logo_image_source(message)
    source_kind = None
    if image_source and image_source.lower().startswith(('http://', 'https://')):
        source_kind = 'distant'
    elif image_source and image_source.lower().startswith('data:'):
        source_kind = 'Base64'

    if source_kind:
        try:
            destination_dir = os.path.join(
                os.path.dirname(os.path.abspath(__file__)),
                'uploads',
            )
            if source_kind == 'distant':
                logo_path = download_logo_image(image_source, destination_dir)
            else:
                logo_path = extract_base64_logo_image(image_source, destination_dir)
            CONFIG['LOGO_FILE'] = logo_path
            CONFIG['LOGO'] = 'cid:yoda-email-logo'
            print_colored(
                f"[+] Logo {source_kind} de la lettre fixe stocké : {logo_path}",
                Colors.GREEN,
            )
        except Exception as exc:
            print_colored(
                f"[!] Impossible de préparer le logo {source_kind} "
                f"de la lettre fixe : {exc}",
                Colors.YELLOW,
            )

    if not logo_path or not os.path.isfile(logo_path):
        return message
    prepared, replaced = replace_logo_image_source(message, 'cid:yoda-email-logo')
    if replaced:
        print_colored(
            "[+] Logo détecté et intégré dans le message HTML fixe",
            Colors.GREEN,
        )
    else:
        print_colored(
            "[!] Logo chargé, mais aucune balise <img> détectée dans le message HTML fixe",
            Colors.YELLOW,
        )
    return prepared

def attach_files(msg, attachments):
    for filepath in attachments:
        if os.path.isfile(filepath):
            try:
                ctype, encoding = mimetypes.guess_type(filepath)
                if ctype is None or encoding is not None:
                    ctype = 'application/octet-stream'
                maintype, subtype = ctype.split('/', 1)
                with open(filepath, 'rb') as f:
                    file_data = f.read()
                part = MIMEBase(maintype, subtype)
                part.set_payload(file_data)
                encoders.encode_base64(part)
                filename = os.path.basename(filepath)
                encoded_filename = quote(filename)
                part.add_header(
                    'Content-Disposition', 
                    f'attachment; filename="{filename}"; filename*=UTF-8\'\'{encoded_filename}'
                )
                msg.attach(part)
                print_colored(f"[+] Pièce jointe ajoutée : {filepath}", Colors.GREEN)
            except Exception as e:
                print_colored(f"[-] Erreur ajout pièce jointe {filepath} : {e}", Colors.RED)

def get_mx_records(domain):
    """Résout et met en cache tous les MX d'un domaine, triés par priorité."""
    normalized_domain = str(domain).strip().lower().rstrip('.')
    if not normalized_domain:
        return []
    if normalized_domain in MX_CACHE:
        return list(MX_CACHE[normalized_domain])
    try:
        resolved_records = dns.resolver.resolve(normalized_domain, 'MX')
        ordered_records = sorted(
            resolved_records,
            key=lambda record: (
                int(record.preference),
                str(record.exchange).lower(),
            ),
        )
        mx_servers = []
        for record in ordered_records:
            mx_server = str(record.exchange).rstrip('.')
            if mx_server and mx_server not in mx_servers:
                mx_servers.append(mx_server)
        MX_CACHE[normalized_domain] = mx_servers
        return list(mx_servers)
    except Exception as e:
        if CONFIG.get('SHOW_ERRORS_IN_PROGRESS', False):
            print_colored(f"[-] Erreur résolution MX pour {normalized_domain} : {e}", Colors.RED)
        return []


def get_mx_record(domain, apply_target=True):
    """
    Sélectionne un seul MX pour le message courant.

    PRIMARY conserve le comportement historique. ALL fait une rotation parmi
    tous les MX. MATCH fait la même rotation uniquement parmi les noms qui
    contiennent MX_TARGET_PATTERN, sans tenir compte de la casse.
    """
    mx_servers = get_mx_records(domain)
    if not mx_servers:
        return None

    if not apply_target:
        return mx_servers[0]

    mode = str(CONFIG.get('MX_TARGET_MODE', 'PRIMARY')).strip().upper()
    if mode not in {'PRIMARY', 'ALL', 'MATCH'}:
        mode = 'PRIMARY'

    pattern = str(CONFIG.get('MX_TARGET_PATTERN', '')).strip().lower().rstrip('.')
    if mode == 'PRIMARY':
        return mx_servers[0]
    if mode == 'MATCH':
        if not pattern:
            return None
        mx_servers = [
            mx_server
            for mx_server in mx_servers
            if pattern in mx_server.lower()
        ]
        if not mx_servers:
            if CONFIG.get('SHOW_ERRORS_IN_PROGRESS', False):
                print_colored(
                    f"[-] Aucun MX de {domain} ne contient « {pattern} ».",
                    Colors.RED,
                )
            return None

    selection_key = (
        str(domain).strip().lower().rstrip('.'),
        mode,
        pattern if mode == 'MATCH' else '',
    )
    with MX_SELECTION_LOCK:
        selection_index = MX_SELECTION_COUNTERS.get(selection_key, 0)
        MX_SELECTION_COUNTERS[selection_key] = selection_index + 1
    return mx_servers[selection_index % len(mx_servers)]

def save_failed_email(email):
    try:
        with open('fail.txt', 'a', encoding='utf-8') as f:
            f.write(f"{email}\n")
    except Exception as e:
        pass

def clear_fail_file():
    try:
        with open('fail.txt', 'w', encoding='utf-8') as f:
            f.write("")
        print_colored("[+] Fichier fail.txt initialisé", Colors.GREEN)
    except Exception as e:
        print_colored(f"[-] Erreur initialisation fail.txt: {e}", Colors.RED)

def save_good_email(email):
    """Enregistre une adresse valide dans good.txt"""
    try:
        good_file = CONFIG.get('GOOD_FILE', 'good.txt')
        with open(good_file, 'a', encoding='utf-8') as f:
            f.write(f"{email}\n")
    except Exception:
        pass

def save_bad_email(email):
    """Enregistre une adresse invalide dans bad.txt"""
    try:
        bad_file = CONFIG.get('BAD_FILE', 'bad.txt')
        with open(bad_file, 'a', encoding='utf-8') as f:
            f.write(f"{email}\n")
    except Exception:
        pass

def verify_email_exists(email):
    """
    Vérifie l'existence d'une adresse email en interrogeant le serveur MX du domaine.
    Utilise MAIL FROM + RCPT TO sans envoyer de message réel.
    Retourne True si l'adresse existe, False sinon.
    """
    timeout   = int(CONFIG.get('CHECK_TIMEOUT', 10))
    from_addr = CONFIG.get('CHECK_FROM', 'check@example.com')

    try:
        domain = email.split('@')[1]
    except IndexError:
        return False

    # Résolution MX
    # Le vérificateur doit contrôler le domaine réel, indépendamment du filtre
    # d'acheminement choisi pour les campagnes SMTP directes.
    mx_server = get_mx_record(domain, apply_target=False)
    if not mx_server:
        print_colored(f"[⚠️] CHECK: Pas de MX pour {domain} → {email} → bad.txt", Colors.YELLOW)
        return False

    smtp_conn = None
    try:
        # Connexion directe : host + port en types corrects
        smtp_conn = open_smtp(str(mx_server), 25, timeout=timeout)
        smtp_conn.ehlo()
        smtp_conn.mail(from_addr)
        code, _ = smtp_conn.rcpt(email)
        try:
            smtp_conn.rset()
            smtp_conn.quit()
        except Exception:
            pass

        # 250 = OK, 251/252 = redirigé/non vérifié mais accepté
        return code in (250, 251, 252)

    except smtplib.SMTPRecipientsRefused:
        return False
    except smtplib.SMTPConnectError as e:
        print_colored(f"[⚠️] CHECK: Connexion refusée à {mx_server}: {e}", Colors.YELLOW)
        return False
    except smtplib.SMTPServerDisconnected:
        return False
    except Exception as e:
        print_colored(f"[⚠️] CHECK: Erreur vérification {email}: {e}", Colors.YELLOW)
        return False
    finally:
        if smtp_conn is not None:
            try:
                smtp_conn.close()
            except Exception:
                pass

def run_email_check(emails):
    """
    Vérifie l'existence de chaque adresse de la liste.
    Enregistre les valides dans good.txt, les invalides dans bad.txt.
    """
    global REINFORCE_ERRORS

    good_file = CONFIG.get('GOOD_FILE', 'good.txt')
    bad_file  = CONFIG.get('BAD_FILE', 'bad.txt')

    print_colored(f"\n[🔍] VÉRIFICATION DES ADRESSES EMAIL (Check=true)", Colors.BOLD)
    print_colored(f"[📁] Résultats → {good_file} (valides) | {bad_file} (invalides)", Colors.CYAN)
    print_colored(f"[📋] {len(emails)} adresses à vérifier...\n", Colors.CYAN)

    good_count = 0
    bad_count  = 0

    for i, email in enumerate(emails, 1):
        exists = verify_email_exists(email)
        if exists:
            save_good_email(email)
            good_count += 1
            print_colored(f"[✅] ({i}/{len(emails)}) {email} → good.txt", Colors.GREEN)
        else:
            save_bad_email(email)
            bad_count += 1
            REINFORCE_ERRORS += 1
            timestamp = datetime.now().strftime("%H:%M:%S")
            print_colored(f"[❌] ({i}/{len(emails)}) {email} → bad.txt", Colors.RED)

            # Vérifier le seuil d'erreurs pour IP Reinforce (jamais en mode AUTH)
            max_errors = CONFIG.get('MAX_ERRORS_BEFORE_REINFORCE', 10)
            if REINFORCE_ERRORS >= max_errors and CONFIG.get('USE_IP_REINFORCE', False) and not CONFIG.get('USE_AUTH_MODE', False):
                print_colored(f"[{timestamp}] ⚠️ SEUIL D'ERREURS ATTEINT ({REINFORCE_ERRORS}/{max_errors}) → Reinforce déclenché", Colors.RED)
                trigger_reinforce_and_wait(email, i, REINFORCE_ERRORS)
                REINFORCE_ERRORS = 0

    print_colored(f"\n[📊] VÉRIFICATION TERMINÉE", Colors.BOLD)
    print_colored(f"[✅] Adresses valides   : {good_count} → {good_file}", Colors.GREEN)
    print_colored(f"[❌] Adresses invalides : {bad_count}  → {bad_file}", Colors.RED)
    print_colored(f"[📋] Total vérifié      : {len(emails)}", Colors.CYAN)

def send_emails_sequential(recipient_emails, subject, message, attachments=None):
    """Mode normal séquentiel avec connexions persistantes ou multi-ports ou multithread"""
    global email_counter, success_counter, error_counter, start_time, REINFORCE_ERRORS, CURRENT_EMAIL_INDEX

    start_time = time.time()
    email_counter = 0
    success_counter = 0
    error_counter = 0
    REINFORCE_ERRORS = 0

    threads_count = CONFIG.get('THREADS', 1)
    if (not CONFIG.get('USE_AUTH_MODE', False) and 
        not CONFIG.get('USE_FIXED_SMTP', False) and 
        not CONFIG.get('USE_PROXY', False) and 
        threads_count > 1):
        print_colored("[+] 🧵 CONDITIONS REMPLIES POUR LE MODE MULTITHREAD HAUTE PERFORMANCE", Colors.BOLD)
        print_colored(f"[+] USE_AUTH_MODE=false, USE_FIXED_SMTP=false, USE_PROXY=false, THREADS={threads_count}", Colors.CYAN)
        send_emails_multithreaded_normal_mode(recipient_emails, subject, message, attachments)
        return

    if CONFIG.get('USE_MULTI_PORT_MODE', False):
        print_colored("[+] 🌐 MODE MULTI-PORTS INTELLIGENT + LIENS ALÉATOIRES SÉLECTIONNÉ", Colors.BOLD)
        send_emails_multi_port_mode(recipient_emails, subject, message, attachments)
        return

    print_colored("[+] DÉMARRAGE EN MODE NORMAL SÉQUENTIEL + CONNEXIONS INTELLIGENTES + LIENS ALÉATOIRES", Colors.GREEN)
    print_colored(f"[+] {len(recipient_emails)} emails à envoyer", Colors.CYAN)
    print_colored("[+] 🛡️ Protection anti-spam maximale avec headers ultra-réalistes", Colors.MAGENTA)
    print_colored("[+] 🎨 HTML préservé sans modification", Colors.BOLD)
    print_colored("[+] 🔗 Liens aléatoires différents pour chaque email", Colors.BOLD)

    time_per_email = CONFIG.get('TIME_PER_EMAIL_SECONDS', 1.0)
    print_colored(f"[⏱️] Débit configuré: {1/time_per_email:.1f} emails/seconde", Colors.CYAN)

    if CONFIG.get('USE_BCC_MODE', False):
        print_colored("[+] 📮 MODE BCC: Connexions avec rotation normale + liens aléatoires par batch", Colors.YELLOW)
    else:
        print_colored("[+] 💾 MODE PERSISTANT: Une connexion réutilisée pour tous les emails", Colors.GREEN)

    if CONFIG.get('PORT_ROTATE', False):
        print_colored("[+] 🔄 ROTATION AUTOMATIQUE DES PORTS ACTIVÉE", Colors.GREEN)

    start_index = CURRENT_EMAIL_INDEX
    for i in range(start_index, len(recipient_emails)):
        recipient_email = recipient_emails[i]
        CURRENT_EMAIL_INDEX = i

        # Vérifier le statut du reinforce
        control_data = read_control_file()
        if control_data.get("status") == "reinforce" and control_data.get("mode") == "reinforce":
            print_colored(f"[⏸️] Reinforce en cours, en attente...", Colors.YELLOW)
            wait_for_reinforce_complete()

        print_colored(f"\n[📧] Envoi {i+1}/{len(recipient_emails)}: {recipient_email}", Colors.CYAN)

        send_start_time = time.time()
        success = send_email_normal_mode(recipient_email, subject, message, attachments)
        send_elapsed = time.time() - send_start_time

        if send_elapsed < time_per_email:
            if time_per_email > 0.0:
                time.sleep(time_per_email - send_elapsed)

        if i % 50 == 0 or i == len(recipient_emails) - 1:
            print_statistics()

        if i < len(recipient_emails) - 1:
            if email_counter % EMAILS_PER_DELAY == 0:
                print_colored(f"[⏸️] Pause automatique de {DELAY_SECONDS} seconde(s) après {EMAILS_PER_DELAY} emails...", Colors.YELLOW)
                time.sleep(DELAY_SECONDS)

    close_normal_mode_connection()
    print_colored(f"\n[✅] ENVOI SÉQUENTIEL NORMAL + LIENS ALÉATOIRES TERMINÉ", Colors.GREEN)

def send_email_normal_mode(recipient_email, subject, message, attachments=None):
    """Envoie un email en mode normal avec connexion persistante"""
    global email_counter, success_counter, error_counter, REINFORCE_ERRORS

    max_retries = CONFIG.get('MAX_RETRIES', 5)
    retry_delay = CONFIG.get('RETRY_DELAY', 1)

    # Vérifier le statut du reinforce
    control_data = read_control_file()
    if control_data.get("status") == "reinforce" and control_data.get("mode") == "reinforce":
        print_colored(f"[⏸️] Reinforce en cours, en attente...", Colors.YELLOW)
        wait_for_reinforce_complete()

    for retry in range(max_retries):
        server = None
        try:
            sender_email = get_sender_email(recipient_email)
            sender_name = CONFIG.get('SENDER_NAME', '')

            if CONFIG.get('SENDER_DOMAIN_ROTATE', False):
                emails_per_domain = CONFIG.get('EMAILS_PER_DOMAIN_ROTATION', 100)
                if domain_email_counter >= emails_per_domain:
                    rotate_to_next_domain()

            increment_domain_counter()
            personalized_message = replace_random_links_in_content(message)
            token = generate_token()
            final_subject = build_final_subject(subject, token)

            if CONFIG.get('USE_FIXED_SMTP', True):
                mail_server = CONFIG.get('SMTP_SERVER', 'smtp.vialis.net')
                server_port = CONFIG.get('SMTP_PORT', 25)
            else:
                recipient_domain = recipient_email.split('@')[1]
                mail_server = get_mx_record(recipient_domain)
                if not mail_server:
                    raise Exception(f"Impossible de résoudre MX pour {recipient_domain}")
                server_port = 25

            server = get_normal_mode_smtp_connection(mail_server, server_port)
            if not server:
                raise Exception("Impossible d'établir une connexion SMTP")

            msg = MIMEMultipart()
            msg['From'] = get_visible_from_header(sender_email)
            msg['To'] = recipient_email
            msg['Subject'] = final_subject
            msg['Date'] = formatdate(localtime=True)
            msg['Message-ID'] = generate_message_id_enhanced(sender_email.split('@')[1])
            msg = add_ultra_enhanced_anti_spam_headers(msg, sender_email, recipient_email, token)
            delivery_content = prepare_delivery_content(personalized_message)
            attach_delivery_content(msg, delivery_content)
            if attachments:
                attach_files(msg, attachments)

            server.sendmail(sender_email, [recipient_email], finalize_email(msg, sender_email))

            success_counter += 1
            email_counter += 1
            increment_port_counters(success=True)

            timestamp = datetime.now().strftime("%H:%M:%S")
            if CONFIG.get('USE_BCC_MODE', False):
                print_colored(f"[{timestamp}] ✓ {sender_email} → {recipient_email} [Ref-{token}] [HTML+LIENS] via {mail_server}", Colors.GREEN)
            else:
                print_colored(f"[{timestamp}] ✓ PERSISTANT: {sender_email} → {recipient_email} [Ref-{token}] [HTML+LIENS] via {mail_server}", Colors.GREEN)

            update_control_file(error_count=REINFORCE_ERRORS)
            record_campaign_result(recipient_email, True)

            if CONFIG.get('USE_BCC_MODE', False):
                close_smtp_connection(server)
            return True

        except Exception as e:
            error_counter += 1
            email_counter += 1
            REINFORCE_ERRORS += 1
            increment_port_counters(success=False)

            timestamp = datetime.now().strftime("%H:%M:%S")
            sender_email = get_sender_email(recipient_email) if 'sender_email' not in locals() else sender_email

            # Vérifier le seuil d'erreurs pour IP Reinforce (jamais en mode AUTH)
            max_errors = CONFIG.get('MAX_ERRORS_BEFORE_REINFORCE', 10)
            if REINFORCE_ERRORS >= max_errors and CONFIG.get('USE_IP_REINFORCE', False) and not CONFIG.get('USE_AUTH_MODE', False):
                print_colored(f"[{timestamp}] ⚠️ SEUIL D'ERREURS ATTEINT ({REINFORCE_ERRORS}/{max_errors})", Colors.RED)
                print_colored(f"[{timestamp}] 🔄 Déclenchement du reinforce...", Colors.MAGENTA)

                current_idx = 0
                if recipient_email in RECIPIENT_EMAILS:
                    current_idx = RECIPIENT_EMAILS.index(recipient_email)

                trigger_reinforce_and_wait(
                    recipient_email, current_idx, REINFORCE_ERRORS
                )
                REINFORCE_ERRORS = 0
                continue

            if retry < max_retries - 1:
                print_colored(f"[{timestamp}] ⚠️ Tentative {retry + 1}/{max_retries}: {sender_email} → {recipient_email} - {e}", Colors.YELLOW)
                check_and_rotate_port_if_needed()
                close_normal_mode_connection()
                time.sleep(retry_delay)
            else:
                print_colored(f"[{timestamp}] ✗ ÉCHEC FINAL: {sender_email} → {recipient_email} - {e}", Colors.RED)
                save_failed_email(recipient_email)
                close_normal_mode_connection()
                update_control_file(error_count=REINFORCE_ERRORS)
                record_campaign_result(recipient_email, False)

    return False

# ===============================================
# FONCTION PRINCIPALE
# ===============================================

def main():
    global CONFIG, RECIPIENT_EMAILS, CURRENT_EMAIL_INDEX, REINFORCE_ERRORS, start_time
    global SMTP_ACCOUNTS, VALID_SMTP_ACCOUNTS, current_smtp_index, smtp_rotation_counter
    global TEST_MAIL_SUCCESS_COUNT

    if len(sys.argv) < 2:
        print_colored("Usage:", Colors.RED)
        print_colored("  python send.py config.txt              - Mode envoi normal", Colors.CYAN)
        print_colored("  python send.py config.txt reinforce   - Mode reinforce (écoute)", Colors.CYAN)
        print_colored("  python send.py config.txt warm_boucle - Warm infini sur clean.txt", Colors.CYAN)
        print_colored("  python send.py config.txt checkv2     - Validation SMTP/IMAP + Resend ou SMTP AUTH", Colors.CYAN)
        sys.exit(1)

    config_path = sys.argv[1]
    mode_arg = sys.argv[2].lower() if len(sys.argv) > 2 else ""
    is_checkv2_mode = mode_arg == "checkv2"
    is_warm_boucle_mode = mode_arg == "warm_boucle"
    is_reinforce_mode = mode_arg in ("reinforce", "warm_boucle")

    print_banner()

    CONFIG = parse_config_file(config_path)
    TEST_MAIL_SUCCESS_COUNT = 0
    if is_warm_boucle_mode:
        # Le raccourci CLI doit garder la même sémantique que le bouton
        # d'interface, qui lance reinforce avec WARM_BOUCLE=true.
        CONFIG['WARM_BOUCLE'] = True

    if is_checkv2_mode and not CONFIG.get('CHECKV2_ENABLED', False):
        print_colored(
            "[-] CHECKV2 est désactivé. Activez CHECKV2_ENABLED=true dans config.txt.",
            Colors.RED,
        )
        sys.exit(1)
    if is_checkv2_mode:
        CONFIG['_CHECKV2_ACTIVE'] = True

    if is_reinforce_mode:
        # Les fournisseurs API gèrent eux-mêmes leur réputation et ne doivent
        # jamais basculer vers le transport SMTP de warmup.
        active_managed_provider = next(
            (
                label
                for key, label in (
                    ('USE_SENDBYTE_API', 'SENDBYTE API'),
                    ('USE_RESEND_API', 'RESEND API'),
                    ('USE_AUTH_MODE', 'AUTH SMTP'),
                )
                if CONFIG.get(key, False)
            ),
            None,
        )
        if active_managed_provider:
            print_colored(
                f"\n[⛔] MODE {active_managed_provider} ACTIF — Reinforce et Warm Boucle désactivés.",
                Colors.RED,
            )
            print_colored(
                "[ℹ️] La réputation est gérée par le fournisseur d'envoi.",
                Colors.YELLOW,
            )
            sys.exit(0)

    init_port_counters()
    load_links()
    initialize_enhanced_ip_pools()
    clear_fail_file()

    if is_reinforce_mode:
        if CONFIG.get('WARM_BOUCLE', False):
            # WARM_BOUCLE=true → boucle infinie sur clean.txt, pas d'écoute
            print_colored(f"\n[🔁] WARM BOUCLE ACTIVÉ (reinforce sans écoute)", Colors.BOLD)
            print_colored(f"[📊] Intervalle: {_parse_boucle_time(CONFIG.get('BOUCLE_TIME', 20))} min", Colors.CYAN)
            print_colored(f"[📊] Mode warmup: {CONFIG.get('WARMUP_MODE', 'ADVANCED')}", Colors.CYAN)
            print_colored(f"[📊] Fichier clean: {CONFIG.get('CLEAN_EMAILS_FILE', 'clean.txt')}", Colors.CYAN)
            run_warm_boucle()
        else:
            print_colored(f"\n[🔄] MODE REINFORCE ACTIVÉ", Colors.BOLD)
            print_colored(f"[📋] En écoute sur {CONTROL_FILE}", Colors.CYAN)
            print_colored(f"[📊] Seuil d'erreurs: {CONFIG.get('MAX_ERRORS_BEFORE_REINFORCE', 10)}", Colors.CYAN)
            print_colored(f"[📊] Durée du reinforce: {CONFIG.get('REINFORCE_DURATION', 60)}s", Colors.CYAN)
            print_colored(f"[📊] Warmups: {CONFIG.get('REINFORCE_WARMUP_COUNT', 5)}", Colors.CYAN)
            print_colored(f"[📊] Mode warmup: {CONFIG.get('WARMUP_MODE', 'ADVANCED')}", Colors.CYAN)
            print_colored(f"[📊] Fichier clean: {CONFIG.get('CLEAN_EMAILS_FILE', 'clean.txt')}", Colors.CYAN)
            run_reinforce_mode()
        sys.exit(0)

    print_colored(f"\n[📧] MODE {'CHECKV2' if is_checkv2_mode else 'ENVOI'} ACTIVÉ", Colors.BOLD)

    # CHECKV2 contrôle toujours la liste d'envoi principale, même si une
    # autre liste est configurée pour un mode d'envoi classique.
    email_list_file = 'liste.txt' if is_checkv2_mode else CONFIG.get('EMAIL_LIST_FILE', 'liste.txt')
    try:
        with open(email_list_file, "r", encoding='utf-8') as file:
            RECIPIENT_EMAILS = [line.strip() for line in file if '@' in line]
        print_colored(f"[+] {len(RECIPIENT_EMAILS)} emails chargés depuis {email_list_file}", Colors.GREEN)
    except Exception as e:
        print_colored(f"[-] Erreur lecture liste emails: {e}", Colors.RED)
        sys.exit(1)

    if is_checkv2_mode:
        use_resend_api = bool(CONFIG.get('USE_RESEND_API', False))
        use_auth_mode = bool(CONFIG.get('USE_AUTH_MODE', False))
        if use_resend_api and use_auth_mode:
            print_colored(
                "[-] CHECKV2 nécessite un seul transport : Resend ou SMTP AUTH.",
                Colors.RED,
            )
            sys.exit(1)
        if not use_resend_api and not use_auth_mode:
            print_colored(
                "[-] CHECKV2 nécessite USE_RESEND_API=true ou USE_AUTH_MODE=true.",
                Colors.RED,
            )
            sys.exit(1)
        resend_from_config = str(CONFIG.get('RESEND_FROM', '')).strip()
        configured_name, resend_from = parseaddr(resend_from_config)
        if not resend_from:
            resend_from = resend_from_config
        if use_resend_api and '@' not in resend_from:
            print_colored(
                "[-] CHECKV2 nécessite RESEND_FROM avec une adresse vérifiée dans Resend.",
                Colors.RED,
            )
            sys.exit(1)
        if use_resend_api:
            sender_name = str(CONFIG.get('SENDER_NAME', '')).strip() or configured_name
            formatted_sender_name = format_sender_name(sender_name, resend_from)
            resend_from = formataddr((formatted_sender_name, resend_from))
        if use_auth_mode:
            SMTP_ACCOUNTS = []
            VALID_SMTP_ACCOUNTS = []
            load_smtp_accounts()
            if not SMTP_ACCOUNTS:
                print_colored(
                    "[-] CHECKV2 en SMTP AUTH nécessite au moins un compte dans smtp.txt.",
                    Colors.RED,
                )
                sys.exit(1)
            if CONFIG.get('_COORDINATED_ACCOUNTS'):
                VALID_SMTP_ACCOUNTS = list(SMTP_ACCOUNTS)
            else:
                validate_all_smtp_accounts()
            if not VALID_SMTP_ACCOUNTS:
                print_colored(
                    "[-] Aucun compte SMTP AUTH valide trouvé dans smtp.txt.",
                    Colors.RED,
                )
                sys.exit(1)
            current_smtp_index = 0
            smtp_rotation_counter = 0

        subject = str(CONFIG.get('EMAIL_SUBJECT', '')).strip()
        if not subject:
            print_colored("[-] CHECKV2 nécessite EMAIL_SUBJECT.", Colors.RED)
            sys.exit(1)
        if CONFIG.get('LETTER_RANDOM', False) and not AVAILABLE_LINKS:
            print_colored(
                "[-] CHECKV2 avec LETTER_RANDOM=true nécessite au moins un lien "
                "dans liens.txt.",
                Colors.RED,
            )
            sys.exit(1)
        message = read_html_file(CONFIG.get('MESSAGE_FILE', 'message.html'))
        if not CONFIG.get('LETTER_RANDOM', False):
            message = prepare_fixed_message_logo(message)
        reply_to = str(CONFIG.get('RESEND_REPLY_TO', '')).strip() or None
        delivery_label = "SMTP AUTH" if use_auth_mode else "Resend"
        attachment_dir = CONFIG.get('ATTACHMENT_DIR', 'attachments')
        attachments = [
            os.path.join(attachment_dir, filename)
            for filename in os.listdir(attachment_dir)
            if os.path.isfile(os.path.join(attachment_dir, filename))
        ] if os.path.isdir(attachment_dir) else []

        init_control_file()
        CONFIG['_CHECKV2_ACTIVE'] = True
        update_control_file(
            mode="checkv2",
            status="running",
            total_sent=0,
            total_errors=0,
            total_recipients=len(RECIPIENT_EMAILS),
            processed_count=0,
            email_index=0,
        )

        def _stop_requested():
            return stop_requested_for(read_control_file(), "checkv2")

        def _send_validated_email(recipient):
            try:
                if use_auth_mode:
                    smtp_account = get_next_smtp_account_sequential()
                    if not smtp_account:
                        return False, "aucun compte SMTP AUTH disponible"
                    success = send_email_with_auth(
                        smtp_account,
                        recipient,
                        subject,
                        message,
                        attachments,
                    )
                    if not success:
                        raise RuntimeError(
                            f"échec SMTP AUTH via {smtp_account['email']}"
                        )
                    message_id = f"SMTP AUTH via {smtp_account['email']}"
                else:
                    personalized_message = replace_random_links_in_content(message)
                    delivery_content = prepare_delivery_content(personalized_message)
                    try:
                        result = send_resend_email(
                            sender=resend_from,
                            recipients=[recipient],
                            subject=subject,
                            html_content=delivery_content['html'],
                            text_content=delivery_content.get('text') or None,
                            reply_to=reply_to,
                            attachments=attachments,
                            inline_attachments=delivery_content['inline_assets'],
                        )
                    finally:
                        cleanup_delivery_content(delivery_content)
                    message_id = result.get("id", "accepté")
                print(
                    f"[CHECKV2→ENVOI] ✓ {recipient} validé puis envoyé "
                    f"via {delivery_label} ({message_id})"
                )
                record_campaign_result(recipient, True)
                return True, str(message_id)
            except ResendError as error:
                print(
                    f"[CHECKV2→ENVOI] ✗ {recipient} validé mais Resend "
                    f"a refusé l'envoi : {error}"
                )
                record_campaign_result(recipient, False)
                return False, str(error)
            except Exception as error:
                print(
                    f"[CHECKV2→ENVOI] ✗ {recipient} validé mais {delivery_label} "
                    f"a refusé l'envoi : {error}"
                )
                record_campaign_result(recipient, False)
                return False, str(error)

        try:
            run_checkv2(
                RECIPIENT_EMAILS,
                CONFIG,
                _send_validated_email,
                lambda line: print_colored(line, Colors.CYAN),
                _stop_requested,
            )
        except RuntimeError as error:
            print_colored(f"[-] CHECKV2 : {error}", Colors.RED)
            update_control_file(status="error")
            sys.exit(1)
        update_control_file(status="idle", stop_target=None)
        sys.exit(0)

    # -------------------------------------------------------
    # MODE CHECK : vérification des adresses avant envoi
    # -------------------------------------------------------
    if CONFIG.get('Check', False):
        run_email_check(RECIPIENT_EMAILS)
        sys.exit(0)

    control_data = read_control_file()
    if control_data.get("status") == "reinforce":
        print_colored(f"[⏸️] Reinforce en cours, en attente...", Colors.YELLOW)
        wait_for_reinforce_complete()

    init_control_file()
    update_control_file(
        mode="send",
        status="running",
        total_sent=0,
        total_errors=0,
        total_recipients=len(RECIPIENT_EMAILS),
        processed_count=0,
        email_index=0,
        error_count=0
    )

    use_resend_api = CONFIG.get('USE_RESEND_API', False)
    use_sendbyte_api = CONFIG.get('USE_SENDBYTE_API', False)
    use_auth_mode = CONFIG.get('USE_AUTH_MODE', False)
    active_providers = [
        label
        for enabled, label in (
            (use_sendbyte_api, 'SendByte'),
            (use_resend_api, 'Resend'),
            (use_auth_mode, 'AUTH SMTP'),
        )
        if enabled
    ]
    if len(active_providers) > 1:
        print_colored(
            "[-] Configuration invalide : choisissez un seul fournisseur d'envoi "
            f"({', '.join(active_providers)} sont actifs).",
            Colors.RED,
        )
        sys.exit(1)

    if use_sendbyte_api:
        print_colored("[+] Transport SendByte sélectionné — les paramètres SMTP et proxy sont ignorés.", Colors.CYAN)
    elif use_resend_api:
        print_colored("[+] Transport Resend sélectionné — les paramètres SMTP et proxy sont ignorés.", Colors.CYAN)
    elif use_auth_mode:
        load_smtp_accounts()
        if not SMTP_ACCOUNTS:
            print_colored("[-] Aucun compte SMTP AUTH trouvé dans smtp.txt.", Colors.RED)
            sys.exit(1)
        validate_all_smtp_accounts()
        if not VALID_SMTP_ACCOUNTS:
            print_colored("[-] Aucun compte SMTP valide trouvé", Colors.RED)
            sys.exit(1)
    else:
        if CONFIG.get('USERNAME_MODE') == 'FIXED_MULTIPLE':
            load_fixed_users()
        if CONFIG.get('SENDER_DOMAIN_ROTATE', False):
            load_sender_domains()
        get_ip_and_rdns()

    if (not (use_resend_api or use_sendbyte_api)
            and CONFIG.get('USE_PROXY', False)
            and not CONFIG.get('USE_MULTI_PORT_MODE', False)):
        setup_proxy(CONFIG)
        print_colored(f"[+] 🔄 ROTATION DES PORTS : {'ACTIVÉE' if CONFIG.get('PORT_ROTATE', False) else 'DÉSACTIVÉE'}", Colors.GREEN)

    message_file = CONFIG.get('MESSAGE_FILE', 'message.html')
    message = read_html_file(message_file)

    if CONFIG.get('LETTER_RANDOM', False):
        print_colored("[+] 📧 LETTER_RANDOM activé : template + synonymes uniques par destinataire", Colors.GREEN)
    else:
        message = prepare_fixed_message_logo(message)

    attachment_dir = CONFIG.get('ATTACHMENT_DIR', 'attachments')
    attachments = []
    if os.path.exists(attachment_dir) and os.path.isdir(attachment_dir):
        attachments = [
            os.path.join(attachment_dir, f)
            for f in os.listdir(attachment_dir)
            if os.path.isfile(os.path.join(attachment_dir, f))
        ]
        if attachments:
            print_colored(f"[+] {len(attachments)} pièces jointes", Colors.GREEN)

    subject = CONFIG.get('EMAIL_SUBJECT', '')
    if not subject:
        print_colored("[-] Configuration incomplète: sujet manquant", Colors.RED)
        sys.exit(1)

    if (use_resend_api
            and '@' not in str(CONFIG.get('RESEND_FROM', '')).strip()):
        print_colored(
            "[-] Configuration Resend incomplète : renseignez RESEND_FROM avec "
            "une adresse vérifiée dans Resend.",
            Colors.RED,
        )
        sys.exit(1)
    if (use_sendbyte_api
            and '@' not in str(CONFIG.get('SENDBYTE_FROM', '')).strip()):
        print_colored(
            "[-] Configuration SendByte incomplète : renseignez SENDBYTE_FROM avec "
            "une adresse vérifiée dans SendByte.",
            Colors.RED,
        )
        sys.exit(1)

    print_colored(f"[+] Sujet : {subject}", Colors.CYAN)

    if CONFIG.get('USE_IP_REINFORCE', False) and not (use_resend_api or use_sendbyte_api):
        print_colored(f"[+] 🛡️ IP Reinforce activé (seuil: {CONFIG.get('MAX_ERRORS_BEFORE_REINFORCE', 10)})", Colors.GREEN)
        print_colored(f"[+] 📋 Reinforce en mode {CONFIG.get('WARMUP_MODE', 'ADVANCED')}", Colors.GREEN)

    if CONFIG.get('USE_MULTI_PORT_MODE', False) and not (use_resend_api or use_sendbyte_api):
        if initialize_multi_port_connections():
            print_colored("[+] 🌐 MODE MULTI-PORTS ACTIVÉ", Colors.GREEN)
            send_emails_multi_port_mode(RECIPIENT_EMAILS, subject, message, attachments)
            close_multi_port_connections()
        else:
            CONFIG['USE_MULTI_PORT_MODE'] = False

    if use_sendbyte_api:
        send_emails_with_sendbyte(RECIPIENT_EMAILS, subject, message, attachments)
    elif use_resend_api:
        send_emails_with_resend(RECIPIENT_EMAILS, subject, message, attachments)
    elif CONFIG.get('USE_AUTH_MODE', False):
        print_colored("[+] 🚀 MODE AUTH ACTIVÉ", Colors.GREEN)
        send_emails_with_auth_mode(RECIPIENT_EMAILS, subject, message, attachments)
    else:
        send_emails_sequential(RECIPIENT_EMAILS, subject, message, attachments)

    print_colored(f"\n{'='*70}", Colors.BLUE)
    print_colored("🚀 RAPPORT FINAL", Colors.BOLD)

    if use_auth_mode:
        print_statistics_auth()
    else:
        print_statistics()

    print_connection_pool_stats()

    if CONFIG.get('USE_MULTI_PORT_MODE', False):
        print_multi_port_stats()

    if CONFIG.get('USE_IP_REINFORCE', False):
        print_reinforce_stats()

    if start_time is not None:
        elapsed_time = time.time() - start_time
        print_colored(f"[+] Opération terminée en {elapsed_time:.2f} secondes", Colors.GREEN)

    if use_auth_mode:
        close_all_smtp_connections()
    else:
        close_normal_mode_connection()

    update_control_file(status="idle", stop_target=None)

if __name__ == "__main__":
    main()