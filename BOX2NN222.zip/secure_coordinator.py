"""Small transactional coordinator shared by SMTP_CHECK and campaign workers.

The coordinator deliberately keeps the credential-bearing database private
(0600) and exposes only non-secret status through the web application.
"""

from __future__ import annotations

import hashlib
import os
import sqlite3
import threading
import time
import uuid
from contextlib import closing
from pathlib import Path
from typing import Iterable


class SecureCoordinator:
    def __init__(self, app_dir: str | os.PathLike[str], filename: str = "smtp_coordinator.sqlite3"):
        self.path = Path(app_dir) / filename
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._initialize()

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(
            self.path,
            timeout=30,
            isolation_level=None,
            check_same_thread=False,
        )
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA busy_timeout=30000")
        connection.execute("PRAGMA journal_mode=WAL")
        connection.execute("PRAGMA synchronous=FULL")
        for sidecar in (Path(f"{self.path}-wal"), Path(f"{self.path}-shm")):
            try:
                if sidecar.exists():
                    os.chmod(sidecar, 0o600)
            except OSError:
                pass
        return connection

    def _initialize(self) -> None:
        with self._lock, closing(self._connect()) as db:
            db.executescript(
                """
                CREATE TABLE IF NOT EXISTS runs (
                    run_id TEXT PRIMARY KEY,
                    run_seq INTEGER,
                    status TEXT NOT NULL,
                    warning TEXT NOT NULL DEFAULT '',
                    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
                );
                CREATE TABLE IF NOT EXISTS accounts (
                    account_key TEXT PRIMARY KEY,
                    email TEXT NOT NULL,
                    password TEXT NOT NULL,
                    server TEXT NOT NULL,
                    port INTEGER NOT NULL,
                    run_id TEXT NOT NULL,
                    stage1 TEXT NOT NULL DEFAULT 'pending',
                    stage2 TEXT NOT NULL DEFAULT 'pending',
                    status TEXT NOT NULL DEFAULT 'pending',
                    warning TEXT NOT NULL DEFAULT '',
                    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
                );
                CREATE INDEX IF NOT EXISTS accounts_status_idx
                    ON accounts(status);
                CREATE TABLE IF NOT EXISTS recipient_claims (
                    campaign_id TEXT NOT NULL,
                    recipient TEXT NOT NULL,
                    account_key TEXT NOT NULL,
                    status TEXT NOT NULL DEFAULT 'claimed',
                    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY(campaign_id, recipient)
                );
                CREATE TABLE IF NOT EXISTS warnings (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    run_id TEXT NOT NULL,
                    account_key TEXT NOT NULL,
                    message TEXT NOT NULL,
                    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
                );
                CREATE TABLE IF NOT EXISTS validated_account_cache (
                    account_key TEXT PRIMARY KEY,
                    email TEXT NOT NULL,
                    password TEXT NOT NULL,
                    server TEXT NOT NULL,
                    port INTEGER NOT NULL,
                    validated_run_id TEXT NOT NULL,
                    validated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
                );
                CREATE TABLE IF NOT EXISTS smtp_check_messages (
                    message_id TEXT PRIMARY KEY,
                    run_id TEXT NOT NULL,
                    account_email TEXT NOT NULL,
                    recipient TEXT NOT NULL,
                    stage INTEGER NOT NULL,
                    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
                );
                CREATE INDEX IF NOT EXISTS smtp_check_messages_account_idx
                    ON smtp_check_messages(account_email);
                CREATE TABLE IF NOT EXISTS campaign_leases (
                    lease_key TEXT PRIMARY KEY,
                    run_id TEXT NOT NULL,
                    campaign_id TEXT NOT NULL,
                    owner TEXT NOT NULL,
                    acquired_at REAL NOT NULL,
                    expires_at REAL NOT NULL
                );
                """
            )
            # Older coordinator databases predate the monotonic run identity.
            # Backfill from rowid once, then all new runs use run_seq.
            columns = {
                row["name"]
                for row in db.execute("PRAGMA table_info(runs)").fetchall()
            }
            if "run_seq" not in columns:
                db.execute("ALTER TABLE runs ADD COLUMN run_seq INTEGER")
            db.execute(
                "UPDATE runs SET run_seq=COALESCE(run_seq,rowid) "
                "WHERE run_seq IS NULL"
            )
            db.execute(
                "CREATE INDEX IF NOT EXISTS runs_seq_idx ON runs(run_seq DESC)"
            )
            try:
                os.chmod(self.path, 0o600)
            except OSError:
                pass
            for sidecar in (Path(f"{self.path}-wal"), Path(f"{self.path}-shm")):
                try:
                    if sidecar.exists():
                        os.chmod(sidecar, 0o600)
                except OSError:
                    pass

    @staticmethod
    def account_key(
        email: str, server: str, port: int, password: str = ""
    ) -> str:
        # Include the credential fingerprint: changing a password must force
        # SMTP_CHECK to retest the account rather than reuse old validation.
        value = (
            f"{email.strip().lower()}|{server.strip().lower()}|{int(port)}|"
            f"{password}"
        )
        return hashlib.sha256(value.encode("utf-8")).hexdigest()

    @staticmethod
    def account_key_for_account(account: dict) -> str:
        return SecureCoordinator.account_key(
            account["email"],
            account["server"],
            account["port"],
            str(account.get("password") or ""),
        )

    def begin_run(self, run_id: str, accounts: Iterable[dict]) -> None:
        with self._lock, closing(self._connect()) as db:
            db.execute("BEGIN IMMEDIATE")
            next_seq = db.execute(
                "SELECT COALESCE(MAX(run_seq),0)+1 AS next_seq FROM runs"
            ).fetchone()["next_seq"]
            db.execute(
                "INSERT OR REPLACE INTO runs(run_id,run_seq,status,warning,updated_at) "
                "VALUES(?,?,?,?,CURRENT_TIMESTAMP)",
                (run_id, next_seq, "running", ""),
            )
            for account in accounts:
                key = self.account_key_for_account(account)
                db.execute(
                    "INSERT OR REPLACE INTO accounts("
                    "account_key,email,password,server,port,run_id,stage1,stage2,status,warning,updated_at"
                    ") VALUES(?,?,?,?,?,?, 'pending','pending','pending','',CURRENT_TIMESTAMP)",
                    (
                        key,
                        account["email"],
                        account["password"],
                        account["server"],
                        int(account["port"]),
                        run_id,
                    ),
                )
            db.execute("COMMIT")

    def update_stage(
        self,
        run_id: str,
        account: dict,
        stage: int,
        status: str,
        warning: str = "",
    ) -> None:
        key = self.account_key_for_account(account)
        column = "stage1" if int(stage) == 1 else "stage2"
        with self._lock, closing(self._connect()) as db:
            db.execute("BEGIN IMMEDIATE")
            db.execute(
                f"UPDATE accounts SET {column}=?, warning=?, updated_at=CURRENT_TIMESTAMP "
                "WHERE account_key=? AND run_id=?",
                (status, warning[:500], key, run_id),
            )
            db.execute(
                "UPDATE accounts SET status=CASE WHEN stage1='confirmed' AND stage2='confirmed' "
                "THEN 'validated' WHEN stage1='failed' OR stage2='failed' THEN 'failed' "
                "ELSE status END, updated_at=CURRENT_TIMESTAMP WHERE account_key=? AND run_id=?",
                (key, run_id),
            )
            if warning:
                db.execute(
                    "INSERT INTO warnings(run_id,account_key,message) VALUES(?,?,?)",
                    (run_id, key, warning[:500]),
                )
            db.execute("COMMIT")

    def publish_validated(self, run_id: str, account: dict) -> None:
        key = self.account_key_for_account(account)
        with self._lock, closing(self._connect()) as db:
            db.execute("BEGIN IMMEDIATE")
            cursor = db.execute(
                "UPDATE accounts SET status='validated', updated_at=CURRENT_TIMESTAMP "
                "WHERE account_key=? AND run_id=? AND stage1='confirmed' AND stage2='confirmed'",
                (key, run_id),
            )
            if cursor.rowcount == 1:
                db.execute(
                    "INSERT OR REPLACE INTO validated_account_cache("
                    "account_key,email,password,server,port,validated_run_id,validated_at"
                    ") VALUES(?,?,?,?,?,?,CURRENT_TIMESTAMP)",
                    (
                        key,
                        account["email"],
                        account["password"],
                        account["server"],
                        int(account["port"]),
                        run_id,
                    ),
                )
            db.execute("COMMIT")

    def finish_run(self, run_id: str, status: str, warning: str = "") -> None:
        with self._lock, closing(self._connect()) as db:
            db.execute(
                "UPDATE runs SET status=?,warning=?,updated_at=CURRENT_TIMESTAMP WHERE run_id=?",
                (status, warning[:500], run_id),
            )

    def cached_validated_accounts(self, accounts: Iterable[dict]) -> list[dict]:
        """Return only exact, previously double-confirmed fingerprints."""
        candidates = [
            self.account_key_for_account(account) for account in accounts
        ]
        if not candidates:
            return []
        placeholders = ",".join("?" for _ in candidates)
        with self._lock, closing(self._connect()) as db:
            rows = db.execute(
                "SELECT account_key,email,password,server,port "
                "FROM validated_account_cache "
                f"WHERE account_key IN ({placeholders}) ",
                candidates,
            ).fetchall()
        return [dict(row) for row in rows]

    def seed_cached_validated(
        self, run_id: str, accounts: Iterable[dict]
    ) -> int:
        seeded = 0
        with self._lock, closing(self._connect()) as db:
            db.execute("BEGIN IMMEDIATE")
            for account in accounts:
                key = self.account_key_for_account(account)
                cursor = db.execute(
                    "UPDATE accounts SET stage1='confirmed',stage2='confirmed',"
                    "status='validated',warning='',updated_at=CURRENT_TIMESTAMP "
                    "WHERE account_key=? AND run_id=?",
                    (key, run_id),
                )
                seeded += cursor.rowcount
            db.execute("COMMIT")
        return seeded

    def record_smtp_check_messages(
        self,
        run_id: str,
        account_email: str,
        stage: int,
        message_ids: dict[str, str],
    ) -> None:
        """Persist sent test IDs without storing any credential material."""
        rows = [
            (
                message_id.strip(),
                run_id,
                account_email,
                recipient,
                int(stage),
            )
            for recipient, message_id in message_ids.items()
            if str(message_id).strip()
        ]
        if not rows:
            return
        with self._lock, closing(self._connect()) as db:
            db.executemany(
                "INSERT OR REPLACE INTO smtp_check_messages("
                "message_id,run_id,account_email,recipient,stage"
                ") VALUES(?,?,?,?,?)",
                rows,
            )

    def smtp_check_message_metadata(self) -> list[dict]:
        with self._lock, closing(self._connect()) as db:
            rows = db.execute(
                "SELECT message_id,run_id,account_email,recipient,stage "
                "FROM smtp_check_messages ORDER BY created_at, rowid"
            ).fetchall()
        return [dict(row) for row in rows]

    def latest_run(self) -> dict | None:
        with self._lock, closing(self._connect()) as db:
            row = db.execute(
                "SELECT run_id,run_seq,status,warning,created_at,updated_at FROM runs "
                "ORDER BY run_seq DESC, rowid DESC LIMIT 1"
            ).fetchone()
        return dict(row) if row else None

    def list_validated(self) -> list[dict]:
        with self._lock, closing(self._connect()) as db:
            latest = db.execute(
                "SELECT run_id FROM runs ORDER BY run_seq DESC, rowid DESC LIMIT 1"
            ).fetchone()
            if not latest:
                return []
            rows = db.execute(
                "SELECT email,password,server,port,account_key FROM accounts "
                "WHERE status='validated' AND run_id=? ORDER BY rowid",
                (latest["run_id"],),
            ).fetchall()
        return [dict(row) for row in rows]

    def public_status(self) -> dict:
        with self._lock, closing(self._connect()) as db:
            run = db.execute(
                "SELECT run_id,run_seq,status,warning,created_at,updated_at FROM runs "
                "ORDER BY run_seq DESC, rowid DESC LIMIT 1"
            ).fetchone()
            accounts = db.execute(
                "SELECT email,server,port,stage1,stage2,status,warning "
                "FROM accounts WHERE run_id=? ORDER BY rowid",
                (run["run_id"],) if run else (None,),
            ).fetchall()
            warnings = db.execute(
                "SELECT message,created_at FROM warnings "
                "WHERE run_id=? ORDER BY id DESC LIMIT 50",
                (run["run_id"],) if run else ("",),
            ).fetchall()
        return {
            "run": dict(run) if run else None,
            "accounts": [dict(row) for row in accounts],
            "warnings": [dict(row) for row in warnings],
        }

    def claim_recipient(self, campaign_id: str, recipient: str, account_key: str) -> bool:
        """Atomically claim a recipient; a second worker can never send it."""
        with self._lock, closing(self._connect()) as db:
            try:
                db.execute(
                    "INSERT INTO recipient_claims(campaign_id,recipient,account_key) "
                    "VALUES(?,?,?)",
                    (campaign_id, recipient.strip().lower(), account_key),
                )
                return True
            except sqlite3.IntegrityError:
                return False

    def campaign_complete(self, campaign_id: str) -> bool:
        """True when this campaign has claims and every claim is terminal."""
        with self._lock, closing(self._connect()) as db:
            row = db.execute(
                "SELECT COUNT(*) AS total, "
                "SUM(CASE WHEN status IN ('sent','failed') THEN 1 ELSE 0 END) "
                "AS terminal FROM recipient_claims WHERE campaign_id=?",
                (campaign_id,),
            ).fetchone()
        return bool(row and row["total"] and row["terminal"] == row["total"])

    @staticmethod
    def campaign_id_for_run(run_id: str) -> str:
        return f"auth:{run_id}"

    def acquire_campaign_lease(
        self,
        run_id: str,
        owner: str | None = None,
        ttl_seconds: float = 300,
    ) -> dict | None:
        """Acquire the single AUTH campaign lease for a run atomically."""
        owner = owner or uuid.uuid4().hex
        campaign_id = self.campaign_id_for_run(run_id)
        now = time.time()
        expires = now + max(30.0, float(ttl_seconds))
        with self._lock, closing(self._connect()) as db:
            db.execute("BEGIN IMMEDIATE")
            row = db.execute(
                "SELECT run_id,campaign_id,owner,expires_at FROM campaign_leases "
                "WHERE lease_key='auth'",
            ).fetchone()
            if row and float(row["expires_at"]) > now:
                db.execute("COMMIT")
                return None
            db.execute(
                "INSERT OR REPLACE INTO campaign_leases("
                "lease_key,run_id,campaign_id,owner,acquired_at,expires_at"
                ") VALUES('auth',?,?,?,?,?)",
                (run_id, campaign_id, owner, now, expires),
            )
            db.execute("COMMIT")
        return {
            "run_id": run_id,
            "campaign_id": campaign_id,
            "owner": owner,
            "expires_at": expires,
        }

    def renew_campaign_lease(
        self, campaign_id: str, owner: str, ttl_seconds: float = 300
    ) -> bool:
        now = time.time()
        expires = now + max(30.0, float(ttl_seconds))
        with self._lock, closing(self._connect()) as db:
            cursor = db.execute(
                "UPDATE campaign_leases SET expires_at=? "
                "WHERE lease_key='auth' AND campaign_id=? AND owner=? "
                "AND expires_at>?",
                (expires, campaign_id, owner, now),
            )
        return cursor.rowcount == 1

    def bind_campaign_lease(self, owner: str, run_id: str) -> str | None:
        """Bind a pending lease to the monotonic SMTP_CHECK run identity."""
        campaign_id = self.campaign_id_for_run(run_id)
        with self._lock, closing(self._connect()) as db:
            cursor = db.execute(
                "UPDATE campaign_leases SET run_id=?,campaign_id=? "
                "WHERE lease_key='auth' AND owner=? AND expires_at>?",
                (run_id, campaign_id, owner, time.time()),
            )
        return campaign_id if cursor.rowcount == 1 else None

    def release_campaign_lease(self, campaign_id: str, owner: str) -> bool:
        with self._lock, closing(self._connect()) as db:
            cursor = db.execute(
                "DELETE FROM campaign_leases "
                "WHERE lease_key='auth' AND campaign_id=? AND owner=?",
                (campaign_id, owner),
            )
        return cursor.rowcount == 1

    def complete_recipient(self, campaign_id: str, recipient: str, success: bool) -> None:
        with self._lock, closing(self._connect()) as db:
            db.execute(
                "UPDATE recipient_claims SET status=?,updated_at=CURRENT_TIMESTAMP "
                "WHERE campaign_id=? AND recipient=?",
                ("sent" if success else "failed", campaign_id, recipient.strip().lower()),
            )