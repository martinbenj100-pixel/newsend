#!/usr/bin/env node
"use strict";

/*
 * Rend un fichier HTML local en PNG avec Chromium DevTools.
 * L'API Page.captureScreenshot permet de capturer la page complète, sans
 * dépendre d'une bibliothèque Node ou Python supplémentaire.
 */

const { spawn } = require("node:child_process");
const fs = require("node:fs/promises");
const os = require("node:os");
const path = require("node:path");
const { pathToFileURL } = require("node:url");

const [inputPath, outputPath, rawWidth = "720", rawMaxHeight = "12000"] =
  process.argv.slice(2);
const width = Math.max(320, Math.min(1600, Number.parseInt(rawWidth, 10) || 720));
const maxHeight = Math.max(800, Math.min(16000, Number.parseInt(rawMaxHeight, 10) || 12000));

if (!inputPath || !outputPath) {
  console.error("Usage: render_html_to_image.js input.html output.png [width] [maxHeight]");
  process.exit(2);
}

function delay(milliseconds) {
  return new Promise((resolve) => setTimeout(resolve, milliseconds));
}

async function waitForDebugger(browser) {
  let output = "";
  browser.stderr.on("data", (chunk) => {
    output += chunk.toString();
  });

  for (let attempt = 0; attempt < 400; attempt += 1) {
    const match = output.match(/DevTools listening on (ws:\/\/[^\s]+)/);
    if (match) {
      return match[1];
    }
    if (browser.exitCode !== null) {
      throw new Error(`Chromium a quitté prématurément : ${output.trim()}`);
    }
    await delay(50);
  }
  throw new Error(`Démarrage de Chromium trop long après 20 secondes : ${output.trim()}`);
}

function connectCdp(url) {
  return new Promise((resolve, reject) => {
    const socket = new WebSocket(url);
    const pending = new Map();
    let nextId = 1;

    socket.addEventListener("open", () => {
      resolve({
        call(method, params = {}) {
          return new Promise((resolveCall, rejectCall) => {
            const id = nextId++;
            pending.set(id, { resolve: resolveCall, reject: rejectCall });
            socket.send(JSON.stringify({ id, method, params }));
          });
        },
        close() {
          socket.close();
        },
      });
    });

    socket.addEventListener("message", (event) => {
      const message = JSON.parse(event.data);
      const request = pending.get(message.id);
      if (!request) return;
      pending.delete(message.id);
      if (message.error) {
        request.reject(new Error(`${message.error.message || "Erreur Chrome DevTools"}`));
      } else {
        request.resolve(message.result || {});
      }
    });

    socket.addEventListener("error", () => {
      reject(new Error("Impossible de se connecter à Chromium DevTools."));
    });

    socket.addEventListener("close", () => {
      for (const request of pending.values()) {
        request.reject(new Error("La connexion Chromium DevTools a été fermée."));
      }
      pending.clear();
    });
  });
}

async function main() {
    const profileDirectory = await fs.mkdtemp(path.join(os.tmpdir(), "yoda-letter-browser-"));
  const chrome = process.env.CHROMIUM_BIN || "chromium";
  const browser = spawn(
    chrome,
    [
      "--headless=new",
      "--no-sandbox",
      "--disable-gpu",
      "--disable-dev-shm-usage",
      "--hide-scrollbars",
      "--force-color-profile=srgb",
      "--allow-file-access-from-files",
      "--remote-debugging-port=0",
      `--user-data-dir=${profileDirectory}`,
      `--window-size=${width},800`,
      "--run-all-compositor-stages-before-draw",
      pathToFileURL(path.resolve(inputPath)).href,
    ],
    { stdio: ["ignore", "ignore", "pipe"] },
  );

  try {
    // Chrome picks an ephemeral port with --remote-debugging-port=0; recover it
    // from the debugger URL before querying the targets.
    const browserUrl = await waitForDebugger(browser);
    const debuggerPort = new URL(browserUrl).port;
    const pages = await (await fetch(`http://127.0.0.1:${debuggerPort}/json/list`)).json();
    const page = pages.find((target) => target.type === "page");
    if (!page || !page.webSocketDebuggerUrl) {
      throw new Error("Aucune page Chromium disponible pour rendre la lettre.");
    }

    const cdp = await connectCdp(page.webSocketDebuggerUrl);
    try {
      await cdp.call("Page.enable");
      await delay(350);
      await cdp.call("Runtime.evaluate", {
        expression: "document.fonts ? document.fonts.ready.then(() => true) : true",
        awaitPromise: true,
      });
      const metrics = await cdp.call("Page.getLayoutMetrics");
      const content = metrics.contentSize || { width, height: 800 };
      const captureWidth = Math.max(width, Math.ceil(content.width || width));
      const fullHeight = Math.max(1, Math.ceil(content.height || 800));
      const captureHeight = Math.min(fullHeight, maxHeight);
      if (fullHeight > maxHeight) {
        console.error(`La lettre dépasse ${maxHeight}px ; elle a été limitée à cette hauteur.`);
      }
      const screenshot = await cdp.call("Page.captureScreenshot", {
        format: "png",
        fromSurface: true,
        captureBeyondViewport: true,
        clip: { x: 0, y: 0, width: captureWidth, height: captureHeight, scale: 1 },
      });
      await fs.writeFile(outputPath, Buffer.from(screenshot.data, "base64"));
    } finally {
      cdp.close();
    }
  } finally {
    if (browser.exitCode === null) {
      browser.kill("SIGTERM");
      await new Promise((resolve) => browser.once("exit", resolve));
    }
    await fs.rm(profileDirectory, {
      recursive: true,
      force: true,
      maxRetries: 5,
      retryDelay: 200,
    });
  }
}

main().catch((error) => {
  console.error(error instanceof Error ? error.message : String(error));
  process.exit(1);
});