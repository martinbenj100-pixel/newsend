"""Rendu local de lettres HTML vers une image PNG inline."""

from __future__ import annotations

import os
import shutil
import subprocess
import tempfile
import hashlib
import threading
from collections import OrderedDict
from html import escape as html_escape
from pathlib import Path
from typing import Final


class LetterImageError(RuntimeError):
    """Le rendu de la lettre HTML n'a pas pu être terminé."""


_PROJECT_DIR: Final = Path(__file__).resolve().parent
_RENDERER: Final = _PROJECT_DIR / "render_html_to_image.js"
_MAX_OUTPUT_BYTES: Final = 10 * 1024 * 1024
_PNG_SIGNATURE: Final = b"\x89PNG\r\n\x1a\n"
_RENDER_CACHE_MAX_ENTRIES: Final = 4
_RENDER_LOCK: Final = threading.Lock()
_RENDER_CACHE: Final = OrderedDict()
_CHROMIUM_NAMES: Final = (
    "chromium",
    "chromium-browser",
    "google-chrome-stable",
    "google-chrome",
    "chrome",
)
_CHROMIUM_PATHS: Final = (
    "/repl/tools/bin/chromium",
    "/usr/bin/chromium",
    "/usr/bin/chromium-browser",
    "/usr/bin/google-chrome-stable",
    "/usr/bin/google-chrome",
    *sorted(
        _win for _win in (
            os.path.join(p, "Google", "Chrome", "Application", "chrome.exe")
            for p in (
                os.environ.get("ProgramFiles", r"C:\Program Files"),
                os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)"),
            )
        )
    ),
    os.path.join(
        os.environ.get("ProgramFiles", r"C:\Program Files"),
        "Google", "Application", "chrome.exe",
    ),
    os.path.join(
        os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)"),
        "Google", "Application", "chrome.exe",
    ),
)


def _absolute_path(path: str | os.PathLike[str] | None) -> Path | None:
    if not path:
        return None
    candidate = Path(path)
    return candidate if candidate.is_absolute() else (_PROJECT_DIR / candidate)


def find_chromium_binary() -> str | None:
    """Trouve Chromium dans les environnements Replit de dev et de déploiement."""
    configured = str(
        os.environ.get("CHROMIUM_BIN")
        or os.environ.get("CHROME_BIN")
        or ""
    ).strip()
    if configured and Path(configured).is_file() and os.access(configured, os.X_OK):
        return configured
    for name in _CHROMIUM_NAMES:
        resolved = shutil.which(name)
        if resolved:
            return resolved
    for candidate in _CHROMIUM_PATHS:
        if Path(candidate).is_file() and os.access(candidate, os.X_OK):
            return candidate
    return None


def _insert_base_tag(content: str, base_uri: str) -> str:
    base_tag = f'<base href="{html_escape(base_uri, quote=True)}">'
    head_index = content.lower().find("<head")
    if head_index >= 0:
        closing = content.find(">", head_index)
        if closing >= 0:
            return content[: closing + 1] + base_tag + content[closing + 1 :]
    return f"<html><head>{base_tag}</head><body>{content}</body></html>"


def _prepare_html(
    content: str,
    *,
    source_path: str | os.PathLike[str] | None,
    logo_path: str | os.PathLike[str] | None,
) -> str:
    source = _absolute_path(source_path)
    base_directory = (source.parent if source else _PROJECT_DIR).resolve()
    prepared = _insert_base_tag(content, base_directory.as_uri() + "/")

    logo = _absolute_path(logo_path)
    if logo and logo.is_file():
        prepared = prepared.replace("cid:yoda-email-logo", logo.resolve().as_uri())
    return prepared


def render_html_to_png(
    html_content: str,
    *,
    source_path: str | os.PathLike[str] | None = None,
    logo_path: str | os.PathLike[str] | None = None,
    width: int = 720,
    max_height: int = 12000,
) -> str:
    """Retourne le chemin d'un PNG temporaire représentant la lettre complète."""
    if not isinstance(html_content, str) or not html_content.strip():
        raise LetterImageError("La lettre HTML est vide et ne peut pas être convertie en image.")
    if not _RENDERER.is_file():
        raise LetterImageError("Le script de rendu HTML est introuvable.")

    node = shutil.which("node")
    chromium = find_chromium_binary()
    if not node or not chromium:
        raise LetterImageError(
            "Le rendu HTML nécessite Node.js et Chromium dans l'environnement "
            "d'envoi. Définissez CHROMIUM_BIN si Chromium utilise un chemin personnalisé."
        )

    prepared_html = _prepare_html(
        html_content,
        source_path=source_path,
        logo_path=logo_path,
    )
    cache_key = hashlib.sha256(
        (
            prepared_html
            + f"\0{int(width)}\0{int(max_height)}\0{chromium}"
        ).encode("utf-8")
    ).hexdigest()

    work_dir = Path(tempfile.mkdtemp(prefix="yoda-letter-render-"))
    input_path = work_dir / "letter.html"
    captured_path = work_dir / "letter.png"
    output_descriptor, output_path = tempfile.mkstemp(
        prefix="yoda-letter-", suffix=".png", dir=tempfile.gettempdir()
    )
    os.close(output_descriptor)

    try:
        with _RENDER_LOCK:
            data = _RENDER_CACHE.get(cache_key)
            if data is not None:
                _RENDER_CACHE.move_to_end(cache_key)
            else:
                input_path.write_text(prepared_html, encoding="utf-8")
                result = subprocess.run(
                    [
                        node,
                        str(_RENDERER),
                        str(input_path),
                        str(captured_path),
                        str(width),
                        str(max_height),
                    ],
                    capture_output=True,
                    text=True,
                    encoding="utf-8",
                    errors="replace",
                    timeout=45,
                    env={**os.environ, "CHROMIUM_BIN": chromium},
                    check=False,
                )
                if result.returncode != 0:
                    detail = " ".join((result.stderr or result.stdout or "").split())
                    raise LetterImageError(
                        "Impossible de convertir la lettre HTML en image : "
                        f"{detail or 'Chromium a échoué.'}"
                    )
                if not captured_path.is_file():
                    raise LetterImageError("Chromium n'a produit aucune image de la lettre.")
                data = captured_path.read_bytes()
                if not data.startswith(_PNG_SIGNATURE):
                    raise LetterImageError(
                        "Le rendu de la lettre n'est pas une image PNG valide."
                    )
                if len(data) > _MAX_OUTPUT_BYTES:
                    raise LetterImageError(
                        "L'image de la lettre dépasse 10 Mo ; "
                        "réduisez la taille ou le contenu du HTML."
                    )
                _RENDER_CACHE[cache_key] = data
                _RENDER_CACHE.move_to_end(cache_key)
                while len(_RENDER_CACHE) > _RENDER_CACHE_MAX_ENTRIES:
                    _RENDER_CACHE.popitem(last=False)
        Path(output_path).write_bytes(data)
        return output_path
    except subprocess.TimeoutExpired as exc:
        raise LetterImageError("Le rendu HTML a dépassé le délai de 45 secondes.") from exc
    except Exception:
        try:
            os.unlink(output_path)
        except OSError:
            pass
        raise
    finally:
        shutil.rmtree(work_dir, ignore_errors=True)