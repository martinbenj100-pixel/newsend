# Lancement de YODA Mailer sous Windows

## Prérequis

- Windows 10 ou Windows 11.
- Python 3.13 ou supérieur.
- Node.js 18 ou supérieur si la connexion Resend gérée par Replit est utilisée.
- pnpm 9 ou supérieur si la connexion Resend gérée par Replit est utilisée.
- Les fichiers de configuration du projet (`config.txt`, `liste.txt`,
  `imap.txt`, `message.html`) placés dans le même dossier que `app.py`.

## Installation avec un environnement virtuel

Dans PowerShell, depuis le dossier du projet :

```powershell
cd C:\chemin\vers\le\projet
py -3.13 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -e .
```

Si la connexion Resend gérée par Replit est utilisée, installer aussi la
dépendance Node du pont depuis le même dossier :

```powershell
corepack enable
pnpm install --frozen-lockfile
```

Si la commande `pnpm` n’est pas encore disponible après `corepack enable`,
installer pnpm une fois puis relancer l’installation du projet :

```powershell
npm install --global pnpm
pnpm install --frozen-lockfile
```

Vérifier que le module utilisé par Resend est bien résolu :

```powershell
node -e "console.log(require.resolve('@replit/connectors-sdk'))"
```

## Envoi depuis une copie Windows hors Replit

Une copie locale Windows ne possède pas automatiquement l’identité Replit
(`REPL_IDENTITY` ou `WEB_REPL_RENEWAL`). Pour envoyer depuis Windows, utilisez
l’API Resend directe avec une clé stockée dans le fichier local `API.txt`.
Ce fichier ne doit jamais être partagé, versionné ou ajouté à `config.txt`.

Créez `API.txt` dans le même dossier que `app.py`, avec exactement cette ligne :

```text
RESEND_API_KEY=votre_clé_resend
```

Si `API.txt` n’existe pas, YODA crée automatiquement un modèle vide au
premier appel Resend. Remplacez alors la valeur vide par votre clé locale.
Une fois `RESEND_API_KEY` présente, YODA utilise directement
`https://api.resend.com` et Node.js n’est plus nécessaire pour l’envoi.
La variable d’environnement `RESEND_API_KEY` reste acceptée comme solution de
secours, mais `API.txt` est prioritaire.

Si PowerShell bloque l’activation, l’activation peut être autorisée pour
l’utilisateur courant :

```powershell
Set-ExecutionPolicy -Scope CurrentUser RemoteSigned
```

L’activation n’est pas obligatoire pour lancer l’application avec le chemin
direct vers le Python de l’environnement virtuel :

```powershell
.\.venv\Scripts\python.exe app.py
```

## Lancement

```powershell
.\.venv\Scripts\python.exe app.py
```

Puis ouvrir :

```text
http://localhost:5000
```

L’application résout ses fichiers depuis le dossier de `app.py`, même si le
terminal a été ouvert depuis un autre dossier. Le serveur est arrêté avec
`Ctrl+C`.

## Encodage de la console

L’interface transmet automatiquement UTF-8 à `send.py`. Pour lancer
`send.py` directement dans une ancienne console Windows, ces variables peuvent
être définies dans la session PowerShell :

```powershell
$env:PYTHONUTF8 = "1"
$env:PYTHONIOENCODING = "utf-8"
.\.venv\Scripts\python.exe send.py config.txt checkv2
```

## CHECKV2

Avant de lancer le Vérifieur :

1. Mettre les adresses à contrôler dans `liste.txt`, une par ligne.
2. Vérifier le format de `imap.txt` :
   `provider|adresse|mot_de_passe`.
3. Activer `CHECKV2_ENABLED=true` dans `config.txt`.
4. Activer Resend et renseigner une adresse `RESEND_FROM` vérifiée.
5. Démarrer le serveur avec la commande ci-dessus, puis utiliser l’onglet
   **Vérifieur**.

CHECKV2 lit toujours `imap.txt` et `liste.txt` depuis le dossier du projet.
Les secrets ne doivent pas être ajoutés à ce fichier de documentation.

## Diagnostic rapide

Vérifier les versions :

```powershell
py --version
node --version
python -c "import flask, dns, socks; print('Dépendances Python OK')"
```

Si `uv` n’est pas installé, il n’est pas nécessaire pour Windows : le
lancement avec `.venv\Scripts\python.exe` fonctionne directement. Si Node.js
est absent, l’interface démarre mais l’appel au pont Resend échoue avec un
message explicite.