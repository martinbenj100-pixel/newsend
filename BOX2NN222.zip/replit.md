# YODA Mailer

Application Flask de pilotage d’envois et de vérification d’adresses e-mail.

## Run & Operate

- `python app.py` — run the interface web (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Production: le workflow Replit lance `APP_ENV=production NODE_ENV=production python app.py`.
- Required secrets: `SESSION_SECRET`, `PANEL_PASSWORD`, `RESEND_API_KEY`.
- `RESEND_FROM` reste configuré dans `config.txt` et doit être vérifié dans Resend.

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

## Where things live

- `app.py` : serveur Flask et endpoints de l’interface.
- `templates/` : interface web.
- `send.py` / `checkv2.py` : moteurs d’envoi et de vérification.
- `config.txt` : options non secrètes de l’application.
- `resend_client.py` : transport Resend, alimenté par `RESEND_API_KEY`.

## Architecture decisions

## Architecture decisions

- Le serveur Flask est le point d’entrée de production ; l’ancien scaffold TypeScript est conservé mais n’est pas le serveur public.
- Le déploiement est configuré en autoscale sur le port `PORT` fourni par Replit.
- CHECKV2 charge exclusivement ses comptes depuis `imap.txt`, y compris en publication.
- L’accès au panneau est refusé en production tant que `PANEL_PASSWORD` et `SESSION_SECRET` ne sont pas définis.

## Product

## Product

Panneau d’administration pour configurer une campagne, gérer les comptes SMTP,
lancer les modes d’envoi ou CHECKV2, suivre les journaux en direct et consulter
les résultats.

## User preferences

## User preferences

Aucune préférence persistante enregistrée.

## Gotchas

## Gotchas

- `imap.txt` est requis par CHECKV2 et doit être présent dans l’image de production ; `API.txt`, `pkey.pem` et `smtp.txt` restent exclus.
- `RESEND_FROM` doit être une adresse appartenant à un domaine vérifié dans Resend.
- Les fichiers de campagne écrits localement ne sont pas une base persistante sur Autoscale.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
