import threading
import time
import unittest
from unittest.mock import patch

import send


class SimultaneousAuthWorkerTests(unittest.TestCase):
    def setUp(self):
        self.original_config = dict(send.CONFIG)
        self.original_valid = list(send.VALID_SMTP_ACCOUNTS)
        self.original_accounts = list(send.SMTP_ACCOUNTS)
        send.CONFIG.clear()
        send.CONFIG.update({
            "TIME_PER_EMAIL_SECONDS": 0,
            "USE_AUTH_MODE": True,
        })

    def tearDown(self):
        send.CONFIG.clear()
        send.CONFIG.update(self.original_config)
        send.VALID_SMTP_ACCOUNTS[:] = self.original_valid
        send.SMTP_ACCOUNTS[:] = self.original_accounts

    @staticmethod
    def account(number):
        return {
            "email": f"sender{number}@example.test",
            "password": "secret",
            "smtp_server": "smtp.example.test",
        }

    def run_workers(self, recipients, accounts, cap, sender):
        send.SMTP_ACCOUNTS[:] = accounts
        send.VALID_SMTP_ACCOUNTS[:] = accounts
        with patch.object(send, "wait_for_dynamic_auth_accounts", return_value=True), \
                patch.object(send, "refresh_validated_smtp_accounts"), \
                patch.object(send, "get_smtp_accounts_simultaneous", return_value=accounts[:cap]), \
                patch.object(send, "send_email_with_auth", side_effect=sender), \
                patch.object(send, "complete_coordinator_recipient"), \
                patch.object(send, "close_all_smtp_connections"):
            send.send_emails_simultaneous_individual_mode(
                recipients, "subject", "<p>body</p>", None, cap
            )

    def test_two_workers_overlap_in_real_time(self):
        accounts = [self.account(1), self.account(2)]
        entered = threading.Barrier(2)
        active = 0
        active_lock = threading.Lock()
        overlap = threading.Event()

        def sender(account, *_args):
            nonlocal active
            with active_lock:
                active += 1
                if active == 2:
                    overlap.set()
            entered.wait(timeout=2)
            with active_lock:
                active -= 1
            return True

        self.run_workers(["a@example.test", "b@example.test"], accounts, 2, sender)
        self.assertTrue(overlap.is_set(), "SMTP workers did not overlap")

    def test_worker_count_honors_cap(self):
        accounts = [self.account(i) for i in range(4)]
        active = 0
        maximum = 0
        lock = threading.Lock()

        def sender(_account, *_args):
            nonlocal active, maximum
            with lock:
                active += 1
                maximum = max(maximum, active)
            time.sleep(0.01)
            with lock:
                active -= 1
            return True

        self.run_workers(
            [f"recipient{i}@example.test" for i in range(12)],
            accounts,
            2,
            sender,
        )
        self.assertLessEqual(maximum, 2)
        self.assertGreater(maximum, 1)

    def test_removed_account_does_not_strand_shared_queue(self):
        accounts = [self.account(1), self.account(2)]
        calls = []
        lock = threading.Lock()

        def sender(account, recipient, *_args):
            with lock:
                calls.append((account["email"], recipient))
            if account is accounts[0]:
                # Simulate the failure threshold removing this account while
                # the shared queue still contains work.
                send.VALID_SMTP_ACCOUNTS.remove(account)
                return False
            return True

        recipients = [f"recipient{i}@example.test" for i in range(8)]
        self.run_workers(recipients, accounts, 2, sender)
        self.assertEqual({recipient for _, recipient in calls}, set(recipients))
        self.assertEqual(len(calls), len(recipients))
        self.assertTrue(any(account == accounts[1]["email"] for account, _ in calls))


if __name__ == "__main__":
    unittest.main()