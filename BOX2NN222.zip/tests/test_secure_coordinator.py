import tempfile
import time
import threading
import json
import unittest
from email import message_from_string
from pathlib import Path
from unittest.mock import Mock, patch

from secure_coordinator import SecureCoordinator
from smtp_check import SmtpCheckManager


class SecureCoordinatorTests(unittest.TestCase):
    def test_validated_accounts_and_recipient_claim_are_transactional(self):
        with tempfile.TemporaryDirectory() as directory:
            coordinator = SecureCoordinator(directory)
            account = {
                "email": "sender@example.test",
                "password": "not-exposed-by-api",
                "server": "smtp.example.test",
                "port": 587,
            }
            coordinator.begin_run("run-1", [account])
            coordinator.update_stage("run-1", account, 1, "confirmed")
            coordinator.update_stage("run-1", account, 2, "confirmed")
            coordinator.publish_validated("run-1", account)
            self.assertEqual(coordinator.list_validated()[0]["email"], account["email"])
            self.assertTrue(coordinator.claim_recipient("campaign", "A@EXAMPLE.TEST", "pool"))
            self.assertFalse(coordinator.claim_recipient("campaign", "a@example.test", "pool"))
            public = coordinator.public_status()
            self.assertNotIn("password", repr(public))
            self.assertEqual(Path(directory, "smtp_coordinator.sqlite3").stat().st_mode & 0o777, 0o600)

    def test_stage_headers_and_from_values_are_correlated(self):
        account = {
            "email": "sender@example.test",
            "server": "smtp.example.test",
            "port": 587,
        }
        delivery = {"html": "<p>test</p>", "image_path": None, "preview": ""}
        stage_one = SmtpCheckManager._build_message(
            account, "inbox@example.test", "subject", "run-id", delivery, 1
        )
        stage_two = SmtpCheckManager._build_message(
            account, "inbox@example.test", "subject", "run-id", delivery, 2, "Sender Name"
        )
        first = message_from_string(stage_one.as_string())
        second = message_from_string(stage_two.as_string())
        self.assertEqual(first["From"], account["email"])
        self.assertEqual(second["From"], "Sender Name <sender@example.test>")
        for message, stage in ((first, "1"), (second, "2")):
            self.assertEqual(message["X-Yoda-SMTP-Check"], "run-id")
            self.assertEqual(message["X-Yoda-SMTP-Account"], account["email"])
            self.assertEqual(message["X-Yoda-SMTP-Stage"], stage)
            self.assertIn(f"run-id:{account['email']}:{stage}", message["X-Yoda-SMTP-Correlation"])

    def test_fake_smtp_receives_both_stages_without_network(self):
        class FakeSMTP:
            def __init__(self):
                self.messages = []

            def login(self, *_credentials):
                return "ok"

            def sendmail(self, _sender, _recipients, raw):
                self.messages.append(message_from_string(raw))

            def quit(self):
                return "ok"

        fake = FakeSMTP()
        account = {
            "index": 0,
            "email": "sender@example.test",
            "password": "secret",
            "server": "smtp.example.test",
            "port": 587,
        }
        delivery = {"html": "<p>test</p>", "image_path": None, "preview": ""}
        with patch("smtp_check.open_smtp", return_value=fake), patch(
            "smtp_check.establish_tls"
        ):
            result_one = SmtpCheckManager._send_one(
                account, ["inbox@example.test"], "subject", "run", delivery,
                Mock(is_set=lambda: False), 1, ""
            )
            result_two = SmtpCheckManager._send_one(
                account, ["inbox@example.test"], "subject", "run", delivery,
                Mock(is_set=lambda: False), 2, "Visible Name"
            )
        self.assertEqual(result_one["sent"], 1)
        self.assertEqual(result_two["sent"], 1)
        self.assertEqual(fake.messages[0]["From"], account["email"])
        self.assertEqual(fake.messages[1]["From"], "Visible Name <sender@example.test>")

    def test_explicit_stage_messages_are_safe_and_stage_two_matches_campaign_subject(self):
        account = {
            "index": 0,
            "email": "sender@example.test",
            "password": "secret",
            "server": "smtp.example.test",
            "port": 587,
        }
        delivery = {
            "html": "<html><body>REAL CAMPAIGN</body></html>",
            "image_path": None,
            "preview": "campaign preview",
        }
        config = {
            "REPLY_TO": "reply@example.test",
            "UNSUBSCRIBE_URL": "https://example.test/stop",
        }
        stage_one = message_from_string(
            SmtpCheckManager._build_message(
                account, "inbox@example.test", "Campaign Subject", "run",
                delivery, 1, "Visible Name", config,
            ).as_string()
        )
        stage_two = message_from_string(
            SmtpCheckManager._build_message(
                account, "inbox@example.test", "Campaign Subject", "run",
                delivery, 2, "Visible Name", config,
            ).as_string()
        )
        self.assertEqual(stage_one["Subject"], "SMTP_CHECK STAGE-1")
        self.assertIn(
            "REAL CAMPAIGN",
            stage_one.get_payload(0).get_payload(decode=True).decode(),
        )
        self.assertEqual(stage_one["X-Yoda-SMTP-Check"], "run")
        self.assertEqual(stage_two["Subject"], "Campaign Subject")
        self.assertEqual(stage_two["Reply-To"], "reply@example.test")
        self.assertIn("List-Unsubscribe", stage_two)
        self.assertIsNone(stage_two.get("X-Yoda-SMTP-Check"))
        self.assertIsNotNone(stage_two["Message-ID"])

    def test_message_id_is_the_only_production_imap_correlation(self):
        account = {
            "email": "inbox@example.test",
            "password": "secret",
            "server": "imap.example.test",
            "port": 993,
        }
        smtp_account = {
            "email": "sender@example.test",
            "password": "secret",
            "server": "smtp.example.test",
            "port": 587,
        }
        message = SmtpCheckManager._build_message(
            smtp_account, account["email"], "Campaign Subject", "run",
            {"html": "<p>campaign</p>", "image_path": None, "preview": ""},
            2, "", {},
        )
        message_id = message["Message-ID"]
        raw = message.as_bytes()

        class FakeIMAP:
            def select(self, _mailbox):
                return "OK", [b""]

            def login(self, *_credentials):
                return "OK", [b""]

            def uid(self, operation, _charset, *args):
                if operation == "search":
                    return "OK", [b"1"]
                return "OK", [(b"header", raw)]

            def logout(self):
                return "OK", [b""]

        manager = SmtpCheckManager(tempfile.mkdtemp())
        with patch.object(manager, "_open_imap", return_value=FakeIMAP()):
            found, error = manager._poll_mailbox(
                account, "run", 2, set(), smtp_account["email"],
                {message_id: account["email"]},
            )
        self.assertIsNone(error)
        self.assertEqual(len(found), 1)
        self.assertEqual(found[0]["correlation"], message_id)

    def test_stage_two_visible_from_still_confirms_and_publishes_afterward(self):
        class FakeCoordinator:
            def __init__(self):
                self.events = []

            def begin_run(self, *_args):
                self.events.append("begin")

            def update_stage(self, _run, _account, stage, status, *_args):
                self.events.append(("stage", stage, status))

            def publish_validated(self, _run, _account):
                self.events.append("publish")

            def finish_run(self, *_args):
                self.events.append("finish")

        coordinator = FakeCoordinator()
        manager = SmtpCheckManager(tempfile.mkdtemp(), coordinator=coordinator)
        smtp_account = {
            "index": 0,
            "email": "sender@example.test",
            "password": "secret",
            "server": "smtp.example.test",
            "port": 587,
        }
        mailbox = {
            "email": "inbox@example.test",
            "password": "secret",
            "server": "imap.example.test",
            "port": 993,
        }
        raw_messages = {}
        config = {
            "EMAIL_SUBJECT": "Campaign Subject",
            "SENDER_NAME": "Configured Sender",
            "VISIBLE_FROM": "Visible Name <visible@example.test>",
            "_SMTP_CHECK_SEND": True,
            "SMTP_CHECK_CONFIRM_TIMEOUT": 1,
            "CHECKV2_POLL_INTERVAL": 0.01,
        }
        manager._message_html = lambda _config: "<html><body>campaign</body></html>"
        manager._delivery_template = lambda _config, html: {
            "html": html, "image_path": None, "preview": "",
        }

        def fake_send(account, recipients, subject, run_id, delivery, _stop,
                      stage=1, sender_name="", config=None):
            message = SmtpCheckManager._build_message(
                account, recipients[0], subject, run_id, delivery, stage,
                sender_name, config,
            )
            raw_messages[stage] = message.as_bytes()
            return {
                "sent": 1, "failed": 0, "failures": [],
                "message_ids": {recipients[0].lower(): message["Message-ID"]},
                "cancelled": False,
            }

        manager._send_one = fake_send

        class FakeIMAP:
            def select(self, _mailbox):
                return "OK", [b""]

            def login(self, *_credentials):
                return "OK", [b""]

            def uid(self, operation, _charset, *args):
                if operation == "search":
                    return "OK", [
                        " ".join(str(stage) for stage in sorted(raw_messages)).encode()
                    ]
                uid = _charset.decode("ascii")
                stage = int(uid)
                return "OK", [(b"header", raw_messages[stage])]

            def logout(self):
                return "OK", [b""]

        manager._open_imap = lambda _account: FakeIMAP()
        manager._run(
            config, {"accounts": [mailbox]}, [smtp_account],
            ["inbox@example.test"], "run-visible-from",
        )
        self.assertEqual(
            coordinator.events,
            [
                "begin",
                ("stage", 1, "sent"), ("stage", 1, "confirmed"),
                ("stage", 2, "sent"), ("stage", 2, "confirmed"),
                "publish", "finish",
            ],
        )

    def test_stage_one_reuses_campaign_delivery_for_image_and_random_content(self):
        account = {
            "email": "sender@example.test",
            "password": "secret",
            "server": "smtp.example.test",
            "port": 587,
        }
        with tempfile.NamedTemporaryFile(suffix=".png") as image:
            image.write(b"offline-image")
            image.flush()
            message = SmtpCheckManager._build_message(
                account, "inbox@example.test", "Subject", "run",
                {
                    "html": "<p>campaign</p>",
                    "image_path": image.name,
                    "preview": "preview",
                },
                1,
                "",
                {},
            )
            self.assertTrue(
                any(
                    part.get_content_maintype() == "application"
                    and part.get_payload(decode=True) == b"offline-image"
                    for part in message.walk()
                )
            )

        manager = SmtpCheckManager(tempfile.mkdtemp())
        Path(manager.app_dir, "message.html").write_text(
            "<p>template</p>", encoding="utf-8"
        )
        Path(manager.app_dir, "liens.txt").write_text(
            "https://example.test", encoding="utf-8"
        )
        with patch(
            "smtp_check.build_letter_message",
            return_value="<p>random-rendered</p>",
        ) as builder:
            html = manager._message_html({
                "MESSAGE_FILE": "message.html",
                "LETTER_RANDOM": "true",
                "LINKS_FILE": "liens.txt",
            })
        self.assertEqual(html, "<p>random-rendered</p>")
        builder.assert_called_once()

    def test_concurrent_message_merge_is_persistent_and_deleteable(self):
        manager = SmtpCheckManager(tempfile.mkdtemp())
        messages = [
            {
                "id": f"unstable-{index}",
                "inbox_email": "inbox@example.test",
                "uid": str(index),
                "smtp_account": "sender@example.test",
                "stage": 2,
                "to": "recipient@example.test",
            }
            for index in range(12)
        ]
        workers = [
            threading.Thread(
                target=manager._append_messages,
                args=(messages[index:index + 3],),
            )
            for index in range(0, len(messages), 3)
        ]
        for worker in workers:
            worker.start()
        for worker in workers:
            worker.join()
        manager._update(phase="complete")
        manager.settings_path.write_text(
            '{"accounts":[{"email":"inbox@example.test",'
            '"password":"secret","server":"imap.example.test","port":993}],'
            '"recipients":["inbox@example.test"]}',
            encoding="utf-8",
        )
        snapshot = manager.snapshot()
        self.assertEqual(len(snapshot["messages"]), 12)
        self.assertEqual(snapshot["received"], 12)
        self.assertEqual(
            {item["id"] for item in snapshot["messages"]},
            {f"inbox@example.test:{index}" for index in range(12)},
        )
        deleted = snapshot["messages"][0]["id"]
        with patch.object(manager, "_open_imap") as open_imap:
            client = open_imap.return_value
            client.uid.return_value = ("OK", [])
            client.logout.return_value = ("OK", [])
            manager.delete_message(deleted)
        self.assertNotIn(deleted, {
            item["id"] for item in manager.snapshot()["messages"]
        })

    def test_imap_preflight_success_and_persisted_prior_message_discovery(self):
        directory = tempfile.mkdtemp()
        coordinator = SecureCoordinator(directory)
        manager = SmtpCheckManager(directory, coordinator=coordinator)
        mailbox = {
            "email": "inbox@example.test",
            "password": "secret",
            "server": "imap.example.test",
            "port": 993,
        }
        smtp_account = {
            "email": "sender@example.test",
            "password": "secret",
            "server": "smtp.example.test",
            "port": 587,
        }
        manager.settings_path.write_text(
            json.dumps({"recipients": [mailbox["email"]], "accounts": [mailbox]}),
            encoding="utf-8",
        )
        stage_one = SmtpCheckManager._build_message(
            smtp_account, mailbox["email"], "SMTP_CHECK STAGE-1", "old-run",
            {"html": "<p>campaign</p>", "image_path": None, "preview": ""},
            1, "", {},
        )
        stage_two = SmtpCheckManager._build_message(
            smtp_account, mailbox["email"], "Campaign", "old-run",
            {"html": "<p>campaign</p>", "image_path": None, "preview": ""},
            2, "Sender", {"VISIBLE_FROM": "Visible <visible@example.test>"},
        )
        coordinator.record_smtp_check_messages(
            "old-run", smtp_account["email"], 2,
            {mailbox["email"]: stage_two["Message-ID"]},
        )
        unrelated = SmtpCheckManager._build_message(
            smtp_account, mailbox["email"], "Unrelated", "other",
            {"html": "<p>other</p>", "image_path": None, "preview": ""},
            2, "", {},
        )
        raw_by_uid = {
            b"1": stage_one.as_bytes(),
            b"2": stage_two.as_bytes(),
            b"3": unrelated.as_bytes(),
        }

        class FakeIMAP:
            def select(self, _mailbox):
                return "OK", [b""]

            def login(self, *_credentials):
                return "OK", [b""]

            def uid(self, operation, _charset, *args):
                if operation == "search":
                    return "OK", [b"1 2 3"]
                return "OK", [(b"header", raw_by_uid[_charset])]

            def logout(self):
                return "OK", [b""]

        manager._open_imap = lambda _account: FakeIMAP()
        validation = manager.validate_imap_connections()
        self.assertTrue(validation["ok"])
        self.assertEqual(len(validation["messages"]), 2)
        self.assertEqual(
            {item["stage"] for item in validation["messages"]}, {1, 2}
        )
        restarted = SmtpCheckManager(directory, coordinator=coordinator)
        restarted.settings_path.write_text(
            manager.settings_path.read_text(encoding="utf-8"), encoding="utf-8"
        )
        restarted._open_imap = lambda _account: FakeIMAP()
        self.assertEqual(
            len(restarted.validate_imap_connections()["messages"]), 2
        )

    def test_imap_preflight_failure_blocks_start_before_smtp_work(self):
        directory = tempfile.mkdtemp()
        manager = SmtpCheckManager(directory)
        accounts = [
            {
                "email": "ok@example.test", "password": "secret",
                "server": "imap.ok.test", "port": 993,
            },
            {
                "email": "bad@example.test", "password": "secret",
                "server": "imap.bad.test", "port": 993,
            },
        ]
        manager.settings_path.write_text(
            json.dumps({"recipients": [item["email"] for item in accounts],
                        "accounts": accounts}),
            encoding="utf-8",
        )

        class FakeIMAP:
            def logout(self):
                return "OK", []

        def open_imap(account):
            if account["email"] == "bad@example.test":
                raise RuntimeError("authentication refused")
            return FakeIMAP()

        manager._open_imap = open_imap
        manager._read_smtp_accounts = Mock(side_effect=AssertionError("SMTP touched"))
        with self.assertRaisesRegex(ValueError, "bad@example.test"):
            manager.start({"SMTP_ACCOUNTS_FILE": "smtp.txt"})
        self.assertFalse(manager.snapshot()["running"])

    def test_fake_imap_only_confirms_matching_run_account_and_stage(self):
        account = {
            "email": "inbox@example.test",
            "password": "secret",
            "server": "imap.example.test",
            "port": 993,
        }
        smtp_account = {
            "email": "sender@example.test",
            "server": "smtp.example.test",
            "port": 587,
        }
        delivery = {"html": "<p>test</p>", "image_path": None, "preview": ""}
        matching = SmtpCheckManager._build_message(
            smtp_account, account["email"], "subject", "run", delivery, 2, "Name"
        ).as_bytes()
        wrong_stage = SmtpCheckManager._build_message(
            smtp_account, account["email"], "subject", "run", delivery, 1, ""
        ).as_bytes()

        class FakeIMAP:
            def __init__(self):
                self.payload = {b"2": matching, b"1": wrong_stage}

            def select(self, _mailbox):
                return "OK", [b""]

            def login(self, *_credentials):
                return "OK", [b""]

            def uid(self, operation, _charset, *args):
                if operation == "search":
                    return "OK", [b"1 2"]
                return "OK", [(b"header", self.payload[_charset])]

            def logout(self):
                return "OK", [b""]

        manager = SmtpCheckManager(tempfile.mkdtemp())
        with patch.object(manager, "_open_imap", return_value=FakeIMAP()):
            messages, error = manager._poll_mailbox(
                account, "run", 2, set()
            )
        self.assertIsNone(error)
        self.assertEqual(len(messages), 1)
        self.assertEqual(messages[0]["stage"], 2)

    def test_run_enforces_stage_order_and_publishes_each_account_immediately(self):
        class FakeCoordinator:
            def __init__(self):
                self.events = []

            def begin_run(self, *_args):
                self.events.append(("begin",))

            def update_stage(self, _run, account, stage, status, *_args):
                self.events.append(("stage", account["email"], stage, status))

            def publish_validated(self, _run, account):
                self.events.append(("publish", account["email"]))

            def finish_run(self, *_args):
                self.events.append(("finish",))

        coordinator = FakeCoordinator()
        manager = SmtpCheckManager(tempfile.mkdtemp(), coordinator=coordinator)
        accounts = [
            {"index": 0, "email": "one@example.test", "password": "x",
             "server": "smtp.test", "port": 587},
            {"index": 1, "email": "two@example.test", "password": "x",
             "server": "smtp.test", "port": 587},
        ]
        config = {"EMAIL_SUBJECT": "test", "SENDER_NAME": "Name",
                  "SMTP_CHECK_CONFIRM_TIMEOUT": 1, "CHECKV2_POLL_INTERVAL": 0.01}
        manager._message_html = lambda _config: "<p>x</p>"
        manager._delivery_template = lambda _config, html: {
            "html": html, "image_path": None, "preview": ""
        }
        sent_stages = []

        def fake_send(account, recipients, *_args, stage=1, **_kwargs):
            # _run passes stage positionally after stop_event.
            stage = _args[-2] if len(_args) >= 2 else stage
            sent_stages.append((account["email"], stage))
            return {"sent": 1, "failed": 0, "failures": [], "cancelled": False}

        manager._send_one = fake_send

        def fake_poll(mailbox, _run, stage, _known, target):
            return [{
                "id": f"{target}-{stage}", "to": "recipient@example.test",
                "smtp_account": target, "stage": stage,
            }], None

        manager._poll_mailbox = fake_poll
        manager._run(config, {"accounts": [{
            "email": "recipient@example.test", "password": "x",
            "server": "imap.test", "port": 993,
        }]}, accounts, ["recipient@example.test"], "run")
        self.assertEqual(
            sent_stages,
            [("one@example.test", 1), ("one@example.test", 2),
             ("two@example.test", 1), ("two@example.test", 2)],
        )
        publish_one = coordinator.events.index(("publish", "one@example.test"))
        send_two = sent_stages.index(("two@example.test", 1))
        self.assertLess(publish_one, len(coordinator.events))
        self.assertEqual(coordinator.events[publish_one + 1], ("stage", "two@example.test", 1, "sent"))

    def test_stop_does_not_touch_unstarted_accounts(self):
        class FakeCoordinator:
            def begin_run(self, *_args): pass
            def update_stage(self, *_args): pass
            def publish_validated(self, *_args): pass
            def finish_run(self, *_args): pass

        manager = SmtpCheckManager(tempfile.mkdtemp(), coordinator=FakeCoordinator())
        manager._message_html = lambda _config: "<p>x</p>"
        manager._delivery_template = lambda _config, html: {
            "html": html, "image_path": None, "preview": ""
        }
        calls = []

        def stop_after_first(account, recipients, *_args, **_kwargs):
            calls.append(account["email"])
            manager.stop_event.set()
            return {"sent": 0, "failed": 0, "failures": [], "cancelled": True}

        manager._send_one = stop_after_first
        removed = []
        manager._remove_failed_smtp_accounts = lambda *_args: removed.append(True) or 1
        accounts = [
            {"index": 0, "email": "one@example.test", "password": "x",
             "server": "smtp.test", "port": 587},
            {"index": 1, "email": "two@example.test", "password": "x",
             "server": "smtp.test", "port": 587},
        ]
        manager._run(
            {"EMAIL_SUBJECT": "test", "SMTP_CHECK_CONFIRM_TIMEOUT": 1},
            {"accounts": []}, accounts, ["recipient@example.test"], "run",
        )
        self.assertEqual(calls, ["one@example.test"])
        self.assertEqual(removed, [])

    def test_scheduler_starts_workers_one_second_apart_while_first_waits(self):
        class FakeCoordinator:
            def begin_run(self, *_args): pass
            def finish_run(self, *_args): pass

        manager = SmtpCheckManager(tempfile.mkdtemp(), coordinator=FakeCoordinator())
        manager._message_html = lambda _config: "<p>x</p>"
        manager._delivery_template = lambda _config, html: {
            "html": html, "image_path": None, "preview": ""
        }
        starts = []
        finished = {}

        def worker(account, *_args):
            starts.append((account["email"], time.monotonic()))
            if account["index"] == 0:
                time.sleep(1.25)
            finished[account["email"]] = time.monotonic()

        manager._run_account = worker
        accounts = [
            {"index": index, "email": f"{index}@example.test", "password": "x",
             "server": "smtp.test", "port": 587}
            for index in range(3)
        ]
        manager._run(
            {"EMAIL_SUBJECT": "test"},
            {"accounts": []},
            accounts,
            ["recipient@example.test"],
            "run",
        )
        self.assertEqual(len(starts), 3)
        gaps = [
            starts[index + 1][1] - starts[index][1]
            for index in range(len(starts) - 1)
        ]
        self.assertTrue(all(gap >= 0.95 for gap in gaps))
        self.assertLess(starts[1][1], finished["0@example.test"])

    def test_auth_pool_does_not_import_smtp_check_accounts(self):
        import send

        class Coordinator:
            def list_validated(self):
                return [{
                    "email": "new@example.test", "password": "x",
                    "server": "smtp.test", "port": 587,
                    "account_key": "new-key",
                }]

        old_coordinator = send.AUTH_COORDINATOR
        old_accounts = send.VALID_SMTP_ACCOUNTS
        try:
            send.AUTH_COORDINATOR = Coordinator()
            send.VALID_SMTP_ACCOUNTS = []
            refreshed = send.refresh_validated_smtp_accounts()
            self.assertEqual(refreshed, [])
        finally:
            send.AUTH_COORDINATOR = old_coordinator
            send.VALID_SMTP_ACCOUNTS = old_accounts

    def test_campaign_lease_and_claim_scope_are_stable_across_competitors(self):
        with tempfile.TemporaryDirectory() as directory:
            first = SecureCoordinator(directory)
            second = SecureCoordinator(directory)
            first.begin_run("run-old", [])
            first.begin_run("run-current", [])
            lease = first.acquire_campaign_lease("run-current", owner="one")
            self.assertIsNotNone(lease)
            self.assertEqual(lease["campaign_id"], "auth:run-current")
            self.assertIsNone(
                second.acquire_campaign_lease("run-current", owner="two")
            )
            self.assertTrue(
                first.claim_recipient(
                    lease["campaign_id"], "target@example.test", "pool"
                )
            )
            self.assertFalse(
                second.claim_recipient(
                    lease["campaign_id"], "TARGET@example.test", "pool"
                )
            )

    def test_latest_run_and_warnings_are_not_selected_by_updated_at(self):
        with tempfile.TemporaryDirectory() as directory:
            coordinator = SecureCoordinator(directory)
            account = {
                "email": "sender@example.test",
                "password": "x",
                "server": "smtp.example.test",
                "port": 587,
            }
            coordinator.begin_run("run-old", [account])
            coordinator.update_stage("run-old", account, 1, "failed", "old warning")
            coordinator.begin_run("run-current", [account])
            # Updating an old run must not make it current again.
            coordinator.finish_run("run-old", "failed", "old finished")
            status = coordinator.public_status()
            self.assertEqual(status["run"]["run_id"], "run-current")
            self.assertEqual(status["warnings"], [])

    def test_worker_gate_rate_limits_more_than_executor_capacity(self):
        manager = SmtpCheckManager(tempfile.mkdtemp())
        gate = {"lock": threading.Lock(), "next_start": 0.0, "starts": []}
        with patch("smtp_check.time.monotonic", return_value=0.0), \
                patch.object(manager.stop_event, "wait") as wait:
            for _ in range(31):
                self.assertTrue(manager._worker_start_gate(gate))
        self.assertEqual(gate["starts"], list(range(31)))
        self.assertEqual(wait.call_count, 30)

    def test_cached_double_confirmation_reuses_exact_fingerprint_only(self):
        with tempfile.TemporaryDirectory() as directory:
            coordinator = SecureCoordinator(directory)
            account = {
                "index": 0,
                "email": "sender@example.test",
                "password": "secret-a",
                "server": "smtp.example.test",
                "port": 587,
            }
            coordinator.begin_run("old", [account])
            coordinator.update_stage("old", account, 1, "confirmed")
            coordinator.update_stage("old", account, 2, "confirmed")
            coordinator.publish_validated("old", account)
            self.assertEqual(
                len(coordinator.cached_validated_accounts([account])), 1
            )
            changed = dict(account, password="secret-b")
            moved = dict(account, server="smtp2.example.test")
            absent = dict(account, email="absent@example.test")
            self.assertEqual(
                coordinator.cached_validated_accounts([changed, moved, absent]), []
            )

    def test_cached_account_is_seeded_without_sending_again(self):
        with tempfile.TemporaryDirectory() as directory:
            coordinator = SecureCoordinator(directory)
            account = {
                "index": 0,
                "email": "sender@example.test",
                "password": "secret",
                "server": "smtp.example.test",
                "port": 587,
            }
            coordinator.begin_run("old", [account])
            coordinator.update_stage("old", account, 1, "confirmed")
            coordinator.update_stage("old", account, 2, "confirmed")
            coordinator.publish_validated("old", account)
            manager = SmtpCheckManager(directory, coordinator=coordinator)
            manager._message_html = lambda _config: "<p>x</p>"
            manager._delivery_template = lambda _config, html: {
                "html": html, "image_path": None, "preview": ""
            }
            sent = []
            manager._send_one = lambda *args, **kwargs: sent.append(True)
            manager._run(
                {"EMAIL_SUBJECT": "test"},
                {"accounts": []},
                [account],
                ["recipient@example.test"],
                "new",
            )
            self.assertEqual(sent, [])
            self.assertEqual(manager.snapshot()["validated_count"], 1)
            self.assertEqual(coordinator.latest_run()["run_id"], "new")
            self.assertEqual(
                coordinator.list_validated()[0]["email"], account["email"]
            )

    def test_campaign_completion_stops_check_without_starting_pending_accounts(self):
        with tempfile.TemporaryDirectory() as directory:
            coordinator = SecureCoordinator(directory)
            run_id = "campaign-run"
            coordinator.begin_run(run_id, [])
            campaign_id = coordinator.campaign_id_for_run(run_id)
            self.assertTrue(
                coordinator.claim_recipient(
                    campaign_id, "recipient@example.test", "pool"
                )
            )
            coordinator.complete_recipient(
                campaign_id, "recipient@example.test", True
            )
            manager = SmtpCheckManager(directory, coordinator=coordinator)
            manager._message_html = lambda _config: "<p>x</p>"
            manager._delivery_template = lambda _config, html: {
                "html": html, "image_path": None, "preview": ""
            }
            sent = []
            manager._send_one = lambda *args, **kwargs: sent.append(True)
            account = {
                "index": 0,
                "email": "untested@example.test",
                "password": "secret",
                "server": "smtp.example.test",
                "port": 587,
            }
            manager._run(
                {"EMAIL_SUBJECT": "test"},
                {"accounts": []},
                [account],
                ["recipient@example.test"],
                run_id,
            )
            self.assertEqual(sent, [])
            self.assertEqual(manager.snapshot()["phase"], "campaign_complete")
            self.assertEqual(manager.snapshot()["accounts"][0]["status"], "stopped")


class DeleteAllCompatibilityTests(unittest.TestCase):
    def test_delete_all_keeps_existing_message_deletion_contract(self):
        class FakeManager:
            def __init__(self):
                self.deleted = []

            def snapshot(self):
                return {"messages": [{"id": "one"}, {"id": "two"}]}

            def delete_message(self, message_id):
                self.deleted.append(message_id)
                return self.snapshot()

            delete_all_messages = SmtpCheckManager.delete_all_messages

        manager = FakeManager()
        manager.delete_all_messages()
        self.assertEqual(manager.deleted, ["one", "two"])


if __name__ == "__main__":
    unittest.main()