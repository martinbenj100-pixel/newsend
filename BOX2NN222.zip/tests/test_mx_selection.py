import unittest
from unittest.mock import patch

import send


class _MxRecord:
    def __init__(self, preference, exchange):
        self.preference = preference
        self.exchange = exchange


class _SmtpConnection:
    def __init__(self):
        self.noop_calls = 0
        self.quit_calls = 0

    def noop(self):
        self.noop_calls += 1

    def quit(self):
        self.quit_calls += 1

    def close(self):
        pass


class MxSelectionTests(unittest.TestCase):
    def setUp(self):
        send.MX_CACHE.clear()
        send.MX_SELECTION_COUNTERS.clear()
        send.NORMAL_MODE_CONNECTION = None
        send.NORMAL_MODE_CONNECTION_TARGET = None
        send.CONFIG = {
            'MX_TARGET_MODE': 'PRIMARY',
            'MX_TARGET_PATTERN': '',
            'SHOW_ERRORS_IN_PROGRESS': False,
        }
        self.records = [
            _MxRecord(10, 'mx1.mail.ovh.net.'),
            _MxRecord(1, 'mx0.mail.ovh.net.'),
            _MxRecord(20, 'backup.other.net.'),
        ]

    def _resolve(self):
        return patch.object(send.dns.resolver, 'resolve', return_value=self.records)

    def test_primary_mode_keeps_the_preferred_mx(self):
        with self._resolve():
            self.assertEqual(send.get_mx_record('example.test'), 'mx0.mail.ovh.net')

    def test_all_mode_rotates_without_duplicate_delivery(self):
        send.CONFIG['MX_TARGET_MODE'] = 'ALL'
        with self._resolve():
            selected = [send.get_mx_record('example.test') for _ in range(4)]
        self.assertEqual(
            selected,
            [
                'mx0.mail.ovh.net',
                'mx1.mail.ovh.net',
                'backup.other.net',
                'mx0.mail.ovh.net',
            ],
        )

    def test_match_mode_uses_only_hosts_containing_the_pattern(self):
        send.CONFIG.update({
            'MX_TARGET_MODE': 'MATCH',
            'MX_TARGET_PATTERN': '.OVH.NET',
        })
        with self._resolve():
            selected = [send.get_mx_record('example.test') for _ in range(3)]
        self.assertEqual(
            selected,
            ['mx0.mail.ovh.net', 'mx1.mail.ovh.net', 'mx0.mail.ovh.net'],
        )

    def test_match_mode_returns_none_when_no_mx_matches(self):
        send.CONFIG.update({
            'MX_TARGET_MODE': 'MATCH',
            'MX_TARGET_PATTERN': 'missing.net',
        })
        with self._resolve():
            self.assertIsNone(send.get_mx_record('example.test'))

    def test_unfiltered_lookup_remains_available_for_address_checks(self):
        send.CONFIG.update({
            'MX_TARGET_MODE': 'MATCH',
            'MX_TARGET_PATTERN': 'missing.net',
        })
        with self._resolve():
            self.assertEqual(
                send.get_mx_record('example.test', apply_target=False),
                'mx0.mail.ovh.net',
            )

    def test_persistent_connection_is_reused_only_for_the_same_mx(self):
        first_connection = _SmtpConnection()
        second_connection = _SmtpConnection()
        with patch.object(
            send,
            'create_smtp_connection',
            side_effect=[first_connection, second_connection],
        ):
            first = send.get_normal_mode_smtp_connection('mx0.mail.ovh.net', 25)
            reused = send.get_normal_mode_smtp_connection('mx0.mail.ovh.net', 25)
            changed = send.get_normal_mode_smtp_connection('mx1.mail.ovh.net', 25)

        self.assertIs(first, first_connection)
        self.assertIs(reused, first_connection)
        self.assertIs(changed, second_connection)
        self.assertEqual(first_connection.noop_calls, 1)
        self.assertEqual(first_connection.quit_calls, 1)
        self.assertEqual(
            send.NORMAL_MODE_CONNECTION_TARGET,
            ('mx1.mail.ovh.net', 25),
        )


if __name__ == '__main__':
    unittest.main()