import io
import os
import sys
import tempfile
import threading
import time
import unittest
import json
import urllib.error
import uuid
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock, patch

import app
import resend_client
import send


class WindowsCompatibilityTests(unittest.TestCase):
    def test_multithread_retries_then_records_one_success(self):
        previous_config = send.CONFIG
        previous_errors = send.REINFORCE_ERRORS
        previous_stats = json.loads(json.dumps(send.MULTITHREAD_STATS))
        server = SimpleNamespace(sendmail=Mock(side_effect=[OSError("temporary"), None]))
        send.CONFIG = {
            "MAX_RETRIES": 3,
            "RETRY_DELAY": 2,
            "TIME_PER_EMAIL_SECONDS": 0,
            "USE_IP_REINFORCE": True,
            "USE_AUTH_MODE": False,
        }
        send.REINFORCE_ERRORS = 0
        try:
            with patch.object(send, "read_control_file", return_value={}), patch.object(
                send, "get_sender_email", return_value="sender@example.test"
            ), patch.object(
                send, "get_mx_record", return_value="mx.example.test"
            ), patch.object(
                send, "create_smtp_connection", return_value=server
            ), patch.object(
                send, "close_smtp_connection"
            ), patch.object(
                send, "add_ultra_enhanced_anti_spam_headers", side_effect=lambda msg, *_: msg
            ), patch.object(
                send, "finalize_email", return_value=b"message"
            ), patch.object(
                send, "record_campaign_result"
            ) as record_result, patch.object(
                send, "update_control_file"
            ), patch.object(
                send, "print_colored"
            ), patch.object(
                send.time, "sleep"
            ) as sleep:
                result = send.send_email_multithreaded_worker(
                    1, ["recipient@example.test"], "Subject", "<p>Body</p>"
                )

            self.assertEqual(result, 1)
            self.assertEqual(server.sendmail.call_count, 2)
            record_result.assert_called_once_with("recipient@example.test", True)
            sleep.assert_called_once_with(2)
            self.assertEqual(send.REINFORCE_ERRORS, 0)
        finally:
            send.CONFIG = previous_config
            send.REINFORCE_ERRORS = previous_errors
            send.MULTITHREAD_STATS.clear()
            send.MULTITHREAD_STATS.update(previous_stats)

    def test_multithread_counts_failure_only_after_last_retry(self):
        previous_config = send.CONFIG
        previous_errors = send.REINFORCE_ERRORS
        previous_stats = json.loads(json.dumps(send.MULTITHREAD_STATS))
        server = SimpleNamespace(sendmail=Mock(side_effect=OSError("still failing")))
        send.CONFIG = {
            "MAX_RETRIES": 3,
            "RETRY_DELAY": 2,
            "TIME_PER_EMAIL_SECONDS": 0,
            "MAX_ERRORS_BEFORE_REINFORCE": 1,
            "USE_IP_REINFORCE": True,
            "USE_AUTH_MODE": False,
        }
        send.REINFORCE_ERRORS = 0
        try:
            with patch.object(send, "read_control_file", return_value={}), patch.object(
                send, "get_sender_email", return_value="sender@example.test"
            ), patch.object(
                send, "get_mx_record", return_value="mx.example.test"
            ), patch.object(
                send, "create_smtp_connection", return_value=server
            ), patch.object(
                send, "close_smtp_connection"
            ), patch.object(
                send, "add_ultra_enhanced_anti_spam_headers", side_effect=lambda msg, *_: msg
            ), patch.object(
                send, "finalize_email", return_value=b"message"
            ), patch.object(
                send, "record_campaign_result"
            ) as record_result, patch.object(
                send, "update_control_file"
            ), patch.object(
                send, "save_failed_email"
            ) as save_failed, patch.object(
                send, "trigger_reinforce_and_wait"
            ) as trigger_reinforce, patch.object(
                send, "print_colored"
            ), patch.object(
                send.time, "sleep"
            ) as sleep:
                result = send.send_email_multithreaded_worker(
                    1, ["recipient@example.test"], "Subject", "<p>Body</p>"
                )

            self.assertEqual(result, 0)
            self.assertEqual(server.sendmail.call_count, 3)
            record_result.assert_called_once_with("recipient@example.test", False)
            save_failed.assert_called_once_with("recipient@example.test")
            trigger_reinforce.assert_called_once()
            self.assertEqual(sleep.call_args_list, [unittest.mock.call(2), unittest.mock.call(2)])
            self.assertEqual(send.REINFORCE_ERRORS, 0)
        finally:
            send.CONFIG = previous_config
            send.REINFORCE_ERRORS = previous_errors
            send.MULTITHREAD_STATS.clear()
            send.MULTITHREAD_STATS.update(previous_stats)

    def test_multithread_sender_selection_failure_does_not_abort_worker(self):
        previous_config = send.CONFIG
        previous_errors = send.REINFORCE_ERRORS
        previous_stats = json.loads(json.dumps(send.MULTITHREAD_STATS))
        server = SimpleNamespace(sendmail=Mock(return_value=None))
        send.CONFIG = {
            "MAX_RETRIES": 1,
            "RETRY_DELAY": 0,
            "TIME_PER_EMAIL_SECONDS": 0,
            "USE_IP_REINFORCE": False,
            "USE_AUTH_MODE": False,
        }
        send.REINFORCE_ERRORS = 0
        try:
            with patch.object(send, "read_control_file", return_value={}), patch.object(
                send,
                "get_sender_email",
                side_effect=[ValueError("bad sender config"), "sender@example.test"],
            ), patch.object(
                send, "get_mx_record", return_value="mx.example.test"
            ), patch.object(
                send, "create_smtp_connection", return_value=server
            ), patch.object(
                send, "close_smtp_connection"
            ), patch.object(
                send, "add_ultra_enhanced_anti_spam_headers", side_effect=lambda msg, *_: msg
            ), patch.object(
                send, "finalize_email", return_value=b"message"
            ), patch.object(
                send, "record_campaign_result"
            ) as record_result, patch.object(
                send, "update_control_file"
            ), patch.object(
                send, "save_failed_email"
            ), patch.object(
                send, "print_colored"
            ):
                result = send.send_email_multithreaded_worker(
                    1,
                    ["first@example.test", "second@example.test"],
                    "Subject",
                    "<p>Body</p>",
                )

            self.assertEqual(result, 1)
            self.assertEqual(
                record_result.call_args_list,
                [
                    unittest.mock.call("first@example.test", False),
                    unittest.mock.call("second@example.test", True),
                ],
            )
            server.sendmail.assert_called_once()
        finally:
            send.CONFIG = previous_config
            send.REINFORCE_ERRORS = previous_errors
            send.MULTITHREAD_STATS.clear()
            send.MULTITHREAD_STATS.update(previous_stats)

    def test_reinforce_listener_polls_signal_and_returns_control(self):
        previous_control_file = send.CONTROL_FILE
        previous_config = send.CONFIG
        previous_clean_emails = send.CLEAN_EMAILS
        with tempfile.TemporaryDirectory() as directory:
            send.CONTROL_FILE = str(Path(directory) / "control.json")
            send.CONFIG = {
                "MAX_ERRORS_BEFORE_REINFORCE": 2,
                "REINFORCE_DURATION": 3,
                "REINFORCE_WARMUP_COUNT": 40,
                "WARMUP_MODE": "ADVANCED",
                "CLEAN_EMAILS_FILE": "clean.txt",
            }
            send.CLEAN_EMAILS = ["clean@example.test"]

            try:
                with patch.object(send, "execute_initial_warmup"), patch.object(
                    send, "load_clean_emails"
                ), patch.object(send.time, "sleep", wraps=time.sleep), patch.object(
                    send, "execute_reinforce"
                ):
                    listener = threading.Thread(
                        target=send.run_reinforce_mode, daemon=True
                    )
                    listener.start()

                    deadline = time.time() + 5
                    while time.time() < deadline:
                        control = send.read_control_file()
                        if (
                            control.get("status") == "running"
                            and control.get("mode") == "reinforce"
                        ):
                            break
                        time.sleep(0.05)
                    else:
                        self.fail("Le processus Reinforce n'est pas passé en écoute")

                    send.update_control_file(
                        status="reinforce",
                        mode="reinforce",
                        error_count=2,
                        reinforce_request_id="cycle-poll",
                    )

                    deadline = time.time() + 5
                    while time.time() < deadline:
                        control = send.read_control_file()
                        if (
                            control.get("status") == "running"
                            and control.get("mode") == "send"
                            and control.get("reinforce_completed_id") == "cycle-poll"
                        ):
                            break
                        time.sleep(0.05)
                    else:
                        self.fail("Le relais Reinforce vers send n'a pas été rendu")

                    send.update_control_file(status="stopped")
                    listener.join(timeout=2)
                    self.assertFalse(listener.is_alive())
            finally:
                send.CONTROL_FILE = previous_control_file
                send.CONFIG = previous_config
                send.CLEAN_EMAILS = previous_clean_emails

    def test_reinforce_trigger_waits_for_the_same_cycle(self):
        previous_config = send.CONFIG
        send.CONFIG = {"REINFORCE_DURATION": 3}
        try:
            with patch.object(send, "update_control_file") as update, patch.object(
                send, "wait_for_reinforce_complete", return_value=True
            ) as wait:
                result = send.trigger_reinforce_and_wait(
                    "recipient@example.test", 2, 2
                )

            self.assertTrue(result)
            request_id = update.call_args.kwargs["reinforce_request_id"]
            uuid.UUID(hex=request_id)
            self.assertEqual(update.call_args.kwargs["status"], "reinforce")
            self.assertEqual(update.call_args.kwargs["mode"], "reinforce")
            self.assertEqual(update.call_args.kwargs["error_count"], 2)
            wait.assert_called_once_with(request_id)
        finally:
            send.CONFIG = previous_config

    def test_reinforce_without_clean_email_still_returns_control_to_send(self):
        previous_config = send.CONFIG
        previous_clean_emails = send.CLEAN_EMAILS
        send.CONFIG = {
            "CLEAN_EMAILS_FILE": "clean.txt",
            "REINFORCE_DURATION": 3,
            "REINFORCE_WARMUP_COUNT": 40,
        }
        send.CLEAN_EMAILS = []
        control = {
            "status": "reinforce",
            "mode": "reinforce",
            "reinforce_request_id": "cycle-2",
            "error_count": 2,
        }
        try:
            with patch.object(send, "read_control_file", return_value=control), patch.object(
                send, "load_clean_emails"
            ), patch.object(send, "update_control_file") as update:
                send.execute_reinforce()

            handoff = update.call_args.kwargs
            self.assertEqual(handoff["status"], "running")
            self.assertEqual(handoff["mode"], "send")
            self.assertEqual(handoff["reinforce_completed_id"], "cycle-2")
        finally:
            send.CONFIG = previous_config
            send.CLEAN_EMAILS = previous_clean_emails

    def test_project_paths_are_anchored_to_application_directory(self):
        self.assertEqual(Path(app.APP_DIR), Path(app.__file__).resolve().parent)
        self.assertEqual(
            Path(app._project_file_path("liste.txt")),
            Path(app.APP_DIR) / "liste.txt",
        )

    def test_temporary_config_uses_platform_temp_directory(self):
        path = app.make_temp_config({"CHECK": "true"})
        try:
            self.assertEqual(Path(path).parent, Path(tempfile.gettempdir()))
            self.assertTrue(Path(path).is_file())
        finally:
            Path(path).unlink(missing_ok=True)

    def test_forced_ip_refresh_bypasses_server_cache(self):
        class FakeIpResponse:
            def __enter__(self):
                return self

            def __exit__(self, exc_type, exc_value, traceback):
                return False

            def read(self):
                return b"203.0.113.42"

        previous_cache = dict(app._ip_cache)
        app._ip_cache.update({"ip": "198.51.100.10", "ts": app.time.time()})
        try:
            client = app.app.test_client()
            with client.session_transaction() as session:
                session["authenticated"] = True
            with patch.object(
                app.urllib.request,
                "urlopen",
                return_value=FakeIpResponse(),
            ) as urlopen:
                response = client.get("/api/ip?fresh=1")

            self.assertEqual(response.status_code, 200)
            self.assertEqual(response.get_json()["ip"], "203.0.113.42")
            self.assertFalse(response.get_json()["cached"])
            self.assertEqual(response.headers["Cache-Control"], "no-store")
            urlopen.assert_called_once()
        finally:
            app._ip_cache.clear()
            app._ip_cache.update(previous_cache)

    def test_windows_netstat_pid_is_parsed_without_fuser(self):
        netstat = (
            "  TCP    0.0.0.0:5000       0.0.0.0:0       LISTENING       4321\r\n"
        )
        with patch.object(app.os, "name", "nt"), patch.object(
            app.subprocess,
            "run",
            return_value=SimpleNamespace(stdout=netstat),
        ) as run:
            self.assertEqual(app._pid_listening_on_port(5000), 4321)
        self.assertEqual(run.call_args.args[0], ["netstat", "-ano", "-p", "tcp"])

    def test_start_process_uses_current_python_and_project_working_directory(self):
        slot = app.SLOTS["send"]
        fake_process = SimpleNamespace(
            pid=1234,
            stdout=io.BytesIO(),
            poll=lambda: None,
        )
        slot.process = None
        try:
            client = app.app.test_client()
            with client.session_transaction() as session:
                session["authenticated"] = True
            real_open = open

            def open_with_test_recipients(path, *args, **kwargs):
                if path == app.CONFIG_FILE:
                    return io.StringIO("EMAIL_LIST_FILE=liste.txt\n")
                if path == os.path.join(app.APP_DIR, "liste.txt"):
                    return io.StringIO("recipient@example.test\n")
                return real_open(path, *args, **kwargs)

            with patch("builtins.open", side_effect=open_with_test_recipients), patch.object(
                app.subprocess,
                "Popen",
                return_value=fake_process,
            ) as popen:
                response = client.post("/api/start", json={"mode": "send"})

            self.assertEqual(response.status_code, 200)
            self.assertTrue(response.get_json()["success"])
            command = popen.call_args.args[0]
            options = popen.call_args.kwargs
            self.assertEqual(command[0], sys.executable)
            self.assertEqual(command[2], os.path.join(app.APP_DIR, "send.py"))
            self.assertEqual(options["cwd"], app.APP_DIR)
            self.assertEqual(options["env"]["PYTHONIOENCODING"], "utf-8")
            self.assertEqual(options["env"]["PYTHONUTF8"], "1")
        finally:
            slot.process = None

    def test_checkv2_reads_account_lines_only_from_imap_file(self):
        with tempfile.TemporaryDirectory() as directory:
            account_file = Path(directory) / "imap.txt"
            account_file.write_text(
                "ovh|mailbox@example.test|file-value\n",
                encoding="utf-8",
            )
            with patch.object(app, "APP_DIR", directory):
                lines, source = app._checkv2_account_lines()

        self.assertEqual(source, "file")
        self.assertEqual(lines, ["ovh|mailbox@example.test|file-value"])

    def test_send_route_starts_checkv2_when_checkv2_is_enabled(self):
        slot = app.SLOTS["checkv2"]
        fake_process = SimpleNamespace(
            pid=9876,
            stdout=io.BytesIO(),
            poll=lambda: None,
        )
        slot.process = None
        real_open = open

        def open_with_checkv2_enabled(path, *args, **kwargs):
            if path == app.CONFIG_FILE:
                return io.StringIO(
                    "CHECKV2_ENABLED=true\n"
                    "USE_RESEND_API=true\n"
                    "RESEND_FROM=verified@example.test\n"
                )
            return real_open(path, *args, **kwargs)

        try:
            client = app.app.test_client()
            with client.session_transaction() as session:
                session["authenticated"] = True
            with patch("builtins.open", side_effect=open_with_checkv2_enabled), patch.object(
                app, "_checkv2_account_lines",
                return_value=(["ovh|mailbox@example.test|file-value"], "file"),
            ), patch.object(app.subprocess, "Popen", return_value=fake_process) as popen:
                response = client.post("/api/start", json={"mode": "send"})

            self.assertEqual(response.status_code, 200)
            self.assertTrue(response.get_json()["success"])
            self.assertEqual(response.get_json()["mode"], "checkv2")
            self.assertEqual(response.get_json()["slot"], "checkv2")
            self.assertEqual(popen.call_args.args[0][-1], "checkv2")
        finally:
            slot.process = None

    def test_reinforce_uses_its_own_process_slot(self):
        reinforce_slot = app.SLOTS["reinforce"]
        checkv2_slot = app.SLOTS["checkv2"]
        fake_process = SimpleNamespace(
            pid=7654,
            stdout=io.BytesIO(),
            poll=lambda: None,
        )
        reinforce_slot.process = None
        checkv2_slot.process = None

        try:
            client = app.app.test_client()
            with client.session_transaction() as session:
                session["authenticated"] = True
            with patch.object(
                app,
                "_read_config_values",
                return_value={
                    "USE_AUTH_MODE": "false",
                    "USE_RESEND_API": "false",
                    "USE_SENDBYTE_API": "false",
                },
            ), patch.object(app.subprocess, "Popen", return_value=fake_process) as popen:
                response = client.post("/api/start", json={"mode": "reinforce"})

            self.assertEqual(response.status_code, 200)
            self.assertTrue(response.get_json()["success"])
            self.assertEqual(response.get_json()["slot"], "reinforce")
            self.assertEqual(popen.call_args.args[0][-1], "reinforce")
            self.assertIsNone(checkv2_slot.process)
        finally:
            reinforce_slot.process = None
            checkv2_slot.process = None

    def test_checkv2_reports_a_server_side_resend_prerequisite(self):
        real_open = open

        def open_with_resend_disabled(path, *args, **kwargs):
            if path == app.CONFIG_FILE:
                return io.StringIO(
                    "CHECKV2_ENABLED=true\n"
                    "USE_RESEND_API=false\n"
                    "RESEND_FROM=verified@example.test\n"
                )
            return real_open(path, *args, **kwargs)

        client = app.app.test_client()
        with client.session_transaction() as session:
            session["authenticated"] = True
        with patch("builtins.open", side_effect=open_with_resend_disabled):
            response = client.post("/api/start", json={"mode": "checkv2"})

        self.assertEqual(response.status_code, 200)
        self.assertFalse(response.get_json()["success"])
        self.assertIn("Activez Resend", response.get_json()["error"])

    def test_checkv2_starts_with_auth_smtp_when_resend_is_disabled(self):
        slot = app.SLOTS["checkv2"]
        fake_process = SimpleNamespace(
            pid=6543,
            stdout=io.BytesIO(),
            poll=lambda: None,
        )
        slot.process = None
        real_open = open

        def open_with_auth_smtp(path, *args, **kwargs):
            if path == app.CONFIG_FILE:
                return io.StringIO(
                    "CHECKV2_ENABLED=true\n"
                    "USE_RESEND_API=false\n"
                    "USE_AUTH_MODE=true\n"
                )
            return real_open(path, *args, **kwargs)

        try:
            client = app.app.test_client()
            with client.session_transaction() as session:
                session["authenticated"] = True
            with patch("builtins.open", side_effect=open_with_auth_smtp), patch.object(
                app, "_checkv2_account_lines",
                return_value=(["ovh|mailbox@example.test|file-value"], "file"),
            ), patch.object(app.subprocess, "Popen", return_value=fake_process):
                response = client.post("/api/start", json={"mode": "checkv2"})

            self.assertEqual(response.status_code, 200)
            self.assertTrue(response.get_json()["success"])
            self.assertEqual(response.get_json()["mode"], "checkv2")
        finally:
            slot.process = None

    def test_checkv2_delivers_validated_candidates_with_smtp_auth(self):
        smtp_account = {
            "email": "sender@example.test",
            "password": "not-used-in-test",
            "smtp_server": "smtp.example.test",
        }
        original_config = dict(send.CONFIG)
        original_smtp_accounts = list(send.SMTP_ACCOUNTS)
        original_valid_accounts = list(send.VALID_SMTP_ACCOUNTS)
        original_argv = list(sys.argv)

        def load_test_smtp_account():
            send.SMTP_ACCOUNTS.append(smtp_account)

        def validate_test_smtp_account():
            send.VALID_SMTP_ACCOUNTS.extend(send.SMTP_ACCOUNTS)

        def deliver_candidate(_emails, _config, deliver_validated, *_args):
            self.assertEqual(
                deliver_validated("candidate@example.test"),
                (True, "SMTP AUTH via sender@example.test"),
            )

        real_open = open

        def open_test_list(path, *args, **kwargs):
            if path == "liste.txt":
                return io.StringIO("candidate@example.test\n")
            return real_open(path, *args, **kwargs)

        try:
            with tempfile.TemporaryDirectory() as directory:
                config_path = Path(directory) / "config.txt"
                config_path.write_text(
                    "\n".join(
                        (
                            "CHECKV2_ENABLED=true",
                            "USE_RESEND_API=false",
                            "USE_AUTH_MODE=true",
                            "EMAIL_SUBJECT=Test",
                            "MESSAGE_FILE=message.html",
                            "LETTER_RANDOM=false",
                        )
                    ),
                    encoding="utf-8",
                )
                sys.argv = ["send.py", str(config_path), "checkv2"]
                with patch("builtins.open", side_effect=open_test_list), patch.object(
                    send, "print_banner"
                ), patch.object(send, "load_links"), patch.object(
                    send, "initialize_enhanced_ip_pools"
                ), patch.object(send, "clear_fail_file"), patch.object(
                    send, "init_port_counters"
                ), patch.object(
                    send, "load_smtp_accounts", side_effect=load_test_smtp_account
                ), patch.object(
                    send, "validate_all_smtp_accounts",
                    side_effect=validate_test_smtp_account,
                ), patch.object(
                    send, "read_html_file", return_value="<p>Message</p>"
                ), patch.object(
                    send, "init_control_file"
                ), patch.object(
                    send, "update_control_file"
                ), patch.object(
                    send, "read_control_file", return_value={}
                ), patch.object(
                    send, "send_email_with_auth", return_value=True
                ) as send_auth, patch.object(
                    send, "send_resend_email"
                ) as send_resend, patch.object(
                    send, "run_checkv2", side_effect=deliver_candidate
                ):
                    with self.assertRaises(SystemExit) as exit_context:
                        send.main()

            self.assertEqual(exit_context.exception.code, 0)
            send_auth.assert_called_once_with(
                smtp_account,
                "candidate@example.test",
                "Test",
                "<p>Message</p>",
                [],
            )
            send_resend.assert_not_called()
        finally:
            sys.argv = original_argv
            send.CONFIG.clear()
            send.CONFIG.update(original_config)
            send.SMTP_ACCOUNTS[:] = original_smtp_accounts
            send.VALID_SMTP_ACCOUNTS[:] = original_valid_accounts

    def test_config_batch_update_preserves_unmentioned_settings(self):
        with tempfile.TemporaryDirectory() as directory:
            config_path = Path(directory) / "config.txt"
            config_path.write_text(
                "CHECKV2_ENABLED=false\n"
                "USE_RESEND_API=false\n"
                "CUSTOM_SETTING=preserved\n",
                encoding="utf-8",
            )
            client = app.app.test_client()
            with client.session_transaction() as session:
                session["authenticated"] = True
            with patch.object(app, "CONFIG_FILE", str(config_path)):
                response = client.post(
                    "/api/config/update",
                    json={
                        "values": {
                            "CHECKV2_ENABLED": "true",
                            "USE_RESEND_API": "true",
                        }
                    },
                )

            self.assertEqual(response.status_code, 200)
            self.assertTrue(response.get_json()["success"])
            config = config_path.read_text(encoding="utf-8")
            self.assertIn("CHECKV2_ENABLED=true", config)
            self.assertIn("USE_RESEND_API=true", config)
            self.assertIn("CUSTOM_SETTING=preserved", config)

    def test_resend_node_module_error_is_kept_on_one_line(self):
        missing_module = (
            "node:internal/modules/cjs/loader:1386\n"
            "Error: Cannot find module '@replit/connectors-sdk'\n"
        )
        result = SimpleNamespace(stdout="", stderr=missing_module, returncode=1)
        with tempfile.TemporaryDirectory() as temp_dir:
            api_file = Path(temp_dir) / "API.txt"
            api_file.write_text("RESEND_API_KEY=\n", encoding="utf-8")
            with patch.object(resend_client, "_API_FILE_PATH", api_file), patch.dict(
                resend_client.os.environ,
                {"REPL_IDENTITY": "test-identity"},
                clear=True,
            ), patch.object(resend_client.subprocess, "run", return_value=result):
                with self.assertRaises(resend_client.ResendError) as error:
                    resend_client._request("/emails", {})

        message = str(error.exception)
        self.assertIn("node:internal/modules/cjs/loader:1386", message)
        self.assertIn("Cannot find module '@replit/connectors-sdk'", message)
        self.assertIn("pnpm install", message)

    def test_resend_uses_direct_api_key_outside_replit(self):
        class FakeResponse:
            status = 200

            def __enter__(self):
                return self

            def __exit__(self, *args):
                return False

            def read(self):
                return b'{"id":"email-test"}'

        payload = {"from": "sender@example.com", "to": ["target@example.com"]}
        with tempfile.TemporaryDirectory() as temp_dir:
            api_file = Path(temp_dir) / "API.txt"
            api_file.write_text("RESEND_API_KEY=\n", encoding="utf-8")
            with patch.object(resend_client, "_API_FILE_PATH", api_file), patch.dict(
                resend_client.os.environ,
                {"RESEND_API_KEY": "re_test_only"},
                clear=True,
            ), patch.object(
                resend_client.urllib.request,
                "urlopen",
                return_value=FakeResponse(),
            ) as urlopen:
                response = resend_client._request("/emails", payload)

        self.assertEqual(response, {"id": "email-test"})
        request = urlopen.call_args.args[0]
        self.assertEqual(request.full_url, "https://api.resend.com/emails")
        self.assertEqual(request.get_header("Authorization"), "Bearer re_test_only")
        self.assertEqual(
            request.get_header("User-agent"),
            "YODA-Mailer/1.0 (Resend API client)",
        )
        self.assertEqual(json.loads(request.data), payload)

    def test_resend_uses_direct_api_key_inside_replit(self):
        class FakeResponse:
            status = 200

            def __enter__(self):
                return self

            def __exit__(self, *args):
                return False

            def read(self):
                return b'{"id":"email-via-secret"}'

        payload = {"from": "sender@example.com", "to": ["target@example.com"]}
        with tempfile.TemporaryDirectory() as temp_dir:
            api_file = Path(temp_dir) / "API.txt"
            api_file.write_text("RESEND_API_KEY=\n", encoding="utf-8")
            with patch.object(resend_client, "_API_FILE_PATH", api_file), patch.dict(
                resend_client.os.environ,
                {
                    "RESEND_API_KEY": "re_secure_secret",
                    "REPL_IDENTITY": "test-identity",
                },
                clear=True,
            ), patch.object(
                resend_client.urllib.request,
                "urlopen",
                return_value=FakeResponse(),
            ) as urlopen, patch.object(resend_client.subprocess, "run") as bridge:
                response = resend_client._request("/emails", payload)

        self.assertEqual(response, {"id": "email-via-secret"})
        self.assertFalse(bridge.called)
        request = urlopen.call_args.args[0]
        self.assertEqual(
            request.get_header("Authorization"),
            "Bearer re_secure_secret",
        )

    def test_resend_respects_time_per_email_seconds(self):
        original_config = send.CONFIG.copy()
        original_counters = (
            send.email_counter,
            send.success_counter,
            send.error_counter,
            send.REINFORCE_ERRORS,
        )
        started_at = []

        def fake_send_email(**_kwargs):
            started_at.append(time.monotonic())
            return {"id": "test-message"}

        try:
            send.CONFIG.update({
                "RESEND_FROM": "Sender <sender@example.test>",
                "TIME_PER_EMAIL_SECONDS": 0.03,
                "MAX_RETRIES": 1,
                "RETRY_DELAY": 0,
            })
            with patch.object(send, "send_resend_email", side_effect=fake_send_email), patch.object(
                send, "read_control_file", return_value={"status": "running"}
            ), patch.object(send, "update_control_file"), patch.object(
                send, "print_colored"
            ), patch.object(send, "replace_random_links_in_content", side_effect=lambda value: value), patch.object(
                send, "build_final_subject", side_effect=lambda value, _token: value
            ), patch.object(send, "generate_ultra_enhanced_headers", return_value={}):
                send.send_emails_with_resend(
                    [f"recipient-{number}@example.test" for number in range(3)],
                    "Test",
                    "<p>Test</p>",
                )

            self.assertEqual(len(started_at), 3)
            self.assertGreaterEqual(started_at[1] - started_at[0], 0.025)
            self.assertGreaterEqual(started_at[2] - started_at[1], 0.025)
        finally:
            send.CONFIG.clear()
            send.CONFIG.update(original_config)
            (
                send.email_counter,
                send.success_counter,
                send.error_counter,
                send.REINFORCE_ERRORS,
            ) = original_counters

    def test_resend_reads_direct_api_key_from_api_file(self):
        class FakeResponse:
            status = 200

            def __enter__(self):
                return self

            def __exit__(self, *args):
                return False

            def read(self):
                return b'{"id":"email-from-file"}'

        with tempfile.TemporaryDirectory() as temp_dir:
            api_file = Path(temp_dir) / "API.txt"
            api_file.write_text(
                "# Clé locale\nRESEND_API_KEY=re_file_only\n",
                encoding="utf-8",
            )
            payload = {"from": "sender@example.com", "to": ["target@example.com"]}
            with patch.object(resend_client, "_API_FILE_PATH", api_file), patch.dict(
                resend_client.os.environ, {}, clear=True
            ), patch.object(
                resend_client.urllib.request,
                "urlopen",
                return_value=FakeResponse(),
            ) as urlopen:
                response = resend_client._request("/emails", payload)

        self.assertEqual(response, {"id": "email-from-file"})
        request = urlopen.call_args.args[0]
        self.assertEqual(request.get_header("Authorization"), "Bearer re_file_only")

    def test_missing_api_file_gets_a_safe_template(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            api_file = Path(temp_dir) / "API.txt"
            with patch.object(resend_client, "_API_FILE_PATH", api_file):
                self.assertEqual(resend_client._read_api_file_key(), "")

            self.assertTrue(api_file.is_file())
            self.assertIn("RESEND_API_KEY=", api_file.read_text(encoding="utf-8"))

    def test_cloudflare_browser_signature_error_is_not_retryable(self):
        body = (
            b'{"status":403,"error_code":1010,'
            b'"error_name":"browser_signature_banned","cloudflare_error":true}'
        )
        error = urllib.error.HTTPError(
            "https://api.resend.com/emails",
            403,
            "Forbidden",
            {},
            io.BytesIO(body),
        )
        with patch.object(resend_client.urllib.request, "urlopen", side_effect=error):
            with self.assertRaises(resend_client.ResendError) as raised:
                resend_client._request_direct(
                    "/emails",
                    {},
                    api_key="re_test_only",
                )

        self.assertFalse(raised.exception.retryable)
        self.assertIn("1010", str(raised.exception))


if __name__ == "__main__":
    unittest.main()