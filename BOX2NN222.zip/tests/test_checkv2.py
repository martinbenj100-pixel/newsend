import imaplib
import tempfile
import threading
import time
import unittest
from pathlib import Path
from unittest.mock import patch

import checkv2


class _SMTP:
    def __init__(self):
        self.messages = []

    def login(self, *_args):
        pass

    def sendmail(self, sender, recipient, message):
        self.messages.append((sender, recipient, message))

    def quit(self):
        pass


class _IMAP:
    def login(self, *_args):
        pass

    def logout(self):
        pass

    def select(self, _folder):
        return "OK", [b""]

    def uid(self, command, _message_id=None, _query=None):
        if command == "search":
            return "OK", [b""]
        return "NO", []


class _ProbeIMAP:
    def __init__(self):
        self.message_ids = [b"1"]
        self.fetched = []
        self.stored = []

    def select(self, _folder):
        return "OK", [b""]

    def uid(self, command, message_id=None, _query=None, *_args):
        if command == "search":
            return "OK", [b" ".join(self.message_ids)]
        if command == "store":
            self.stored.append(message_id)
            return "OK", [b""]
        self.fetched.append(message_id)
        return "OK", [
            (b"RFC822", b"From: Mailer-Daemon\r\nSubject: Delivery failure\r\n\r\ntarget@example.test")
        ]

    def expunge(self):
        return "OK", [b""]


class _CleanupIMAP:
    def __init__(self):
        self.selected = []
        self.stored = []
        self.expunged = []

    def login(self, *_args):
        pass

    def logout(self):
        pass

    def select(self, folder):
        self.selected.append(folder)
        return "OK", [b""]

    def uid(self, command, message_ids=None, *_args):
        if command == "search":
            return "OK", [b"1 2"]
        if command == "fetch":
            message = (
                b"From: Mailer-Daemon\r\nSubject: Delivery failure\r\n\r\n"
                if message_ids == b"2"
                else b"From: colleague@example.test\r\nSubject: Bonjour\r\n\r\nMessage normal"
            )
            return "OK", [(b"RFC822", message)]
        if command == "store":
            self.stored.append(message_ids)
            return "OK", [b""]
        raise AssertionError(f"commande UID inattendue : {command}")

    def expunge(self):
        self.expunged.append(self.selected[-1])
        return "OK", [b""]


class _TargetedCleanupIMAP:
    def __init__(self):
        self.fetched = []
        self.searches = []
        self.stored = []

    def select(self, _folder):
        return "OK", [b""]

    def uid(self, command, message_id=None, *criteria):
        if command == "search":
            self.searches.append(criteria)
            if criteria == ("FROM", "mailer-daemon"):
                return "OK", [b"2"]
            return "OK", [b""]
        if command == "fetch":
            self.fetched.append((message_id, criteria))
            return "OK", [
                (b"RFC822", b"From: Mailer-Daemon\r\nSubject: Delivery failure\r\n\r\n")
            ]
        if command == "store":
            self.stored.append(message_id)
            return "OK", [b""]
        raise AssertionError(f"commande UID inattendue : {command}")

    def expunge(self):
        return "OK", [b""]


class _UidIMAP:
    def __init__(self):
        self.fetched = []

    def select(self, _folder):
        return "OK", [b""]

    def uid(self, command, message_id=None, _query=None, *_args):
        if command == "search":
            return "OK", [b"1 2 3 4"]
        if command == "store":
            return "OK", [b""]
        self.fetched.append(message_id)
        return "OK", [(b"RFC822", b"Subject: delivery failure\r\n\r\ntarget@example.test")]

    def expunge(self):
        return "OK", [b""]


class _SentIMAP:
    def __init__(self):
        self.selected = []
        self.stored = []
        self.expunged = []

    def select(self, folder):
        self.selected.append(folder)
        return "OK", [b""]

    def uid(self, command, message_id=None, *_args):
        if command == "search":
            return "OK", [b"1 2 3"]
        if command == "fetch":
            messages = {
                b"2": (
                    b"To: target@example.test\r\n"
                    b"Subject: =?utf-8?b?dCdlcyBwcsOpc2VudD8=?=\r\n"
                    b"Content-Type: text/plain; charset=utf-8\r\n\r\n.\r\n"
                ),
                b"3": (
                    b"To: friend@example.test\r\nSubject: Bonjour\r\n\r\nMessage normal"
                ),
            }
            return "OK", [(b"RFC822", messages[message_id])]
        if command == "store":
            self.stored.append(message_id)
            return "OK", [b""]
        raise AssertionError(f"commande UID inattendue : {command}")

    def expunge(self):
        self.expunged.append(self.selected[-1])
        return "OK", [b""]


class CheckV2BatchGateTests(unittest.TestCase):
    def _run_batch(self, scan):
        writes, delivered = [], []
        monotonic = iter((0, 2, 3, 5, 6, 8))
        account = {
            "provider": "ovh",
            "email": "control@example.test",
            "password": "secret",
        }
        config = {
            "CHECKV2_INITIAL_WAIT": 1,
            "CHECKV2_POLL_INTERVAL": 1,
            "CHECKV2_BATCH_SIZE": 2,
            "CHECKV2_BATCH_WAIT": 1,
            "CHECKV2_RECENT_NDR_LIMIT": 10,
            "CHECKV2_ACCOUNTS_FILE": "unused.txt",
            "GOOD_FILE": "good.txt",
            "BAD_FILE": "bad.txt",
        }
        with patch.object(checkv2, "_load_accounts", return_value=[account]), patch.object(
            checkv2, "_connect_smtp", side_effect=lambda _account: _SMTP()
        ), patch.object(checkv2, "_connect_imap", side_effect=lambda _account: _IMAP()), patch.object(
            checkv2, "_folders", return_value=["INBOX"]
        ), patch.object(
            checkv2, "_has_bounce", return_value=False
        ), patch.object(
            checkv2, "_wait_for_batch_window", return_value=True
        ), patch.object(
            checkv2, "_capture_batch_checkpoints", return_value={}
        ), patch.object(
            checkv2, "_scan_batch_bounces", side_effect=scan
        ), patch.object(
            checkv2, "_append_address", side_effect=lambda path, recipient: writes.append((path, recipient))
        ), patch.object(
            checkv2.time, "monotonic", side_effect=monotonic
        ):
            stats = checkv2.run_checkv2(
                ["a@example.test", "b@example.test", "c@example.test"],
                config,
                lambda recipient: (delivered.append(recipient) is None, "queued"),
                lambda _message: None,
                lambda: False,
            )
        return stats, writes, delivered

    def test_late_bounce_is_excluded_and_partial_batch_is_sent(self):
        batches = []

        def scan(
            _accounts,
            _file,
            recipients,
            _limit,
            _checkpoints,
            _stats,
            _log,
            _scope,
        ):
            batches.append(list(recipients))
            return {"b@example.test"} if len(recipients) == 2 else set()

        stats, writes, delivered = self._run_batch(scan)

        self.assertEqual(batches, [["a@example.test", "b@example.test"], ["c@example.test"]])
        self.assertEqual(delivered, ["a@example.test", "c@example.test"])
        self.assertIn(("bad.txt", "b@example.test"), writes)
        self.assertEqual(stats["batch_rejected"], 1)

    def test_bounce_before_three_seconds_sets_next_window_to_ten_seconds(self):
        windows = []
        writes = []
        account = {
            "provider": "ovh",
            "email": "control@example.test",
            "password": "secret",
        }
        config = {
            "CHECKV2_INITIAL_WAIT": 15,
            "CHECKV2_MIN_ADAPTIVE_WAIT": 10,
            "CHECKV2_POLL_INTERVAL": 1,
            "CHECKV2_BATCH_SIZE": 20,
            "CHECKV2_BATCH_WAIT": 1,
            "CHECKV2_RECENT_NDR_LIMIT": 10,
            "CHECKV2_ACCOUNTS_FILE": "unused.txt",
            "GOOD_FILE": "good.txt",
            "BAD_FILE": "bad.txt",
        }
        monotonic = iter((0, 1, 1, 2.5, 3, 3.5, 3.5, 13.5))
        with patch.object(checkv2, "_load_accounts", return_value=[account]), patch.object(
            checkv2, "_connect_smtp", return_value=_SMTP()
        ), patch.object(
            checkv2, "_connect_imap", return_value=_IMAP()
        ), patch.object(
            checkv2, "_folders", return_value=["INBOX"]
        ), patch.object(
            checkv2, "_has_bounce", side_effect=(True, False)
        ), patch.object(
            checkv2, "_capture_batch_checkpoints", return_value={}
        ), patch.object(
            checkv2, "_wait_for_batch_window", return_value=True
        ), patch.object(
            checkv2, "_scan_batch_bounces", return_value=set()
        ), patch.object(
            checkv2, "_append_address", side_effect=lambda path, recipient: writes.append((path, recipient))
        ), patch.object(
            checkv2.time, "monotonic", side_effect=monotonic
        ), patch.object(
            checkv2.time, "sleep"
        ):
            stats = checkv2.run_checkv2(
                ["early-bounce@example.test", "next@example.test"],
                config,
                lambda recipient: (True, "queued"),
                lambda message: windows.append(message) if "Fenêtre d'attente utilisée" in message else None,
                lambda: False,
            )

        self.assertEqual(stats["bounce"], 1)
        self.assertEqual(writes, [("bad.txt", "early-bounce@example.test"), ("good.txt", "next@example.test")])
        self.assertTrue(any("Fenêtre d'attente utilisée : 10.0s." in message for message in windows))

    def test_second_scan_failure_prevents_resend_delivery(self):
        def scan(*_args):
            raise checkv2.BatchScanError("IMAP timeout")

        stats, _writes, delivered = self._run_batch(scan)

        self.assertEqual(delivered, [])
        self.assertEqual(stats["error"], 2)

    def test_checkpoint_scan_includes_every_message_received_after_checkpoint(self):
        imap = _UidIMAP()
        with patch.object(checkv2, "_message_is_bounce", return_value=True), patch.object(
            checkv2, "_message_body", return_value="target@example.test"
        ):
            bounced = checkv2._recent_bounced_recipients(
                imap,
                ["INBOX"],
                ["target@example.test"],
                1,
                {"INBOX": {b"1", b"2"}},
            )

        self.assertEqual(bounced, {"target@example.test"})
        self.assertEqual(set(imap.fetched), {b"3", b"4"})

    def test_existing_unread_bounce_does_not_end_a_new_probe_early(self):
        imap = _ProbeIMAP()
        with patch.object(checkv2, "_message_is_bounce", return_value=True), patch.object(
            checkv2, "_message_body", return_value="target@example.test"
        ):
            self.assertFalse(
                checkv2._has_bounce(
                    imap,
                    ["INBOX"],
                    "target@example.test",
                    {"INBOX": {b"1"}},
                )
            )
            imap.message_ids.append(b"2")
            self.assertTrue(
                checkv2._has_bounce(
                    imap,
                    ["INBOX"],
                    "target@example.test",
                    {"INBOX": {b"1"}},
                )
            )

        self.assertEqual(imap.fetched, [b"2"])
        self.assertEqual(imap.stored, [b"2"])

    def test_cleanup_deletes_only_ndr_in_inbox_and_spam_folders(self):
        imap = _CleanupIMAP()

        cleaned = checkv2._clean_mailboxes(
            imap,
            ["INBOX", "Sent", "INBOX.Spam", "Drafts"],
        )

        self.assertEqual(cleaned, ["INBOX", "INBOX.Spam"])
        self.assertEqual(imap.selected, ["INBOX", "INBOX.Spam"])
        self.assertEqual(imap.stored, [b"2", b"2"])
        self.assertEqual(imap.expunged, ["INBOX", "INBOX.Spam"])

    def test_initial_cleanup_fetches_only_server_selected_bounce_headers(self):
        imap = _TargetedCleanupIMAP()

        cleaned = checkv2._clean_mailboxes(imap, ["INBOX"])

        self.assertEqual(cleaned, ["INBOX"])
        self.assertIn(("FROM", "mailer-daemon"), imap.searches)
        self.assertEqual(
            imap.fetched,
            [(b"2", ("(BODY.PEEK[HEADER.FIELDS (FROM SUBJECT)])",))],
        )
        self.assertEqual(imap.stored, [b"2"])

    def test_sent_control_copy_is_deleted_without_touching_normal_sent_mail(self):
        imap = _SentIMAP()

        checkv2._delete_sent_control_messages(
            imap,
            {"Sent": {b"1"}},
            "target@example.test",
        )

        self.assertEqual(imap.selected, ["Sent"])
        self.assertEqual(imap.stored, [b"2"])
        self.assertEqual(imap.expunged, ["Sent"])

    def test_controls_use_configured_parallel_waves_without_real_delivery(self):
        accounts = [
            {
                "provider": "ovh",
                "email": f"control-{number}@example.test",
                "password": "secret",
            }
            for number in range(3)
        ]
        active = 0
        peak_active = 0
        lock = threading.Lock()
        logs = []
        assignments = {}

        def probe(account, recipient, *_args):
            nonlocal active, peak_active
            with lock:
                active += 1
                peak_active = max(peak_active, active)
                assignments[recipient] = account["email"]
            time.sleep(0.02)
            with lock:
                active -= 1
            return {
                "account": account,
                "recipient": recipient,
                "status": "candidate",
                "elapsed": 0.0,
                "error": "",
            }

        config = {
            "CHECKV2_INITIAL_WAIT": 1,
            "CHECKV2_POLL_INTERVAL": 1,
            "CHECKV2_MAX_CONCURRENT_ACCOUNTS": 2,
            "CHECKV2_BATCH_SIZE": 10,
            "CHECKV2_BATCH_WAIT": 1,
            "CHECKV2_RECENT_NDR_LIMIT": 10,
            "CHECKV2_ACCOUNTS_FILE": "unused.txt",
            "GOOD_FILE": "good.txt",
            "BAD_FILE": "bad.txt",
        }
        with patch.object(checkv2, "_load_accounts", return_value=accounts), patch.object(
            checkv2, "_prepare_accounts"
        ), patch.object(
            checkv2, "_run_single_probe", side_effect=probe
        ), patch.object(
            checkv2, "_capture_batch_checkpoints", return_value={}
        ), patch.object(
            checkv2, "_wait_for_batch_window", return_value=True
        ), patch.object(
            checkv2, "_scan_batch_bounces", return_value=set()
        ), patch.object(
            checkv2, "_append_address"
        ):
            stats = checkv2.run_checkv2(
                ["one@example.test", "two@example.test", "three@example.test"],
                config,
                lambda _recipient: (True, "queued"),
                logs.append,
                lambda: False,
            )

        self.assertEqual(peak_active, 2)
        self.assertEqual(stats["checked"], 3)
        self.assertEqual(stats["sent"], 3)
        self.assertEqual(
            assignments,
            {
                "one@example.test": "control-0@example.test",
                "two@example.test": "control-1@example.test",
                "three@example.test": "control-2@example.test",
            },
        )
        self.assertTrue(
            any("Vague parallèle : 2 contrôle(s)" in message for message in logs)
        )
        self.assertTrue(
            any("Vague parallèle : 1 contrôle(s)" in message for message in logs)
        )

    def test_initial_cleanup_uses_configured_parallel_workers(self):
        accounts = [
            {
                "provider": "ovh",
                "email": f"cleanup-{number}@example.test",
                "password": "secret",
            }
            for number in range(3)
        ]
        active = 0
        peak_active = 0
        lock = threading.Lock()

        def prepare(_account, _scope):
            nonlocal active, peak_active
            with lock:
                active += 1
                peak_active = max(peak_active, active)
            time.sleep(0.02)
            with lock:
                active -= 1
            return {"status": "usable", "cleaned": ["INBOX"], "error": ""}

        stats = {"auth_failed": 0}
        with patch.object(checkv2, "_prepare_single_account", side_effect=prepare):
            checkv2._prepare_accounts(
                accounts,
                "unused.txt",
                stats,
                lambda _message: None,
                "INBOX",
                2,
            )

        self.assertEqual(peak_active, 2)
        self.assertEqual(len(accounts), 3)
        self.assertEqual(stats["auth_failed"], 0)

    def test_batch_checkpoint_uses_parallel_workers(self):
        accounts = [
            {
                "provider": "ovh",
                "email": f"checkpoint-{number}@example.test",
                "password": "secret",
            }
            for number in range(3)
        ]
        active = 0
        peak_active = 0
        lock = threading.Lock()

        def checkpoint(_account, _scope):
            nonlocal active, peak_active
            with lock:
                active += 1
                peak_active = max(peak_active, active)
            time.sleep(0.02)
            with lock:
                active -= 1
            return {"status": "ok", "checkpoints": {"INBOX": set()}, "error": ""}

        stats = {"auth_failed": 0}
        with patch.object(
            checkv2,
            "MAX_BATCH_IMAP_WORKERS",
            2,
        ), patch.object(
            checkv2,
            "_capture_single_account_checkpoint",
            side_effect=checkpoint,
        ):
            checkpoints = checkv2._capture_batch_checkpoints(
                accounts,
                "unused.txt",
                stats,
                lambda _message: None,
            )

        self.assertEqual(peak_active, 2)
        self.assertEqual(len(checkpoints), 3)
        self.assertEqual(stats["auth_failed"], 0)

    def test_candidate_batch_is_flushed_at_its_exact_configured_size(self):
        accounts = [
            {
                "provider": "ovh",
                "email": f"control-{number}@example.test",
                "password": "secret",
            }
            for number in range(2)
        ]
        batches = []
        config = {
            "CHECKV2_INITIAL_WAIT": 1,
            "CHECKV2_POLL_INTERVAL": 1,
            "CHECKV2_MAX_CONCURRENT_ACCOUNTS": 2,
            "CHECKV2_BATCH_SIZE": 3,
            "CHECKV2_BATCH_WAIT": 1,
            "CHECKV2_RECENT_NDR_LIMIT": 10,
            "GOOD_FILE": "good.txt",
            "BAD_FILE": "bad.txt",
        }

        def candidate(account, recipient, *_args):
            return {
                "account": account,
                "recipient": recipient,
                "status": "candidate",
                "elapsed": 0.0,
                "error": "",
            }

        def scan(
            _accounts,
            _file,
            recipients,
            _limit,
            _checkpoints,
            _stats,
            _log,
            _scope,
        ):
            batches.append(list(recipients))
            return set()

        with patch.object(checkv2, "_load_accounts", return_value=accounts), patch.object(
            checkv2,
            "_prepare_accounts",
        ), patch.object(
            checkv2,
            "_run_single_probe",
            side_effect=candidate,
        ), patch.object(
            checkv2,
            "_capture_batch_checkpoints",
            return_value={},
        ), patch.object(
            checkv2,
            "_wait_for_batch_window",
            return_value=True,
        ), patch.object(
            checkv2,
            "_scan_batch_bounces",
            side_effect=scan,
        ), patch.object(
            checkv2,
            "_append_address",
        ):
            checkv2.run_checkv2(
                [
                    "one@example.test",
                    "two@example.test",
                    "three@example.test",
                    "four@example.test",
                ],
                config,
                lambda _recipient: (True, "queued"),
                lambda _message: None,
                lambda: False,
            )

        self.assertEqual(
            batches,
            [
                ["one@example.test", "two@example.test", "three@example.test"],
                ["four@example.test"],
            ],
        )

    def test_control_message_has_sender_subject_and_dot_body(self):
        smtp = _SMTP()
        account = {
            "provider": "ovh",
            "email": "control@example.test",
            "password": "secret",
        }
        config = {
            "CHECKV2_INITIAL_WAIT": 1,
            "CHECKV2_POLL_INTERVAL": 1,
            "CHECKV2_BATCH_SIZE": 20,
            "CHECKV2_BATCH_WAIT": 1,
            "CHECKV2_RECENT_NDR_LIMIT": 10,
            "CHECKV2_ACCOUNTS_FILE": "unused.txt",
            "GOOD_FILE": "good.txt",
            "BAD_FILE": "bad.txt",
        }
        with patch.object(checkv2, "_load_accounts", return_value=[account]), patch.object(
            checkv2, "_prepare_accounts"
        ), patch.object(checkv2, "_connect_smtp", return_value=smtp), patch.object(
            checkv2, "_connect_imap", return_value=_IMAP()
        ), patch.object(
            checkv2, "_folders", return_value=["INBOX"]
        ), patch.object(
            checkv2, "_capture_probe_checkpoints", return_value={"INBOX": set()}
        ), patch.object(
            checkv2, "_has_bounce", return_value=False
        ), patch.object(
            checkv2, "_capture_batch_checkpoints", return_value={}
        ), patch.object(
            checkv2, "_wait_for_batch_window", return_value=True
        ), patch.object(
            checkv2, "_scan_batch_bounces", return_value=set()
        ), patch.object(
            checkv2, "_append_address"
        ), patch.object(
            checkv2.time, "monotonic", side_effect=(0, 2)
        ):
            checkv2.run_checkv2(
                ["target@example.test"],
                config,
                lambda _recipient: (True, "queued"),
                lambda _message: None,
                lambda: False,
            )

        self.assertEqual(
            smtp.messages,
            [
                (
                    "control@example.test",
                    "target@example.test",
                    (
                        b"From: control@example.test\r\n"
                        b"To: target@example.test\r\n"
                        b"Subject: =?utf-8?b?dCdlcyBwcsOpc2VudD8=?=\r\n"
                        b"Content-Type: text/plain; charset=utf-8\r\n"
                        b"\r\n"
                        b".\r\n"
                    ),
                )
            ],
        )

    def test_authentication_rejection_keeps_account_source_before_a_batch_scan(self):
        class RejectedIMAP:
            def login(self, *_args):
                raise imaplib.IMAP4.error("invalid credentials")

            def logout(self):
                pass

        account = {
            "provider": "ovh",
            "email": "control@example.test",
            "password": "secret",
        }
        stats = {"auth_failed": 0}
        with tempfile.TemporaryDirectory() as directory:
            account_file = Path(directory) / "imap.txt"
            account_file.write_text("ovh|control@example.test|secret\n", encoding="utf-8")
            accounts = [account]
            with patch.object(checkv2, "_connect_imap", return_value=RejectedIMAP()):
                with self.assertRaises(checkv2.BatchScanError):
                    checkv2._capture_batch_checkpoints(
                        accounts,
                        str(account_file),
                        stats,
                        lambda _message: None,
                    )

            self.assertEqual(accounts, [])
            self.assertEqual(
                account_file.read_text(encoding="utf-8"),
                "ovh|control@example.test|secret\n",
            )
            self.assertEqual(stats["auth_failed"], 1)

    def test_one_of_multiple_accounts_lost_during_checkpoint_blocks_the_batch(self):
        rejected = {
            "provider": "ovh",
            "email": "rejected@example.test",
            "password": "secret",
        }
        remaining = {
            "provider": "homepl",
            "email": "remaining@example.test",
            "password": "secret",
        }
        stats = {"auth_failed": 0}
        with tempfile.TemporaryDirectory() as directory:
            account_file = Path(directory) / "imap.txt"
            account_file.write_text(
                "ovh|rejected@example.test|secret\nhomepl|remaining@example.test|secret\n",
                encoding="utf-8",
            )
            accounts = [rejected, remaining]
            def capture(account, _scope):
                if account == rejected:
                    return {
                        "status": "auth_error",
                        "checkpoints": {},
                        "error": "invalid credentials",
                    }
                return {
                    "status": "ok",
                    "checkpoints": {"INBOX": set()},
                    "error": "",
                }

            with patch.object(
                checkv2,
                "_capture_single_account_checkpoint",
                side_effect=capture,
            ):
                with self.assertRaises(checkv2.BatchScanError):
                    checkv2._capture_batch_checkpoints(
                        accounts,
                        str(account_file),
                        stats,
                        lambda _message: None,
                    )

            self.assertEqual(accounts, [remaining])
            self.assertEqual(
                account_file.read_text(encoding="utf-8"),
                "ovh|rejected@example.test|secret\n"
                "homepl|remaining@example.test|secret\n",
            )
            self.assertEqual(stats["auth_failed"], 1)

    def test_unavailable_imap_folders_prevent_resend_delivery(self):
        class UnavailableIMAP:
            def __init__(self, select_status="OK", search_status="OK"):
                self.select_status = select_status
                self.search_status = search_status

            def login(self, *_args):
                pass

            def logout(self):
                pass

            def select(self, _folder):
                return self.select_status, [b""]

            def uid(self, command, *_args):
                if command != "search":
                    raise AssertionError(f"commande IMAP inattendue : {command}")
                return self.search_status, [b""]

        account = {
            "provider": "ovh",
            "email": "control@example.test",
            "password": "secret",
        }
        config = {
            "CHECKV2_MAILBOX_SCOPE": "ALL",
            "CHECKV2_INITIAL_WAIT": 1,
            "CHECKV2_POLL_INTERVAL": 1,
            "CHECKV2_BATCH_SIZE": 1,
            "CHECKV2_BATCH_WAIT": 1,
            "CHECKV2_ACCOUNTS_FILE": "unused.txt",
        }

        for folders, imap in (
            ([], UnavailableIMAP()),
            (["INBOX"], UnavailableIMAP(select_status="NO")),
            (["INBOX"], UnavailableIMAP(search_status="NO")),
        ):
            with self.subTest(folders=folders, select=imap.select_status, search=imap.search_status):
                delivered = []
                with patch.object(checkv2, "_load_accounts", return_value=[account.copy()]), patch.object(
                    checkv2, "_connect_smtp", side_effect=lambda _account: _SMTP()
                ), patch.object(
                    checkv2, "_connect_imap", return_value=imap
                ), patch.object(
                    checkv2, "_folders", return_value=folders
                ), patch.object(
                    checkv2, "_has_bounce", return_value=False
                ), patch.object(
                    checkv2, "_append_address"
                ), patch.object(
                    checkv2.time, "monotonic", side_effect=(0, 2)
                ):
                    stats = checkv2.run_checkv2(
                        ["target@example.test"],
                        config,
                        lambda recipient: (delivered.append(recipient) is None, "queued"),
                        lambda _message: None,
                        lambda: False,
                    )

                self.assertEqual(delivered, [])
                self.assertEqual(stats["error"], 1)


class CheckV2FinalCleanupTests(unittest.TestCase):
    def test_final_cleanup_visits_all_folders_and_only_deletes_ndr(self):
        account = {
            "provider": "ovh",
            "email": "control@example.test",
            "password": "secret",
        }
        imap = _CleanupIMAP()
        stats = {"auth_failed": 0}
        logs = []

        with patch.object(checkv2, "_connect_imap", return_value=imap), patch.object(
            checkv2,
            "_folders",
            return_value=["INBOX", "Trash", "Sent"],
        ):
            checkv2._final_cleanup_bounces(
                [account],
                "unused.txt",
                stats,
                logs.append,
            )

        self.assertEqual(imap.selected, ["INBOX", "Trash", "Sent"])
        self.assertEqual(imap.stored, [b"2", b"2", b"2"])
        self.assertEqual(imap.expunged, ["INBOX", "Trash", "Sent"])
        self.assertEqual(stats["auth_failed"], 0)
        self.assertTrue(any("Nettoyage final terminé" in message for message in logs))


if __name__ == "__main__":
    unittest.main()