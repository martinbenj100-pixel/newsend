import base64
import os
import tempfile
import unittest
from email.message import Message
from unittest.mock import patch

from inline_logo import (
    MAX_DOWNLOAD_BYTES,
    download_logo_image,
    extract_base64_logo_image,
    find_logo_image_source,
    replace_logo_image_source,
)


class _ImageResponse:
    def __init__(self, data=b'original-image-bytes', content_type='image/png'):
        self.data = data
        self.headers = Message()
        self.headers['Content-Type'] = content_type
        self.headers['Content-Length'] = str(len(data))

    def __enter__(self):
        return self

    def __exit__(self, *_args):
        return False

    def read(self, size=-1):
        return self.data[:size]


class InlineLogoTests(unittest.TestCase):
    def test_finds_explicit_logo_before_other_images(self):
        html = (
            '<img src="https://example.test/banner.png">'
            '<img class="brand-logo" width="137" height="42" '
            'src="https://example.test/logo.png">'
        )
        self.assertEqual(
            find_logo_image_source(html),
            'https://example.test/logo.png',
        )

    def test_replacement_preserves_logo_dimensions(self):
        html = (
            '<img class="logo" width="137" height="42" '
            'style="max-width:137px" src="https://example.test/logo.png">'
        )
        replaced, found = replace_logo_image_source(html, 'cid:yoda-email-logo')
        self.assertTrue(found)
        self.assertIn('width="137"', replaced)
        self.assertIn('height="42"', replaced)
        self.assertIn('style="max-width:137px"', replaced)
        self.assertIn('src="cid:yoda-email-logo"', replaced)

    def test_download_stores_original_bytes_without_reencoding(self):
        with tempfile.TemporaryDirectory() as directory:
            response = _ImageResponse()
            with patch('inline_logo.urlopen', return_value=response):
                path = download_logo_image(
                    'https://example.test/assets/logo.png',
                    directory,
                )
            self.assertEqual(os.path.basename(path), 'fixed-letter-logo.png')
            with open(path, 'rb') as image_file:
                self.assertEqual(image_file.read(), response.data)

    def test_extracts_base64_logo_without_reencoding(self):
        original = b'\x89PNG\r\n\x1a\noriginal-image-bytes'
        source = 'data:image/png;base64,' + base64.b64encode(original).decode()
        with tempfile.TemporaryDirectory() as directory:
            path = extract_base64_logo_image(source, directory)
            self.assertEqual(os.path.basename(path), 'fixed-letter-logo.png')
            with open(path, 'rb') as image_file:
                self.assertEqual(image_file.read(), original)

    def test_rejects_malformed_base64_payload(self):
        with tempfile.TemporaryDirectory() as directory:
            with self.assertRaisesRegex(ValueError, 'invalides'):
                extract_base64_logo_image(
                    'data:image/png;base64,not-valid-***',
                    directory,
                )

    def test_rejects_unsupported_base64_image_type(self):
        payload = base64.b64encode(b'<svg/>').decode()
        with tempfile.TemporaryDirectory() as directory:
            with self.assertRaisesRegex(ValueError, 'non pris en charge'):
                extract_base64_logo_image(
                    f'data:image/svg+xml;base64,{payload}',
                    directory,
                )

    def test_rejects_empty_base64_payload(self):
        with tempfile.TemporaryDirectory() as directory:
            with self.assertRaisesRegex(ValueError, 'vide'):
                extract_base64_logo_image('data:image/png;base64,', directory)

    def test_rejects_oversized_base64_payload(self):
        oversized = base64.b64encode(b'x' * (MAX_DOWNLOAD_BYTES + 1)).decode()
        with tempfile.TemporaryDirectory() as directory:
            with self.assertRaisesRegex(ValueError, 'taille maximale'):
                extract_base64_logo_image(
                    f'data:image/png;base64,{oversized}',
                    directory,
                )

    def test_base64_logo_replacement_preserves_attributes(self):
        payload = base64.b64encode(b'image').decode()
        html = (
            '<img alt="Company logo" width="137" height="42" '
            f'src="data:image/png;base64,{payload}">'
        )
        replaced, found = replace_logo_image_source(html, 'cid:yoda-email-logo')
        self.assertTrue(found)
        self.assertIn('width="137"', replaced)
        self.assertIn('height="42"', replaced)
        self.assertIn('src="cid:yoda-email-logo"', replaced)

    def test_fixed_message_preparation_extracts_base64_logo_and_uses_cid(self):
        import send

        original = b'\x89PNG\r\n\x1a\nfixed-message-logo'
        payload = base64.b64encode(original).decode()
        html = (
            '<html><img class="logo" width="137" '
            f'src="data:image/png;base64,{payload}"></html>'
        )
        with tempfile.TemporaryDirectory() as directory:
            expected_path = os.path.join(directory, 'fixed-letter-logo.png')
            with (
                patch.dict(send.CONFIG, {'LOGO_FILE': '', 'LOGO': ''}),
                patch.object(
                    send,
                    'extract_base64_logo_image',
                    wraps=lambda source, _destination: extract_base64_logo_image(
                        source,
                        directory,
                    ),
                ),
                patch.object(send, 'print_colored'),
            ):
                prepared = send.prepare_fixed_message_logo(html)
                self.assertEqual(send.CONFIG['LOGO_FILE'], expected_path)
                self.assertEqual(send.CONFIG['LOGO'], 'cid:yoda-email-logo')

            self.assertIn('src="cid:yoda-email-logo"', prepared)
            self.assertIn('width="137"', prepared)
            with open(expected_path, 'rb') as image_file:
                self.assertEqual(image_file.read(), original)


if __name__ == '__main__':
    unittest.main()