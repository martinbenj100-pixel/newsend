import unittest

import app


class SmtpFileAccessTests(unittest.TestCase):
    def setUp(self):
        self.client = app.app.test_client()
        with self.client.session_transaction() as session:
            session["authenticated"] = True

    def test_smtp_file_is_hidden_from_file_editor_api(self):
        response = self.client.get("/api/file/smtp.txt")

        self.assertEqual(response.status_code, 403)
        self.assertEqual(
            response.get_json()["error"],
            "L'API YODA NE PERMET PAS L'ACCÈS AUX SMTP",
        )

    def test_smtp_manager_is_restored(self):
        response = self.client.get("/api/smtp/list")

        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.get_json()["success"])
        self.assertEqual(response.get_json()["entries"], [])

    def test_smtp_account_details_and_mutations_are_hidden(self):
        routes = [
            ("get", "/api/smtp/get/0", None),
            ("post", "/api/smtp/add", {}),
            ("post", "/api/smtp/update/0", {}),
            ("post", "/api/smtp/delete/0", None),
        ]

        for method, path, payload in routes:
            response = getattr(self.client, method)(path, json=payload)
            self.assertEqual(response.status_code, 403, path)


if __name__ == "__main__":
    unittest.main()