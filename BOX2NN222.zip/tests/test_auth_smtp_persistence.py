import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import send


class AuthSmtpPersistenceTests(unittest.TestCase):
    def setUp(self):
        self.original_project_dir = send.PROJECT_DIR
        self.original_config = dict(send.CONFIG)
        self.original_accounts = list(send.SMTP_ACCOUNTS)
        self.original_valid_accounts = list(send.VALID_SMTP_ACCOUNTS)
        self.directory = tempfile.TemporaryDirectory()
        send.PROJECT_DIR = self.directory.name
        send.CONFIG.clear()
        send.CONFIG.update({
            "SMTP_ACCOUNTS_FILE": "smtp.txt",
            "AUTH_SMTP_PORT": 587,
            "AUTH_SMTP_SERVER": "AUTO",
        })
        send.SMTP_ACCOUNTS[:] = []
        send.VALID_SMTP_ACCOUNTS[:] = []

    def tearDown(self):
        send.PROJECT_DIR = self.original_project_dir
        send.CONFIG.clear()
        send.CONFIG.update(self.original_config)
        send.SMTP_ACCOUNTS[:] = self.original_accounts
        send.VALID_SMTP_ACCOUNTS[:] = self.original_valid_accounts
        self.directory.cleanup()

    def _account(self):
        raw = "sender@example.test:secret:smtp.example.test:587"
        return {
            "email": "sender@example.test",
            "password": "secret",
            "smtp_server": "smtp.example.test",
            "smtp_port": 587,
            "raw": raw,
        }

    def test_validated_account_is_reused_without_another_network_test(self):
        account = self._account()
        Path(self.directory.name, "smtp.txt").write_text(
            account["raw"] + "\n",
            encoding="utf-8",
        )
        send.SMTP_ACCOUNTS.append(account)

        with patch.object(send, "validate_smtp_account", return_value=True) as validate:
            send.validate_all_smtp_accounts()
            send.VALID_SMTP_ACCOUNTS[:] = []
            send.validate_all_smtp_accounts()

        self.assertEqual(validate.call_count, 1)
        self.assertEqual(
            [item["email"] for item in send.VALID_SMTP_ACCOUNTS],
            ["sender@example.test"],
        )

    def test_third_consecutive_failure_removes_account_from_smtp_file(self):
        account = self._account()
        smtp_path = Path(self.directory.name, "smtp.txt")
        smtp_path.write_text(
            "# comptes\n" + account["raw"] + "\nother@example.test:x:smtp.test:587\n",
            encoding="utf-8",
        )
        send.SMTP_ACCOUNTS.append(account)
        send.VALID_SMTP_ACCOUNTS.append(account)
        send.mark_auth_smtp_success(account)

        self.assertFalse(send.mark_auth_smtp_failure(account))
        self.assertFalse(send.mark_auth_smtp_failure(account))
        self.assertTrue(send.mark_auth_smtp_failure(account))

        self.assertNotIn(account["raw"], smtp_path.read_text(encoding="utf-8"))
        self.assertIn("other@example.test", smtp_path.read_text(encoding="utf-8"))
        self.assertEqual(send.SMTP_ACCOUNTS, [])
        self.assertEqual(send.VALID_SMTP_ACCOUNTS, [])
        state = json.loads(
            Path(self.directory.name, "auth_smtp_state.json").read_text(encoding="utf-8")
        )
        self.assertEqual(state["accounts"], {})

    def test_success_resets_previous_failure_count(self):
        account = self._account()
        Path(self.directory.name, "smtp.txt").write_text(
            account["raw"] + "\n",
            encoding="utf-8",
        )
        send.mark_auth_smtp_success(account)
        send.mark_auth_smtp_failure(account)
        send.mark_auth_smtp_success(account)

        state = json.loads(
            Path(self.directory.name, "auth_smtp_state.json").read_text(encoding="utf-8")
        )
        record = state["accounts"][send._auth_smtp_account_key(account)]
        self.assertEqual(record["failure_count"], 0)


if __name__ == "__main__":
    unittest.main()