"""Connexions SMTP compatibles avec les environnements sans IPv6 sortant."""

import smtplib
import socket
import ssl


def _resolve_ipv4(host: str, port: int) -> str:
    """Retourne une adresse IPv4 pour *host* sans modifier le nom TLS."""
    try:
        addresses = socket.getaddrinfo(
            host,
            port,
            family=socket.AF_INET,
            type=socket.SOCK_STREAM,
        )
    except socket.gaierror as exc:
        raise OSError(f"Impossible de résoudre une adresse IPv4 pour {host}") from exc

    if not addresses:
        raise OSError(f"Aucune adresse IPv4 disponible pour {host}")

    return addresses[0][4][0]


class IPv4SMTP(smtplib.SMTP):
    """SMTP explicite qui se connecte en IPv4 mais conserve le nom du serveur."""

    def _get_socket(self, host, port, timeout):
        ipv4_address = _resolve_ipv4(host, port)
        return socket.create_connection(
            (ipv4_address, port),
            timeout,
            self.source_address,
        )


class IPv4SMTP_SSL(smtplib.SMTP_SSL):
    """SMTP implicite TLS avec connexion IPv4 et validation TLS par nom d'hôte."""

    def _get_socket(self, host, port, timeout):
        ipv4_address = _resolve_ipv4(host, port)
        raw_socket = socket.create_connection(
            (ipv4_address, port),
            timeout,
            self.source_address,
        )
        return self.context.wrap_socket(raw_socket, server_hostname=host)


def open_smtp(host, port, *, timeout=30, ssl_context=None):
    """Ouvre une connexion SMTP en privilégiant IPv4.

    Le protocole TLS implicite est utilisé uniquement sur le port 465.
    Pour les autres ports, l'appelant peut lancer STARTTLS après EHLO.
    """
    port = int(port)
    if port == 465:
        context = ssl_context or ssl.create_default_context()
        return IPv4SMTP_SSL(host, port, timeout=timeout, context=context)
    return IPv4SMTP(host, port, timeout=timeout)


def establish_tls(server, host, port, *, required=True):
    """Sécurise une connexion SMTP avec TLS réel.

    Le port 465 est déjà chiffré par SMTP_SSL. Sur les autres ports,
    STARTTLS est négocié après EHLO. Quand TLS est requis, une connexion
    vers un serveur qui ne l'annonce pas est refusée au lieu de continuer
    en clair.
    """
    port = int(port)
    if port == 465:
        return True

    if not getattr(server, "esmtp_features", None):
        server.ehlo()

    if server.has_extn("starttls"):
        server.starttls(context=ssl.create_default_context())
        server.ehlo()
        return True

    if required:
        raise smtplib.SMTPNotSupportedError(
            f"Le serveur SMTP {host}:{port} n'annonce pas STARTTLS."
        )
    return False