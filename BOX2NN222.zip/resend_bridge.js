const fs = require("node:fs");
const { ReplitConnectors } = require("@replit/connectors-sdk");

async function main() {
  const request = JSON.parse(fs.readFileSync(0, "utf8"));
  const connectors = new ReplitConnectors();
  const response = await connectors.proxy("resend", request.path, {
    method: request.method || "POST",
    headers: { "Content-Type": "application/json" },
    body: request.body ? JSON.stringify(request.body) : undefined,
  });

  const rawBody = await response.text();
  let body = rawBody;
  try {
    body = rawBody ? JSON.parse(rawBody) : {};
  } catch {
    // The Resend API normally returns JSON; preserve a non-JSON error if any.
  }

  process.stdout.write(JSON.stringify({
    ok: response.ok,
    status: response.status,
    body,
  }));
}

main().catch((error) => {
  process.stdout.write(JSON.stringify({
    ok: false,
    status: 0,
    error: error?.message || String(error),
  }));
  process.exitCode = 1;
});