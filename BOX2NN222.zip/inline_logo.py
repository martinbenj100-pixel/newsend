#!/usr/bin/env python3
"""Détection, téléchargement et remplacement du logo d'un e-mail HTML."""

import base64
import binascii
import mimetypes
import os
import re
import tempfile
from urllib.parse import urlparse
from urllib.request import Request, urlopen


IMG_TAG_PATTERN = re.compile(r'<img\b[^>]*>', re.IGNORECASE)
SRC_PATTERN = re.compile(
    r'(\bsrc\s*=\s*)(["\'])(.*?)\2',
    re.IGNORECASE | re.DOTALL,
)
ALLOWED_IMAGE_TYPES = {
    'image/gif': '.gif',
    'image/jpeg': '.jpg',
    'image/png': '.png',
    'image/webp': '.webp',
}
MAX_DOWNLOAD_BYTES = 5 * 1024 * 1024
DATA_IMAGE_PATTERN = re.compile(
    r'^data:([^;,]+);base64,(.*)$',
    re.IGNORECASE | re.DOTALL,
)


def find_logo_image_source(html: str) -> str | None:
    """Retourne la source de l'image la plus susceptible d'être le logo."""
    if not html:
        return None

    matches = list(IMG_TAG_PATTERN.finditer(html))
    if not matches:
        return None

    selected = None
    for match in matches:
        tag = match.group(0)
        if re.search(r'\b(?:alt|id|class)\s*=\s*(["\'])[^"\']*logo[^"\']*\1', tag, re.IGNORECASE):
            selected = match
            break
        src_match = SRC_PATTERN.search(tag)
        if src_match and 'logo' in src_match.group(3).lower():
            selected = match
            break

    if selected is None:
        selected = matches[0]

    src_match = SRC_PATTERN.search(selected.group(0))
    return src_match.group(3).strip() if src_match else None


def download_logo_image(
    source: str,
    destination_dir: str,
    basename: str = 'fixed-letter-logo',
) -> str:
    """Télécharge une image distante sans la redimensionner ni la réencoder."""
    parsed = urlparse(source)
    if parsed.scheme not in {'http', 'https'} or not parsed.netloc:
        raise ValueError("Le lien du logo doit être une URL HTTP ou HTTPS.")

    request = Request(source, headers={'User-Agent': 'YODA-Mailer/1.0'})
    with urlopen(request, timeout=15) as response:
        content_type = response.headers.get_content_type().lower()
        if content_type not in ALLOWED_IMAGE_TYPES:
            guessed_type, _ = mimetypes.guess_type(parsed.path)
            content_type = guessed_type or content_type
        if content_type not in ALLOWED_IMAGE_TYPES:
            raise ValueError(f"Format d'image non pris en charge : {content_type}")

        declared_size = response.headers.get('Content-Length')
        if declared_size and int(declared_size) > MAX_DOWNLOAD_BYTES:
            raise ValueError("Le logo distant dépasse la taille maximale de 5 Mo.")

        data = response.read(MAX_DOWNLOAD_BYTES + 1)
        if not data:
            raise ValueError("Le logo distant est vide.")
        if len(data) > MAX_DOWNLOAD_BYTES:
            raise ValueError("Le logo distant dépasse la taille maximale de 5 Mo.")

    return _store_logo_image(data, content_type, destination_dir, basename)


def extract_base64_logo_image(
    source: str,
    destination_dir: str,
    basename: str = 'fixed-letter-logo',
) -> str:
    """Décode et stocke une image Base64 data URI sans modifier ses octets."""
    match = DATA_IMAGE_PATTERN.fullmatch(source.strip())
    if not match:
        raise ValueError(
            "Le logo Base64 doit être une data URI image encodée en base64."
        )

    content_type = match.group(1).lower()
    if content_type not in ALLOWED_IMAGE_TYPES:
        raise ValueError(f"Format d'image non pris en charge : {content_type}")

    payload = ''.join(match.group(2).split())
    if not payload:
        raise ValueError("Le logo Base64 est vide.")

    maximum_encoded_size = ((MAX_DOWNLOAD_BYTES + 2) // 3) * 4
    if len(payload) > maximum_encoded_size:
        raise ValueError("Le logo Base64 dépasse la taille maximale de 5 Mo.")

    try:
        data = base64.b64decode(payload, validate=True)
    except (binascii.Error, ValueError) as exc:
        raise ValueError("Les données Base64 du logo sont invalides.") from exc

    if not data:
        raise ValueError("Le logo Base64 est vide.")
    if len(data) > MAX_DOWNLOAD_BYTES:
        raise ValueError("Le logo Base64 dépasse la taille maximale de 5 Mo.")

    return _store_logo_image(data, content_type, destination_dir, basename)


def _store_logo_image(
    data: bytes,
    content_type: str,
    destination_dir: str,
    basename: str,
) -> str:
    """Stocke atomiquement le logo et supprime les anciennes variantes."""
    os.makedirs(destination_dir, exist_ok=True)
    extension = ALLOWED_IMAGE_TYPES[content_type]
    final_path = os.path.join(destination_dir, f'{basename}{extension}')
    descriptor, temporary_path = tempfile.mkstemp(
        prefix=f'.{basename}-',
        suffix='.tmp',
        dir=destination_dir,
    )
    try:
        with os.fdopen(descriptor, 'wb') as image_file:
            image_file.write(data)
        os.replace(temporary_path, final_path)
    except Exception:
        try:
            os.unlink(temporary_path)
        except OSError:
            pass
        raise

    for filename in os.listdir(destination_dir):
        candidate = os.path.join(destination_dir, filename)
        if filename.startswith(basename) and candidate != final_path:
            try:
                os.unlink(candidate)
            except OSError:
                pass
    return final_path


def replace_logo_image_source(html: str, source: str) -> tuple[str, bool]:
    """Remplace la source de l'image qui représente le plus probablement le logo.

    La priorité va aux images explicitement marquées comme logo, puis aux images
    embarquées en data URI. En dernier recours, la première image du message est
    utilisée, ce qui correspond à l'emplacement habituel du logo d'en-tête.
    """
    if not html or not source:
        return html, False

    matches = list(IMG_TAG_PATTERN.finditer(html))
    if not matches:
        return html, False

    selected = None
    for match in matches:
        tag = match.group(0)
        if re.search(r'\b(?:alt|id|class)\s*=\s*(["\'])[^"\']*logo[^"\']*\1', tag, re.IGNORECASE):
            selected = match
            break
        src_match = SRC_PATTERN.search(tag)
        if src_match and 'logo' in src_match.group(3).lower():
            selected = match
            break

    if selected is None:
        for match in matches:
            src_match = SRC_PATTERN.search(match.group(0))
            if src_match and src_match.group(3).lower().startswith('data:image/'):
                selected = match
                break

    if selected is None:
        selected = matches[0]

    tag = selected.group(0)
    if SRC_PATTERN.search(tag):
        updated_tag = SRC_PATTERN.sub(
            lambda match: f'{match.group(1)}{match.group(2)}{source}{match.group(2)}',
            tag,
            count=1,
        )
    else:
        updated_tag = tag[:-1] + f' src="{source}">'

    return html[:selected.start()] + updated_tag + html[selected.end():], True