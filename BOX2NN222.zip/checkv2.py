"""CHECKV2 — validation SMTP/IMAP avec détection de bounces.

Le validateur envoie un message minimal depuis les comptes définis dans
``imap.txt`` puis surveille leurs boîtes IMAP. Une adresse sans NDR dans le
délai configuré est considérée valide et remise immédiatement au callback
d'envoi fourni par ``send.py``.
"""

from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor, as_completed
from email.header import Header, decode_header
import imaplib
import os
import re
import smtplib
import ssl
import time
from datetime import datetime
from pathlib import Path
from typing import Callable


SPAM_FOLDERS = (
    "INBOX.Spam",
    "Spam",
    "Junk",
    "Junk E-mail",
    "Indésirables",
    "INBOX.Junk",
    "INBOX.Indésirables",
)

SENT_FOLDER_MARKERS = (
    "sent",
    "sent items",
    "envoy",
    "éléments envoyés",
    "element envoy",
)
CONTROL_SUBJECT = "t'es présent?"
CONTROL_SEARCH_TERM = "t'es"
MAX_BATCH_IMAP_WORKERS = 20
_ACTIVE_BATCH_IMAP_WORKERS: int | None = None

BOUNCE_SEARCH_CRITERIA = (
    ("FROM", "mailer-daemon"),
    ("FROM", "message-status"),
    ("SUBJECT", "undeliverable"),
    ("SUBJECT", "échec de remise"),
    ("SUBJECT", "delivery failed"),
    ("SUBJECT", "failure notice"),
    ("SUBJECT", "returned mail"),
    ("SUBJECT", "mail delivery failed"),
    ("SUBJECT", "non remis"),
    ("SUBJECT", "remise impossible"),
    ("SUBJECT", "delivery status notification"),
    ("SUBJECT", "recipient rejected"),
    ("SUBJECT", "bounce"),
)

PROVIDERS = {
    "ovh": {
        "smtp_server": "smtp.mail.ovh.net",
        "smtp_port": 465,
        "imap_server": "ssl0.ovh.net",
        "imap_port": 993,
    },
    "homepl": {
        "smtp_server": "poczta2582757.home.pl",
        "smtp_port": 465,
        "imap_server": "poczta2582757.home.pl",
        "imap_port": 993,
    },
}


class AccountAuthenticationError(RuntimeError):
    """Erreur d'identifiants : le compte ne doit plus être réutilisé."""


class BatchScanError(RuntimeError):
    """La seconde vérification d'un lot n'est pas assez fiable pour envoyer."""


def _load_accounts_from_lines(lines: list[str], source: str) -> list[dict[str, object]]:
    accounts: list[dict[str, object]] = []
    for line_number, raw_line in enumerate(lines, start=1):
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        parts = [part.strip() for part in line.split("|", 2)]
        if len(parts) < 3:
            raise RuntimeError(f"{source}, ligne {line_number} : format invalide.")
        provider = parts[0].lower()
        if provider not in PROVIDERS:
            raise RuntimeError(
                f"{source}, ligne {line_number} : fournisseur inconnu ({provider})."
            )
        accounts.append(
            {
                "provider": provider,
                "email": parts[1],
                "password": parts[2],
                **PROVIDERS[provider],
            }
        )

    if not accounts:
        raise RuntimeError(f"Aucun compte exploitable dans {source}.")
    return accounts


def _load_accounts(path: str) -> list[dict[str, object]]:
    file_path = Path(path)
    if not file_path.exists():
        raise RuntimeError(
            f"Fichier {path} introuvable. Format attendu : provider|email|password"
        )
    return _load_accounts_from_lines(
        file_path.read_text(encoding="utf-8").splitlines(),
        str(file_path),
    )


def _load_runtime_accounts(account_file: str) -> tuple[list[dict[str, object]], str]:
    """Charge les comptes CHECKV2 exclusivement depuis imap.txt."""
    return _load_accounts(account_file), "imap.txt"


def _connect_smtp(account: dict[str, object]) -> smtplib.SMTP_SSL:
    return smtplib.SMTP_SSL(
        str(account["smtp_server"]),
        int(account["smtp_port"]),
        context=ssl.create_default_context(),
        timeout=20,
    )


def _connect_imap(account: dict[str, object]) -> imaplib.IMAP4_SSL:
    return imaplib.IMAP4_SSL(
        str(account["imap_server"]),
        int(account["imap_port"]),
        ssl_context=ssl.create_default_context(),
        timeout=20,
    )


def _imap_error_detail(error: BaseException) -> str:
    """Retourne un détail serveur court, sans données d'authentification."""
    detail = " ".join(str(error).split())
    detail = re.sub(
        r"(?i)(password|passwd|pass|secret)\s*[=:]\s*\S+",
        r"\1=[masqué]",
        detail,
    )
    return detail[:180] or type(error).__name__


def _imap_supports_plain(imap: imaplib.IMAP4_SSL) -> bool:
    try:
        status, capabilities = imap.capability()
    except Exception:
        return False
    if str(status).upper() != "OK":
        return False
    normalized = {
        token
        for item in (capabilities or [])
        for token in (
            item.decode("ascii", "replace")
            if isinstance(item, bytes)
            else str(item)
        ).upper().split()
    }
    return "AUTH=PLAIN" in normalized


def _login_imap(imap: imaplib.IMAP4_SSL, account: dict[str, object]) -> None:
    """Authentifie une boîte IMAP avec le mécanisme OVH de secours."""
    email_address = str(account["email"])
    password = str(account["password"])
    first_error: BaseException | None = None
    try:
        response = imap.login(email_address, password)
    except imaplib.IMAP4.error as error:
        first_error = error
        response = None

    # imaplib retourne normalement ("OK", ...). Les implémentations de test
    # légères peuvent ne rien retourner après une authentification réussie.
    status = response[0] if isinstance(response, tuple) and response else None
    if first_error is None and (status is None or str(status).upper() == "OK"):
        return

    # OVH annonce AUTH=PLAIN et AUTH=LOGIN. Si LOGIN est refusé par le
    # serveur, tenter PLAIN sur la même connexion évite un faux négatif.
    if _imap_supports_plain(imap):
        try:
            response = imap.authenticate(
                "PLAIN",
                lambda _challenge: f"\x00{email_address}\x00{password}".encode(
                    "utf-8"
                ),
            )
            fallback_status = (
                response[0]
                if isinstance(response, tuple) and response
                else "OK"
            )
            if str(fallback_status).upper() == "OK":
                return
            first_error = imaplib.IMAP4.error(
                f"AUTH=PLAIN returned {fallback_status}"
            )
        except imaplib.IMAP4.error as error:
            if first_error is None:
                first_error = error

    if first_error is None:
        first_error = imaplib.IMAP4.error(f"LOGIN returned {status}")
    raise AccountAuthenticationError(
        f"IMAP {account['provider']} : authentification refusée "
        f"({type(first_error).__name__}: {_imap_error_detail(first_error)})"
    ) from first_error


def _message_is_bounce(message) -> bool:
    sender = str(message.get("From", "")).lower()
    subject = str(message.get("Subject", "")).lower()
    if "mailer-daemon" in sender or "message-status" in sender:
        return True
    keywords = (
        "undeliverable",
        "échec de remise",
        "delivery failed",
        "failure notice",
        "returned mail",
        "mail delivery failed",
        "non remis",
        "remise impossible",
        "delivery status notification",
        "recipient rejected",
        "bounce",
    )
    return any(keyword in subject for keyword in keywords)


def _search_message_ids(
    imap: imaplib.IMAP4_SSL,
    *criteria: str,
) -> tuple[bool, list[bytes]]:
    """Recherche des UID côté serveur et indique si la requête est supportée."""
    try:
        status, messages = imap.uid("search", None, *criteria)
    except Exception:
        return False, []
    if status != "OK":
        return False, []
    if not messages:
        return True, []
    return True, messages[0].split()


def _bounce_candidate_ids(imap: imaplib.IMAP4_SSL) -> list[bytes]:
    """Cible les NDR par IMAP avant de replier sur un scan complet si nécessaire."""
    candidate_ids: set[bytes] = set()
    supported_searches = 0
    for criteria in BOUNCE_SEARCH_CRITERIA:
        supported, message_ids = _search_message_ids(imap, *criteria)
        if supported:
            supported_searches += 1
            candidate_ids.update(message_ids)

    if supported_searches:
        return sorted(candidate_ids, key=lambda message_id: int(message_id))

    _supported, message_ids = _search_message_ids(imap, "ALL")
    return message_ids


def _message_body(message) -> str:
    chunks: list[str] = []
    for part in message.walk() if message.is_multipart() else (message,):
        if part.get_content_type() not in ("text/plain", "text/html"):
            continue
        payload = part.get_payload(decode=True)
        if payload:
            chunks.append(payload.decode("utf-8", errors="ignore"))
    return "\n".join(chunks)


def _bounce_mentions_address(body: str, recipient: str) -> bool:
    if recipient.lower() in body.lower():
        return True
    patterns = (
        r"Final-Recipient:\s*rfc822;\s*([^>\s]+@[^>\s]+)",
        r"Original-Recipient:\s*rfc822;\s*([^>\s]+@[^>\s]+)",
        r"<([^>]+@[^>]+)>:\s+host.*?said:\s+5\d{2}",
    )
    return any(
        match and match.group(1).strip().lower() == recipient.lower()
        for pattern in patterns
        if (match := re.search(pattern, body, re.IGNORECASE | re.MULTILINE))
    )


def _folders(imap: imaplib.IMAP4_SSL) -> list[str]:
    names = ["INBOX"]
    try:
        status, folders = imap.list()
        if status == "OK":
            for folder in folders:
                decoded = folder.decode("utf-8", errors="ignore")
                match = re.search(r'"([^"]+)"$', decoded)
                if match and match.group(1) not in names:
                    names.append(match.group(1))
    except Exception:
        pass

    for folder in SPAM_FOLDERS:
        if folder not in names:
            try:
                if imap.select(folder)[0] == "OK":
                    names.append(folder)
            except Exception:
                pass
    return names


def _folders_for_scope(
    imap: imaplib.IMAP4_SSL,
    scope: str,
) -> list[str]:
    """Retourne les dossiers contrôlés selon le réglage choisi."""
    normalized_scope = scope.strip().upper()
    if normalized_scope == "INBOX":
        return ["INBOX"]
    if normalized_scope == "ALL":
        return _folders(imap)
    raise RuntimeError(
        f"périmètre IMAP invalide ({scope!r}); utilisez INBOX ou ALL"
    )


def _sent_folders(folders: list[str]) -> list[str]:
    """Retourne les dossiers susceptibles de contenir les messages envoyés."""
    result: list[str] = []
    for folder in folders:
        normalized = folder.casefold()
        if any(marker in normalized for marker in SENT_FOLDER_MARKERS):
            if folder not in result:
                result.append(folder)
    return result


def _delete_message_ids(
    imap: imaplib.IMAP4_SSL,
    message_ids: list[bytes],
    folder: str,
) -> None:
    """Marque puis supprime définitivement un ensemble de messages du dossier actif."""
    if not message_ids:
        return
    status, _ = imap.uid(
        "store",
        b",".join(message_ids),
        "+FLAGS.SILENT",
        r"(\Deleted)",
    )
    if status != "OK":
        raise RuntimeError(f"suppression IMAP impossible ({folder})")
    status, _ = imap.expunge()
    if status != "OK":
        raise RuntimeError(f"validation de suppression IMAP impossible ({folder})")


def _decode_header_value(value: object) -> str:
    if not value:
        return ""
    decoded: list[str] = []
    for part, charset in decode_header(str(value)):
        if isinstance(part, bytes):
            decoded.append(part.decode(charset or "utf-8", errors="replace"))
        else:
            decoded.append(part)
    return "".join(decoded)


def _is_control_message(message, recipient: str) -> bool:
    """Identifie une copie du message CHECKV2 dans le dossier Envoyés."""
    subject = _decode_header_value(message.get("Subject", "")).strip().casefold()
    if subject != CONTROL_SUBJECT.casefold():
        return False
    to_header = str(message.get("To", "")).casefold()
    if recipient.casefold() not in to_header:
        return False
    return _message_body(message).strip() == "."


def _capture_sent_checkpoints(
    imap: imaplib.IMAP4_SSL,
    folders: list[str],
) -> dict[str, set[bytes]]:
    """Mémorise les UID du dossier Envoyés avant un message de contrôle."""
    checkpoints: dict[str, set[bytes]] = {}
    for folder in _sent_folders(folders):
        try:
            if imap.select(folder)[0] != "OK":
                continue
            status, messages = imap.uid("search", None, "ALL")
            if status == "OK" and messages:
                checkpoints[folder] = set(messages[0].split())
        except Exception:
            continue
    return checkpoints


def _delete_sent_control_messages(
    imap: imaplib.IMAP4_SSL,
    checkpoints: dict[str, set[bytes]],
    recipient: str,
) -> None:
    """Supprime les nouvelles copies du message de contrôle dans Envoyés."""
    import email as email_parser

    for folder, checkpoint in checkpoints.items():
        if imap.select(folder)[0] != "OK":
            continue
        status, messages = imap.uid("search", None, "ALL")
        if status != "OK" or not messages:
            continue
        new_ids = [
            message_id
            for message_id in messages[0].split()
            if message_id not in checkpoint
        ]
        to_delete: list[bytes] = []
        for message_id in new_ids:
            status, data = imap.uid("fetch", message_id, "(RFC822)")
            if status != "OK" or not data or not data[0]:
                continue
            message = email_parser.message_from_bytes(data[0][1])
            if _is_control_message(message, recipient):
                to_delete.append(message_id)
        _delete_message_ids(imap, to_delete, folder)


def _has_bounce(
    imap: imaplib.IMAP4_SSL,
    folders: list[str],
    recipient: str,
    checkpoints: dict[str, set[bytes]] | None = None,
) -> bool:
    import email as email_parser

    for folder in folders:
        try:
            if imap.select(folder)[0] != "OK":
                continue
            if checkpoints is None:
                status, messages = imap.search(None, "UNSEEN")
                message_ids = messages[0].split() if status == "OK" and messages else []
                fetch_message = lambda message_id: imap.fetch(message_id, "(RFC822)")
            else:
                status, messages = imap.uid("search", None, "ALL")
                if status != "OK" or not messages:
                    continue
                message_ids = [
                    message_id
                    for message_id in messages[0].split()
                    if message_id not in checkpoints.get(folder, set())
                ]
                fetch_message = lambda message_id: imap.uid(
                    "fetch", message_id, "(RFC822)"
                )
            if status != "OK":
                continue
            for message_id in message_ids:
                status, data = fetch_message(message_id)
                if status != "OK" or not data or not data[0]:
                    continue
                message = email_parser.message_from_bytes(data[0][1])
                if _message_is_bounce(message) and _bounce_mentions_address(
                    _message_body(message), recipient
                ):
                    try:
                        if checkpoints is None:
                            imap.store(message_id, "+FLAGS", r"(\Deleted)")
                            imap.expunge()
                        else:
                            _delete_message_ids(imap, [message_id], folder)
                    except Exception:
                        pass
                    return True
        except Exception:
            continue
    return False


def _capture_probe_checkpoints(
    imap: imaplib.IMAP4_SSL,
    folders: list[str],
) -> dict[str, set[bytes]]:
    """Mémorise les UID présents avant l'envoi du message de contrôle."""
    checkpoints: dict[str, set[bytes]] = {}
    if not folders:
        raise BatchScanError("aucun dossier IMAP disponible avant le contrôle")

    for folder in folders:
        if imap.select(folder)[0] != "OK":
            raise BatchScanError(f"sélection IMAP impossible avant le contrôle ({folder})")
        status, messages = imap.uid("search", None, "ALL")
        if status != "OK" or not messages:
            raise BatchScanError(f"lecture IMAP impossible avant le contrôle ({folder})")
        checkpoints[folder] = set(messages[0].split())
    return checkpoints


def _mailbox_cleanup_targets(folders: list[str]) -> list[str]:
    """Retourne INBOX et les dossiers identifiés comme spam."""
    targets: list[str] = []
    for folder in folders:
        normalized = folder.casefold()
        if folder == "INBOX" or any(
            marker in normalized
            for marker in ("spam", "junk", "indésirable", "indesirable")
        ):
            if folder not in targets:
                targets.append(folder)
    return targets


def _clean_bounces_in_folders(
    imap: imaplib.IMAP4_SSL,
    folders: list[str],
) -> list[str]:
    """Supprime uniquement les NDR dans les dossiers fournis."""
    import email as email_parser

    cleaned: list[str] = []
    for folder in folders:
        if imap.select(folder)[0] != "OK":
            raise RuntimeError(f"sélection IMAP impossible pour le nettoyage ({folder})")
        message_ids = _bounce_candidate_ids(imap)
        ndr_ids: list[bytes] = []
        for message_id in message_ids:
            status, data = imap.uid(
                "fetch",
                message_id,
                "(BODY.PEEK[HEADER.FIELDS (FROM SUBJECT)])",
            )
            if status != "OK" or not data or not data[0]:
                raise RuntimeError(f"lecture du message IMAP impossible ({folder})")
            message = email_parser.message_from_bytes(data[0][1])
            if _message_is_bounce(message):
                ndr_ids.append(message_id)
        _delete_message_ids(imap, ndr_ids, folder)
        cleaned.append(folder)
    return cleaned


def _clean_mailboxes(
    imap: imaplib.IMAP4_SSL,
    folders: list[str],
) -> list[str]:
    """Supprime uniquement les NDR présents dans INBOX et les dossiers Spam."""
    targets = _mailbox_cleanup_targets(folders)
    if "INBOX" not in targets:
        raise RuntimeError("dossier INBOX indisponible pour le nettoyage")
    return _clean_bounces_in_folders(imap, targets)


def _clean_sent_control_messages(
    imap: imaplib.IMAP4_SSL,
    folders: list[str],
) -> None:
    """Supprime les anciens messages CHECKV2 identifiables du dossier Envoyés."""
    import email as email_parser

    for folder in _sent_folders(folders):
        try:
            if imap.select(folder)[0] != "OK":
                continue
            supported, message_ids = _search_message_ids(
                imap,
                "SUBJECT",
                CONTROL_SEARCH_TERM,
            )
            if not supported:
                _supported, message_ids = _search_message_ids(imap, "ALL")
            to_delete: list[bytes] = []
            for message_id in message_ids:
                status, data = imap.uid("fetch", message_id, "(RFC822)")
                if status != "OK" or not data or not data[0]:
                    continue
                message = email_parser.message_from_bytes(data[0][1])
                if _decode_header_value(message.get("Subject", "")).strip().casefold() != CONTROL_SUBJECT.casefold():
                    continue
                if _message_body(message).strip() == ".":
                    to_delete.append(message_id)
            _delete_message_ids(imap, to_delete, folder)
        except Exception:
            continue


def _prepare_single_account(
    account: dict[str, object],
    folder_scope: str,
) -> dict[str, object]:
    """Nettoie un compte sur une connexion IMAP dédiée."""
    imap = None
    try:
        imap = _connect_imap(account)
        _login_imap(imap, account)
        all_folders = _folders(imap)
        folders = _folders_for_scope(imap, folder_scope)
        cleaned = _clean_mailboxes(imap, folders)
        _clean_sent_control_messages(imap, all_folders)
        return {"status": "usable", "cleaned": cleaned, "error": ""}
    except AccountAuthenticationError as error:
        return {"status": "auth_error", "cleaned": [], "error": str(error)}
    except Exception as error:
        return {"status": "error", "cleaned": [], "error": str(error)}
    finally:
        if imap:
            try:
                imap.logout()
            except Exception:
                pass


def _final_cleanup_single_account(
    account: dict[str, object],
) -> dict[str, object]:
    """Nettoie les NDR de tous les dossiers d'un compte après le dernier envoi."""
    imap = None
    try:
        imap = _connect_imap(account)
        _login_imap(imap, account)
        folders = _folders(imap)
        cleaned = _clean_bounces_in_folders(imap, folders)
        return {"status": "ok", "cleaned": cleaned, "error": ""}
    except AccountAuthenticationError as error:
        return {"status": "auth_error", "cleaned": [], "error": str(error)}
    except Exception as error:
        return {"status": "error", "cleaned": [], "error": str(error)}
    finally:
        if imap:
            try:
                imap.logout()
            except Exception:
                pass


def _final_cleanup_bounces(
    accounts: list[dict[str, object]],
    account_file: str,
    stats: dict[str, int],
    log: Callable[[str], None],
    max_concurrent_accounts: int | None = None,
) -> None:
    """Nettoie les NDR de tous les dossiers, en parallèle, après les envois."""
    original_accounts = list(accounts)
    if not original_accounts:
        return

    worker_limit = (
        max_concurrent_accounts
        if max_concurrent_accounts is not None
        else _ACTIVE_BATCH_IMAP_WORKERS or MAX_BATCH_IMAP_WORKERS
    )
    worker_count = max(1, min(worker_limit, len(original_accounts)))
    log(
        f"[CHECKV2] Nettoyage final des NDR dans tous les dossiers : "
        f"{len(original_accounts)} compte(s), {worker_count} worker(s)."
    )
    results: list[tuple[dict[str, object], dict[str, object]]] = []
    with ThreadPoolExecutor(max_workers=worker_count) as executor:
        futures = {
            executor.submit(_final_cleanup_single_account, account): account
            for account in original_accounts
        }
        for future in as_completed(futures):
            account = futures[future]
            results.append((account, future.result()))

    cleaned_folder_count = 0
    errors: list[str] = []
    for account, result in results:
        if result["status"] == "ok":
            cleaned_folder_count += len(result["cleaned"])
        elif result["status"] == "auth_error":
            _discard_authenticated_account(accounts, account, account_file, stats, log)
        else:
            errors.append(str(result["error"]))

    log(
        f"[CHECKV2] Nettoyage final terminé : "
        f"{cleaned_folder_count} dossier(s) traité(s), uniquement les NDR supprimés."
    )
    if errors:
        log(
            f"[CHECKV2] ⚠ Nettoyage final incomplet sur "
            f"{len(errors)} compte(s) ; les comptes concernés sont conservés."
        )


def _prepare_accounts(
    accounts: list[dict[str, object]],
    account_file: str,
    stats: dict[str, int],
    log: Callable[[str], None],
    folder_scope: str = "INBOX",
    max_concurrent_accounts: int = 20,
) -> None:
    """Nettoie les boîtes en parallèle et désactive les comptes inutilisables."""
    if not accounts:
        return

    worker_count = max(1, min(max_concurrent_accounts, len(accounts)))
    usable: list[dict[str, object]] = []
    total_accounts = len(accounts)
    completed_accounts = 0
    original_accounts = list(accounts)
    log(
        f"[CHECKV2] Nettoyage IMAP en cours : {total_accounts} compte(s), "
        f"{worker_count} worker(s) actif(s)."
    )
    with ThreadPoolExecutor(max_workers=worker_count) as executor:
        futures = {
            executor.submit(_prepare_single_account, account, folder_scope): account
            for account in original_accounts
        }
        completed_results: list[tuple[dict[str, object], dict[str, object]]] = []
        for future in as_completed(futures):
            account = futures[future]
            completed_accounts += 1
            result = future.result()
            completed_results.append((account, result))
            log(
                f"[CHECKV2] Nettoyage IMAP : {completed_accounts}/{total_accounts} "
                f"terminé(s) ({account['email']})."
            )

    for account, result in completed_results:
        if result["status"] == "usable":
            usable.append(account)
            cleaned = result["cleaned"]
            log(
                f"[CHECKV2] Nettoyage IMAP terminé pour {account['email']} : "
                f"{', '.join(cleaned)}."
            )
        elif result["status"] == "auth_error":
            _discard_authenticated_account(accounts, account, account_file, stats, log)
            log(
                f"[CHECKV2] ✗ Compte ignoré pendant le nettoyage : "
                f"{result['error']}"
            )
        else:
            log(
                f"[CHECKV2] ⚠ Nettoyage impossible pour {account['email']} : "
                f"{result['error']}. Compte conservé dans imap.txt et ignoré "
                "pour cette exécution."
            )

    accounts[:] = usable


def _append_address(path: str, address: str) -> None:
    with open(path, "a", encoding="utf-8") as file:
        file.write(f"{address}\n")


def _discard_authenticated_account(
    accounts: list[dict[str, object]],
    account: dict[str, object],
    account_file: str,
    stats: dict[str, int],
    log: Callable[[str], None],
) -> None:
    """Écarte un compte refusé pour cette exécution sans modifier sa source."""
    if account in accounts:
        accounts.remove(account)

    stats["auth_failed"] = stats.get("auth_failed", 0) + 1
    log(
        f"[CHECKV2] ⚠ Authentification refusée pour "
        f"{account['provider']}|{account['email']}. "
        "Compte conservé dans sa source et ignoré pour cette exécution."
    )


def _account_key(account: dict[str, object]) -> str:
    return f"{account['provider']}|{account['email']}"


def _capture_single_account_checkpoint(
    account: dict[str, object],
    folder_scope: str,
) -> dict[str, object]:
    """Capture les UID d'un compte sur une connexion IMAP dédiée."""
    imap = None
    try:
        imap = _connect_imap(account)
        _login_imap(imap, account)
        folders = _folders_for_scope(imap, folder_scope)
        if not folders:
            raise BatchScanError(
                f"aucun dossier IMAP disponible pour {account['email']}"
            )
        folder_checkpoints: dict[str, set[bytes]] = {}
        for folder in folders:
            if imap.select(folder)[0] != "OK":
                raise BatchScanError(f"sélection IMAP impossible ({folder})")
            status, messages = imap.uid("search", None, "ALL")
            if status != "OK" or not messages:
                raise BatchScanError(f"lecture IMAP impossible ({folder})")
            folder_checkpoints[folder] = set(messages[0].split())
        return {"status": "ok", "checkpoints": folder_checkpoints, "error": ""}
    except AccountAuthenticationError as error:
        return {"status": "auth_error", "checkpoints": {}, "error": str(error)}
    except BatchScanError as error:
        return {"status": "error", "checkpoints": {}, "error": str(error)}
    except Exception as error:
        return {"status": "error", "checkpoints": {}, "error": str(error)}
    finally:
        if imap:
            try:
                imap.logout()
            except Exception:
                pass


def _capture_batch_checkpoints(
    accounts: list[dict[str, object]],
    account_file: str,
    stats: dict[str, int],
    log: Callable[[str], None],
    folder_scope: str = "INBOX",
    max_concurrent_accounts: int | None = None,
) -> dict[str, dict[str, set[bytes]]]:
    """Mémorise les UID déjà présents avant l'attente finale du lot."""
    checkpoints: dict[str, dict[str, set[bytes]]] = {}
    original_accounts = list(accounts)
    worker_limit = (
        max_concurrent_accounts
        if max_concurrent_accounts is not None
        else _ACTIVE_BATCH_IMAP_WORKERS or MAX_BATCH_IMAP_WORKERS
    )
    worker_count = max(1, min(worker_limit, len(original_accounts)))
    log(
        f"[CHECKV2] Point de contrôle IMAP en parallèle : "
        f"{len(original_accounts)} compte(s), {worker_count} worker(s)."
    )
    results: list[tuple[dict[str, object], dict[str, object]]] = []
    with ThreadPoolExecutor(max_workers=worker_count) as executor:
        futures = {
            executor.submit(
                _capture_single_account_checkpoint,
                account,
                folder_scope,
            ): account
            for account in original_accounts
        }
        completed_accounts = 0
        for future in as_completed(futures):
            account = futures[future]
            results.append((account, future.result()))
            completed_accounts += 1
            log(
                f"[CHECKV2] Point de contrôle IMAP : "
                f"{completed_accounts}/{len(original_accounts)} terminé(s) "
                f"({account['email']})."
            )

    errors: list[str] = []
    auth_failed = False
    for account, result in results:
        if result["status"] == "auth_error":
            _discard_authenticated_account(accounts, account, account_file, stats, log)
            auth_failed = True
        elif result["status"] != "ok":
            errors.append(
                f"{account['provider']}|{account['email']} : {result['error']}"
            )
        else:
            checkpoints[_account_key(account)] = result["checkpoints"]

    if auth_failed:
        raise BatchScanError(
            "authentification IMAP perdue pendant le point de contrôle du lot"
        )
    if errors:
        raise BatchScanError(errors[0])

    if not accounts:
        raise BatchScanError("aucun compte IMAP authentifié restant pour valider le lot")
    return checkpoints


def _recent_bounced_recipients(
    imap: imaplib.IMAP4_SSL,
    folders: list[str],
    recipients: list[str],
    recent_limit: int,
    checkpoints: dict[str, set[bytes]],
) -> set[str]:
    """Cherche les NDR dans les N derniers messages et ceux reçus depuis le lot."""
    import email as email_parser

    if not folders:
        raise BatchScanError("aucun dossier IMAP disponible pour la seconde analyse")

    bounced: set[str] = set()
    for folder in folders:
        try:
            if imap.select(folder)[0] != "OK":
                raise BatchScanError(f"sélection IMAP impossible ({folder})")
            status, messages = imap.uid("search", None, "ALL")
            if status != "OK" or not messages:
                raise BatchScanError(f"lecture IMAP impossible ({folder})")
            if not messages[0]:
                continue
            message_ids = messages[0].split()
            new_message_ids = [
                message_id
                for message_id in message_ids
                if message_id not in checkpoints.get(folder, set())
            ]
            ids_to_scan = list(
                dict.fromkeys(message_ids[-recent_limit:] + new_message_ids)
            )
            ndr_ids: list[bytes] = []
            for message_id in ids_to_scan:
                status, data = imap.uid("fetch", message_id, "(RFC822)")
                if status != "OK" or not data or not data[0]:
                    raise BatchScanError(
                        f"lecture du message IMAP impossible ({folder})"
                    )
                message = email_parser.message_from_bytes(data[0][1])
                if not _message_is_bounce(message):
                    continue
                body = _message_body(message)
                for recipient in recipients:
                    if _bounce_mentions_address(body, recipient):
                        bounced.add(recipient.lower())
                        ndr_ids.append(message_id)
            _delete_message_ids(imap, list(dict.fromkeys(ndr_ids)), folder)
        except Exception as error:
            raise BatchScanError(f"lecture IMAP impossible ({folder}) : {error}") from error
    return bounced


def _scan_single_account_bounces(
    account: dict[str, object],
    recipients: list[str],
    recent_limit: int,
    account_checkpoints: dict[str, set[bytes]],
    folder_scope: str,
) -> dict[str, object]:
    """Analyse les NDR récents d'un compte sur une connexion dédiée."""
    imap = None
    try:
        imap = _connect_imap(account)
        _login_imap(imap, account)
        folders = _folders_for_scope(imap, folder_scope)
        bounced = _recent_bounced_recipients(
            imap,
            folders,
            recipients,
            recent_limit,
            account_checkpoints,
        )
        return {"status": "ok", "bounced": bounced, "error": ""}
    except AccountAuthenticationError as error:
        return {"status": "auth_error", "bounced": set(), "error": str(error)}
    except BatchScanError as error:
        return {"status": "error", "bounced": set(), "error": str(error)}
    except Exception as error:
        return {"status": "error", "bounced": set(), "error": str(error)}
    finally:
        if imap:
            try:
                imap.logout()
            except Exception:
                pass


def _scan_batch_bounces(
    accounts: list[dict[str, object]],
    account_file: str,
    recipients: list[str],
    recent_limit: int,
    checkpoints: dict[str, dict[str, set[bytes]]],
    stats: dict[str, int],
    log: Callable[[str], None],
    folder_scope: str = "INBOX",
    max_concurrent_accounts: int | None = None,
) -> set[str]:
    """Analyse les NDR récents de chaque compte encore authentifié."""
    bounced: set[str] = set()
    original_accounts = list(accounts)
    worker_limit = (
        max_concurrent_accounts
        if max_concurrent_accounts is not None
        else _ACTIVE_BATCH_IMAP_WORKERS or MAX_BATCH_IMAP_WORKERS
    )
    worker_count = max(1, min(worker_limit, len(original_accounts)))
    log(
        f"[CHECKV2] Seconde analyse IMAP en parallèle : "
        f"{len(original_accounts)} compte(s), {worker_count} worker(s)."
    )
    results: list[tuple[dict[str, object], dict[str, object]]] = []
    with ThreadPoolExecutor(max_workers=worker_count) as executor:
        futures = {
            executor.submit(
                _scan_single_account_bounces,
                account,
                recipients,
                recent_limit,
                checkpoints.get(_account_key(account), {}),
                folder_scope,
            ): account
            for account in original_accounts
        }
        completed_accounts = 0
        for future in as_completed(futures):
            account = futures[future]
            results.append((account, future.result()))
            completed_accounts += 1
            log(
                f"[CHECKV2] Seconde analyse IMAP : "
                f"{completed_accounts}/{len(original_accounts)} terminé(s) "
                f"({account['email']})."
            )

    errors: list[str] = []
    auth_failed = False
    for account, result in results:
        if result["status"] == "auth_error":
            _discard_authenticated_account(accounts, account, account_file, stats, log)
            auth_failed = True
        elif result["status"] != "ok":
            errors.append(
                f"{account['provider']}|{account['email']} : {result['error']}"
            )
        else:
            bounced.update(result["bounced"])

    if auth_failed:
        raise BatchScanError(
            "authentification IMAP perdue pendant la seconde analyse du lot"
        )
    if errors:
        raise BatchScanError(errors[0])

    if not accounts:
        raise BatchScanError("aucun compte IMAP authentifié restant pour valider le lot")
    return bounced


def _run_single_probe(
    account: dict[str, object],
    recipient: str,
    adaptive_wait: float,
    poll_interval: int,
    folder_scope: str,
    is_stopped: Callable[[], bool],
) -> dict[str, object]:
    """Exécute un contrôle isolé, avec une connexion dédiée à ce compte."""
    smtp = None
    imap = None
    sent_checkpoints: dict[str, set[bytes]] = {}
    result: dict[str, object] = {
        "account": account,
        "recipient": recipient,
        "status": "error",
        "elapsed": 0.0,
        "error": "",
    }
    try:
        smtp = _connect_smtp(account)
        try:
            smtp.login(str(account["email"]), str(account["password"]))
        except smtplib.SMTPAuthenticationError as error:
            raise AccountAuthenticationError(
                f"SMTP {account['provider']} : authentification refusée"
            ) from error

        imap = _connect_imap(account)
        try:
            imap.login(str(account["email"]), str(account["password"]))
        except imaplib.IMAP4.error as error:
            raise AccountAuthenticationError(
                f"IMAP {account['provider']} : authentification refusée"
            ) from error

        all_folders = _folders(imap)
        folders = _folders_for_scope(imap, folder_scope)
        probe_checkpoints = _capture_probe_checkpoints(imap, folders)
        sent_checkpoints = _capture_sent_checkpoints(imap, all_folders)

        control_subject = Header(CONTROL_SUBJECT, "utf-8").encode()
        smtp.sendmail(
            str(account["email"]),
            recipient,
            (
                f"From: {account['email']}\r\n"
                f"To: {recipient}\r\n"
                f"Subject: {control_subject}\r\n"
                "Content-Type: text/plain; charset=utf-8\r\n"
                "\r\n"
                ".\r\n"
            ).encode("utf-8"),
        )

        bounce_started_at = time.monotonic()
        while time.monotonic() - bounce_started_at < adaptive_wait:
            if is_stopped():
                result["status"] = "stopped"
                return result
            remaining = adaptive_wait - (time.monotonic() - bounce_started_at)
            time.sleep(min(poll_interval, max(0.1, remaining)))
            if _has_bounce(imap, folders, recipient, probe_checkpoints):
                result["status"] = "bounce"
                result["elapsed"] = max(
                    1.0, time.monotonic() - bounce_started_at
                )
                return result

        result["status"] = "candidate"
        return result
    except AccountAuthenticationError as error:
        result["status"] = "auth_error"
        result["error"] = str(error)
        return result
    except Exception as error:
        result["status"] = "error"
        result["error"] = str(error)
        return result
    finally:
        if imap:
            if sent_checkpoints:
                try:
                    _delete_sent_control_messages(
                        imap,
                        sent_checkpoints,
                        recipient,
                    )
                except Exception as error:
                    result["sent_cleanup_error"] = str(error)
            try:
                imap.logout()
            except Exception:
                pass
        if smtp:
            try:
                smtp.quit()
            except Exception:
                pass


def _wait_for_batch_window(
    duration: int,
    is_stopped: Callable[[], bool],
) -> bool:
    """Attend la fenêtre finale tout en restant arrêt-able."""
    deadline = time.monotonic() + duration
    while True:
        if is_stopped():
            return False
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            return True
        time.sleep(min(1.0, remaining))


def run_checkv2(
    emails: list[str],
    config: dict[str, object],
    deliver_validated: Callable[[str], tuple[bool, str]],
    log: Callable[[str], None],
    is_stopped: Callable[[], bool],
) -> dict[str, int]:
    """Contrôle les adresses puis envoie les lots qui passent le second scan NDR."""

    global _ACTIVE_BATCH_IMAP_WORKERS
    account_file = str(Path(__file__).resolve().parent / "imap.txt")
    good_file = str(config.get("GOOD_FILE", "good.txt"))
    bad_file = str(config.get("BAD_FILE", "bad.txt"))
    initial_wait = max(1, int(config.get("CHECKV2_INITIAL_WAIT", 60)))
    poll_interval = max(1, int(config.get("CHECKV2_POLL_INTERVAL", 3)))
    batch_size = max(1, int(config.get("CHECKV2_BATCH_SIZE", 20)))
    batch_wait = max(1, int(config.get("CHECKV2_BATCH_WAIT", 20)))
    recent_ndr_limit = max(1, int(config.get("CHECKV2_RECENT_NDR_LIMIT", 10)))
    max_concurrent_accounts = max(
        1, int(config.get("CHECKV2_MAX_CONCURRENT_ACCOUNTS", 20))
    )
    folder_scope = str(config.get("CHECKV2_MAILBOX_SCOPE", "INBOX")).strip().upper()
    if folder_scope not in {"INBOX", "ALL"}:
        raise RuntimeError(
            f"CHECKV2_MAILBOX_SCOPE invalide ({folder_scope}); utilisez INBOX ou ALL."
        )
    adaptive_floor = max(
        1.0, float(config.get("CHECKV2_MIN_ADAPTIVE_WAIT", 10))
    )
    accounts, account_source = _load_runtime_accounts(account_file)
    delivery_label = (
        "SMTP AUTH"
        if config.get("USE_AUTH_MODE", False)
        else "Resend"
    )

    stats = {
        "checked": 0,
        "valid": 0,
        "bounce": 0,
        "error": 0,
        "sent": 0,
        "auth_failed": 0,
        "candidates": 0,
        "batch_rejected": 0,
    }
    pending: list[str] = []
    batch_halted = False

    log("╔══════════════════════════════════════════════════════════════╗")
    log("║                    CHECKV2 — SMTP / IMAP                    ║")
    log("╚══════════════════════════════════════════════════════════════╝")
    log(f"[CHECKV2] {len(emails)} adresse(s) à traiter avec {len(accounts)} compte(s).")
    log(f"[CHECKV2] Source des comptes : {account_source}.")
    log(
        f"[CHECKV2] Délai initial : {initial_wait}s | sondage : {poll_interval}s "
        f" | délai adaptatif activé (minimum {adaptive_floor:.0f}s après un bounce)."
    )
    log(
        f"[CHECKV2] Envoi par lots : {batch_size} candidate(s), attente finale "
        f"{batch_wait}s, analyse des {recent_ndr_limit} derniers messages IMAP."
    )
    log(
        f"[CHECKV2] Dossiers contrôlés : "
        f"{'INBOX uniquement' if folder_scope == 'INBOX' else 'tous les dossiers'}."
    )
    log(
        "[CHECKV2] Nettoyage demandé : "
        f"{'INBOX uniquement' if folder_scope == 'INBOX' else 'INBOX et dossiers Spam'} "
        "avant le contrôle."
    )
    log(
        f"[CHECKV2] Contrôles simultanés : jusqu'à "
        f"{max_concurrent_accounts} compte(s) par vague."
    )
    log(
        f"[CHECKV2] Nettoyage initial parallèle : jusqu'à "
        f"{max_concurrent_accounts} compte(s) en même temps."
    )
    _prepare_accounts(
        accounts,
        account_file,
        stats,
        log,
        folder_scope,
        max_concurrent_accounts,
    )
    if not accounts:
        stats["error"] += len(emails)
        log("[CHECKV2] Aucun compte disponible après le nettoyage, aucun envoi effectué.")
        return stats
    log(f"[CHECKV2] {len(accounts)} compte(s) disponible(s) après nettoyage.")

    def flush_pending_batch() -> bool:
        if not pending:
            return True
        batch = pending[:batch_size]
        log(
            f"\n[CHECKV2] Lot de {len(batch)} candidate(s) prêt. "
            "Création du point de contrôle IMAP."
        )
        try:
            global _ACTIVE_BATCH_IMAP_WORKERS
            previous_batch_workers = _ACTIVE_BATCH_IMAP_WORKERS
            _ACTIVE_BATCH_IMAP_WORKERS = max_concurrent_accounts
            checkpoints = _capture_batch_checkpoints(
                accounts,
                account_file,
                stats,
                log,
                folder_scope,
            )
        except BatchScanError as error:
            stats["error"] += len(batch)
            log(f"[CHECKV2] ⚠ Lot non envoyé : point de contrôle IMAP impossible ({error}).")
            return False
        finally:
            _ACTIVE_BATCH_IMAP_WORKERS = previous_batch_workers

        log(f"[CHECKV2] Point de contrôle terminé. Attente de sécurité : {batch_wait}s.")
        if not _wait_for_batch_window(batch_wait, is_stopped):
            log("[CHECKV2] Lot conservé sans envoi : arrêt demandé pendant l'attente.")
            return False

        log("[CHECKV2] Attente terminée. Lancement de la seconde analyse IMAP.")
        try:
            previous_batch_workers = _ACTIVE_BATCH_IMAP_WORKERS
            _ACTIVE_BATCH_IMAP_WORKERS = max_concurrent_accounts
            bounced = _scan_batch_bounces(
                accounts,
                account_file,
                batch,
                recent_ndr_limit,
                checkpoints,
                stats,
                log,
                folder_scope,
            )
        except BatchScanError as error:
            stats["error"] += len(batch)
            log(f"[CHECKV2] ⚠ Lot non envoyé : seconde vérification impossible ({error}).")
            return False
        finally:
            _ACTIVE_BATCH_IMAP_WORKERS = previous_batch_workers

        log(
            f"[CHECKV2] Seconde analyse terminée : {len(bounced)} bounce(s) "
            f"trouvé(s) dans le lot."
        )
        for recipient in batch:
            if recipient.lower() in bounced:
                _append_address(bad_file, recipient)
                stats["bounce"] += 1
                stats["batch_rejected"] += 1
                log(f"[CHECKV2] ✗ BOUNCE tardif : {recipient} → {bad_file}")
                continue

            _append_address(good_file, recipient)
            stats["valid"] += 1
            log(f"[CHECKV2] ✓ VALIDÉ APRÈS LOT : {recipient} → {good_file}")
            if config.get("CHECKV2_DRY_RUN", False):
                success, detail = True, "enregistrement uniquement — aucun envoi final"
            else:
                try:
                    success, detail = deliver_validated(recipient)
                except Exception as error:
                    success, detail = False, str(error)
            if success:
                stats["sent"] += 1
                log(
                    f"[CHECKV2] → {delivery_label} livré après lot : "
                    f"{recipient} ({detail})"
                )
            else:
                stats["error"] += 1
                log(
                    f"[CHECKV2] ✗ Échec {delivery_label} pour "
                    f"{recipient} : {detail}"
                )
        del pending[: len(batch)]
        return True

    adaptive_waits = {
        _account_key(account): float(initial_wait)
        for account in accounts
    }
    position = 0
    account_cursor = 0
    stop_requested = False
    while position < len(emails) and accounts and not batch_halted:
        if is_stopped():
            log("[CHECKV2] Arrêt demandé, vérification interrompue.")
            break

        wave_size = min(
            max_concurrent_accounts,
            len(accounts),
            len(emails) - position,
        )
        account_cursor %= len(accounts)
        wave_accounts = [
            accounts[(account_cursor + offset) % len(accounts)]
            for offset in range(wave_size)
        ]
        next_account_key = _account_key(
            accounts[(account_cursor + wave_size) % len(accounts)]
        )
        wave_recipients = emails[position : position + wave_size]
        wave_start = position
        position += wave_size
        log(
            f"\n[CHECKV2] Vague parallèle : {len(wave_recipients)} contrôle(s) "
            f"avec {len(wave_accounts)} compte(s) distinct(s)."
        )

        futures = []
        with ThreadPoolExecutor(max_workers=wave_size) as executor:
            for offset, (recipient, account) in enumerate(
                zip(wave_recipients, wave_accounts),
                start=1,
            ):
                stats["checked"] += 1
                account_key = _account_key(account)
                wait_for_account = adaptive_waits.get(
                    account_key,
                    float(initial_wait),
                )
                log(
                    f"[CHECKV2] [{wave_start + offset}/{len(emails)}] "
                    f"Test de {recipient} via {account['email']} — "
                    f"Fenêtre d'attente utilisée : {wait_for_account:.1f}s."
                )
                futures.append(
                    executor.submit(
                        _run_single_probe,
                        account,
                        recipient,
                        wait_for_account,
                        poll_interval,
                        folder_scope,
                        is_stopped,
                    )
                )
            results = [future.result() for future in futures]

        for recipient, account, result in zip(
            wave_recipients,
            wave_accounts,
            results,
        ):
            status = result["status"]
            account_key = _account_key(account)
            sent_cleanup_error = result.get("sent_cleanup_error")
            if sent_cleanup_error:
                log(
                    f"[CHECKV2] ⚠ Copie Envoyés non supprimée pour {recipient} "
                    f"({sent_cleanup_error})."
                )

            if status == "auth_error":
                _discard_authenticated_account(accounts, account, account_file, stats, log)
                stats["error"] += 1
                log(
                    f"[CHECKV2] ✗ Authentification refusée pour {recipient} : "
                    f"{result['error']}"
                )
                continue

            if status == "stopped":
                stop_requested = True
                continue

            if status == "bounce":
                bounce_elapsed = float(result["elapsed"])
                adaptive_waits[account_key] = max(adaptive_floor, bounce_elapsed)
                _append_address(bad_file, recipient)
                stats["bounce"] += 1
                log(
                    f"[CHECKV2] ✗ BOUNCE détecté en {bounce_elapsed:.1f}s : "
                    f"{recipient} → {bad_file}"
                )
                log(
                    f"[CHECKV2] Prochaine fenêtre pour {account['email']} : "
                    f"{adaptive_waits[account_key]:.1f}s."
                )
                continue

            if status == "candidate":
                pending.append(recipient)
                stats["candidates"] += 1
                log(
                    f"[CHECKV2] ✓ CANDIDAT : {recipient} "
                    f"(en attente du lot {len(pending)}/{batch_size})."
                )
                if len(pending) >= batch_size and not batch_halted:
                    if not flush_pending_batch():
                        batch_halted = True
                continue

            stats["error"] += 1
            log(
                f"[CHECKV2] ⚠ Contrôle impossible pour {recipient}, "
                f"adresse conservée hors de bad.txt : {result['error']}"
            )

        if stop_requested:
            log("[CHECKV2] Arrêt demandé pendant la vague, aucun nouveau contrôle.")
            break
        if not accounts:
            log("[CHECKV2] Aucun compte authentifié restant, arrêt du contrôle.")
            break
        next_account = next(
            (
                index
                for index, account in enumerate(accounts)
                if _account_key(account) == next_account_key
            ),
            None,
        )
        account_cursor = (
            next_account if next_account is not None else account_cursor % len(accounts)
        )

        while len(pending) >= batch_size and not batch_halted:
            if not flush_pending_batch():
                batch_halted = True
                break

    if pending and not is_stopped() and not batch_halted:
        log(f"\n[CHECKV2] Dernier lot partiel : {len(pending)} candidate(s).")
        if not flush_pending_batch():
            batch_halted = True

    if stats["sent"] > 0 and not is_stopped() and not batch_halted:
        previous_batch_workers = _ACTIVE_BATCH_IMAP_WORKERS
        _ACTIVE_BATCH_IMAP_WORKERS = max_concurrent_accounts
        try:
            _final_cleanup_bounces(accounts, account_file, stats, log)
        finally:
            _ACTIVE_BATCH_IMAP_WORKERS = previous_batch_workers

    if config.get("CHECKV2_DRY_RUN", False):
        delivery_summary = f"{stats['sent']} enregistrées sans envoi final"
    else:
        delivery_summary = (
            f"{stats['sent']} livrées via {delivery_label}"
        )
    log(
        "\n[CHECKV2] Terminé — "
        f"{stats['checked']} contrôlées, {stats['valid']} validées, "
        f"{stats['bounce']} bounces, {delivery_summary}, "
        f"{stats['batch_rejected']} bounce(s) tardif(s), "
        f"{stats['auth_failed']} compte(s) ignoré(s) pour authentification."
    )
    return stats


"""CHECKV2 — validation SMTP/IMAP avec détection de bounces.

Le validateur envoie un message minimal depuis les comptes définis dans
``imap.txt`` puis surveille leurs boîtes IMAP. Une adresse sans NDR dans le
délai configuré est considérée valide et remise immédiatement au callback
d'envoi fourni par ``send.py``.
"""

# Bloc historique dupliqué : l'import future ne peut pas apparaître au milieu
# du module. Le bloc reste exécutable jusqu'à sa suppression séparée.

from concurrent.futures import ThreadPoolExecutor, as_completed
from email.header import Header, decode_header
import imaplib
import os
import re
import smtplib
import ssl
import time
from datetime import datetime
from pathlib import Path
from typing import Callable


SPAM_FOLDERS = (
    "INBOX.Spam",
    "Spam",
    "Junk",
    "Junk E-mail",
    "Indésirables",
    "INBOX.Junk",
    "INBOX.Indésirables",
)

SENT_FOLDER_MARKERS = (
    "sent",
    "sent items",
    "envoy",
    "éléments envoyés",
    "element envoy",
)
CONTROL_SUBJECT = "t'es présent?"
CONTROL_SEARCH_TERM = "t'es"
MAX_BATCH_IMAP_WORKERS = 20
_ACTIVE_BATCH_IMAP_WORKERS: int | None = None

BOUNCE_SEARCH_CRITERIA = (
    ("FROM", "mailer-daemon"),
    ("FROM", "message-status"),
    ("SUBJECT", "undeliverable"),
    ("SUBJECT", "échec de remise"),
    ("SUBJECT", "delivery failed"),
    ("SUBJECT", "failure notice"),
    ("SUBJECT", "returned mail"),
    ("SUBJECT", "mail delivery failed"),
    ("SUBJECT", "non remis"),
    ("SUBJECT", "remise impossible"),
    ("SUBJECT", "delivery status notification"),
    ("SUBJECT", "recipient rejected"),
    ("SUBJECT", "bounce"),
)

PROVIDERS = {
    "ovh": {
        "smtp_server": "smtp.mail.ovh.net",
        "smtp_port": 465,
        "imap_server": "ssl0.ovh.net",
        "imap_port": 993,
    },
    "homepl": {
        "smtp_server": "poczta2582757.home.pl",
        "smtp_port": 465,
        "imap_server": "poczta2582757.home.pl",
        "imap_port": 993,
    },
}


class AccountAuthenticationError(RuntimeError):
    """Erreur d'identifiants : le compte ne doit plus être réutilisé."""


class BatchScanError(RuntimeError):
    """La seconde vérification d'un lot n'est pas assez fiable pour envoyer."""


def _load_accounts_from_lines(lines: list[str], source: str) -> list[dict[str, object]]:
    accounts: list[dict[str, object]] = []
    for line_number, raw_line in enumerate(lines, start=1):
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        parts = [part.strip() for part in line.split("|", 2)]
        if len(parts) < 3:
            raise RuntimeError(f"{source}, ligne {line_number} : format invalide.")
        provider = parts[0].lower()
        if provider not in PROVIDERS:
            raise RuntimeError(
                f"{source}, ligne {line_number} : fournisseur inconnu ({provider})."
            )
        accounts.append(
            {
                "provider": provider,
                "email": parts[1],
                "password": parts[2],
                **PROVIDERS[provider],
            }
        )

    if not accounts:
        raise RuntimeError(f"Aucun compte exploitable dans {source}.")
    return accounts


def _load_accounts(path: str) -> list[dict[str, object]]:
    file_path = Path(path)
    if not file_path.exists():
        raise RuntimeError(
            f"Fichier {path} introuvable. Format attendu : provider|email|password"
        )
    return _load_accounts_from_lines(
        file_path.read_text(encoding="utf-8").splitlines(),
        str(file_path),
    )


def _load_runtime_accounts(account_file: str) -> tuple[list[dict[str, object]], str]:
    """Charge les comptes CHECKV2 exclusivement depuis imap.txt."""
    return _load_accounts(account_file), "imap.txt"


def _connect_smtp(account: dict[str, object]) -> smtplib.SMTP_SSL:
    return smtplib.SMTP_SSL(
        str(account["smtp_server"]),
        int(account["smtp_port"]),
        context=ssl.create_default_context(),
        timeout=20,
    )


def _connect_imap(account: dict[str, object]) -> imaplib.IMAP4_SSL:
    return imaplib.IMAP4_SSL(
        str(account["imap_server"]),
        int(account["imap_port"]),
        ssl_context=ssl.create_default_context(),
        timeout=20,
    )


def _imap_error_detail(error: BaseException) -> str:
    """Retourne un détail serveur court, sans données d'authentification."""
    detail = " ".join(str(error).split())
    detail = re.sub(
        r"(?i)(password|passwd|pass|secret)\s*[=:]\s*\S+",
        r"\1=[masqué]",
        detail,
    )
    return detail[:180] or type(error).__name__


def _imap_supports_plain(imap: imaplib.IMAP4_SSL) -> bool:
    try:
        status, capabilities = imap.capability()
    except Exception:
        return False
    if str(status).upper() != "OK":
        return False
    normalized = {
        token
        for item in (capabilities or [])
        for token in (
            item.decode("ascii", "replace")
            if isinstance(item, bytes)
            else str(item)
        ).upper().split()
    }
    return "AUTH=PLAIN" in normalized


def _login_imap(imap: imaplib.IMAP4_SSL, account: dict[str, object]) -> None:
    """Authentifie une boîte IMAP avec le mécanisme OVH de secours."""
    email_address = str(account["email"])
    password = str(account["password"])
    first_error: BaseException | None = None
    try:
        response = imap.login(email_address, password)
    except imaplib.IMAP4.error as error:
        first_error = error
        response = None

    # imaplib retourne normalement ("OK", ...). Les implémentations de test
    # légères peuvent ne rien retourner après une authentification réussie.
    status = response[0] if isinstance(response, tuple) and response else None
    if first_error is None and (status is None or str(status).upper() == "OK"):
        return

    # OVH annonce AUTH=PLAIN et AUTH=LOGIN. Si LOGIN est refusé par le
    # serveur, tenter PLAIN sur la même connexion évite un faux négatif.
    if _imap_supports_plain(imap):
        try:
            response = imap.authenticate(
                "PLAIN",
                lambda _challenge: f"\x00{email_address}\x00{password}".encode(
                    "utf-8"
                ),
            )
            fallback_status = (
                response[0]
                if isinstance(response, tuple) and response
                else "OK"
            )
            if str(fallback_status).upper() == "OK":
                return
            first_error = imaplib.IMAP4.error(
                f"AUTH=PLAIN returned {fallback_status}"
            )
        except imaplib.IMAP4.error as error:
            if first_error is None:
                first_error = error

    if first_error is None:
        first_error = imaplib.IMAP4.error(f"LOGIN returned {status}")
    raise AccountAuthenticationError(
        f"IMAP {account['provider']} : authentification refusée "
        f"({type(first_error).__name__}: {_imap_error_detail(first_error)})"
    ) from first_error


def _message_is_bounce(message) -> bool:
    sender = str(message.get("From", "")).lower()
    subject = str(message.get("Subject", "")).lower()
    if "mailer-daemon" in sender or "message-status" in sender:
        return True
    keywords = (
        "undeliverable",
        "échec de remise",
        "delivery failed",
        "failure notice",
        "returned mail",
        "mail delivery failed",
        "non remis",
        "remise impossible",
        "delivery status notification",
        "recipient rejected",
        "bounce",
    )
    return any(keyword in subject for keyword in keywords)


def _search_message_ids(
    imap: imaplib.IMAP4_SSL,
    *criteria: str,
) -> tuple[bool, list[bytes]]:
    """Recherche des UID côté serveur et indique si la requête est supportée."""
    try:
        status, messages = imap.uid("search", None, *criteria)
    except Exception:
        return False, []
    if status != "OK":
        return False, []
    if not messages:
        return True, []
    return True, messages[0].split()


def _bounce_candidate_ids(imap: imaplib.IMAP4_SSL) -> list[bytes]:
    """Cible les NDR par IMAP avant de replier sur un scan complet si nécessaire."""
    candidate_ids: set[bytes] = set()
    supported_searches = 0
    for criteria in BOUNCE_SEARCH_CRITERIA:
        supported, message_ids = _search_message_ids(imap, *criteria)
        if supported:
            supported_searches += 1
            candidate_ids.update(message_ids)

    if supported_searches:
        return sorted(candidate_ids, key=lambda message_id: int(message_id))

    _supported, message_ids = _search_message_ids(imap, "ALL")
    return message_ids


def _message_body(message) -> str:
    chunks: list[str] = []
    for part in message.walk() if message.is_multipart() else (message,):
        if part.get_content_type() not in ("text/plain", "text/html"):
            continue
        payload = part.get_payload(decode=True)
        if payload:
            chunks.append(payload.decode("utf-8", errors="ignore"))
    return "\n".join(chunks)


def _bounce_mentions_address(body: str, recipient: str) -> bool:
    if recipient.lower() in body.lower():
        return True
    patterns = (
        r"Final-Recipient:\s*rfc822;\s*([^>\s]+@[^>\s]+)",
        r"Original-Recipient:\s*rfc822;\s*([^>\s]+@[^>\s]+)",
        r"<([^>]+@[^>]+)>:\s+host.*?said:\s+5\d{2}",
    )
    return any(
        match and match.group(1).strip().lower() == recipient.lower()
        for pattern in patterns
        if (match := re.search(pattern, body, re.IGNORECASE | re.MULTILINE))
    )


def _folders(imap: imaplib.IMAP4_SSL) -> list[str]:
    names = ["INBOX"]
    try:
        status, folders = imap.list()
        if status == "OK":
            for folder in folders:
                decoded = folder.decode("utf-8", errors="ignore")
                match = re.search(r'"([^"]+)"$', decoded)
                if match and match.group(1) not in names:
                    names.append(match.group(1))
    except Exception:
        pass

    for folder in SPAM_FOLDERS:
        if folder not in names:
            try:
                if imap.select(folder)[0] == "OK":
                    names.append(folder)
            except Exception:
                pass
    return names


def _folders_for_scope(
    imap: imaplib.IMAP4_SSL,
    scope: str,
) -> list[str]:
    """Retourne les dossiers contrôlés selon le réglage choisi."""
    normalized_scope = scope.strip().upper()
    if normalized_scope == "INBOX":
        return ["INBOX"]
    if normalized_scope == "ALL":
        return _folders(imap)
    raise RuntimeError(
        f"périmètre IMAP invalide ({scope!r}); utilisez INBOX ou ALL"
    )


def _sent_folders(folders: list[str]) -> list[str]:
    """Retourne les dossiers susceptibles de contenir les messages envoyés."""
    result: list[str] = []
    for folder in folders:
        normalized = folder.casefold()
        if any(marker in normalized for marker in SENT_FOLDER_MARKERS):
            if folder not in result:
                result.append(folder)
    return result


def _delete_message_ids(
    imap: imaplib.IMAP4_SSL,
    message_ids: list[bytes],
    folder: str,
) -> None:
    """Marque puis supprime définitivement un ensemble de messages du dossier actif."""
    if not message_ids:
        return
    status, _ = imap.uid(
        "store",
        b",".join(message_ids),
        "+FLAGS.SILENT",
        r"(\Deleted)",
    )
    if status != "OK":
        raise RuntimeError(f"suppression IMAP impossible ({folder})")
    status, _ = imap.expunge()
    if status != "OK":
        raise RuntimeError(f"validation de suppression IMAP impossible ({folder})")


def _decode_header_value(value: object) -> str:
    if not value:
        return ""
    decoded: list[str] = []
    for part, charset in decode_header(str(value)):
        if isinstance(part, bytes):
            decoded.append(part.decode(charset or "utf-8", errors="replace"))
        else:
            decoded.append(part)
    return "".join(decoded)


def _is_control_message(message, recipient: str) -> bool:
    """Identifie une copie du message CHECKV2 dans le dossier Envoyés."""
    subject = _decode_header_value(message.get("Subject", "")).strip().casefold()
    if subject != CONTROL_SUBJECT.casefold():
        return False
    to_header = str(message.get("To", "")).casefold()
    if recipient.casefold() not in to_header:
        return False
    return _message_body(message).strip() == "."


def _capture_sent_checkpoints(
    imap: imaplib.IMAP4_SSL,
    folders: list[str],
) -> dict[str, set[bytes]]:
    """Mémorise les UID du dossier Envoyés avant un message de contrôle."""
    checkpoints: dict[str, set[bytes]] = {}
    for folder in _sent_folders(folders):
        try:
            if imap.select(folder)[0] != "OK":
                continue
            status, messages = imap.uid("search", None, "ALL")
            if status == "OK" and messages:
                checkpoints[folder] = set(messages[0].split())
        except Exception:
            continue
    return checkpoints


def _delete_sent_control_messages(
    imap: imaplib.IMAP4_SSL,
    checkpoints: dict[str, set[bytes]],
    recipient: str,
) -> None:
    """Supprime les nouvelles copies du message de contrôle dans Envoyés."""
    import email as email_parser

    for folder, checkpoint in checkpoints.items():
        if imap.select(folder)[0] != "OK":
            continue
        status, messages = imap.uid("search", None, "ALL")
        if status != "OK" or not messages:
            continue
        new_ids = [
            message_id
            for message_id in messages[0].split()
            if message_id not in checkpoint
        ]
        to_delete: list[bytes] = []
        for message_id in new_ids:
            status, data = imap.uid("fetch", message_id, "(RFC822)")
            if status != "OK" or not data or not data[0]:
                continue
            message = email_parser.message_from_bytes(data[0][1])
            if _is_control_message(message, recipient):
                to_delete.append(message_id)
        _delete_message_ids(imap, to_delete, folder)


def _has_bounce(
    imap: imaplib.IMAP4_SSL,
    folders: list[str],
    recipient: str,
    checkpoints: dict[str, set[bytes]] | None = None,
) -> bool:
    import email as email_parser

    for folder in folders:
        try:
            if imap.select(folder)[0] != "OK":
                continue
            if checkpoints is None:
                status, messages = imap.search(None, "UNSEEN")
                message_ids = messages[0].split() if status == "OK" and messages else []
                fetch_message = lambda message_id: imap.fetch(message_id, "(RFC822)")
            else:
                status, messages = imap.uid("search", None, "ALL")
                if status != "OK" or not messages:
                    continue
                message_ids = [
                    message_id
                    for message_id in messages[0].split()
                    if message_id not in checkpoints.get(folder, set())
                ]
                fetch_message = lambda message_id: imap.uid(
                    "fetch", message_id, "(RFC822)"
                )
            if status != "OK":
                continue
            for message_id in message_ids:
                status, data = fetch_message(message_id)
                if status != "OK" or not data or not data[0]:
                    continue
                message = email_parser.message_from_bytes(data[0][1])
                if _message_is_bounce(message) and _bounce_mentions_address(
                    _message_body(message), recipient
                ):
                    try:
                        if checkpoints is None:
                            imap.store(message_id, "+FLAGS", r"(\Deleted)")
                            imap.expunge()
                        else:
                            _delete_message_ids(imap, [message_id], folder)
                    except Exception:
                        pass
                    return True
        except Exception:
            continue
    return False


def _capture_probe_checkpoints(
    imap: imaplib.IMAP4_SSL,
    folders: list[str],
) -> dict[str, set[bytes]]:
    """Mémorise les UID présents avant l'envoi du message de contrôle."""
    checkpoints: dict[str, set[bytes]] = {}
    if not folders:
        raise BatchScanError("aucun dossier IMAP disponible avant le contrôle")

    for folder in folders:
        if imap.select(folder)[0] != "OK":
            raise BatchScanError(f"sélection IMAP impossible avant le contrôle ({folder})")
        status, messages = imap.uid("search", None, "ALL")
        if status != "OK" or not messages:
            raise BatchScanError(f"lecture IMAP impossible avant le contrôle ({folder})")
        checkpoints[folder] = set(messages[0].split())
    return checkpoints


def _mailbox_cleanup_targets(folders: list[str]) -> list[str]:
    """Retourne INBOX et les dossiers identifiés comme spam."""
    targets: list[str] = []
    for folder in folders:
        normalized = folder.casefold()
        if folder == "INBOX" or any(
            marker in normalized
            for marker in ("spam", "junk", "indésirable", "indesirable")
        ):
            if folder not in targets:
                targets.append(folder)
    return targets


def _clean_bounces_in_folders(
    imap: imaplib.IMAP4_SSL,
    folders: list[str],
) -> list[str]:
    """Supprime uniquement les NDR dans les dossiers fournis."""
    import email as email_parser

    cleaned: list[str] = []
    for folder in folders:
        if imap.select(folder)[0] != "OK":
            raise RuntimeError(f"sélection IMAP impossible pour le nettoyage ({folder})")
        message_ids = _bounce_candidate_ids(imap)
        ndr_ids: list[bytes] = []
        for message_id in message_ids:
            status, data = imap.uid(
                "fetch",
                message_id,
                "(BODY.PEEK[HEADER.FIELDS (FROM SUBJECT)])",
            )
            if status != "OK" or not data or not data[0]:
                raise RuntimeError(f"lecture du message IMAP impossible ({folder})")
            message = email_parser.message_from_bytes(data[0][1])
            if _message_is_bounce(message):
                ndr_ids.append(message_id)
        _delete_message_ids(imap, ndr_ids, folder)
        cleaned.append(folder)
    return cleaned


def _clean_mailboxes(
    imap: imaplib.IMAP4_SSL,
    folders: list[str],
) -> list[str]:
    """Supprime uniquement les NDR présents dans INBOX et les dossiers Spam."""
    targets = _mailbox_cleanup_targets(folders)
    if "INBOX" not in targets:
        raise RuntimeError("dossier INBOX indisponible pour le nettoyage")
    return _clean_bounces_in_folders(imap, targets)


def _clean_sent_control_messages(
    imap: imaplib.IMAP4_SSL,
    folders: list[str],
) -> None:
    """Supprime les anciens messages CHECKV2 identifiables du dossier Envoyés."""
    import email as email_parser

    for folder in _sent_folders(folders):
        try:
            if imap.select(folder)[0] != "OK":
                continue
            supported, message_ids = _search_message_ids(
                imap,
                "SUBJECT",
                CONTROL_SEARCH_TERM,
            )
            if not supported:
                _supported, message_ids = _search_message_ids(imap, "ALL")
            to_delete: list[bytes] = []
            for message_id in message_ids:
                status, data = imap.uid("fetch", message_id, "(RFC822)")
                if status != "OK" or not data or not data[0]:
                    continue
                message = email_parser.message_from_bytes(data[0][1])
                if _decode_header_value(message.get("Subject", "")).strip().casefold() != CONTROL_SUBJECT.casefold():
                    continue
                if _message_body(message).strip() == ".":
                    to_delete.append(message_id)
            _delete_message_ids(imap, to_delete, folder)
        except Exception:
            continue


def _prepare_single_account(
    account: dict[str, object],
    folder_scope: str,
) -> dict[str, object]:
    """Nettoie un compte sur une connexion IMAP dédiée."""
    imap = None
    try:
        imap = _connect_imap(account)
        _login_imap(imap, account)
        all_folders = _folders(imap)
        folders = _folders_for_scope(imap, folder_scope)
        cleaned = _clean_mailboxes(imap, folders)
        _clean_sent_control_messages(imap, all_folders)
        return {"status": "usable", "cleaned": cleaned, "error": ""}
    except AccountAuthenticationError as error:
        return {"status": "auth_error", "cleaned": [], "error": str(error)}
    except Exception as error:
        return {"status": "error", "cleaned": [], "error": str(error)}
    finally:
        if imap:
            try:
                imap.logout()
            except Exception:
                pass


def _final_cleanup_single_account(
    account: dict[str, object],
) -> dict[str, object]:
    """Nettoie les NDR de tous les dossiers d'un compte après le dernier envoi."""
    imap = None
    try:
        imap = _connect_imap(account)
        _login_imap(imap, account)
        folders = _folders(imap)
        cleaned = _clean_bounces_in_folders(imap, folders)
        return {"status": "ok", "cleaned": cleaned, "error": ""}
    except AccountAuthenticationError as error:
        return {"status": "auth_error", "cleaned": [], "error": str(error)}
    except Exception as error:
        return {"status": "error", "cleaned": [], "error": str(error)}
    finally:
        if imap:
            try:
                imap.logout()
            except Exception:
                pass


def _final_cleanup_bounces(
    accounts: list[dict[str, object]],
    account_file: str,
    stats: dict[str, int],
    log: Callable[[str], None],
    max_concurrent_accounts: int | None = None,
) -> None:
    """Nettoie les NDR de tous les dossiers, en parallèle, après les envois."""
    original_accounts = list(accounts)
    if not original_accounts:
        return

    worker_limit = (
        max_concurrent_accounts
        if max_concurrent_accounts is not None
        else _ACTIVE_BATCH_IMAP_WORKERS or MAX_BATCH_IMAP_WORKERS
    )
    worker_count = max(1, min(worker_limit, len(original_accounts)))
    log(
        f"[CHECKV2] Nettoyage final des NDR dans tous les dossiers : "
        f"{len(original_accounts)} compte(s), {worker_count} worker(s)."
    )
    results: list[tuple[dict[str, object], dict[str, object]]] = []
    with ThreadPoolExecutor(max_workers=worker_count) as executor:
        futures = {
            executor.submit(_final_cleanup_single_account, account): account
            for account in original_accounts
        }
        for future in as_completed(futures):
            account = futures[future]
            results.append((account, future.result()))

    cleaned_folder_count = 0
    errors: list[str] = []
    for account, result in results:
        if result["status"] == "ok":
            cleaned_folder_count += len(result["cleaned"])
        elif result["status"] == "auth_error":
            _discard_authenticated_account(accounts, account, account_file, stats, log)
        else:
            errors.append(str(result["error"]))

    log(
        f"[CHECKV2] Nettoyage final terminé : "
        f"{cleaned_folder_count} dossier(s) traité(s), uniquement les NDR supprimés."
    )
    if errors:
        log(
            f"[CHECKV2] ⚠ Nettoyage final incomplet sur "
            f"{len(errors)} compte(s) ; les comptes concernés sont conservés."
        )


def _prepare_accounts(
    accounts: list[dict[str, object]],
    account_file: str,
    stats: dict[str, int],
    log: Callable[[str], None],
    folder_scope: str = "INBOX",
    max_concurrent_accounts: int = 20,
) -> None:
    """Nettoie les boîtes en parallèle et désactive les comptes inutilisables."""
    if not accounts:
        return

    worker_count = max(1, min(max_concurrent_accounts, len(accounts)))
    usable: list[dict[str, object]] = []
    total_accounts = len(accounts)
    completed_accounts = 0
    original_accounts = list(accounts)
    log(
        f"[CHECKV2] Nettoyage IMAP en cours : {total_accounts} compte(s), "
        f"{worker_count} worker(s) actif(s)."
    )
    with ThreadPoolExecutor(max_workers=worker_count) as executor:
        futures = {
            executor.submit(_prepare_single_account, account, folder_scope): account
            for account in original_accounts
        }
        completed_results: list[tuple[dict[str, object], dict[str, object]]] = []
        for future in as_completed(futures):
            account = futures[future]
            completed_accounts += 1
            result = future.result()
            completed_results.append((account, result))
            log(
                f"[CHECKV2] Nettoyage IMAP : {completed_accounts}/{total_accounts} "
                f"terminé(s) ({account['email']})."
            )

    for account, result in completed_results:
        if result["status"] == "usable":
            usable.append(account)
            cleaned = result["cleaned"]
            log(
                f"[CHECKV2] Nettoyage IMAP terminé pour {account['email']} : "
                f"{', '.join(cleaned)}."
            )
        elif result["status"] == "auth_error":
            _discard_authenticated_account(accounts, account, account_file, stats, log)
            log(
                f"[CHECKV2] ✗ Compte ignoré pendant le nettoyage : "
                f"{result['error']}"
            )
        else:
            log(
                f"[CHECKV2] ⚠ Nettoyage impossible pour {account['email']} : "
                f"{result['error']}. Compte conservé dans imap.txt et ignoré "
                "pour cette exécution."
            )

    accounts[:] = usable


def _append_address(path: str, address: str) -> None:
    with open(path, "a", encoding="utf-8") as file:
        file.write(f"{address}\n")


def _discard_authenticated_account(
    accounts: list[dict[str, object]],
    account: dict[str, object],
    account_file: str,
    stats: dict[str, int],
    log: Callable[[str], None],
) -> None:
    """Écarte un compte refusé pour cette exécution sans modifier sa source."""
    if account in accounts:
        accounts.remove(account)

    stats["auth_failed"] = stats.get("auth_failed", 0) + 1
    log(
        f"[CHECKV2] ⚠ Authentification refusée pour "
        f"{account['provider']}|{account['email']}. "
        "Compte conservé dans sa source et ignoré pour cette exécution."
    )


def _account_key(account: dict[str, object]) -> str:
    return f"{account['provider']}|{account['email']}"


def _capture_single_account_checkpoint(
    account: dict[str, object],
    folder_scope: str,
) -> dict[str, object]:
    """Capture les UID d'un compte sur une connexion IMAP dédiée."""
    imap = None
    try:
        imap = _connect_imap(account)
        _login_imap(imap, account)
        folders = _folders_for_scope(imap, folder_scope)
        if not folders:
            raise BatchScanError(
                f"aucun dossier IMAP disponible pour {account['email']}"
            )
        folder_checkpoints: dict[str, set[bytes]] = {}
        for folder in folders:
            if imap.select(folder)[0] != "OK":
                raise BatchScanError(f"sélection IMAP impossible ({folder})")
            status, messages = imap.uid("search", None, "ALL")
            if status != "OK" or not messages:
                raise BatchScanError(f"lecture IMAP impossible ({folder})")
            folder_checkpoints[folder] = set(messages[0].split())
        return {"status": "ok", "checkpoints": folder_checkpoints, "error": ""}
    except AccountAuthenticationError as error:
        return {"status": "auth_error", "checkpoints": {}, "error": str(error)}
    except BatchScanError as error:
        return {"status": "error", "checkpoints": {}, "error": str(error)}
    except Exception as error:
        return {"status": "error", "checkpoints": {}, "error": str(error)}
    finally:
        if imap:
            try:
                imap.logout()
            except Exception:
                pass


def _capture_batch_checkpoints(
    accounts: list[dict[str, object]],
    account_file: str,
    stats: dict[str, int],
    log: Callable[[str], None],
    folder_scope: str = "INBOX",
    max_concurrent_accounts: int | None = None,
) -> dict[str, dict[str, set[bytes]]]:
    """Mémorise les UID déjà présents avant l'attente finale du lot."""
    checkpoints: dict[str, dict[str, set[bytes]]] = {}
    original_accounts = list(accounts)
    worker_limit = (
        max_concurrent_accounts
        if max_concurrent_accounts is not None
        else _ACTIVE_BATCH_IMAP_WORKERS or MAX_BATCH_IMAP_WORKERS
    )
    worker_count = max(1, min(worker_limit, len(original_accounts)))
    log(
        f"[CHECKV2] Point de contrôle IMAP en parallèle : "
        f"{len(original_accounts)} compte(s), {worker_count} worker(s)."
    )
    results: list[tuple[dict[str, object], dict[str, object]]] = []
    with ThreadPoolExecutor(max_workers=worker_count) as executor:
        futures = {
            executor.submit(
                _capture_single_account_checkpoint,
                account,
                folder_scope,
            ): account
            for account in original_accounts
        }
        completed_accounts = 0
        for future in as_completed(futures):
            account = futures[future]
            results.append((account, future.result()))
            completed_accounts += 1
            log(
                f"[CHECKV2] Point de contrôle IMAP : "
                f"{completed_accounts}/{len(original_accounts)} terminé(s) "
                f"({account['email']})."
            )

    errors: list[str] = []
    auth_failed = False
    for account, result in results:
        if result["status"] == "auth_error":
            _discard_authenticated_account(accounts, account, account_file, stats, log)
            auth_failed = True
        elif result["status"] != "ok":
            errors.append(
                f"{account['provider']}|{account['email']} : {result['error']}"
            )
        else:
            checkpoints[_account_key(account)] = result["checkpoints"]

    if auth_failed:
        raise BatchScanError(
            "authentification IMAP perdue pendant le point de contrôle du lot"
        )
    if errors:
        raise BatchScanError(errors[0])

    if not accounts:
        raise BatchScanError("aucun compte IMAP authentifié restant pour valider le lot")
    return checkpoints


def _recent_bounced_recipients(
    imap: imaplib.IMAP4_SSL,
    folders: list[str],
    recipients: list[str],
    recent_limit: int,
    checkpoints: dict[str, set[bytes]],
) -> set[str]:
    """Cherche les NDR dans les N derniers messages et ceux reçus depuis le lot."""
    import email as email_parser

    if not folders:
        raise BatchScanError("aucun dossier IMAP disponible pour la seconde analyse")

    bounced: set[str] = set()
    for folder in folders:
        try:
            if imap.select(folder)[0] != "OK":
                raise BatchScanError(f"sélection IMAP impossible ({folder})")
            status, messages = imap.uid("search", None, "ALL")
            if status != "OK" or not messages:
                raise BatchScanError(f"lecture IMAP impossible ({folder})")
            if not messages[0]:
                continue
            message_ids = messages[0].split()
            new_message_ids = [
                message_id
                for message_id in message_ids
                if message_id not in checkpoints.get(folder, set())
            ]
            ids_to_scan = list(
                dict.fromkeys(message_ids[-recent_limit:] + new_message_ids)
            )
            ndr_ids: list[bytes] = []
            for message_id in ids_to_scan:
                status, data = imap.uid("fetch", message_id, "(RFC822)")
                if status != "OK" or not data or not data[0]:
                    raise BatchScanError(
                        f"lecture du message IMAP impossible ({folder})"
                    )
                message = email_parser.message_from_bytes(data[0][1])
                if not _message_is_bounce(message):
                    continue
                body = _message_body(message)
                for recipient in recipients:
                    if _bounce_mentions_address(body, recipient):
                        bounced.add(recipient.lower())
                        ndr_ids.append(message_id)
            _delete_message_ids(imap, list(dict.fromkeys(ndr_ids)), folder)
        except Exception as error:
            raise BatchScanError(f"lecture IMAP impossible ({folder}) : {error}") from error
    return bounced


def _scan_single_account_bounces(
    account: dict[str, object],
    recipients: list[str],
    recent_limit: int,
    account_checkpoints: dict[str, set[bytes]],
    folder_scope: str,
) -> dict[str, object]:
    """Analyse les NDR récents d'un compte sur une connexion dédiée."""
    imap = None
    try:
        imap = _connect_imap(account)
        _login_imap(imap, account)
        folders = _folders_for_scope(imap, folder_scope)
        bounced = _recent_bounced_recipients(
            imap,
            folders,
            recipients,
            recent_limit,
            account_checkpoints,
        )
        return {"status": "ok", "bounced": bounced, "error": ""}
    except AccountAuthenticationError as error:
        return {"status": "auth_error", "bounced": set(), "error": str(error)}
    except BatchScanError as error:
        return {"status": "error", "bounced": set(), "error": str(error)}
    except Exception as error:
        return {"status": "error", "bounced": set(), "error": str(error)}
    finally:
        if imap:
            try:
                imap.logout()
            except Exception:
                pass


def _scan_batch_bounces(
    accounts: list[dict[str, object]],
    account_file: str,
    recipients: list[str],
    recent_limit: int,
    checkpoints: dict[str, dict[str, set[bytes]]],
    stats: dict[str, int],
    log: Callable[[str], None],
    folder_scope: str = "INBOX",
    max_concurrent_accounts: int | None = None,
) -> set[str]:
    """Analyse les NDR récents de chaque compte encore authentifié."""
    bounced: set[str] = set()
    original_accounts = list(accounts)
    worker_limit = (
        max_concurrent_accounts
        if max_concurrent_accounts is not None
        else _ACTIVE_BATCH_IMAP_WORKERS or MAX_BATCH_IMAP_WORKERS
    )
    worker_count = max(1, min(worker_limit, len(original_accounts)))
    log(
        f"[CHECKV2] Seconde analyse IMAP en parallèle : "
        f"{len(original_accounts)} compte(s), {worker_count} worker(s)."
    )
    results: list[tuple[dict[str, object], dict[str, object]]] = []
    with ThreadPoolExecutor(max_workers=worker_count) as executor:
        futures = {
            executor.submit(
                _scan_single_account_bounces,
                account,
                recipients,
                recent_limit,
                checkpoints.get(_account_key(account), {}),
                folder_scope,
            ): account
            for account in original_accounts
        }
        completed_accounts = 0
        for future in as_completed(futures):
            account = futures[future]
            results.append((account, future.result()))
            completed_accounts += 1
            log(
                f"[CHECKV2] Seconde analyse IMAP : "
                f"{completed_accounts}/{len(original_accounts)} terminé(s) "
                f"({account['email']})."
            )

    errors: list[str] = []
    auth_failed = False
    for account, result in results:
        if result["status"] == "auth_error":
            _discard_authenticated_account(accounts, account, account_file, stats, log)
            auth_failed = True
        elif result["status"] != "ok":
            errors.append(
                f"{account['provider']}|{account['email']} : {result['error']}"
            )
        else:
            bounced.update(result["bounced"])

    if auth_failed:
        raise BatchScanError(
            "authentification IMAP perdue pendant la seconde analyse du lot"
        )
    if errors:
        raise BatchScanError(errors[0])

    if not accounts:
        raise BatchScanError("aucun compte IMAP authentifié restant pour valider le lot")
    return bounced


def _run_single_probe(
    account: dict[str, object],
    recipient: str,
    adaptive_wait: float,
    poll_interval: int,
    folder_scope: str,
    is_stopped: Callable[[], bool],
) -> dict[str, object]:
    """Exécute un contrôle isolé, avec une connexion dédiée à ce compte."""
    smtp = None
    imap = None
    sent_checkpoints: dict[str, set[bytes]] = {}
    result: dict[str, object] = {
        "account": account,
        "recipient": recipient,
        "status": "error",
        "elapsed": 0.0,
        "error": "",
    }
    try:
        smtp = _connect_smtp(account)
        try:
            smtp.login(str(account["email"]), str(account["password"]))
        except smtplib.SMTPAuthenticationError as error:
            raise AccountAuthenticationError(
                f"SMTP {account['provider']} : authentification refusée"
            ) from error

        imap = _connect_imap(account)
        try:
            imap.login(str(account["email"]), str(account["password"]))
        except imaplib.IMAP4.error as error:
            raise AccountAuthenticationError(
                f"IMAP {account['provider']} : authentification refusée"
            ) from error

        all_folders = _folders(imap)
        folders = _folders_for_scope(imap, folder_scope)
        probe_checkpoints = _capture_probe_checkpoints(imap, folders)
        sent_checkpoints = _capture_sent_checkpoints(imap, all_folders)

        control_subject = Header(CONTROL_SUBJECT, "utf-8").encode()
        smtp.sendmail(
            str(account["email"]),
            recipient,
            (
                f"From: {account['email']}\r\n"
                f"To: {recipient}\r\n"
                f"Subject: {control_subject}\r\n"
                "Content-Type: text/plain; charset=utf-8\r\n"
                "\r\n"
                ".\r\n"
            ).encode("utf-8"),
        )

        bounce_started_at = time.monotonic()
        while time.monotonic() - bounce_started_at < adaptive_wait:
            if is_stopped():
                result["status"] = "stopped"
                return result
            remaining = adaptive_wait - (time.monotonic() - bounce_started_at)
            time.sleep(min(poll_interval, max(0.1, remaining)))
            if _has_bounce(imap, folders, recipient, probe_checkpoints):
                result["status"] = "bounce"
                result["elapsed"] = max(
                    1.0, time.monotonic() - bounce_started_at
                )
                return result

        result["status"] = "candidate"
        return result
    except AccountAuthenticationError as error:
        result["status"] = "auth_error"
        result["error"] = str(error)
        return result
    except Exception as error:
        result["status"] = "error"
        result["error"] = str(error)
        return result
    finally:
        if imap:
            if sent_checkpoints:
                try:
                    _delete_sent_control_messages(
                        imap,
                        sent_checkpoints,
                        recipient,
                    )
                except Exception as error:
                    result["sent_cleanup_error"] = str(error)
            try:
                imap.logout()
            except Exception:
                pass
        if smtp:
            try:
                smtp.quit()
            except Exception:
                pass


def _wait_for_batch_window(
    duration: int,
    is_stopped: Callable[[], bool],
) -> bool:
    """Attend la fenêtre finale tout en restant arrêt-able."""
    deadline = time.monotonic() + duration
    while True:
        if is_stopped():
            return False
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            return True
        time.sleep(min(1.0, remaining))


def run_checkv2(
    emails: list[str],
    config: dict[str, object],
    deliver_validated: Callable[[str], tuple[bool, str]],
    log: Callable[[str], None],
    is_stopped: Callable[[], bool],
) -> dict[str, int]:
    """Contrôle les adresses puis envoie les lots qui passent le second scan NDR."""

    global _ACTIVE_BATCH_IMAP_WORKERS
    account_file = str(Path(__file__).resolve().parent / "imap.txt")
    good_file = str(config.get("GOOD_FILE", "good.txt"))
    bad_file = str(config.get("BAD_FILE", "bad.txt"))
    initial_wait = max(1, int(config.get("CHECKV2_INITIAL_WAIT", 60)))
    poll_interval = max(1, int(config.get("CHECKV2_POLL_INTERVAL", 3)))
    batch_size = max(1, int(config.get("CHECKV2_BATCH_SIZE", 20)))
    batch_wait = max(1, int(config.get("CHECKV2_BATCH_WAIT", 20)))
    recent_ndr_limit = max(1, int(config.get("CHECKV2_RECENT_NDR_LIMIT", 10)))
    max_concurrent_accounts = max(
        1, int(config.get("CHECKV2_MAX_CONCURRENT_ACCOUNTS", 20))
    )
    folder_scope = str(config.get("CHECKV2_MAILBOX_SCOPE", "INBOX")).strip().upper()
    if folder_scope not in {"INBOX", "ALL"}:
        raise RuntimeError(
            f"CHECKV2_MAILBOX_SCOPE invalide ({folder_scope}); utilisez INBOX ou ALL."
        )
    adaptive_floor = max(
        1.0, float(config.get("CHECKV2_MIN_ADAPTIVE_WAIT", 10))
    )
    accounts, account_source = _load_runtime_accounts(account_file)
    delivery_label = (
        "SMTP AUTH"
        if config.get("USE_AUTH_MODE", False)
        else "Resend"
    )

    stats = {
        "checked": 0,
        "valid": 0,
        "bounce": 0,
        "error": 0,
        "sent": 0,
        "auth_failed": 0,
        "candidates": 0,
        "batch_rejected": 0,
    }
    pending: list[str] = []
    batch_halted = False

    log("╔══════════════════════════════════════════════════════════════╗")
    log("║                    CHECKV2 — SMTP / IMAP                    ║")
    log("╚══════════════════════════════════════════════════════════════╝")
    log(f"[CHECKV2] {len(emails)} adresse(s) à traiter avec {len(accounts)} compte(s).")
    log(f"[CHECKV2] Source des comptes : {account_source}.")
    log(
        f"[CHECKV2] Délai initial : {initial_wait}s | sondage : {poll_interval}s "
        f" | délai adaptatif activé (minimum {adaptive_floor:.0f}s après un bounce)."
    )
    log(
        f"[CHECKV2] Envoi par lots : {batch_size} candidate(s), attente finale "
        f"{batch_wait}s, analyse des {recent_ndr_limit} derniers messages IMAP."
    )
    log(
        f"[CHECKV2] Dossiers contrôlés : "
        f"{'INBOX uniquement' if folder_scope == 'INBOX' else 'tous les dossiers'}."
    )
    log(
        "[CHECKV2] Nettoyage demandé : "
        f"{'INBOX uniquement' if folder_scope == 'INBOX' else 'INBOX et dossiers Spam'} "
        "avant le contrôle."
    )
    log(
        f"[CHECKV2] Contrôles simultanés : jusqu'à "
        f"{max_concurrent_accounts} compte(s) par vague."
    )
    log(
        f"[CHECKV2] Nettoyage initial parallèle : jusqu'à "
        f"{max_concurrent_accounts} compte(s) en même temps."
    )
    _prepare_accounts(
        accounts,
        account_file,
        stats,
        log,
        folder_scope,
        max_concurrent_accounts,
    )
    if not accounts:
        stats["error"] += len(emails)
        log("[CHECKV2] Aucun compte disponible après le nettoyage, aucun envoi effectué.")
        return stats
    log(f"[CHECKV2] {len(accounts)} compte(s) disponible(s) après nettoyage.")

    def flush_pending_batch() -> bool:
        if not pending:
            return True
        batch = pending[:batch_size]
        log(
            f"\n[CHECKV2] Lot de {len(batch)} candidate(s) prêt. "
            "Création du point de contrôle IMAP."
        )
        try:
            global _ACTIVE_BATCH_IMAP_WORKERS
            previous_batch_workers = _ACTIVE_BATCH_IMAP_WORKERS
            _ACTIVE_BATCH_IMAP_WORKERS = max_concurrent_accounts
            checkpoints = _capture_batch_checkpoints(
                accounts,
                account_file,
                stats,
                log,
                folder_scope,
            )
        except BatchScanError as error:
            stats["error"] += len(batch)
            log(f"[CHECKV2] ⚠ Lot non envoyé : point de contrôle IMAP impossible ({error}).")
            return False
        finally:
            _ACTIVE_BATCH_IMAP_WORKERS = previous_batch_workers

        log(f"[CHECKV2] Point de contrôle terminé. Attente de sécurité : {batch_wait}s.")
        if not _wait_for_batch_window(batch_wait, is_stopped):
            log("[CHECKV2] Lot conservé sans envoi : arrêt demandé pendant l'attente.")
            return False

        log("[CHECKV2] Attente terminée. Lancement de la seconde analyse IMAP.")
        try:
            previous_batch_workers = _ACTIVE_BATCH_IMAP_WORKERS
            _ACTIVE_BATCH_IMAP_WORKERS = max_concurrent_accounts
            bounced = _scan_batch_bounces(
                accounts,
                account_file,
                batch,
                recent_ndr_limit,
                checkpoints,
                stats,
                log,
                folder_scope,
            )
        except BatchScanError as error:
            stats["error"] += len(batch)
            log(f"[CHECKV2] ⚠ Lot non envoyé : seconde vérification impossible ({error}).")
            return False
        finally:
            _ACTIVE_BATCH_IMAP_WORKERS = previous_batch_workers

        log(
            f"[CHECKV2] Seconde analyse terminée : {len(bounced)} bounce(s) "
            f"trouvé(s) dans le lot."
        )
        for recipient in batch:
            if recipient.lower() in bounced:
                _append_address(bad_file, recipient)
                stats["bounce"] += 1
                stats["batch_rejected"] += 1
                log(f"[CHECKV2] ✗ BOUNCE tardif : {recipient} → {bad_file}")
                continue

            _append_address(good_file, recipient)
            stats["valid"] += 1
            log(f"[CHECKV2] ✓ VALIDÉ APRÈS LOT : {recipient} → {good_file}")
            if config.get("CHECKV2_DRY_RUN", False):
                success, detail = True, "enregistrement uniquement — aucun envoi final"
            else:
                try:
                    success, detail = deliver_validated(recipient)
                except Exception as error:
                    success, detail = False, str(error)
            if success:
                stats["sent"] += 1
                log(
                    f"[CHECKV2] → {delivery_label} livré après lot : "
                    f"{recipient} ({detail})"
                )
            else:
                stats["error"] += 1
                log(
                    f"[CHECKV2] ✗ Échec {delivery_label} pour "
                    f"{recipient} : {detail}"
                )
        del pending[: len(batch)]
        return True

    adaptive_waits = {
        _account_key(account): float(initial_wait)
        for account in accounts
    }
    position = 0
    account_cursor = 0
    stop_requested = False
    while position < len(emails) and accounts and not batch_halted:
        if is_stopped():
            log("[CHECKV2] Arrêt demandé, vérification interrompue.")
            break

        wave_size = min(
            max_concurrent_accounts,
            len(accounts),
            len(emails) - position,
        )
        account_cursor %= len(accounts)
        wave_accounts = [
            accounts[(account_cursor + offset) % len(accounts)]
            for offset in range(wave_size)
        ]
        next_account_key = _account_key(
            accounts[(account_cursor + wave_size) % len(accounts)]
        )
        wave_recipients = emails[position : position + wave_size]
        wave_start = position
        position += wave_size
        log(
            f"\n[CHECKV2] Vague parallèle : {len(wave_recipients)} contrôle(s) "
            f"avec {len(wave_accounts)} compte(s) distinct(s)."
        )

        futures = []
        with ThreadPoolExecutor(max_workers=wave_size) as executor:
            for offset, (recipient, account) in enumerate(
                zip(wave_recipients, wave_accounts),
                start=1,
            ):
                stats["checked"] += 1
                account_key = _account_key(account)
                wait_for_account = adaptive_waits.get(
                    account_key,
                    float(initial_wait),
                )
                log(
                    f"[CHECKV2] [{wave_start + offset}/{len(emails)}] "
                    f"Test de {recipient} via {account['email']} — "
                    f"Fenêtre d'attente utilisée : {wait_for_account:.1f}s."
                )
                futures.append(
                    executor.submit(
                        _run_single_probe,
                        account,
                        recipient,
                        wait_for_account,
                        poll_interval,
                        folder_scope,
                        is_stopped,
                    )
                )
            results = [future.result() for future in futures]

        for recipient, account, result in zip(
            wave_recipients,
            wave_accounts,
            results,
        ):
            status = result["status"]
            account_key = _account_key(account)
            sent_cleanup_error = result.get("sent_cleanup_error")
            if sent_cleanup_error:
                log(
                    f"[CHECKV2] ⚠ Copie Envoyés non supprimée pour {recipient} "
                    f"({sent_cleanup_error})."
                )

            if status == "auth_error":
                _discard_authenticated_account(accounts, account, account_file, stats, log)
                stats["error"] += 1
                log(
                    f"[CHECKV2] ✗ Authentification refusée pour {recipient} : "
                    f"{result['error']}"
                )
                continue

            if status == "stopped":
                stop_requested = True
                continue

            if status == "bounce":
                bounce_elapsed = float(result["elapsed"])
                adaptive_waits[account_key] = max(adaptive_floor, bounce_elapsed)
                _append_address(bad_file, recipient)
                stats["bounce"] += 1
                log(
                    f"[CHECKV2] ✗ BOUNCE détecté en {bounce_elapsed:.1f}s : "
                    f"{recipient} → {bad_file}"
                )
                log(
                    f"[CHECKV2] Prochaine fenêtre pour {account['email']} : "
                    f"{adaptive_waits[account_key]:.1f}s."
                )
                continue

            if status == "candidate":
                pending.append(recipient)
                stats["candidates"] += 1
                log(
                    f"[CHECKV2] ✓ CANDIDAT : {recipient} "
                    f"(en attente du lot {len(pending)}/{batch_size})."
                )
                if len(pending) >= batch_size and not batch_halted:
                    if not flush_pending_batch():
                        batch_halted = True
                continue

            stats["error"] += 1
            log(
                f"[CHECKV2] ⚠ Contrôle impossible pour {recipient}, "
                f"adresse conservée hors de bad.txt : {result['error']}"
            )

        if stop_requested:
            log("[CHECKV2] Arrêt demandé pendant la vague, aucun nouveau contrôle.")
            break
        if not accounts:
            log("[CHECKV2] Aucun compte authentifié restant, arrêt du contrôle.")
            break
        next_account = next(
            (
                index
                for index, account in enumerate(accounts)
                if _account_key(account) == next_account_key
            ),
            None,
        )
        account_cursor = (
            next_account if next_account is not None else account_cursor % len(accounts)
        )

        while len(pending) >= batch_size and not batch_halted:
            if not flush_pending_batch():
                batch_halted = True
                break

    if pending and not is_stopped() and not batch_halted:
        log(f"\n[CHECKV2] Dernier lot partiel : {len(pending)} candidate(s).")
        if not flush_pending_batch():
            batch_halted = True

    if stats["sent"] > 0 and not is_stopped() and not batch_halted:
        previous_batch_workers = _ACTIVE_BATCH_IMAP_WORKERS
        _ACTIVE_BATCH_IMAP_WORKERS = max_concurrent_accounts
        try:
            _final_cleanup_bounces(accounts, account_file, stats, log)
        finally:
            _ACTIVE_BATCH_IMAP_WORKERS = previous_batch_workers

    if config.get("CHECKV2_DRY_RUN", False):
        delivery_summary = f"{stats['sent']} enregistrées sans envoi final"
    else:
        delivery_summary = (
            f"{stats['sent']} livrées via {delivery_label}"
        )
    log(
        "\n[CHECKV2] Terminé — "
        f"{stats['checked']} contrôlées, {stats['valid']} validées, "
        f"{stats['bounce']} bounces, {delivery_summary}, "
        f"{stats['batch_rejected']} bounce(s) tardif(s), "
        f"{stats['auth_failed']} compte(s) ignoré(s) pour authentification."
    )
    return stats